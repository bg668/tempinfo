#!/usr/bin/env bash
set -Eeuo pipefail

# Runs INSIDE ubuntu:22.04.
# All downloaded artifacts and the final tar.gz are written under /work,
# which is the directory mounted from the CentOS host.

APISIX_VERSION="${APISIX_VERSION:-3.18.0}"
APISIX_IMAGE="${APISIX_IMAGE:-apache/apisix:${APISIX_VERSION}-ubuntu}"
ETCD_VERSION="${ETCD_VERSION:-3.5.33}"
MONGO_MAJOR="${MONGO_MAJOR:-8.0}"

WORKDIR="/work"
STAMP="$(date +%Y%m%d)"
BUNDLE_NAME="offline-stack-ubuntu22.04-amd64-${STAMP}"
STAGE="${WORKDIR}/.offline-bundle-stage"
BUNDLE="${STAGE}/${BUNDLE_NAME}"
OUTPUT="${WORKDIR}/${BUNDLE_NAME}.tar.gz"

log() { printf '\n==> %s\n' "$*"; }
die() { echo "[ERROR] $*" >&2; exit 1; }

cleanup() {
    rm -rf "$STAGE"
}
trap cleanup EXIT

source /etc/os-release
[[ "${ID:-}" == "ubuntu" && "${VERSION_ID:-}" == "22.04" ]] \
    || die "Builder must be Ubuntu 22.04."
[[ "$(dpkg --print-architecture)" == "amd64" ]] \
    || die "Builder must be amd64."
[[ -S /var/run/docker.sock ]] \
    || die "Docker socket was not mounted into the builder."

log "Installing builder-only tools"
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends \
    ca-certificates \
    curl \
    gnupg \
    apt-transport-https \
    docker.io \
    tar \
    gzip

# We only need Docker CLI. The daemon remains on the CentOS host.
docker version >/dev/null 2>&1 \
    || die "Docker CLI cannot talk to the CentOS host daemon through /var/run/docker.sock."

rm -rf "$STAGE"
mkdir -p \
    "$BUNDLE/deb/temurin" \
    "$BUNDLE/deb/mongodb" \
    "$BUNDLE/deb/minio" \
    "$BUNDLE/binary/etcd" \
    "$BUNDLE/images"

cp "$WORKDIR/install_offline.sh" "$BUNDLE/install_offline.sh"
chmod +x "$BUNDLE/install_offline.sh"

# ---------------------------------------------------------------------------
# Helper: ask APT to resolve a package's dependencies, but download ONLY
# artifacts coming from the named external repository.
# Ubuntu dependencies are intentionally not bundled because the target server
# can reach its internal Ubuntu 22.04 APT mirror.
# ---------------------------------------------------------------------------
download_external_apt_set() {
    local package="$1"
    local domain="$2"
    local dest="$3"
    local plan="${STAGE}/${package}.uris"

    mkdir -p "$dest"

    apt-get \
        --print-uris \
        --yes \
        --download-only \
        --no-install-recommends \
        install "$package" >"$plan"

    local count=0
    while IFS= read -r line; do
        [[ "$line" == \'http* ]] || continue

        local uri filename
        uri="$(sed -n "s/^'\([^']*\)'.*/\1/p" <<<"$line")"
        filename="$(sed -n "s/^'[^']*' \([^ ]*\) .*/\1/p" <<<"$line")"

        [[ -n "$uri" && -n "$filename" ]] || continue
        [[ "$uri" == *"$domain"* ]] || continue

        log "Downloading ${filename}"
        curl -fL --retry 4 --retry-delay 2 \
            "$uri" \
            -o "$dest/$filename"
        count=$((count + 1))
    done <"$plan"

    (( count > 0 )) \
        || die "APT resolved no packages from ${domain} for ${package}."

    # Verify that every downloaded file is a readable Debian package.
    find "$dest" -maxdepth 1 -type f -name '*.deb' -print0 \
        | while IFS= read -r -d '' deb; do
            dpkg-deb --info "$deb" >/dev/null
          done
}

# ---------------------------------------------------------------------------
# Temurin 17
# ---------------------------------------------------------------------------
log "Configuring Eclipse Adoptium APT repository"
curl -fsSL https://packages.adoptium.net/artifactory/api/gpg/key/public \
    | gpg --dearmor \
    -o /usr/share/keyrings/adoptium.gpg

cat >/etc/apt/sources.list.d/adoptium.list <<'EOF'
deb [arch=amd64 signed-by=/usr/share/keyrings/adoptium.gpg] https://packages.adoptium.net/artifactory/deb jammy main
EOF

# ---------------------------------------------------------------------------
# MongoDB 8.0
# ---------------------------------------------------------------------------
log "Configuring MongoDB ${MONGO_MAJOR} APT repository"
curl -fsSL "https://pgp.mongodb.com/server-${MONGO_MAJOR}.asc" \
    | gpg --dearmor \
    -o "/usr/share/keyrings/mongodb-server-${MONGO_MAJOR}.gpg"

cat >"/etc/apt/sources.list.d/mongodb-org-${MONGO_MAJOR}.list" <<EOF
deb [arch=amd64 signed-by=/usr/share/keyrings/mongodb-server-${MONGO_MAJOR}.gpg] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/${MONGO_MAJOR} multiverse
EOF

apt-get update

TEMURIN_VERSION="$(apt-cache policy temurin-17-jdk | awk '/Candidate:/ {print $2}')"
MONGO_VERSION="$(apt-cache policy mongodb-org | awk '/Candidate:/ {print $2}')"

[[ -n "$TEMURIN_VERSION" && "$TEMURIN_VERSION" != "(none)" ]] \
    || die "Cannot resolve temurin-17-jdk."
[[ -n "$MONGO_VERSION" && "$MONGO_VERSION" != "(none)" ]] \
    || die "Cannot resolve mongodb-org."

log "Resolving and downloading Temurin 17 external DEBs"
download_external_apt_set \
    "temurin-17-jdk=${TEMURIN_VERSION}" \
    "packages.adoptium.net" \
    "$BUNDLE/deb/temurin"

log "Resolving and downloading MongoDB ${MONGO_MAJOR} external DEBs"
download_external_apt_set \
    "mongodb-org=${MONGO_VERSION}" \
    "repo.mongodb.org" \
    "$BUNDLE/deb/mongodb"

# ---------------------------------------------------------------------------
# MinIO
# ---------------------------------------------------------------------------
log "Downloading MinIO stable amd64 DEB"
MINIO_DEB="$BUNDLE/deb/minio/minio.deb"
curl -fL --retry 4 --retry-delay 2 \
    "https://dl.min.io/server/minio/release/linux-amd64/minio.deb" \
    -o "$MINIO_DEB"

dpkg-deb --info "$MINIO_DEB" >/dev/null
MINIO_VERSION="$(dpkg-deb -f "$MINIO_DEB" Version)"

# ---------------------------------------------------------------------------
# etcd
# ---------------------------------------------------------------------------
log "Downloading etcd v${ETCD_VERSION} amd64 binary"
ETCD_FILE="etcd-v${ETCD_VERSION}-linux-amd64.tar.gz"
curl -fL --retry 4 --retry-delay 2 \
    "https://github.com/etcd-io/etcd/releases/download/v${ETCD_VERSION}/${ETCD_FILE}" \
    -o "$BUNDLE/binary/etcd/$ETCD_FILE"

tar -tzf "$BUNDLE/binary/etcd/$ETCD_FILE" >/dev/null

# ---------------------------------------------------------------------------
# APISIX
# ---------------------------------------------------------------------------
log "Pulling APISIX image through the CentOS host Docker daemon"
docker pull "$APISIX_IMAGE"

APISIX_ARCH="$(docker image inspect --format '{{.Architecture}}' "$APISIX_IMAGE")"
[[ "$APISIX_ARCH" == "amd64" ]] \
    || die "APISIX image architecture is ${APISIX_ARCH}, expected amd64."

APISIX_IMAGE_FILE="apisix-${APISIX_VERSION}-ubuntu-amd64.tar"
docker save "$APISIX_IMAGE" \
    -o "$BUNDLE/images/$APISIX_IMAGE_FILE"

# ---------------------------------------------------------------------------
# Manifest and checksums
# ---------------------------------------------------------------------------
cat >"$BUNDLE/manifest.env" <<EOF
BUNDLE_OS='ubuntu'
BUNDLE_OS_VERSION='22.04'
BUNDLE_ARCH='amd64'
TEMURIN_VERSION='${TEMURIN_VERSION}'
MONGO_MAJOR='${MONGO_MAJOR}'
MONGO_VERSION='${MONGO_VERSION}'
MINIO_VERSION='${MINIO_VERSION}'
ETCD_VERSION='${ETCD_VERSION}'
APISIX_VERSION='${APISIX_VERSION}'
APISIX_IMAGE='${APISIX_IMAGE}'
APISIX_IMAGE_FILE='${APISIX_IMAGE_FILE}'
EOF

cat >"$BUNDLE/versions.txt" <<EOF
Target OS       : Ubuntu 22.04 amd64
Temurin 17      : ${TEMURIN_VERSION}
MongoDB         : ${MONGO_VERSION}
MinIO           : ${MINIO_VERSION}
etcd            : ${ETCD_VERSION}
APISIX          : ${APISIX_VERSION}
APISIX image    : ${APISIX_IMAGE}
APISIX arch     : ${APISIX_ARCH}
EOF

cat >"$BUNDLE/README.txt" <<'EOF'
Offline software bundle for Ubuntu 22.04 amd64

The target server must be able to access an INTERNAL Ubuntu 22.04 APT mirror.

Bundled from external sources:
  - Eclipse Temurin JDK 17 DEB package(s)
  - MongoDB Community 8.0 DEB package(s)
  - MinIO DEB
  - etcd amd64 tar.gz binary
  - Apache APISIX Docker image

Installed from internal Ubuntu APT on the target:
  - nginx
  - mysql-server
  - redis-server
  - docker.io
  - normal Ubuntu runtime dependencies

Install on the offline Ubuntu 22.04 amd64 server:

  tar xf offline-stack-ubuntu22.04-amd64-YYYYMMDD.tar.gz
  cd offline-stack-ubuntu22.04-amd64-YYYYMMDD
  sudo ./install_offline.sh

The installer creates a single-node baseline. It does not configure HA clusters.
EOF

log "Generating bundle SHA256 checksums"
(
    cd "$BUNDLE"
    find . -type f ! -name SHA256SUMS -print0 \
        | sort -z \
        | xargs -0 sha256sum >SHA256SUMS
)

log "Creating final offline archive"
rm -f "$OUTPUT"
tar -C "$STAGE" -czf "$OUTPUT" "$BUNDLE_NAME"

# Make the output owned by the CentOS user who launched build_bundle.sh.
if [[ -n "${HOST_UID:-}" && -n "${HOST_GID:-}" ]]; then
    chown "${HOST_UID}:${HOST_GID}" "$OUTPUT" || true
fi

echo
echo "============================================================"
echo "Offline bundle created successfully"
echo "============================================================"
echo "File:"
echo "  $OUTPUT"
echo
cat "$BUNDLE/versions.txt"
