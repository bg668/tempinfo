#!/usr/bin/env bash
set -Eeuo pipefail

# CentOS 7 / x86_64 host entrypoint.
# It only starts a minimal Ubuntu 22.04 container and mounts this directory.
# The container performs all downloads and creates the final offline bundle.

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BUILDER_IMAGE="${BUILDER_IMAGE:-ubuntu:22.04}"
CONTAINER_NAME="offline-stack-builder"

log() { printf '\n==> %s\n' "$*"; }
die() { echo "[ERROR] $*" >&2; exit 1; }

[[ "$(uname -m)" == "x86_64" ]] || die "Only x86_64/amd64 is supported."

command -v docker >/dev/null 2>&1 || die "docker command not found."

if docker info >/dev/null 2>&1; then
    DOCKER=(docker)
elif command -v sudo >/dev/null 2>&1 && sudo docker info >/dev/null 2>&1; then
    DOCKER=(sudo docker)
else
    die "Cannot access Docker daemon. Start Docker or run this script with sufficient privileges."
fi

[[ -S /var/run/docker.sock ]] || die "/var/run/docker.sock not found."

log "Pulling Ubuntu 22.04 builder image"
"${DOCKER[@]}" pull "$BUILDER_IMAGE"

# If a previous interrupted run left a container with the same name, remove it.
"${DOCKER[@]}" rm -f "$CONTAINER_NAME" >/dev/null 2>&1 || true

log "Starting Ubuntu 22.04 builder container"
"${DOCKER[@]}" run --rm \
    --name "$CONTAINER_NAME" \
    -e HOST_UID="$(id -u)" \
    -e HOST_GID="$(id -g)" \
    -v "${SCRIPT_DIR}:/work:Z" \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -w /work \
    "$BUILDER_IMAGE" \
    bash /work/download_in_ubuntu.sh

log "Build finished"
ls -lh "${SCRIPT_DIR}"/offline-stack-ubuntu22.04-amd64-*.tar.gz 2>/dev/null \
    || die "No offline bundle was produced."
