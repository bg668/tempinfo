#!/usr/bin/env bash
set -Eeuo pipefail

# Runs on the OFFLINE Ubuntu 22.04 amd64 target.
# The target is expected to have access to an internal Ubuntu APT mirror.

if [[ "$(id -u)" -ne 0 ]]; then
    exec sudo -E bash "$0" "$@"
fi

BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CRED_FILE="/root/offline-stack-credentials.env"

log() { printf '\n==> %s\n' "$*"; }
die() { echo "[ERROR] $*" >&2; exit 1; }

source /etc/os-release
[[ "${ID:-}" == "ubuntu" && "${VERSION_ID:-}" == "22.04" ]] \
    || die "Target must be Ubuntu 22.04."
[[ "$(dpkg --print-architecture)" == "amd64" ]] \
    || die "Target must be amd64."

[[ -f "$BASE/manifest.env" ]] || die "manifest.env not found."
[[ -f "$BASE/SHA256SUMS" ]] || die "SHA256SUMS not found."

# shellcheck disable=SC1091
source "$BASE/manifest.env"

log "Verifying offline bundle"
(
    cd "$BASE"
    sha256sum -c SHA256SUMS
)

log "Installing Ubuntu packages from the internal APT mirror"
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y \
    ca-certificates \
    curl \
    nginx \
    mysql-server \
    redis-server \
    docker.io

log "Installing Temurin 17"
mapfile -t TEMURIN_DEBS < <(
    find "$BASE/deb/temurin" -maxdepth 1 -type f -name '*.deb' -print | sort
)
((${#TEMURIN_DEBS[@]} > 0)) || die "Temurin DEB not found."
apt-get install -y "${TEMURIN_DEBS[@]}"

log "Installing MongoDB"
mapfile -t MONGO_DEBS < <(
    find "$BASE/deb/mongodb" -maxdepth 1 -type f -name '*.deb' -print | sort
)
((${#MONGO_DEBS[@]} > 0)) || die "MongoDB DEBs not found."
apt-get install -y "${MONGO_DEBS[@]}"

log "Installing MinIO"
[[ -f "$BASE/deb/minio/minio.deb" ]] || die "MinIO DEB not found."
apt-get install -y "$BASE/deb/minio/minio.deb"

# ---------------------------------------------------------------------------
# etcd
# ---------------------------------------------------------------------------
log "Installing etcd ${ETCD_VERSION}"
ETCD_ARCHIVE="$BASE/binary/etcd/etcd-v${ETCD_VERSION}-linux-amd64.tar.gz"
[[ -f "$ETCD_ARCHIVE" ]] || die "etcd archive not found."

TMP_ETCD="$(mktemp -d)"
trap 'rm -rf "$TMP_ETCD"' EXIT

tar -xzf "$ETCD_ARCHIVE" -C "$TMP_ETCD"
ETCD_DIR="$TMP_ETCD/etcd-v${ETCD_VERSION}-linux-amd64"

install -m 0755 "$ETCD_DIR/etcd" /usr/local/bin/etcd
install -m 0755 "$ETCD_DIR/etcdctl" /usr/local/bin/etcdctl
[[ ! -f "$ETCD_DIR/etcdutl" ]] \
    || install -m 0755 "$ETCD_DIR/etcdutl" /usr/local/bin/etcdutl

getent group etcd >/dev/null || groupadd --system etcd
id etcd >/dev/null 2>&1 || \
    useradd --system \
        --gid etcd \
        --home-dir /var/lib/etcd \
        --shell /usr/sbin/nologin \
        etcd

install -d -o etcd -g etcd -m 0750 /var/lib/etcd

cat >/etc/systemd/system/etcd.service <<'EOF'
[Unit]
Description=etcd key-value store
After=network-online.target
Wants=network-online.target

[Service]
Type=notify
User=etcd
Group=etcd
ExecStart=/usr/local/bin/etcd \
  --name=default \
  --data-dir=/var/lib/etcd \
  --listen-client-urls=http://127.0.0.1:2379 \
  --advertise-client-urls=http://127.0.0.1:2379 \
  --listen-peer-urls=http://127.0.0.1:2380 \
  --initial-advertise-peer-urls=http://127.0.0.1:2380 \
  --initial-cluster=default=http://127.0.0.1:2380 \
  --initial-cluster-state=new
Restart=on-failure
RestartSec=5
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF

# ---------------------------------------------------------------------------
# Credentials
# ---------------------------------------------------------------------------
random_hex() {
    od -An -N"$1" -tx1 /dev/urandom | tr -d ' \n'
}

if [[ -f "$CRED_FILE" ]]; then
    # Reuse credentials if the installer is run again.
    # shellcheck disable=SC1090
    source "$CRED_FILE"
else
    MINIO_ROOT_USER="minioadmin"
    MINIO_ROOT_PASSWORD="$(random_hex 24)"
    APISIX_ADMIN_KEY="$(random_hex 32)"

    umask 077
    cat >"$CRED_FILE" <<EOF
MINIO_ROOT_USER='${MINIO_ROOT_USER}'
MINIO_ROOT_PASSWORD='${MINIO_ROOT_PASSWORD}'
APISIX_ADMIN_KEY='${APISIX_ADMIN_KEY}'
EOF
    chmod 0600 "$CRED_FILE"
fi

# ---------------------------------------------------------------------------
# MinIO
# ---------------------------------------------------------------------------
log "Configuring MinIO"
if ! id minio-user >/dev/null 2>&1; then
    getent group minio-user >/dev/null || groupadd --system minio-user
    useradd --system \
        --gid minio-user \
        --home-dir /var/lib/minio \
        --shell /usr/sbin/nologin \
        minio-user
fi

install -d -o minio-user -g minio-user -m 0750 /var/lib/minio

cat >/etc/default/minio <<EOF
MINIO_VOLUMES="/var/lib/minio"
MINIO_OPTS="--console-address :9001"
MINIO_ROOT_USER="${MINIO_ROOT_USER}"
MINIO_ROOT_PASSWORD="${MINIO_ROOT_PASSWORD}"
EOF
chmod 0600 /etc/default/minio

# ---------------------------------------------------------------------------
# APISIX
# ---------------------------------------------------------------------------
log "Loading APISIX Docker image"
systemctl enable --now docker
docker load -i "$BASE/images/$APISIX_IMAGE_FILE"
docker image inspect "$APISIX_IMAGE" >/dev/null

install -d -m 0750 /etc/apisix

cat >/etc/apisix/config.yaml <<EOF
apisix:
  node_listen: 9080
  enable_ipv6: false

deployment:
  role: traditional
  role_traditional:
    config_provider: etcd
  admin:
    allow_admin:
      - 127.0.0.1/32
    admin_key:
      - name: admin
        key: "${APISIX_ADMIN_KEY}"
        role: admin
  etcd:
    host:
      - "http://127.0.0.1:2379"
    prefix: "/apisix"
    timeout: 30
EOF

# The APISIX image runs as its own non-root user, so the bind-mounted
# config file itself must be readable. The parent directory remains root-only.
chmod 0644 /etc/apisix/config.yaml

cat >/etc/systemd/system/apisix.service <<EOF
[Unit]
Description=Apache APISIX container
Requires=docker.service etcd.service
After=docker.service etcd.service network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStartPre=-/usr/bin/docker rm -f apisix
ExecStart=/usr/bin/docker run --name apisix --network host \
  -v /etc/apisix/config.yaml:/usr/local/apisix/conf/config.yaml:ro \
  ${APISIX_IMAGE}
ExecStop=-/usr/bin/docker stop -t 20 apisix
ExecStopPost=-/usr/bin/docker rm -f apisix
Restart=always
RestartSec=5
TimeoutStartSec=0
TimeoutStopSec=30

[Install]
WantedBy=multi-user.target
EOF

# ---------------------------------------------------------------------------
# Start services
# ---------------------------------------------------------------------------
log "Starting services"
systemctl daemon-reload

systemctl enable --now nginx
systemctl enable --now mysql
systemctl enable --now redis-server
systemctl enable --now mongod
systemctl enable --now minio
systemctl enable --now etcd

ETCD_OK=0
for _ in $(seq 1 30); do
    if ETCDCTL_API=3 /usr/local/bin/etcdctl \
        --endpoints=http://127.0.0.1:2379 \
        endpoint health >/dev/null 2>&1; then
        ETCD_OK=1
        break
    fi
    sleep 1
done
[[ "$ETCD_OK" -eq 1 ]] || die "etcd did not become healthy."

systemctl enable --now apisix

APISIX_OK=0
for _ in $(seq 1 60); do
    if curl -fsS \
        -H "X-API-KEY: ${APISIX_ADMIN_KEY}" \
        "http://127.0.0.1:9180/apisix/admin/services/" \
        >/dev/null 2>&1; then
        APISIX_OK=1
        break
    fi
    sleep 1
done

echo
echo "============================================================"
echo "Installation completed"
echo "============================================================"
echo
echo "Versions:"
java -version 2>&1 | head -n 1 || true
nginx -v 2>&1 || true
mysql --version || true
redis-server --version || true
mongod --version 2>/dev/null | head -n 1 || true
minio --version 2>/dev/null | head -n 1 || true
etcd --version 2>/dev/null | head -n 1 || true
docker image inspect --format='APISIX image: {{join .RepoTags ", "}}' "$APISIX_IMAGE" || true

echo
echo "Services:"
for svc in nginx mysql redis-server mongod minio etcd apisix; do
    printf "  %-14s %s\n" "$svc" "$(systemctl is-active "$svc" 2>/dev/null || true)"
done

echo
echo "Credentials:"
echo "  ${CRED_FILE}"
echo
echo "Ports:"
echo "  nginx        80"
echo "  MySQL        3306"
echo "  Redis        6379"
echo "  MongoDB      27017"
echo "  MinIO        9000"
echo "  MinIO UI     9001"
echo "  etcd         127.0.0.1:2379"
echo "  APISIX       9080"
echo "  APISIX Admin 9180 (localhost only)"
echo

if [[ "$APISIX_OK" -eq 1 ]]; then
    echo "APISIX Admin API health check: OK"
else
    echo "WARNING: APISIX started but the Admin API health check failed."
    echo "Check: systemctl status apisix --no-pager"
    echo "Check: docker logs apisix"
fi
