CentOS 7 -> Ubuntu 22.04 offline bundle builder

Expected architecture:
  x86_64 / amd64

Usage on the Internet-connected CentOS 7 host:

  tar xf offline_bundle_builder_centos7.tar.gz
  cd offline_bundle_builder_centos7
  chmod +x *.sh
  ./build_bundle.sh

What build_bundle.sh does:
  1. Pulls ubuntu:22.04.
  2. Starts a temporary Ubuntu 22.04 container.
  3. Mounts this directory at /work.
  4. Mounts /var/run/docker.sock so the container can ask the host Docker
     daemon to pull/save the APISIX image.
  5. Runs download_in_ubuntu.sh inside Ubuntu.
  6. Writes one final archive into this directory.

Result:
  offline-stack-ubuntu22.04-amd64-YYYYMMDD.tar.gz

Copy ONLY that archive to the offline Ubuntu 22.04 amd64 server.

Install on the offline server:

  tar xf offline-stack-ubuntu22.04-amd64-YYYYMMDD.tar.gz
  cd offline-stack-ubuntu22.04-amd64-YYYYMMDD
  sudo ./install_offline.sh

The offline Ubuntu server is expected to reach an internal Ubuntu 22.04 APT
mirror. nginx, MySQL, Redis, Docker and normal Ubuntu dependencies are taken
from that internal mirror.

External artifacts bundled:
  Temurin JDK 17
  MongoDB Community 8.0
  MinIO
  etcd 3.5.33
  APISIX 3.18.0-ubuntu image

Notes for CentOS 7:
  - Docker must already be installed and running.
  - /var/run/docker.sock must exist.
  - The working directory is mounted with :Z for SELinux compatibility.
