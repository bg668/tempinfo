Container-only Ubuntu 22.04 offline bundle builder

CentOS 7 only starts the Ubuntu 22.04 container.
No docker.sock is mounted.

All downloads happen inside Ubuntu 22.04:
- Temurin JDK 17
- MongoDB Community
- MinIO
- etcd
- APISIX image

APISIX is downloaded by skopeo directly from the OCI registry and saved as a
Docker-compatible archive. The offline target installs it with docker load.

Usage on CentOS 7:

  tar xf offline_bundle_builder_container_only.tar.gz
  cd offline_bundle_builder_container_only
  chmod +x *.sh
  ./build_bundle.sh

Output:

  offline-stack-ubuntu22.04-amd64-YYYYMMDD.tar.gz

Copy only that archive to the offline Ubuntu 22.04 amd64 target.

Offline install:

  tar xf offline-stack-ubuntu22.04-amd64-YYYYMMDD.tar.gz
  cd offline-stack-ubuntu22.04-amd64-YYYYMMDD
  sudo ./install_offline.sh
