#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BUILDER_IMAGE="${BUILDER_IMAGE:-ubuntu:22.04}"

die() { echo "[ERROR] $*" >&2; exit 1; }

[[ "$(uname -m)" == "x86_64" ]] || die "Only x86_64/amd64 hosts are supported."
command -v docker >/dev/null 2>&1 || die "docker command not found."

if docker info >/dev/null 2>&1; then
    DOCKER=(docker)
elif command -v sudo >/dev/null 2>&1 && sudo docker info >/dev/null 2>&1; then
    DOCKER=(sudo docker)
else
    die "Cannot access the Docker daemon."
fi

echo "==> Starting Ubuntu 22.04 builder container"

"${DOCKER[@]}" run --rm     -e HOST_UID="$(id -u)"     -e HOST_GID="$(id -g)"     -v "${SCRIPT_DIR}:/work:Z"     -w /work     "$BUILDER_IMAGE"     bash /work/download_in_ubuntu.sh

echo
echo "==> Build finished"
ls -lh "${SCRIPT_DIR}"/offline-stack-ubuntu22.04-amd64-*.tar.gz     || die "No final offline archive was produced."
