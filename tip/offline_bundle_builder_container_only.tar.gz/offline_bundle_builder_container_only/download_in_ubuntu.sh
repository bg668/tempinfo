#!/usr/bin/env bash
set -Eeuo pipefail

APISIX_VERSION="${APISIX_VERSION:-3.18.0}"
APISIX_IMAGE="${APISIX_IMAGE:-apache/apisix:${APISIX_VERSION}-ubuntu}"
ETCD_VERSION="${ETCD_VERSION:-3.5.33}"
MONGO_MAJOR="${MONGO_MAJOR:-8.0}"

WORKDIR="/work"
STAMP="$(date +%Y%m%d)"
BUNDLE_NAME="offline-stack-ubuntu22.04-amd64-${STAMP}"
STAGE="${WORKDIR}/.offline-bundle-stage"
BUNDLE="${STAGE}/${BUNDLE_NAME}"
OUTPUT="${WORKDIR}/${BUNDLE_NAME}.tar.gz"

log() { printf '\n==> %s\n' "$*"; }
die() { echo "[ERROR] $*" >&2; exit 1; }
cleanup() { rm -rf "$STAGE"; }
trap cleanup EXIT

source /etc/os-release
[[ "${ID:-}" == "ubuntu" && "${VERSION_ID:-}" == "22.04" ]] || die "Builder must be Ubuntu 22.04."
[[ "$(dpkg --print-architecture)" == "amd64" ]] || die "Builder must be amd64."
[[ -f "$WORKDIR/install_offline.sh" ]] || die "install_offline.sh not found."

export DEBIAN_FRONTEND=noninteractive

log "Installing Ubuntu-side builder tools"
apt-get update
apt-get install -y --no-install-recommends     ca-certificates curl gnupg apt-transport-https tar gzip

if ! apt-get install -y --no-install-recommends skopeo; then
    log "Enabling universe repository for skopeo"
    apt-get install -y --no-install-recommends software-properties-common
    add-apt-repository -y universe
    apt-get update
    apt-get install -y --no-install-recommends skopeo
fi

rm -rf "$STAGE"
mkdir -p     "$BUNDLE/deb/temurin"     "$BUNDLE/deb/mongodb"     "$BUNDLE/deb/minio"     "$BUNDLE/binary/etcd"     "$BUNDLE/images"

cp "$WORKDIR/install_offline.sh" "$BUNDLE/install_offline.sh"
chmod +x "$BUNDLE/install_offline.sh"

download_external_apt_set() {
    local package="$1"
    local domain="$2"
    local dest="$3"
    local plan="${STAGE}/$(echo "$package" | tr '/:=' '____').uris"

    mkdir -p "$dest"

    apt-get         --print-uris         --yes         --download-only         --no-install-recommends         install "$package" >"$plan"

    local count=0
    while IFS= read -r line; do
        [[ "$line" == \'http* ]] || continue

        local uri filename
        uri="$(sed -n "s/^'\([^']*\)'.*/\1/p" <<<"$line")"
        filename="$(sed -n "s/^'[^']*' \([^ ]*\) .*/\1/p" <<<"$line")"

        [[ -n "$uri" && -n "$filename" ]] || continue
        [[ "$uri" == *"$domain"* ]] || continue

        log "Downloading ${filename}"
        curl -fL --retry 4 --retry-delay 2 "$uri" -o "$dest/$filename"
        count=$((count + 1))
    done <"$plan"

    (( count > 0 )) || die "No DEBs from ${domain} resolved for ${package}."

    while IFS= read -r -d '' deb; do
        dpkg-deb --info "$deb" >/dev/null
    done < <(find "$dest" -maxdepth 1 -type f -name '*.deb' -print0)
}

log "Configuring Eclipse Adoptium repository"
curl -fsSL https://packages.adoptium.net/artifactory/api/gpg/key/public     | gpg --dearmor -o /usr/share/keyrings/adoptium.gpg

cat >/etc/apt/sources.list.d/adoptium.list <<'EOF'
deb [arch=amd64 signed-by=/usr/share/keyrings/adoptium.gpg] https://packages.adoptium.net/artifactory/deb jammy main
EOF

log "Configuring MongoDB ${MONGO_MAJOR} repository"
curl -fsSL "https://pgp.mongodb.com/server-${MONGO_MAJOR}.asc"     | gpg --dearmor -o "/usr/share/keyrings/mongodb-server-${MONGO_MAJOR}.gpg"

cat >"/etc/apt/sources.list.d/mongodb-org-${MONGO_MAJOR}.list" <<EOF
deb [arch=amd64 signed-by=/usr/share/keyrings/mongodb-server-${MONGO_MAJOR}.gpg] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/${MONGO_MAJOR} multiverse
EOF

apt-get update

TEMURIN_VERSION="$(apt-cache policy temurin-17-jdk | awk '/Candidate:/ {print $2}')"
MONGO_VERSION="$(apt-cache policy mongodb-org | awk '/Candidate:/ {print $2}')"

[[ -n "$TEMURIN_VERSION" && "$TEMURIN_VERSION" != "(none)" ]] || die "Cannot resolve temurin-17-jdk."
[[ -n "$MONGO_VERSION" && "$MONGO_VERSION" != "(none)" ]] || die "Cannot resolve mongodb-org."

log "Downloading Temurin 17 vendor DEBs"
download_external_apt_set     "temurin-17-jdk=${TEMURIN_VERSION}"     "packages.adoptium.net"     "$BUNDLE/deb/temurin"

log "Downloading MongoDB ${MONGO_MAJOR} vendor DEBs"
download_external_apt_set     "mongodb-org=${MONGO_VERSION}"     "repo.mongodb.org"     "$BUNDLE/deb/mongodb"

log "Downloading MinIO amd64 DEB"
MINIO_DEB="$BUNDLE/deb/minio/minio.deb"
curl -fL --retry 4 --retry-delay 2     "https://dl.min.io/server/minio/release/linux-amd64/minio.deb"     -o "$MINIO_DEB"
dpkg-deb --info "$MINIO_DEB" >/dev/null
MINIO_VERSION="$(dpkg-deb -f "$MINIO_DEB" Version)"

log "Downloading etcd v${ETCD_VERSION} linux-amd64"
ETCD_FILE="etcd-v${ETCD_VERSION}-linux-amd64.tar.gz"
curl -fL --retry 4 --retry-delay 2     "https://github.com/etcd-io/etcd/releases/download/v${ETCD_VERSION}/${ETCD_FILE}"     -o "$BUNDLE/binary/etcd/$ETCD_FILE"
tar -tzf "$BUNDLE/binary/etcd/$ETCD_FILE" >/dev/null

log "Downloading APISIX ${APISIX_VERSION} image with skopeo"
APISIX_IMAGE_FILE="apisix-${APISIX_VERSION}-ubuntu-amd64.tar"
APISIX_IMAGE_PATH="$BUNDLE/images/$APISIX_IMAGE_FILE"

skopeo copy     --override-os linux     --override-arch amd64     "docker://${APISIX_IMAGE}"     "docker-archive:${APISIX_IMAGE_PATH}:${APISIX_IMAGE}"

[[ -s "$APISIX_IMAGE_PATH" ]] || die "APISIX archive was not created."

APISIX_DIGEST="$(
    skopeo inspect         --override-os linux         --override-arch amd64         --format '{{.Digest}}'         "docker://${APISIX_IMAGE}"
)"

cat >"$BUNDLE/manifest.env" <<EOF
BUNDLE_OS='ubuntu'
BUNDLE_OS_VERSION='22.04'
BUNDLE_ARCH='amd64'
TEMURIN_VERSION='${TEMURIN_VERSION}'
MONGO_MAJOR='${MONGO_MAJOR}'
MONGO_VERSION='${MONGO_VERSION}'
MINIO_VERSION='${MINIO_VERSION}'
ETCD_VERSION='${ETCD_VERSION}'
APISIX_VERSION='${APISIX_VERSION}'
APISIX_IMAGE='${APISIX_IMAGE}'
APISIX_IMAGE_FILE='${APISIX_IMAGE_FILE}'
APISIX_DIGEST='${APISIX_DIGEST}'
EOF

cat >"$BUNDLE/versions.txt" <<EOF
Target          : Ubuntu 22.04 amd64
Temurin 17      : ${TEMURIN_VERSION}
MongoDB         : ${MONGO_VERSION}
MinIO           : ${MINIO_VERSION}
etcd            : ${ETCD_VERSION}
APISIX          : ${APISIX_VERSION}
APISIX image    : ${APISIX_IMAGE}
APISIX digest   : ${APISIX_DIGEST}
EOF

cat >"$BUNDLE/README.txt" <<'EOF'
Target: Ubuntu 22.04 amd64

The offline target must be able to access an internal Ubuntu 22.04 APT mirror.

Bundled:
  Temurin JDK 17
  MongoDB Community
  MinIO
  etcd
  Apache APISIX Docker image

Installed from internal Ubuntu APT:
  nginx
  mysql-server
  redis-server
  docker.io
  ordinary Ubuntu dependencies

Install:
  tar xf offline-stack-ubuntu22.04-amd64-YYYYMMDD.tar.gz
  cd offline-stack-ubuntu22.04-amd64-YYYYMMDD
  sudo ./install_offline.sh
EOF

log "Generating SHA256SUMS"
(
    cd "$BUNDLE"
    find . -type f ! -name SHA256SUMS -print0         | sort -z         | xargs -0 sha256sum >SHA256SUMS
)

log "Creating final offline archive"
rm -f "$OUTPUT"
tar -C "$STAGE" -czf "$OUTPUT" "$BUNDLE_NAME"

if [[ -n "${HOST_UID:-}" && -n "${HOST_GID:-}" ]]; then
    chown "${HOST_UID}:${HOST_GID}" "$OUTPUT" || true
fi

echo
echo "============================================================"
echo "Offline bundle created successfully"
echo "============================================================"
echo "Output: $OUTPUT"
echo
cat "$BUNDLE/versions.txt"
