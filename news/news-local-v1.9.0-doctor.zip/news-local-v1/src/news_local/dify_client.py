"""Dify HTTP adapter. A POST is never retried without a known execution outcome."""

import json
import logging
import os
import socket
import time
from http.client import IncompleteRead
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener, urlopen

from .config import Settings
from .errors import NewsError, PendingRun, RemoteFailure
from .progress import DifyProgress, input_progress_meta

LOG = logging.getLogger(__name__)




def _http_error_text(exc: HTTPError) -> str:
    """Return a small operator-safe Dify error message without headers or credentials."""
    try:
        raw = exc.read(64 * 1024).decode("utf-8", errors="replace").strip()
    except Exception:
        return ""
    if not raw:
        return ""
    try:
        payload = json.loads(raw)
        if isinstance(payload, dict):
            for key in ("message", "error", "code"):
                value = payload.get(key)
                if isinstance(value, (str, int, float)):
                    return str(value)[:500]
    except json.JSONDecodeError:
        pass
    return raw[:500]

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def sse_events(response, deadline: float | None = None):
    """SSE allows comments, CRLF and multiple data lines in one event."""
    parts, size = [], 0
    while True:
        if deadline is not None and time.monotonic() > deadline:
            raise PendingRun("达到本地等待时限，请 resume 查询远程执行结果")
        line = response.readline(4 * 1024 * 1024 + 1)
        if len(line) > 4 * 1024 * 1024:
            raise RemoteFailure("Dify 单个事件过大")
        if not line:
            if parts:
                yield "\n".join(parts)
            return
        text = line.decode("utf-8").rstrip("\r\n")
        if not text:
            if parts:
                yield "\n".join(parts)
            parts, size = [], 0
        elif text.startswith("data:"):
            parts.append(text[5:].lstrip(" "))
            size += len(line)
            if size > 8 * 1024 * 1024:
                raise RemoteFailure("Dify 事件体过大")


class DifyClient:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.opener = build_opener(NoRedirect())

    def _request(self, path: str, body: dict | None = None):
        if not self.settings.api_key:
            raise NewsError("请通过配置指定的环境变量设置 Dify API Key")
        data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        request = Request(
            self.settings.api_base.rstrip("/") + path,
            data=data,
            headers={
                "Authorization": "Bearer " + self.settings.api_key,
                "Content-Type": "application/json",
            },
        )
        return self.opener.open(request, timeout=self.settings.io_timeout)

    def start(self, inputs: dict, on_execution_id) -> dict:
        try:
            meta = input_progress_meta(inputs)
            with (
                DifyProgress(counts=meta["counts"], items=meta["items"]) as progress,
                self._request(
                    "/workflows/run",
                    {"inputs": inputs, "response_mode": "streaming", "user": "news-local"},
                ) as response,
            ):
                for event_text in sse_events(
                    response, time.monotonic() + self.settings.run_timeout
                ):
                    if event_text == "[DONE]":
                        break
                    event = json.loads(event_text)
                    if not isinstance(event, dict):
                        raise PendingRun("Dify 事件结构异常，请查询原执行状态")
                    data = event.get("data") or {}
                    if not isinstance(data, dict):
                        raise PendingRun("Dify 事件数据异常，请查询原执行状态")
                    execution_id = event.get("workflow_run_id")
                    if event.get("event") in {"workflow_started", "workflow_finished"}:
                        execution_id = execution_id or data.get("id")
                    if execution_id:
                        on_execution_id(str(execution_id))
                    progress.event(event)
                    if event.get("event") == "workflow_finished":
                        return data
                    if event.get("event") == "error":
                        raise PendingRun("Dify 事件流报错，请查询原执行状态")
        except HTTPError as exc:
            detail = _http_error_text(exc)
            suffix = "｜" + detail if detail else ""
            if exc.code in {400, 401, 403, 404, 422}:
                raise RemoteFailure(f"Dify 拒绝请求，HTTP {exc.code}{suffix}") from exc
            raise PendingRun(f"Dify 返回 HTTP {exc.code}，执行状态待确认{suffix}") from exc
        except (
            IncompleteRead,
            URLError,
            TimeoutError,
            socket.timeout,
            ConnectionError,
            json.JSONDecodeError,
        ) as exc:
            raise PendingRun("连接中断或响应异常，执行状态待确认；不会自动重复提交") from exc
        raise PendingRun("事件流结束但没有收到最终结果")

    def detail(self, execution_id: str) -> dict:
        import uuid

        try:
            LOG.info("查询原 Dify 执行｜workflow_run_id=%s", execution_id)
            uuid.UUID(execution_id)
        except ValueError as exc:
            raise NewsError("Dify 执行 ID 格式无效") from exc
        try:
            with self._request("/workflows/run/" + execution_id) as response:
                payload = response.read(16 * 1024 * 1024 + 1)
            if len(payload) > 16 * 1024 * 1024:
                raise NewsError("Dify 执行详情过大")
            return json.loads(payload)
        except (HTTPError, URLError, TimeoutError, IncompleteRead, json.JSONDecodeError) as exc:
            raise PendingRun("暂时无法查询 Dify 执行详情") from exc

    def parameters(self) -> dict:
        with self._request("/parameters") as response:
            return json.load(response)

    def download(self, outputs: dict, variable: str, target: Path) -> None:
        LOG.info("下载结果文件｜%s → %s", variable, target.name)
        files = outputs.get(variable)
        if not isinstance(files, list) or len(files) != 1 or not isinstance(files[0], dict):
            raise NewsError(variable + " 必须返回一个文件")
        address = files[0].get("url") or files[0].get("remote_url")
        if not isinstance(address, str) or not address:
            raise NewsError(variable + " 没有可下载地址")
        origin = self.settings.file_base_url or self.settings.api_base
        # A file URL may be signed. Keep its query intact; never attach the app API key.
        if address.startswith("/"):
            address = urljoin(origin, address)
        elif self.settings.file_base_url:
            original = urlsplit(address)
            address = urljoin(
                origin, original.path + ("?" + original.query if original.query else "")
            )
        if urlsplit(address).scheme not in {"http", "https"}:
            raise NewsError("文件地址必须为 HTTP(S)")
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_suffix(target.suffix + ".part")
        try:
            with (
                urlopen(address, timeout=self.settings.io_timeout) as response,
                temporary.open("wb") as handle,
            ):
                size = 0
                while chunk := response.read(65536):
                    size += len(chunk)
                    if size > self.settings.max_download_bytes:
                        raise NewsError("导出文件超过配置的下载容量")
                    handle.write(chunk)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, target)
            LOG.debug("文件下载完成｜%s｜%s 字节", target.name, size)
        except (HTTPError, URLError, TimeoutError, IncompleteRead) as exc:
            raise NewsError("结果文件下载失败，请检查 Dify 文件地址或签名有效期") from exc
        finally:
            temporary.unlink(missing_ok=True)
