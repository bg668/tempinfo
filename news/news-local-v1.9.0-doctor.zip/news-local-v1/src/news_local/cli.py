"""Composition root and command-line entry point."""

import argparse
import json
import logging
from dataclasses import replace
from pathlib import Path

from .collector import Collector
from .continuous import ContinuousTrigger
from .config import Settings
from .diagnostics import diagnose
from .doctor import Doctor
from .dify_client import DifyClient
from .errors import NewsError
from .progress import configure
from .repository import Repository
from .service import Runner
from .session import SessionRunner
from .state import RunStore

LOG = logging.getLogger(__name__)


def log_option(parser):
    parser.add_argument(
        "--log-level",
        choices=("detailed", "key"),
        default=argparse.SUPPRESS,
        help="日志档位：key 进度视图（默认），detailed 追加节点细节；优先于 config.toml",
    )


def parser():
    root = argparse.ArgumentParser(description="本地资讯处理：SQLite → Dify → SQLite")
    root.add_argument("--config", type=Path, default=Path("config.toml"))
    log_option(root)
    commands = root.add_subparsers(dest="command", required=True)
    commands.add_parser("init", help="初始化结果表与反馈表，不修改采集表")
    doctor = commands.add_parser("doctor", help="部署/迁移自检：配置、Dify、数据库、目录与运行参数")
    doctor.add_argument(
        "--smoke",
        action="store_true",
        help="额外真实执行一条合成资讯，验证 Dify 模型/插件/文件导出；会产生一次远程工作流调用",
    )
    check = commands.add_parser("check", help="兼容旧检查命令；建议改用 doctor")
    check.add_argument("--remote", action="store_true", help="同时查询 Dify 发布应用参数")
    for name in ("plan", "run", "run-all"):
        sub = commands.add_parser(name)
        sub.add_argument("--force", action="store_true", help="显式重新处理，忽略成功记录")
        sub.add_argument("--limit", type=int, help="本批上限，1–50")
    forever = commands.add_parser("run-forever", help="单 Worker 常驻处理；自动恢复未结束 run 并持续扫描新增数据")
    forever.add_argument("--interval", type=float, default=30.0, help="空闲/轮次间检查间隔秒数，最小 1 秒")
    forever.add_argument("--limit", type=int, help="每批上限，1–50")
    for name in ("resume", "ingest", "status", "abandon"):
        sub = commands.add_parser(name)
        sub.add_argument("run_id")
        if name == "resume":
            sub.add_argument("--workflow-run-id", default="", help="仅在自动关联丢失时手动绑定")
    for name in ("resume-all", "status-all", "abandon-all"):
        sub = commands.add_parser(name)
        sub.add_argument("session_id")
        if name == "resume-all":
            sub.add_argument("--workflow-run-id", default="", help="为当前待恢复批次关联远程执行")
            sub.add_argument("--limit", type=int, help="恢复启动时用 --limit 指定的每批上限")
    for sub in commands.choices.values():
        log_option(sub)
    return root


def main(argv=None):
    args = parser().parse_args(argv)
    configure(getattr(args, "log_level", "key"))
    try:
        if args.command == "doctor":
            result = Doctor(args.config, smoke=args.smoke).run()
            print(json.dumps(result, ensure_ascii=False, indent=2))
            if result.get("status") == "FAIL":
                raise SystemExit(2)
            return
        settings = Settings.load(args.config)
        configure(getattr(args, "log_level", settings.log_level))
        if getattr(args, "limit", None) is not None:
            settings = replace(settings, batch_size=args.limit)
            settings.validate()
        collector, repository = Collector(settings.source_db), Repository(settings.result_db)
        client, store = DifyClient(settings), RunStore(settings.state_dir)
        runner = Runner(settings, collector, repository, client, store)
        if args.command == "init":
            collector.check()
            repository.initialize()
            result = {"status": "SUCCESS", "result_db": str(settings.result_db)}
        elif args.command == "check":
            result = {
                "source": collector.check(),
                "result_db": str(settings.result_db),
                "timezone": "+08:00",
            }
            if args.remote:
                params = client.parameters()
                names = {
                    entry.get("variable")
                    for wrapper in params.get("user_input_form", [])
                    for entry in wrapper.values()
                    if isinstance(entry, dict)
                }
                result["dify_inputs"] = sorted(n for n in names if n)
                if not {"articles_json", "run_id", "grouping_mode"} <= names:
                    raise NewsError("已发布主控缺少必需输入，请导入新版 DSL 后发布")
                result["dify_capacity"] = {
                    "status": "NOT_VERIFIED",
                    "reason": "应用 API 不暴露 API/Worker 容量配置，请按 docs/DIFY_SETUP.md 在部署端核对",
                }
        elif args.command == "plan":
            plan = runner.preview(args.force)
            result = {
                "query": plan["query"],
                "rejected": plan["rejected"],
                "selected": [
                    {
                        "source_id": a["source_id"],
                        "title": a["payload"]["title"],
                        "published_at": a["payload"]["published_at"],
                        "digest": a["digest"],
                    }
                    for a in plan["articles"]
                ],
            }
        elif args.command == "run":
            result = runner.run(args.force)
        elif args.command == "run-all":
            result = SessionRunner(runner).start(args.force)
        elif args.command == "run-forever":
            result = ContinuousTrigger(runner, args.interval).run_forever()
        elif args.command == "resume-all":
            result = SessionRunner(runner).resume(args.session_id, args.workflow_run_id)
        elif args.command == "status-all":
            result = SessionRunner(runner).status(args.session_id)
        elif args.command == "abandon-all":
            result = SessionRunner(runner).abandon(args.session_id)
        elif args.command == "resume":
            result = runner.resume(args.run_id, args.workflow_run_id)
        elif args.command == "ingest":
            result = runner.reingest(args.run_id)
        elif args.command == "abandon":
            runner.abandon(args.run_id)
            result = {"status": "ABANDONED", "run_id": args.run_id}
        elif args.command == "status":
            run = store.load(args.run_id)
            result = run.get("summary") or {
                k: run.get(k) for k in ("run_id", "phase", "error", "workflow_run_id")
            }
            if diagnostic := diagnose(str(result.get("error") or "")):
                result["diagnostic"] = diagnostic
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if result.get("status") in {"FAILED", "WAITING", "NEEDS_RECOVERY", "PAUSED"}:
            raise SystemExit(2)
    except (NewsError, OSError, ValueError) as exc:
        LOG.error("命令执行失败｜%s", exc)
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False))
        raise SystemExit(2) from exc
