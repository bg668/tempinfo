"""SQLite → Dify → SQLite. Standard-library command-line batch processing."""

import logging

__version__ = "1.9.0"
logging.getLogger(__name__).addHandler(logging.NullHandler())
