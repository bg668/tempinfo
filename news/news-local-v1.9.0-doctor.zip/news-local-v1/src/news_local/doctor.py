"""Deployment doctor for config, Dify, SQLite and local runtime prerequisites."""

from __future__ import annotations

import json
import os
import sqlite3
import sys
import tempfile
import tomllib
import uuid
from dataclasses import dataclass, asdict
from pathlib import Path
from urllib.error import HTTPError, URLError

from .collector import Collector
from .config import Settings
from .contracts import FIELDS
from .diagnostics import diagnose
from .dify_client import DifyClient
from .errors import NewsError
from .planner import capture_scope
from .repository import Repository
from .state import RunStore


EXPECTED_DIFY_INPUTS = {
    "articles_json": {"types": {"paragraph"}, "required": True},
    "digest_keywords": {"types": {"text-input", "paragraph"}, "required": False},
    "grouping_mode": {"types": {"select"}, "required": True},
    "max_content_chars": {"types": {"number"}, "required": False},
    "run_id": {"types": {"text-input"}, "required": False},
}


@dataclass
class DoctorCheck:
    name: str
    status: str
    message: str
    details: dict | None = None
    action: str | None = None


class Doctor:
    def __init__(self, config_path: Path, *, smoke: bool = False):
        self.config_path = config_path.resolve()
        self.smoke = smoke
        self.checks: list[DoctorCheck] = []
        self.settings: Settings | None = None
        self.raw_config: dict = {}
        self.collector: Collector | None = None
        self.repository: Repository | None = None
        self.client: DifyClient | None = None
        self.store: RunStore | None = None

    def _add(self, name: str, status: str, message: str, **kwargs) -> None:
        self.checks.append(DoctorCheck(name, status, message, **kwargs))

    def run(self) -> dict:
        self._runtime()
        if not self._config():
            return self._result()
        assert self.settings is not None
        self.collector = Collector(self.settings.source_db)
        self.repository = Repository(self.settings.result_db)
        self.client = DifyClient(self.settings)
        self.store = RunStore(self.settings.state_dir)
        self._paths()
        self._source_db()
        self._result_db()
        self._state_dir()
        dify_ok = self._dify()
        if self.smoke:
            if dify_ok:
                self._dify_smoke()
            else:
                self._add(
                    "dify.smoke",
                    "SKIP",
                    "基础 Dify 检查未通过，未执行真实工作流 smoke test",
                )
        return self._result()

    def _runtime(self) -> None:
        version = sys.version_info
        if version >= (3, 11):
            self._add(
                "runtime.python",
                "PASS",
                f"Python {version.major}.{version.minor}.{version.micro}",
            )
        else:
            self._add(
                "runtime.python",
                "FAIL",
                f"Python {version.major}.{version.minor}.{version.micro} 低于要求的 3.11",
                action="使用 Python 3.11+ 重新创建 uv 环境",
            )

    def _config(self) -> bool:
        if not self.config_path.is_file():
            self._add(
                "config.file",
                "FAIL",
                f"配置文件不存在：{self.config_path}",
                action="确认 --config 路径；路径相对当前工作目录解析",
            )
            return False
        try:
            with self.config_path.open("rb") as handle:
                self.raw_config = tomllib.load(handle)
            self.settings = Settings.load(self.config_path)
        except (OSError, tomllib.TOMLDecodeError, NewsError, TypeError, ValueError) as exc:
            self._add(
                "config.load",
                "FAIL",
                str(exc),
                action="修正 config.toml 后重新执行 doctor",
            )
            return False
        self._add(
            "config.load",
            "PASS",
            "配置文件可解析，参数范围合法",
            details={
                "config": str(self.config_path),
                "batch_size": self.settings.batch_size,
                "grouping_mode": self.settings.grouping_mode,
                "max_content_chars": self.settings.max_content_chars,
                "max_input_chars": self.settings.max_input_chars,
                "io_timeout": self.settings.io_timeout,
                "run_timeout": self.settings.run_timeout,
            },
        )
        env_name = str(self.raw_config.get("api_key_env", "DIFY_API_KEY"))
        if self.settings.api_key:
            self._add(
                "config.dify_api_key",
                "PASS",
                f"环境变量 {env_name} 已设置",
                details={"env": env_name, "value": "<redacted>"},
            )
        else:
            self._add(
                "config.dify_api_key",
                "FAIL",
                f"环境变量 {env_name} 未设置或为空",
                action=f"在 .env/运行环境中设置 {env_name}，不要把 Key 写入日志或源码",
            )
        return True

    def _paths(self) -> None:
        assert self.settings is not None
        self._add(
            "paths.resolved",
            "PASS",
            "配置路径已按 config.toml 所在目录解析",
            details={
                "source_db": str(self.settings.source_db),
                "result_db": str(self.settings.result_db),
                "state_dir": str(self.settings.state_dir),
            },
        )

    def _source_db(self) -> None:
        assert self.collector is not None and self.settings is not None
        try:
            info = self.collector.check()
            with self.collector.connect() as db:
                quick = db.execute("PRAGMA quick_check").fetchone()[0]
                if quick != "ok":
                    raise NewsError("采集库 PRAGMA quick_check 失败：" + str(quick))
                tables = {
                    row[0]
                    for row in db.execute(
                        "SELECT name FROM sqlite_master WHERE type='table'"
                    )
                }
                missing = {"feed_items", "article_contents"} - tables
                if missing:
                    raise NewsError("采集库缺少表：" + ", ".join(sorted(missing)))
            scope = capture_scope(self.collector, self.settings)
            status = "WARN" if info.get("orphan_count") else "PASS"
            action = None
            if info.get("orphan_count"):
                action = "修复 article_contents.article_id 到 feed_items.id 的断链记录"
            self._add(
                "database.source",
                status,
                "采集库可读，结构与查询链路正常",
                details={
                    **info,
                    "scope_article_count": scope.get("scope_article_count", 0),
                    "invalid_time_count": scope.get("invalid_time_count", 0),
                },
                action=action,
            )
            if self.settings.accounts:
                available = {row["account"] for row in self.collector.metadata()}
                missing_accounts = sorted(set(self.settings.accounts) - available)
                matched = sorted(set(self.settings.accounts) & available)
                if not matched:
                    self._add(
                        "database.source_accounts",
                        "WARN",
                        "accounts 过滤条件在当前采集库中没有任何匹配",
                        details={"configured": list(self.settings.accounts)},
                        action="检查迁移后 article_contents.account 值及 config.toml accounts",
                    )
                elif missing_accounts:
                    self._add(
                        "database.source_accounts",
                        "WARN",
                        "部分 accounts 过滤条件在当前采集库中不存在",
                        details={"matched": matched, "missing": missing_accounts},
                    )
                else:
                    self._add(
                        "database.source_accounts",
                        "PASS",
                        "accounts 过滤条件均可在采集库中找到",
                        details={"matched": matched},
                    )
        except (NewsError, sqlite3.Error, OSError, ValueError) as exc:
            self._add(
                "database.source",
                "FAIL",
                str(exc),
                action="确认 source_db 指向迁移后的 Collector SQLite，且当前用户有读取权限",
            )

    def _result_db(self) -> None:
        assert self.repository is not None and self.settings is not None
        path = self.settings.result_db
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                self._probe_new_db_path(path)
                self._add(
                    "database.result",
                    "WARN",
                    "结果库尚不存在，但目录可写；首次运行会创建结果表",
                    details={"path": str(path)},
                    action="可先执行 init，或直接由 run-forever 初始化",
                )
                return
            with self.repository.connect() as db:
                quick = db.execute("PRAGMA quick_check").fetchone()[0]
                if quick != "ok":
                    raise NewsError("结果库 PRAGMA quick_check 失败：" + str(quick))
                existing_tables = {
                    row[0]
                    for row in db.execute(
                        "SELECT name FROM sqlite_master WHERE type='table'"
                    )
                }
                for table, fields in FIELDS.items():
                    if table in existing_tables:
                        self.repository._validate_table_contract(db, table, fields)
                self._check_feedback_contract(db, existing_tables)
                self._check_review_contract(db, existing_tables)
                self._write_probe(db)
                extensions = self._safe_extensions(db, existing_tables)
            missing = sorted({*FIELDS, "feedback"} - existing_tables)
            status = "WARN" if missing else "PASS"
            self._add(
                "database.result",
                status,
                "结果库可读写，现有共享表与后台处理契约兼容",
                details={
                    "path": str(path),
                    "missing_tables_created_on_init": missing,
                    "safe_extra_columns": extensions,
                },
                action="缺失表会由 init/run-forever 创建" if missing else None,
            )
        except (NewsError, sqlite3.Error, OSError) as exc:
            self._add(
                "database.result",
                "FAIL",
                str(exc),
                action="检查 result_db 权限与 Schema；Web 扩展列必须允许后台 INSERT 省略",
            )

    @staticmethod
    def _probe_new_db_path(path: Path) -> None:
        fd, name = tempfile.mkstemp(prefix=".doctor-db-", suffix=".sqlite", dir=path.parent)
        os.close(fd)
        probe = Path(name)
        try:
            with sqlite3.connect(probe) as db:
                db.execute("CREATE TABLE probe(id INTEGER)")
                db.execute("INSERT INTO probe VALUES (1)")
                db.commit()
        finally:
            probe.unlink(missing_ok=True)

    @staticmethod
    def _write_probe(db: sqlite3.Connection) -> None:
        # SQLite DDL is transactional. Rollback leaves the shared DB unchanged while
        # proving that the main database can acquire a writer lock and persist schema pages.
        name = "__news_local_doctor_probe"
        db.execute("BEGIN IMMEDIATE")
        try:
            db.execute(f"CREATE TABLE {name}(id INTEGER)")
            db.execute(f"INSERT INTO {name} VALUES (1)")
            db.rollback()
        except BaseException:
            db.rollback()
            raise

    @staticmethod
    def _check_feedback_contract(db, existing_tables: set[str]) -> None:
        if "feedback" not in existing_tables:
            return
        actual = {row["name"] for row in db.execute("PRAGMA table_info(feedback)")}
        expected = {"feedback_id", "target_type", "target_id", "content", "created_at"}
        if actual != expected:
            raise NewsError("feedback 字段不兼容；必须保持最小五字段契约")

    @staticmethod
    def _check_review_contract(db, existing_tables: set[str]) -> None:
        if "candidates" not in existing_tables:
            return
        row = db.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='candidates'"
        ).fetchone()
        sql = (row[0] or "") if row else ""
        if any(token in sql for token in ("'accepted'", "'rejected'", "'deferred'")):
            counts = dict(
                db.execute(
                    "SELECT review_status,count(*) FROM candidates "
                    "WHERE review_status NOT IN ('pending','starred','ignored') "
                    "GROUP BY review_status"
                )
            )
            if counts:
                raise NewsError(
                    "candidates 仍有旧人工审核状态，不能自动猜测三态映射："
                    + ", ".join(f"{k}={v}" for k, v in sorted(counts.items()))
                )

    @staticmethod
    def _safe_extensions(db, existing_tables: set[str]) -> dict:
        result = {}
        for table, fields in FIELDS.items():
            if table not in existing_tables:
                continue
            actual = [row["name"] for row in db.execute(f"PRAGMA table_info({table})")]
            extras = [name for name in actual if name not in fields]
            if extras:
                result[table] = extras
        return result

    def _state_dir(self) -> None:
        assert self.settings is not None and self.store is not None
        root = self.settings.state_dir
        try:
            root.mkdir(parents=True, exist_ok=True)
            fd, name = tempfile.mkstemp(prefix=".doctor-write-", dir=root)
            os.close(fd)
            Path(name).unlink(missing_ok=True)
            corrupt = []
            unfinished = []
            for run in self.store.list():
                if run.get("phase") not in {"COMPLETED", "FAILED", "ABANDONED"}:
                    unfinished.append(run.get("run_id"))
                    try:
                        self.store.load(run["run_id"])
                    except (NewsError, OSError, ValueError, json.JSONDecodeError) as exc:
                        corrupt.append({"run_id": run.get("run_id"), "error": str(exc)})
            if corrupt:
                self._add(
                    "state.journal",
                    "FAIL",
                    "存在无法恢复的未结束 run journal",
                    details={"corrupt": corrupt},
                    action="先备份 state_dir，再人工检查对应 run_xxx/input.json 与 run.json",
                )
            elif len(unfinished) > 1:
                self._add(
                    "state.journal",
                    "FAIL",
                    "存在多个未结束 run，违反单 Worker 约束",
                    details={"unfinished_runs": unfinished},
                    action="人工确认保留哪个 run，其余使用 abandon 或恢复处理",
                )
            elif unfinished:
                self._add(
                    "state.journal",
                    "WARN",
                    "发现一个未结束 run；run-forever 启动后会优先断点恢复",
                    details={"unfinished_runs": unfinished},
                )
            else:
                self._add("state.journal", "PASS", "state_dir 可写，未发现待恢复 run")
        except (OSError, NewsError, ValueError, json.JSONDecodeError) as exc:
            self._add(
                "state.journal",
                "FAIL",
                str(exc),
                action="确认 state_dir 可创建/可写，并从旧环境完整迁移未完成 run 的文件",
            )

    def _dify(self) -> bool:
        assert self.settings is not None and self.client is not None
        if not self.settings.api_key:
            self._add(
                "dify.parameters",
                "FAIL",
                "缺少 Dify API Key，无法验证发布应用",
                action="设置配置指定的 api_key_env 后重试",
            )
            return False
        try:
            params = self.client.parameters()
            inputs = self._extract_dify_inputs(params)
            missing = sorted(set(EXPECTED_DIFY_INPUTS) - set(inputs))
            if missing:
                self._add(
                    "dify.parameters",
                    "FAIL",
                    "Dify Key 可访问，但发布应用不是当前后台程序所需的工作流契约",
                    details={"missing_inputs": missing, "actual_inputs": sorted(inputs)},
                    action="确认 .env 中的 Key 属于已导入并发布的 00_安全资讯处理_单工作流.yml",
                )
                return False
            problems = self._validate_dify_inputs(inputs)
            if problems:
                self._add(
                    "dify.parameters",
                    "FAIL",
                    "Dify 发布应用输入参数与当前配置不兼容",
                    details={"problems": problems, "actual_inputs": inputs},
                    action="重新导入/发布当前 DSL，或修正 config.toml 与发布应用参数",
                )
                return False
            self._add(
                "dify.parameters",
                "PASS",
                "Dify API Key、发布应用与五个输入参数契约正常",
                details={
                    "api_base": self.settings.api_base,
                    "inputs": sorted(inputs),
                },
            )
            return True
        except HTTPError as exc:
            message = self._http_error_text(exc)
            action = {
                401: "确认 API Key 来自当前 Workflow App，而不是旧环境/其他 App",
                403: "确认该 Key 对当前发布应用有访问权限",
                404: "确认 api_base 指向 Dify API 的 /v1，并确认应用已发布",
            }.get(exc.code, "检查 Dify API 地址、Key 与发布状态")
            self._add(
                "dify.parameters",
                "FAIL",
                f"Dify 返回 HTTP {exc.code}" + (f"：{message}" if message else ""),
                action=action,
            )
            return False
        except (URLError, TimeoutError, OSError, NewsError, ValueError, json.JSONDecodeError) as exc:
            self._add(
                "dify.parameters",
                "FAIL",
                f"无法访问 Dify 发布应用：{exc}",
                action="检查 api_base、DNS/端口/反向代理、防火墙和 Dify api 服务状态",
            )
            return False

    @staticmethod
    def _extract_dify_inputs(params: dict) -> dict[str, dict]:
        if not isinstance(params, dict):
            raise NewsError("Dify /parameters 返回值不是对象")
        forms = params.get("user_input_form")
        if not isinstance(forms, list):
            raise NewsError("Dify /parameters 缺少 user_input_form；可能使用了错误的 App Key")
        result = {}
        for wrapper in forms:
            if not isinstance(wrapper, dict):
                continue
            for input_type, entry in wrapper.items():
                if isinstance(entry, dict) and isinstance(entry.get("variable"), str):
                    normalized = dict(entry)
                    normalized.setdefault("type", input_type)
                    result[entry["variable"]] = normalized
        return result

    def _validate_dify_inputs(self, inputs: dict[str, dict]) -> list[str]:
        assert self.settings is not None
        problems = []
        for name, contract in EXPECTED_DIFY_INPUTS.items():
            entry = inputs[name]
            actual_type = str(entry.get("type") or "")
            if actual_type not in contract["types"]:
                problems.append(f"{name}.type={actual_type!r}")
            if contract["required"] and entry.get("required") is False:
                problems.append(f"{name}.required=false")
        articles_max = inputs["articles_json"].get("max_length")
        if type(articles_max) is int and articles_max < self.settings.max_input_chars:
            problems.append(
                f"articles_json.max_length={articles_max} < max_input_chars={self.settings.max_input_chars}"
            )
        run_max = inputs["run_id"].get("max_length")
        if type(run_max) is int and run_max < 36:
            problems.append(f"run_id.max_length={run_max} < 36")
        options = inputs["grouping_mode"].get("options")
        if isinstance(options, list) and self.settings.grouping_mode not in options:
            problems.append(
                f"grouping_mode 不支持配置值 {self.settings.grouping_mode!r}"
            )
        return problems

    def _dify_smoke(self) -> None:
        assert self.client is not None
        run_id = "run_" + uuid.uuid4().hex
        content = (
            "这是 news-local doctor 的合成测试资讯，用于验证迁移后的 Dify 工作流、"
            "模型、插件与文件导出是否可执行。内容为产品宣传，不是真实安全事件。"
        )
        article = {
            "source_article_id": "999999999",
            "account": "doctor",
            "title": "Doctor 测试：安全厂商发布产品宣传",
            "url": "https://example.invalid/news-local-doctor",
            "published_at": "2026-09-21T00:00:00+08:00",
            "content": content,
            "content_chars": len(content),
            "content_truncated": False,
            "source_version": "doctor-v1",
        }
        inputs = {
            "run_id": run_id,
            "articles_json": json.dumps([article], ensure_ascii=False, separators=(",", ":")),
            "grouping_mode": "singleton",
            "digest_keywords": "日报,周报,快讯,安全简讯",
            "max_content_chars": 50000,
        }
        execution_ids = []
        try:
            detail = self.client.start(inputs, execution_ids.append)
            if detail.get("status") not in {"succeeded", "partial-succeeded"}:
                raise NewsError("smoke workflow 未成功：" + str(detail.get("status")))
            outputs = detail.get("outputs") or {}
            with tempfile.TemporaryDirectory(prefix="news-local-doctor-") as temp:
                root = Path(temp)
                result_path = root / "result.json"
                csv_path = root / "review.csv"
                self.client.download(outputs, "result_json_file", result_path)
                self.client.download(outputs, "review_csv_file", csv_path)
                payload = json.loads(result_path.read_text(encoding="utf-8-sig"))
                if payload.get("run_id") != run_id:
                    raise NewsError("Dify smoke 导出的 result.json run_id 不匹配")
                for key in ("processing_items", "candidates"):
                    if not isinstance(payload.get(key), list):
                        raise NewsError("Dify smoke result.json 缺少列表字段：" + key)
            self._add(
                "dify.smoke",
                "PASS",
                "真实 Dify Workflow 执行、模型链路与结果文件下载均成功",
                details={
                    "workflow_run_id": execution_ids[-1] if execution_ids else None,
                    "status": detail.get("status"),
                },
            )
        except Exception as exc:  # doctor must turn transport/runtime failures into one report
            error = str(exc)
            diagnostic = diagnose(error)
            self._add(
                "dify.smoke",
                "FAIL",
                "Dify 真实 smoke test 失败：" + error,
                details={
                    "workflow_run_id": execution_ids[-1] if execution_ids else None,
                    "diagnostic": diagnostic,
                },
                action=(diagnostic or {}).get("action")
                or "进入 Dify 对应 Workflow 运行日志检查失败节点、模型凭据、插件和文件服务",
            )

    @staticmethod
    def _http_error_text(exc: HTTPError) -> str:
        try:
            raw = exc.read(64 * 1024).decode("utf-8", errors="replace").strip()
        except Exception:
            return ""
        if not raw:
            return ""
        try:
            payload = json.loads(raw)
            if isinstance(payload, dict):
                for key in ("message", "error", "code"):
                    value = payload.get(key)
                    if isinstance(value, (str, int, float)):
                        return str(value)[:500]
        except json.JSONDecodeError:
            pass
        return raw[:500]

    def _result(self) -> dict:
        counts = {status: 0 for status in ("PASS", "WARN", "FAIL", "SKIP")}
        for check in self.checks:
            counts[check.status] = counts.get(check.status, 0) + 1
        status = "FAIL" if counts["FAIL"] else "WARN" if counts["WARN"] else "PASS"
        failed = [check.name for check in self.checks if check.status == "FAIL"]
        warnings = [check.name for check in self.checks if check.status == "WARN"]
        return {
            "status": status,
            "summary": {
                "passed": counts["PASS"],
                "warnings": counts["WARN"],
                "failed": counts["FAIL"],
                "skipped": counts["SKIP"],
            },
            "failed_checks": failed,
            "warning_checks": warnings,
            "checks": [asdict(check) for check in self.checks],
        }
