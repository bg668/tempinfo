import json
import os
import sqlite3
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from test_core import SystemCase

from news_local.doctor import Doctor


class DoctorTests(SystemCase):
    def _config(self, api_base: str, *, api_env: str = "DOCTOR_TEST_KEY") -> Path:
        path = self.root / "config.toml"
        path.write_text(
            "\n".join(
                [
                    'source_db = "collector.db"',
                    'result_db = "collector.db"',
                    'state_dir = "state"',
                    f'api_base = "{api_base}"',
                    f'api_key_env = "{api_env}"',
                    'batch_size = 25',
                    'grouping_mode = "event_match"',
                    'max_content_chars = 50000',
                    'max_input_chars = 4000000',
                    'io_timeout = 3',
                    'run_timeout = 10',
                    'max_download_bytes = 52428800',
                    'log_level = "key"',
                ]
            ),
            encoding="utf-8",
        )
        return path

    @staticmethod
    def _parameters():
        return {
            "user_input_form": [
                {
                    "paragraph": {
                        "variable": "articles_json",
                        "required": True,
                        "max_length": 4000000,
                    }
                },
                {
                    "text-input": {
                        "variable": "digest_keywords",
                        "required": False,
                        "max_length": 1024,
                    }
                },
                {
                    "select": {
                        "variable": "grouping_mode",
                        "required": True,
                        "options": ["singleton", "event_match"],
                    }
                },
                {
                    "number": {
                        "variable": "max_content_chars",
                        "required": False,
                    }
                },
                {
                    "text-input": {
                        "variable": "run_id",
                        "required": False,
                        "max_length": 36,
                    }
                },
            ]
        }

    def test_doctor_passes_shared_schema_with_review_version(self):
        with sqlite3.connect(self.source) as db:
            db.execute("ALTER TABLE candidates ADD COLUMN review_version INTEGER DEFAULT 0")
        params = self._parameters()

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(params).encode())

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        old = os.environ.get("DOCTOR_TEST_KEY")
        os.environ["DOCTOR_TEST_KEY"] = "secret"
        try:
            result = Doctor(
                self._config(f"http://127.0.0.1:{server.server_port}/v1")
            ).run()
            self.assertNotEqual(result["status"], "FAIL", result)
            by_name = {c["name"]: c for c in result["checks"]}
            self.assertEqual(by_name["dify.parameters"]["status"], "PASS")
            self.assertEqual(by_name["database.result"]["status"], "PASS")
            self.assertIn(
                "review_version",
                by_name["database.result"]["details"]["safe_extra_columns"]["candidates"],
            )
        finally:
            if old is None:
                os.environ.pop("DOCTOR_TEST_KEY", None)
            else:
                os.environ["DOCTOR_TEST_KEY"] = old
            server.shutdown()
            server.server_close()
            thread.join()

    def test_doctor_detects_wrong_dify_app_contract(self):
        params = {"user_input_form": [{"paragraph": {"variable": "query", "required": True}}]}

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                self.send_response(200)
                self.end_headers()
                self.wfile.write(json.dumps(params).encode())

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        old = os.environ.get("DOCTOR_TEST_KEY")
        os.environ["DOCTOR_TEST_KEY"] = "secret"
        try:
            result = Doctor(
                self._config(f"http://127.0.0.1:{server.server_port}/v1")
            ).run()
            self.assertEqual(result["status"], "FAIL")
            check = next(c for c in result["checks"] if c["name"] == "dify.parameters")
            self.assertEqual(check["status"], "FAIL")
            self.assertIn("articles_json", check["details"]["missing_inputs"])
        finally:
            if old is None:
                os.environ.pop("DOCTOR_TEST_KEY", None)
            else:
                os.environ["DOCTOR_TEST_KEY"] = old
            server.shutdown()
            server.server_close()
            thread.join()

    def test_doctor_smoke_executes_and_downloads_without_database_insert(self):
        params = self._parameters()
        state = {}

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                if self.path.startswith("/v1/parameters"):
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(json.dumps(params).encode())
                elif self.path.startswith("/files/result.json"):
                    self.send_response(200)
                    self.end_headers()
                    payload = {
                        "run_id": state["run_id"],
                        "processing_items": [],
                        "candidates": [],
                    }
                    self.wfile.write(json.dumps(payload).encode())
                elif self.path.startswith("/files/review.csv"):
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write("title,type\n".encode())
                else:
                    self.send_response(404)
                    self.end_headers()

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                state["run_id"] = body["inputs"]["run_id"]
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.end_headers()
                events = [
                    {
                        "event": "workflow_started",
                        "workflow_run_id": "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
                    },
                    {
                        "event": "workflow_finished",
                        "data": {
                            "status": "succeeded",
                            "outputs": {
                                "result_json_file": [{"url": "/files/result.json"}],
                                "review_csv_file": [{"url": "/files/review.csv"}],
                            },
                        },
                    },
                ]
                for event in events:
                    self.wfile.write(("data: " + json.dumps(event) + "\n\n").encode())
                    self.wfile.flush()

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        old = os.environ.get("DOCTOR_TEST_KEY")
        os.environ["DOCTOR_TEST_KEY"] = "secret"
        try:
            before = self.repository.processing("nonexistent")["total"]
            result = Doctor(
                self._config(f"http://127.0.0.1:{server.server_port}/v1"), smoke=True
            ).run()
            check = next(c for c in result["checks"] if c["name"] == "dify.smoke")
            self.assertEqual(check["status"], "PASS", result)
            after = self.repository.processing("nonexistent")["total"]
            self.assertEqual(before, after)
        finally:
            if old is None:
                os.environ.pop("DOCTOR_TEST_KEY", None)
            else:
                os.environ["DOCTOR_TEST_KEY"] = old
            server.shutdown()
            server.server_close()
            thread.join()

    def test_doctor_missing_api_key_is_fail_not_secret_echo(self):
        path = self._config("http://127.0.0.1:1/v1", api_env="DOCTOR_MISSING_KEY")
        os.environ.pop("DOCTOR_MISSING_KEY", None)
        result = Doctor(path).run()
        self.assertEqual(result["status"], "FAIL")
        rendered = json.dumps(result, ensure_ascii=False)
        self.assertNotIn("test-key", rendered)
        self.assertIn("DOCTOR_MISSING_KEY", rendered)


def load_tests(loader, tests, pattern):
    names = [name for name in DoctorTests.__dict__ if name.startswith("test_")]
    return unittest.TestSuite(DoctorTests(name) for name in names)
