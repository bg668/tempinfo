import json
import threading
import unittest
from dataclasses import replace
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from helpers import bundle_for
from test_core import SystemCase

from news_local.dify_client import DifyClient
from news_local.errors import RemoteFailure
from news_local.service import Runner


class HttpTests(SystemCase):
    """Exercise the real HTTP and file-download adapter against a local API simulator."""

    def test_http_400_preserves_dify_message(self):
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_POST(self):
                self.send_response(400)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"message": "model provider is not configured"}).encode())

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            settings = replace(self.settings, api_base=f"http://127.0.0.1:{server.server_port}/v1")
            client = DifyClient(settings)
            with self.assertRaises(RemoteFailure) as caught:
                client.start(
                    {
                        "run_id": "run_" + "a" * 32,
                        "articles_json": "[]",
                        "grouping_mode": "singleton",
                        "digest_keywords": "日报",
                        "max_content_chars": 50000,
                    },
                    lambda _: None,
                )
            self.assertIn("model provider is not configured", str(caught.exception))
        finally:
            server.shutdown()
            server.server_close()
            thread.join()

    def test_streaming_http_and_file_auth_separation(self):
        payloads, file_auth = {}, []

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_POST(self):
                request = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                payloads["inputs"] = request["inputs"]
                payloads["bundle"] = bundle_for(request["inputs"])
                payloads["authorization"] = self.headers.get("Authorization")
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.end_headers()
                for event in [
                    {
                        "event": "workflow_started",
                        "workflow_run_id": "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
                    },
                    {
                        "event": "workflow_finished",
                        "data": {
                            "status": "succeeded",
                            "outputs": {
                                "result_json_file": [{"url": "/files/result.json?sign=keep-this"}],
                                "review_csv_file": [{"url": "/files/review.csv?sign=keep-this"}],
                            },
                        },
                    },
                ]:
                    self.wfile.write(("data: " + json.dumps(event) + "\n\n").encode())
                    self.wfile.flush()

            def do_GET(self):
                file_auth.append(self.headers.get("Authorization"))
                self.send_response(200)
                self.end_headers()
                if self.path.startswith("/files/result.json?sign=keep-this"):
                    self.wfile.write(json.dumps(payloads["bundle"], ensure_ascii=False).encode())
                else:
                    self.wfile.write("\ufeff标题,类型\r\n测试,security_event\r\n".encode())

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            settings = replace(self.settings, api_base=f"http://127.0.0.1:{server.server_port}/v1")
            runner = Runner(
                settings, self.collector, self.repository, DifyClient(settings), self.store
            )
            report = runner.run()
            self.assertEqual(report["status"], "SUCCESS", report)
            self.assertEqual(payloads["authorization"], "Bearer test-key")
            self.assertEqual(file_auth, [None, None])
            self.assertEqual(payloads["inputs"]["run_id"], report["run_id"])
        finally:
            server.shutdown()
            server.server_close()
            thread.join()


# Imported base tests are already discovered in test_core.py; only run adapter-specific tests here.
def load_tests(loader, tests, pattern):
    names = [name for name in HttpTests.__dict__ if name.startswith("test_")]
    return unittest.TestSuite(HttpTests(name) for name in names)
