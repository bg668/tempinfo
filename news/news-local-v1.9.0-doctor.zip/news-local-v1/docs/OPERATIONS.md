# 长期后台模式（v1.7.0）

常驻运行使用 `run-forever`。进程中断后再次执行同一命令即可，程序自动恢复未结束 `run_xxx`，不需要 `session_id` 或 `resume-all`。旧 session 命令只保留历史兼容。

# 运行、恢复与统计口径

| 情况 | 本地行为 | 操作 |
|---|---|---|
| 没有待处理文章 | 不调用 Dify，保存 `NO_WORK` 概况 | 正常结束 |
| 输入质量问题 | 不虚构 AI 判断，最终记录 FAILED；其他可用文章补足本批 | 检查原文或采集器 |
| 普通文章/快讯子项业务失败 | 保存完整合法结果中的成功及失败记录 | 该输入版本视为已处理；源内容变化后才重新进入 |
| SSE 断开，已有执行 ID | 先查询原执行，不重发 POST | `resume run_id` |
| 请求状态不明且没收到执行 ID | `run-forever` 复用同一 run_id/输入快照重提；人工 `resume` 仍保守 | 常驻模式无需人工操作；人工恢复可按业务 run_id 核对 |
| JSON 文件下载失败 | 不入库，保留远程执行及输出信息 | 检查文件地址，`resume` |
| CSV 文件下载失败 | 有效 JSON 仍入库，概况标记部分完成 | `resume` 重试导出，重复入库不覆盖反馈 |
| 结果契约不符 | 拒绝整批入库，保存原始文件用于排查 | 修复原因；确认远程结束后显式放弃本批，再重新处理 |
| SQLite 写入失败 | 两表回滚，已校验 JSON 保存在本地 | `resume` 只重试本地入库 |
| 程序在提交后、写概况前中断 | 恢复时重复入库会跳过已有一致记录 | `resume` |
| 本地入库依据被改动 | 哈希核对失败，拒绝自动导入 | 检查文件完整性 |
| Dify 旧版 `errors` 等冗余输出超过 30 项 | 远程失败，不提交结果表；提示更新 DSL | 导入并发布当前单工作流，再执行新 `run` |
| Dify 实际使用的 Code 数组超过 30 项 | 远程运行失败，附加部署诊断；本地不提交结果表 | 先保持 batch_size=25；若仍触发实际容量限制，按报错检查对应配置 |

`abandon` 仍是人工故障处理工具，不会调用停止工作流接口。常驻 Worker 的正常 Ctrl+C/重启不需要 abandon。

## 概况与统计单位

来源文章数是原始输入单位；普通文章和快讯父文章在此各算一篇。处理条目数包含普通记录、快讯父记录、快讯子项和输入质量失败记录。KEEP/DROP/UNCERTAIN 只统计叶子条目，不统计父记录。失败文章按原文 ID 去重，失败条目逐行统计。

`selected_count` 为本批选中并计划送模型的有效文章，`submitted_count` 为实际本批成功提交路径中的文章数量；调用前失败时不会产生完成概况。输入质量失败另外统计，因而“选中文章”与“异常文章”不一定互为同一总数的分区。事件与政策候选数直接按最终 `candidates.candidate_type` 统计，包含符合类型的快讯候选。

日报、周报、其他快讯按“周报优先、其次日报、其余快讯”分成互斥类别，不重复计数。`digest_article_count` 表示所有快讯父文章数量，`digest_types` 提供具体拆分。

概况保存在本地 JSON 文件，由外部网页通过自己的后端读取；两张业务表保持原定职责。无任务、失败调用或数据库不可用时仍有 `run.json` 可诊断。`created_at`/`updated_at`/`reviewed_at` 保存为北京时间文本，采集库已有原始时间不批量改写。

## 人工状态与反馈

本包只提供 SQLite 数据层，不提供 Web 前端或 HTTP 响应层。候选状态只允许 `pending / starred / ignored`。调用 `Repository.review(candidate_record_id, review_status, expected_updated_at)` 时，服务端数据层固定写入 `reviewer_id=root`；目标状态与当前状态相同时直接返回当前记录且不更新时间，目标状态不同而 `updated_at` 已变化时抛出 `ConflictError`。AI 标题、摘要、事实、IOC、评分和 decision 不允许通过审核入口修改。

反馈使用独立五字段表。调用 `Repository.create_feedback(feedback_id, target_type, target_id, content)`；`target_type` 仅允许 `candidate` / `processing_item`，目标必须真实存在，content trim 后非空且不超过 5000 字符。查询使用 `Repository.feedback()` 或 `Repository.feedback_for_target()`。反馈不会自动改变候选状态，也不会改写 AI 历史。

## 进度日志

`run` / `run-forever` 默认使用 `key` 进度档；`--log-level detailed` 追加节点级排障信息。控制台按 `Bxxx → S x/7 → Item` 展示，普通资讯、快讯和候选分别显示 `文章x/N`、`快讯x/N`、`事件组x/N`。Item 编号只取父 iteration 的 index，子节点自身 index 不作为业务进度。长耗时 heartbeat 每 30 秒显示当前 Item 和子步骤。日志写 stderr，最终 JSON 写 stdout。

每个 `run_xxx` 目录另写 `progress.jsonl` 结构化事件，供外部 Web 状态页直接读取。Dify 流断开后查询原执行的 GET 只返回当前状态，不会重放此前逐节点日志；已经结束且有合法结果文件时继续下载和入库。完整格式见 `LOGGING.md`。

## v1.4 部分快讯成功

同一快讯有有效候选而部分子项失败时，概况为 PARTIAL；成功候选和失败记录一起事务入库，因此该输入版本已经形成业务终态，不在常驻循环中重复处理。failed_article_count 仍表示该批未完整成功的原文数；原文更新导致 input_hash 改变时可再次处理。

## 新环境迁移建议（v1.9.0）

迁移 config/.env/SQLite/state_dir 并导入发布 Dify Workflow 后，先执行：

```bash
uv run --env-file .env run.py --config config.toml doctor
```

默认检查通过后，如果 Dify 在新环境仍提示应用、模型或插件错误，再执行一次真实但不写本地业务库的冒烟：

```bash
uv run --env-file .env run.py --config config.toml doctor --smoke
```

`doctor --smoke` 会产生一次 Dify Workflow/模型调用。两步都通过后再启动 `run-forever`。
