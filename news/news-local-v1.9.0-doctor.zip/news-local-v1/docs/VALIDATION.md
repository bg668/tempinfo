# v1.9.0 验证

本地 Python 回归 105 项、Dify 工作流回归 84 项，共 189 项全部通过；`validate_dsl.py` 与 `validate_single.py` 同时通过。Dify 业务图 SHA-256 仍为 `ce873cda69807b72dde08a85f9268edcc4b7934654cf377d8cc210b4b9ef09fe`，本轮未修改工作流业务图。

新增/调整验证覆盖：

- `run-forever` Batch 序号从 durable run journal 续号，重新创建 Trigger/重启进程后继续递增；恢复未结束 run 沿用原 Batch 编号。
- 六个主阶段固定显示为 `S 1/6` 到 `S 6/6`；快讯与普通资讯作为平级分支共享 `S 2/6`，条件分支跳过不改变编号。
- 父 iteration 的 0-based index 正确转换为 `文章1/N` 等 1-based Item 进度，并传递给其子节点；子节点自身重复 index 不作为文章编号。
- heartbeat 在 key 模式下仍工作，并显示当前 Batch、Stage、Item 和动作，例如 `[文章1/1][价值筛选]`。
- `progress.jsonl` 写入结构化 Batch/Stage/Item 事件，包含 stage_no/stage_total、item_index/item_total、item_id/title 等字段。
- 默认日志档改为 `key`；`detailed` 继续保留节点开始/结束、原始 iteration 和耗时用于排障。
- `run-forever` 连续清空 backlog，空闲时才按 interval 等待，并可拾取随后新增的 Collector 记录。
- daemon 不创建 `session_xxx`，启动时自动恢复唯一未结束 `run_xxx`。
- Ctrl+C 发生在已取得 `workflow_run_id` 后，重启只查询原执行，不重复 POST；未知 POST 复用同一 `run_id` 与输入快照恢复。
- SUCCESS、已事务提交的业务 FAILED、本地确定性输入错误继续作为 processed checkpoint；输入变化后 hash 改变可重新处理。
- 三态审核、root 身份、同状态幂等、feedback 五字段/目标校验/5000 字/防重、Web 扩展 `review_version INTEGER` 的 schema 兼容回归继续通过。


v1.9.0 新增 doctor 回归覆盖：共享 Schema + review_version、错误 Dify App Key/输入契约、真实 HTTP smoke 文件下载、缺失 API Key 脱敏输出，以及 Dify HTTP 400 错误消息保留。
