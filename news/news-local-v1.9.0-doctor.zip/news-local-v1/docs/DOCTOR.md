# doctor：部署与迁移自检

迁移到新机器、新 SQLite 或新 Dify App 后，先执行：

```bash
uv run --env-file .env run.py --config config.toml doctor
```

默认 doctor 不执行模型，不写业务结果。它会检查：Python 版本、config.toml 参数、Dify API Key 是否存在、source/result SQLite 的路径/结构/可读写性、Web 追加字段兼容性、最小 feedback 表契约、state_dir 与未完成 run、Dify `/parameters` 连通性，以及发布 App 是否具有当前工作流要求的五个输入参数。

如果迁移后 Dify 页面/应用仍报错，而默认 doctor 已通过，再执行：

```bash
uv run --env-file .env run.py --config config.toml doctor --smoke
```

`--smoke` 会额外向 Dify 提交一条合成资讯，真实经过 Workflow、模型/插件节点和文件导出，并下载 `result.json` / `review.csv` 到临时目录验证后删除。它不会写入本地结果库，但会产生一次真实的 Dify Workflow/模型调用。

## 状态含义

- `PASS`：该检查正常。
- `WARN`：不会直接阻止运行，但需要确认。例如结果表尚未初始化、存在一个待恢复 run。
- `FAIL`：会阻止或高度可能阻止正常运行。doctor 退出码为 2。
- `SKIP`：前置检查失败，后续检查无法可靠执行。

doctor 永远不会输出 API Key 明文。迁移环境里最常见的 Dify 错误是 `.env` 仍指向旧 App Key，或者新 App 导入 DSL 后没有重新发布。doctor 会通过 `/parameters` 对比 `articles_json / digest_keywords / grouping_mode / max_content_chars / run_id` 五个输入来识别这类错误。
