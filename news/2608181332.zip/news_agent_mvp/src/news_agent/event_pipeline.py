from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

from .config import AppConfig
from .contracts import (
    EVENT_CANDIDATE_CONTRACT_VERSION,
    EVENT_MATCH_CONTRACT_VERSION,
    EventCandidateResult,
    EventMatchResult,
    IOCCounters,
    IncidentResult,
    PolicyCandidateResult,
    PolicyResult,
)
from .skill import skill_sha256
from .stages.base import (
    EventCandidateExecutionError,
    EventCandidateInput,
    EventCandidateRuntime,
    EventMatchExecutionError,
    EventMatchInput,
    EventMatchRuntime,
    StageExecutionError,
)
from .store import NewsAgentStore, RunIdentity

_EVENT_MATCH_STAGE_VERSION = "event-match.v1"
_EVENT_CANDIDATE_STAGE_VERSION = "candidate-compose-event.v1"
_POLICY_CANDIDATE_COMPOSE_VERSION = "candidate-compose-policy.v1"


def _identity(config: AppConfig, skill_text: str, *, stage_version: str, contract_version: str) -> RunIdentity:
    skill_hash = skill_sha256(skill_text)
    payload = {
        "stage_version": stage_version,
        "contract_version": contract_version,
        "skill_sha256": skill_hash,
        "provider": config.provider.model_dump(exclude={"api_key_env"}),
        "model": config.model.model_dump(),
        "runtime": config.runtime.model_dump(),
    }
    signature = hashlib.sha256(
        json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()[:24]
    return RunIdentity(
        analysis_signature=signature,
        stage_version=stage_version,
        contract_version=contract_version,
        skill_sha256=skill_hash,
        model_name=config.model.name,
        skill_snapshot=skill_text,
    )


def build_event_match_identity(config: AppConfig, skill_text: str) -> RunIdentity:
    return _identity(
        config,
        skill_text,
        stage_version=_EVENT_MATCH_STAGE_VERSION,
        contract_version=EVENT_MATCH_CONTRACT_VERSION,
    )


def build_event_candidate_identity(config: AppConfig, skill_text: str) -> RunIdentity:
    return _identity(
        config,
        skill_text,
        stage_version=_EVENT_CANDIDATE_STAGE_VERSION,
        contract_version=EVENT_CANDIDATE_CONTRACT_VERSION,
    )


def policy_candidate_compose_version() -> str:
    return _POLICY_CANDIDATE_COMPOSE_VERSION


def deterministic_event_id(member_article_ids: list[str]) -> str:
    normalized = "|".join(sorted(member_article_ids))
    return "event_" + hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]


def deterministic_policy_id(source_article_id: str) -> str:
    return "policy_" + hashlib.sha256(source_article_id.encode("utf-8")).hexdigest()[:16]


def event_match_input_sha256(incidents: list[IncidentResult]) -> str:
    payload = [
        item.model_dump(mode="json")
        for item in sorted(incidents, key=lambda x: x.source_article_id)
    ]
    return hashlib.sha256(
        json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()


@dataclass(frozen=True)
class MatchedEventGroup:
    event_id: str
    canonical_title: str
    match_reason: str
    member_article_ids: tuple[str, ...]


def materialize_groups(result: EventMatchResult) -> list[MatchedEventGroup]:
    groups: list[MatchedEventGroup] = []
    for group in result.groups.values():
        members = tuple(group.member_article_ids)
        groups.append(
            MatchedEventGroup(
                event_id=deterministic_event_id(list(members)),
                canonical_title=group.canonical_title,
                match_reason=group.match_reason,
                member_article_ids=members,
            )
        )
    return groups


@dataclass
class EventMatchStats:
    incident_count: int = 0
    group_count: int = 0
    reused: bool = False
    failed: bool = False


class EventMatchPipeline:
    def __init__(
        self,
        *,
        config: AppConfig,
        store: NewsAgentStore,
        runtime: EventMatchRuntime,
        skill_text: str,
    ) -> None:
        self.store = store
        self.runtime = runtime
        self.identity = build_event_match_identity(config, skill_text)

    def run(
        self,
        *,
        triage_signature: str,
        incident_signature: str,
        only_ids: list[str] | tuple[str, ...] | None = None,
        force: bool = False,
        verbose: bool = False,
    ) -> tuple[list[MatchedEventGroup], EventMatchStats]:
        rows = self.store.list_success_facts(
            "incident",
            upstream_triage_signature=triage_signature,
            analysis_signature=incident_signature,
            only_ids=only_ids,
        )
        incidents = [IncidentResult.model_validate_json(row["result_json"]) for row in rows]
        stats = EventMatchStats(incident_count=len(incidents))
        if not incidents:
            return [], stats
        input_sha256 = event_match_input_sha256(incidents)

        existing = self.store.get_event_match_run(
            upstream_triage_signature=triage_signature,
            upstream_incident_signature=incident_signature,
            analysis_signature=self.identity.analysis_signature,
            input_sha256=input_sha256,
        )
        if existing is not None and existing["status"] == "SUCCESS" and not force:
            result = EventMatchResult.model_validate_json(existing["result_json"])
            groups = materialize_groups(result)
            stats.group_count = len(groups)
            stats.reused = True
            return groups, stats

        rendered_input = ""
        raw_output = ""
        attempts: tuple[dict, ...] = ()
        try:
            execution = self.runtime.run(
                EventMatchInput(
                    triage_signature=triage_signature,
                    incident_signature=incident_signature,
                    incidents=tuple(incidents),
                )
            )
            rendered_input = execution.rendered_input
            raw_output = execution.raw_output
            attempts = execution.output_attempts
            self.store.save_event_match_success(
                identity=self.identity,
                upstream_triage_signature=triage_signature,
                upstream_incident_signature=incident_signature,
                input_sha256=input_sha256,
                result=execution.result,
                rendered_input=rendered_input,
                raw_output=raw_output,
                output_attempts=attempts,
            )
            groups = materialize_groups(execution.result)
            stats.group_count = len(groups)
            if verbose:
                for group in groups:
                    print(
                        f"[EVENT    ] {group.event_id} members={len(group.member_article_ids)} "
                        f"{group.canonical_title}"
                    )
                    print(f"  articles: {', '.join(group.member_article_ids)}")
                    print(f"  reason: {group.match_reason}")
            return groups, stats
        except Exception as exc:
            actual_error = exc
            if isinstance(exc, StageExecutionError):
                rendered_input = exc.rendered_input
                raw_output = exc.raw_output
                attempts = exc.output_attempts
                actual_error = exc.cause
            self.store.save_event_match_failure(
                identity=self.identity,
                upstream_triage_signature=triage_signature,
                upstream_incident_signature=incident_signature,
                input_sha256=input_sha256,
                rendered_input=rendered_input,
                raw_output=raw_output,
                output_attempts=attempts,
                error=actual_error,
            )
            stats.failed = True
            raise actual_error


def _aggregate_ioc_counts(incidents: list[IncidentResult]) -> IOCCounters:
    buckets: dict[str, set[str]] = {
        "ips": set(), "domains": set(), "urls": set(), "hashes": set(), "file_paths": set()
    }
    for incident in incidents:
        for key, values in incident.ioc.model_dump().items():
            for value in values:
                buckets[key].add(value.casefold())
    return IOCCounters(
        ip_count=len(buckets["ips"]),
        domain_count=len(buckets["domains"]),
        url_count=len(buckets["urls"]),
        hash_count=len(buckets["hashes"]),
        file_path_count=len(buckets["file_paths"]),
    )


def build_event_candidate_result(
    *,
    group: MatchedEventGroup,
    incidents: list[IncidentResult],
    draft,
) -> EventCandidateResult:
    source_ids = [item.source_article_id for item in incidents]
    source_urls = list(dict.fromkeys(item.source_url for item in incidents))
    return EventCandidateResult(
        event_id=group.event_id,
        event_time=draft.event_time,
        title=draft.title,
        source_article_ids=source_ids,
        source_urls=source_urls,
        summary=draft.summary,
        victim=draft.victim,
        attacker=draft.attacker,
        attack_vector_or_cause=draft.attack_vector_or_cause,
        affected_system=draft.affected_system,
        impact=draft.impact,
        data_breach_scope=draft.data_breach_scope,
        lesson=draft.lesson,
        ioc=_aggregate_ioc_counts(incidents),
    )


@dataclass
class CandidateStats:
    event_total: int = 0
    event_succeeded: int = 0
    event_failed: int = 0
    event_skipped_existing: int = 0
    policy_total: int = 0
    policy_succeeded: int = 0


class CandidatePipeline:
    def __init__(
        self,
        *,
        config: AppConfig,
        store: NewsAgentStore,
        runtime: EventCandidateRuntime,
        skill_text: str,
    ) -> None:
        self.store = store
        self.runtime = runtime
        self.identity = build_event_candidate_identity(config, skill_text)

    def compose_events(
        self,
        *,
        groups: list[MatchedEventGroup],
        triage_signature: str,
        incident_signature: str,
        event_match_signature: str,
        force: bool = False,
        verbose: bool = False,
    ) -> CandidateStats:
        rows = self.store.list_success_facts(
            "incident",
            upstream_triage_signature=triage_signature,
            analysis_signature=incident_signature,
        )
        incidents_by_id = {
            row["source_article_id"]: IncidentResult.model_validate_json(row["result_json"])
            for row in rows
        }
        stats = CandidateStats(event_total=len(groups))
        for group in groups:
            if not force and self.store.event_candidate_success_exists(
                event_id=group.event_id,
                upstream_event_match_signature=event_match_signature,
                analysis_signature=self.identity.analysis_signature,
            ):
                stats.event_skipped_existing += 1
                continue
            incidents = [incidents_by_id[x] for x in group.member_article_ids if x in incidents_by_id]
            data = EventCandidateInput(
                event_id=group.event_id,
                canonical_title=group.canonical_title,
                match_reason=group.match_reason,
                incidents=tuple(incidents),
            )
            rendered_input = ""
            raw_output = ""
            attempts: tuple[dict, ...] = ()
            try:
                execution = self.runtime.run(data)
                rendered_input = execution.rendered_input
                raw_output = execution.raw_output
                attempts = execution.output_attempts
                result = build_event_candidate_result(
                    group=group,
                    incidents=incidents,
                    draft=execution.result,
                )
                self.store.save_event_candidate_success(
                    identity=self.identity,
                    upstream_triage_signature=triage_signature,
                    upstream_incident_signature=incident_signature,
                    upstream_event_match_signature=event_match_signature,
                    result=result,
                    rendered_input=rendered_input,
                    raw_output=raw_output,
                    output_attempts=attempts,
                )
                stats.event_succeeded += 1
                if verbose:
                    print(
                        f"[CANDIDATE] {result.event_id} sources={len(result.source_urls)} "
                        f"{result.title}"
                    )
                    print(f"  summary: {result.summary}")
            except Exception as exc:
                actual_error = exc
                if isinstance(exc, StageExecutionError):
                    rendered_input = exc.rendered_input
                    raw_output = exc.raw_output
                    attempts = exc.output_attempts
                    actual_error = exc.cause
                self.store.save_event_candidate_failure(
                    identity=self.identity,
                    event_id=group.event_id,
                    upstream_triage_signature=triage_signature,
                    upstream_incident_signature=incident_signature,
                    upstream_event_match_signature=event_match_signature,
                    rendered_input=rendered_input,
                    raw_output=raw_output,
                    output_attempts=attempts,
                    error=actual_error,
                )
                stats.event_failed += 1
                print(
                    f"[FAILED   ] {group.event_id} candidate: "
                    f"{type(actual_error).__name__}: {actual_error}"
                )
        return stats

    def compose_policies(
        self,
        *,
        triage_signature: str,
        policy_signature: str,
        only_ids: list[str] | tuple[str, ...] | None = None,
    ) -> int:
        rows = self.store.list_success_facts(
            "policy",
            upstream_triage_signature=triage_signature,
            analysis_signature=policy_signature,
            only_ids=only_ids,
        )
        count = 0
        for row in rows:
            policy = PolicyResult.model_validate_json(row["result_json"])
            result = PolicyCandidateResult(
                policy_id=deterministic_policy_id(policy.source_article_id),
                source_article_id=policy.source_article_id,
                policy_time=policy.policy_time,
                title=policy.title,
                source_url=policy.source_url,
                issuer=policy.issuer,
                policy_name=policy.policy_name,
                policy_status=policy.policy_status.value,
                effective_time=policy.effective_time,
                affected_entities=policy.affected_entities,
                requirements=policy.requirements,
                key_changes=policy.key_changes,
                impact=policy.impact,
                summary=policy.summary,
            )
            self.store.save_policy_candidate(
                result=result,
                upstream_triage_signature=triage_signature,
                upstream_policy_signature=policy_signature,
                compose_version=_POLICY_CANDIDATE_COMPOSE_VERSION,
            )
            count += 1
        return count


def export_candidates(
    *,
    store: NewsAgentStore,
    output_dir: str | Path,
    triage_signature: str,
    incident_signature: str,
    policy_signature: str,
    event_match_signature: str,
    event_candidate_signature: str,
    event_ids: list[str] | tuple[str, ...] | None = None,
    policy_ids: list[str] | tuple[str, ...] | None = None,
) -> tuple[Path, Path]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    event_rows = store.list_event_candidates(
        upstream_triage_signature=triage_signature,
        upstream_event_match_signature=event_match_signature,
        analysis_signature=event_candidate_signature,
    )
    policy_rows = store.list_policy_candidates(
        upstream_triage_signature=triage_signature,
        upstream_policy_signature=policy_signature,
        compose_version=_POLICY_CANDIDATE_COMPOSE_VERSION,
    )
    events = [EventCandidateResult.model_validate_json(row["result_json"]) for row in event_rows]
    policies = [PolicyCandidateResult.model_validate_json(row["result_json"]) for row in policy_rows]
    if event_ids is not None:
        wanted_events = set(event_ids)
        events = [item for item in events if item.event_id in wanted_events]
    if policy_ids is not None:
        wanted_policies = set(policy_ids)
        policies = [item for item in policies if item.policy_id in wanted_policies]
    manifest = {
        "triage_signature": triage_signature,
        "incident_signature": incident_signature,
        "policy_signature": policy_signature,
        "event_match_signature": event_match_signature,
        "event_candidate_signature": event_candidate_signature,
        "policy_compose_version": _POLICY_CANDIDATE_COMPOSE_VERSION,
        "event_count": len(events),
        "policy_count": len(policies),
    }
    json_path = output / "candidates.json"
    json_path.write_text(
        json.dumps(
            {
                "manifest": manifest,
                "events": [x.model_dump(mode="json") for x in events],
                "policies": [x.model_dump(mode="json") for x in policies],
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    lines: list[str] = ["# News Agent MVP 候选资讯", "", "## 运行信息", ""]
    for key, value in manifest.items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## 安全事件候选", ""])
    if not events:
        lines.append("无。")
    for index, item in enumerate(events, start=1):
        lines.extend(
            [
                f"### {index}. {item.title}",
                "",
                f"- Event ID：{item.event_id}",
                f"- 时间：{item.event_time}",
                f"- 受害主体：{item.victim}",
                f"- 攻击主体：{item.attacker}",
                f"- 攻击路径/原因：{item.attack_vector_or_cause}",
                f"- 受影响系统：{item.affected_system}",
                f"- 造成后果：{item.impact}",
                f"- 泄露数据范围：{item.data_breach_scope}",
                f"- IOC：IP {item.ioc.ip_count} / 域名 {item.ioc.domain_count} / URL {item.ioc.url_count} / Hash {item.ioc.hash_count} / 文件路径 {item.ioc.file_path_count}",
                f"- 来源：{'；'.join(item.source_urls)}",
                "",
                f"概述：{item.summary}",
                "",
                f"启示：{item.lesson}",
                "",
            ]
        )
    lines.extend(["## 合规政策候选", ""])
    if not policies:
        lines.append("无。")
    for index, item in enumerate(policies, start=1):
        lines.extend(
            [
                f"### {index}. {item.title}",
                "",
                f"- Policy ID：{item.policy_id}",
                f"- 时间：{item.policy_time}",
                f"- 发布机构：{item.issuer}",
                f"- 政策状态：{item.policy_status}",
                f"- 生效时间：{item.effective_time}",
                f"- 影响主体：{'；'.join(item.affected_entities) or 'unknown'}",
                f"- 来源：{item.source_url}",
                "",
                f"主要要求：{'；'.join(item.requirements) or 'unknown'}",
                "",
                f"关键变化：{'；'.join(item.key_changes) or 'unknown'}",
                "",
                f"合规影响：{item.impact}",
                "",
                f"概述：{item.summary}",
                "",
            ]
        )
    md_path = output / "candidates.md"
    md_path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    return json_path, md_path
