from __future__ import annotations

from contextvars import ContextVar, Token
from typing import Any

_OUTPUT_ATTEMPTS: ContextVar[list[dict[str, Any]] | None] = ContextVar(
    "news_agent_output_attempts", default=None
)


def start_trace() -> tuple[list[dict[str, Any]], Token]:
    attempts: list[dict[str, Any]] = []
    return attempts, _OUTPUT_ATTEMPTS.set(attempts)


def finish_trace(token: Token) -> None:
    _OUTPUT_ATTEMPTS.reset(token)


def begin_attempt(text: str, retry_index: int) -> dict[str, Any]:
    attempts = _OUTPUT_ATTEMPTS.get()
    attempt = {
        "attempt": (len(attempts) + 1) if attempts is not None else 1,
        "status": "PENDING",
        "retry_index": retry_index,
        "raw_text": text,
        "error_type": None,
        "error_message": None,
    }
    if attempts is not None:
        attempts.append(attempt)
    return attempt


def fail_attempt(attempt: dict[str, Any], error_type: str, message: str) -> None:
    attempt["status"] = "INVALID"
    attempt["error_type"] = error_type
    attempt["error_message"] = message[:4000]


def pass_attempt(attempt: dict[str, Any]) -> None:
    attempt["status"] = "VALID"
