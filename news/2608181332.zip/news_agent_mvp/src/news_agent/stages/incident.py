from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pydantic_ai import Agent, ModelRetry, RunContext, TextOutput
from pydantic_ai.capabilities import Capability

from ..config import AppConfig
from ..contracts import CollectorArticle, IncidentResult
from ..provider import build_model
from ..tree_text import TreeTextError, parse_incident_output, render_article
from ._attempts import begin_attempt, fail_attempt, finish_trace, pass_attempt, start_trace
from .base import IncidentExecution, IncidentExecutionError


def _validate_linkage(ctx: RunContext[CollectorArticle], result: IncidentResult) -> None:
    if result.source_article_id != ctx.deps.source_article_id:
        raise ValueError(
            "source_article_id 与输入不一致。必须原样返回："
            f"{ctx.deps.source_article_id}"
        )
    if result.source_url != ctx.deps.url:
        raise ValueError(f"source_url 与输入不一致。必须原样返回：{ctx.deps.url}")


def _validate_iocs_are_grounded(article: CollectorArticle, result: IncidentResult) -> None:
    content = article.content.casefold()
    missing: list[str] = []
    for group_name, values in result.ioc.model_dump().items():
        for value in values:
            if value.casefold() not in content:
                missing.append(f"{group_name}={value}")
    if missing:
        joined = "; ".join(missing[:8])
        raise ValueError(
            "IOC 必须从正文原样提取，以下值无法在正文中找到："
            f"{joined}。不要根据常识补充或改写/去混淆 IOC。"
        )


def _parse_output(ctx: RunContext[CollectorArticle], text: str) -> IncidentResult:
    attempt = begin_attempt(text, ctx.retry)
    try:
        result = parse_incident_output(text)
        _validate_linkage(ctx, result)
        _validate_iocs_are_grounded(ctx.deps, result)
    except (TreeTextError, ValueError) as exc:
        fail_attempt(attempt, type(exc).__name__, str(exc))
        raise ModelRetry(
            "输出无法通过 incident-extract 数据契约/事实约束校验。"
            "请只按 SKILL.md 规定的树状格式重新输出，并只提取正文有证据的事实。"
            f"错误：{exc}"
        ) from exc
    pass_attempt(attempt)
    return result


@dataclass
class PydanticAIIncidentRuntime:
    config: AppConfig
    skill_text: str

    def __post_init__(self) -> None:
        model, model_settings = build_model(self.config)
        capability = Capability(
            id="incident-extract",
            description="Extract grounded security incident facts from one selected article.",
            instructions=self.skill_text,
            defer_loading=False,
        )
        self._agent = Agent(
            model,
            deps_type=CollectorArticle,
            output_type=TextOutput(_parse_output),
            capabilities=[capability],
            model_settings=model_settings,
            retries={"output": self.config.runtime.output_retries},
        )

    def run(self, article: CollectorArticle) -> IncidentExecution:
        prompt = render_article(article, max_content_chars=self.config.runtime.max_content_chars)
        attempts, token = start_trace()
        try:
            result = self._agent.run_sync(prompt, deps=article)
            parsed: IncidentResult = result.output
            raw_output = str(attempts[-1].get("raw_text") or "") if attempts else ""
            return IncidentExecution(
                result=parsed,
                rendered_input=prompt,
                raw_output=raw_output,
                output_attempts=tuple(dict(item) for item in attempts),
            )
        except Exception as exc:
            raw_output = str(attempts[-1].get("raw_text") or "") if attempts else ""
            raise IncidentExecutionError(
                cause=exc,
                rendered_input=prompt,
                raw_output=raw_output,
                output_attempts=tuple(dict(item) for item in attempts),
            ) from exc
        finally:
            finish_trace(token)
