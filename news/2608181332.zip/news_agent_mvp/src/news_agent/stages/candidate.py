from __future__ import annotations

from dataclasses import dataclass

from pydantic_ai import Agent, ModelRetry, RunContext, TextOutput
from pydantic_ai.capabilities import Capability

from ..config import AppConfig
from ..contracts import EventCandidateDraft
from ..provider import build_model
from ..tree_text import TreeTextError, parse_event_candidate_output, render_event_candidate_input
from ._attempts import begin_attempt, fail_attempt, finish_trace, pass_attempt, start_trace
from .base import EventCandidateExecution, EventCandidateExecutionError, EventCandidateInput


def _parse_output(ctx: RunContext[EventCandidateInput], text: str) -> EventCandidateDraft:
    attempt = begin_attempt(text, ctx.retry)
    try:
        result = parse_event_candidate_output(text)
    except TreeTextError as exc:
        fail_attempt(attempt, type(exc).__name__, str(exc))
        raise ModelRetry(
            "输出无法通过 candidate-compose 数据契约。"
            "请严格按 SKILL.md 的树状格式重新输出，不要增加字段。"
            f"错误：{exc}"
        ) from exc
    pass_attempt(attempt)
    return result


@dataclass
class PydanticAIEventCandidateRuntime:
    config: AppConfig
    skill_text: str

    def __post_init__(self) -> None:
        model, model_settings = build_model(self.config)
        capability = Capability(
            id="candidate-compose",
            description="Compose one human-reviewable security event candidate from grouped article facts.",
            instructions=self.skill_text,
            defer_loading=False,
        )
        self._agent = Agent(
            model,
            deps_type=EventCandidateInput,
            output_type=TextOutput(_parse_output),
            capabilities=[capability],
            model_settings=model_settings,
            retries={"output": self.config.runtime.output_retries},
        )

    def run(self, data: EventCandidateInput) -> EventCandidateExecution:
        prompt = render_event_candidate_input(
            event_id=data.event_id,
            canonical_title=data.canonical_title,
            match_reason=data.match_reason,
            incidents=list(data.incidents),
        )
        attempts, token = start_trace()
        try:
            result = self._agent.run_sync(prompt, deps=data)
            parsed: EventCandidateDraft = result.output
            raw_output = str(attempts[-1].get("raw_text") or "") if attempts else ""
            return EventCandidateExecution(
                result=parsed,
                rendered_input=prompt,
                raw_output=raw_output,
                output_attempts=tuple(dict(item) for item in attempts),
            )
        except Exception as exc:
            raw_output = str(attempts[-1].get("raw_text") or "") if attempts else ""
            raise EventCandidateExecutionError(
                cause=exc,
                rendered_input=prompt,
                raw_output=raw_output,
                output_attempts=tuple(dict(item) for item in attempts),
            ) from exc
        finally:
            finish_trace(token)
