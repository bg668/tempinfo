from __future__ import annotations

from dataclasses import dataclass

from pydantic_ai import Agent, ModelRetry, RunContext, TextOutput
from pydantic_ai.capabilities import Capability

from ..config import AppConfig
from ..contracts import EventMatchResult
from ..provider import build_model
from ..tree_text import TreeTextError, parse_event_match_output, render_event_match_input
from ._attempts import begin_attempt, fail_attempt, finish_trace, pass_attempt, start_trace
from .base import EventMatchExecution, EventMatchExecutionError, EventMatchInput


def _validate_partition(ctx: RunContext[EventMatchInput], result: EventMatchResult) -> None:
    expected = {item.source_article_id for item in ctx.deps.incidents}
    seen: set[str] = set()
    duplicates: set[str] = set()
    unknown: set[str] = set()
    for group in result.groups.values():
        for source_id in group.member_article_ids:
            if source_id not in expected:
                unknown.add(source_id)
            if source_id in seen:
                duplicates.add(source_id)
            seen.add(source_id)
    missing = expected - seen
    if unknown or duplicates or missing:
        parts: list[str] = []
        if missing:
            parts.append(f"missing={sorted(missing)}")
        if duplicates:
            parts.append(f"duplicate={sorted(duplicates)}")
        if unknown:
            parts.append(f"unknown={sorted(unknown)}")
        raise ValueError(
            "事件分组必须恰好覆盖输入中的每篇文章一次；" + "; ".join(parts)
        )


def _parse_output(ctx: RunContext[EventMatchInput], text: str) -> EventMatchResult:
    attempt = begin_attempt(text, ctx.retry)
    try:
        result = parse_event_match_output(text)
        _validate_partition(ctx, result)
    except (TreeTextError, ValueError) as exc:
        fail_attempt(attempt, type(exc).__name__, str(exc))
        raise ModelRetry(
            "输出无法通过 event-match 数据契约。请按 SKILL.md 重新分组；"
            "所有输入文章必须且只能出现一次，不确定是否同一事件时拆开。"
            f"错误：{exc}"
        ) from exc
    pass_attempt(attempt)
    return result


@dataclass
class PydanticAIEventMatchRuntime:
    config: AppConfig
    skill_text: str

    def __post_init__(self) -> None:
        model, model_settings = build_model(self.config)
        capability = Capability(
            id="event-match",
            description="Conservatively group extracted incident facts that describe the same real-world event.",
            instructions=self.skill_text,
            defer_loading=False,
        )
        self._agent = Agent(
            model,
            deps_type=EventMatchInput,
            output_type=TextOutput(_parse_output),
            capabilities=[capability],
            model_settings=model_settings,
            retries={"output": self.config.runtime.output_retries},
        )

    def run(self, data: EventMatchInput) -> EventMatchExecution:
        prompt = render_event_match_input(
            triage_signature=data.triage_signature,
            incident_signature=data.incident_signature,
            incidents=list(data.incidents),
        )
        attempts, token = start_trace()
        try:
            result = self._agent.run_sync(prompt, deps=data)
            parsed: EventMatchResult = result.output
            raw_output = str(attempts[-1].get("raw_text") or "") if attempts else ""
            return EventMatchExecution(
                result=parsed,
                rendered_input=prompt,
                raw_output=raw_output,
                output_attempts=tuple(dict(item) for item in attempts),
            )
        except Exception as exc:
            raw_output = str(attempts[-1].get("raw_text") or "") if attempts else ""
            raise EventMatchExecutionError(
                cause=exc,
                rendered_input=prompt,
                raw_output=raw_output,
                output_attempts=tuple(dict(item) for item in attempts),
            ) from exc
        finally:
            finish_trace(token)
