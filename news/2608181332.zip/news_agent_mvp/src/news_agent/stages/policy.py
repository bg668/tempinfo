from __future__ import annotations

from dataclasses import dataclass

from pydantic_ai import Agent, ModelRetry, RunContext, TextOutput
from pydantic_ai.capabilities import Capability

from ..config import AppConfig
from ..contracts import CollectorArticle, PolicyResult
from ..provider import build_model
from ..tree_text import TreeTextError, parse_policy_output, render_article
from ._attempts import begin_attempt, fail_attempt, finish_trace, pass_attempt, start_trace
from .base import PolicyExecution, PolicyExecutionError


def _parse_output(ctx: RunContext[CollectorArticle], text: str) -> PolicyResult:
    attempt = begin_attempt(text, ctx.retry)
    try:
        result = parse_policy_output(text)
        if result.source_article_id != ctx.deps.source_article_id:
            raise ValueError(
                "source_article_id 与输入不一致。必须原样返回："
                f"{ctx.deps.source_article_id}"
            )
        if result.source_url != ctx.deps.url:
            raise ValueError(f"source_url 与输入不一致。必须原样返回：{ctx.deps.url}")
    except (TreeTextError, ValueError) as exc:
        fail_attempt(attempt, type(exc).__name__, str(exc))
        raise ModelRetry(
            "输出无法通过 policy-extract 数据契约校验。"
            "请只按 SKILL.md 规定的树状格式重新输出，并只提取正文有证据的事实。"
            f"错误：{exc}"
        ) from exc
    pass_attempt(attempt)
    return result


@dataclass
class PydanticAIPolicyRuntime:
    config: AppConfig
    skill_text: str

    def __post_init__(self) -> None:
        model, model_settings = build_model(self.config)
        capability = Capability(
            id="policy-extract",
            description="Extract grounded Chinese cybersecurity compliance policy facts from one selected article.",
            instructions=self.skill_text,
            defer_loading=False,
        )
        self._agent = Agent(
            model,
            deps_type=CollectorArticle,
            output_type=TextOutput(_parse_output),
            capabilities=[capability],
            model_settings=model_settings,
            retries={"output": self.config.runtime.output_retries},
        )

    def run(self, article: CollectorArticle) -> PolicyExecution:
        prompt = render_article(article, max_content_chars=self.config.runtime.max_content_chars)
        attempts, token = start_trace()
        try:
            result = self._agent.run_sync(prompt, deps=article)
            parsed: PolicyResult = result.output
            raw_output = str(attempts[-1].get("raw_text") or "") if attempts else ""
            return PolicyExecution(
                result=parsed,
                rendered_input=prompt,
                raw_output=raw_output,
                output_attempts=tuple(dict(item) for item in attempts),
            )
        except Exception as exc:
            raw_output = str(attempts[-1].get("raw_text") or "") if attempts else ""
            raise PolicyExecutionError(
                cause=exc,
                rendered_input=prompt,
                raw_output=raw_output,
                output_attempts=tuple(dict(item) for item in attempts),
            ) from exc
        finally:
            finish_trace(token)
