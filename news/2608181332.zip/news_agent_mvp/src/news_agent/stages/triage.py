from __future__ import annotations

from contextvars import ContextVar
from dataclasses import dataclass
from typing import Any

from pydantic_ai import Agent, ModelRetry, RunContext, TextOutput
from pydantic_ai.capabilities import Capability

from ..config import AppConfig
from ..contracts import CollectorArticle, TriageResult
from ..provider import build_model
from ..tree_text import TreeTextError, parse_triage_output, render_article
from .base import TriageExecution, TriageExecutionError

_OUTPUT_ATTEMPTS: ContextVar[list[dict[str, Any]] | None] = ContextVar(
    "triage_output_attempts", default=None
)


def _begin_attempt(text: str, retry_index: int) -> dict[str, Any]:
    attempts = _OUTPUT_ATTEMPTS.get()
    attempt = {
        "attempt": (len(attempts) + 1) if attempts is not None else 1,
        "status": "PENDING",
        "retry_index": retry_index,
        "raw_text": text,
        "error_type": None,
        "error_message": None,
    }
    if attempts is not None:
        attempts.append(attempt)
    return attempt


def _fail_attempt(attempt: dict[str, Any], error_type: str, message: str) -> None:
    attempt["status"] = "INVALID"
    attempt["error_type"] = error_type
    attempt["error_message"] = message[:4000]


def _parse_output(ctx: RunContext[CollectorArticle], text: str) -> TriageResult:
    """Parse/validate one model output attempt and retain its trace before ModelRetry."""
    attempt = _begin_attempt(text, ctx.retry)
    try:
        result = parse_triage_output(text)
    except TreeTextError as exc:
        _fail_attempt(attempt, type(exc).__name__, str(exc))
        raise ModelRetry(
            "输出无法通过数据契约校验。请只按 SKILL.md 规定的树状格式重新输出。"
            f"错误：{exc}"
        ) from exc

    if result.source_article_id != ctx.deps.source_article_id:
        message = (
            "source_article_id 与输入不一致。必须原样返回："
            f"{ctx.deps.source_article_id}"
        )
        _fail_attempt(attempt, "SourceArticleIdMismatch", message)
        raise ModelRetry(message)

    attempt["status"] = "VALID"
    return result


@dataclass
class PydanticAITriageRuntime:
    config: AppConfig
    skill_text: str

    def __post_init__(self) -> None:
        model, model_settings = build_model(self.config)

        capability = Capability(
            id="article-triage",
            description="Stage 1 article triage rules.",
            instructions=self.skill_text,
            defer_loading=False,
        )

        self._agent = Agent(
            model,
            deps_type=CollectorArticle,
            output_type=TextOutput(_parse_output),
            capabilities=[capability],
            model_settings=model_settings,
            retries={"output": self.config.runtime.output_retries},
        )

    def run(self, article: CollectorArticle) -> TriageExecution:
        prompt = render_article(article, max_content_chars=self.config.runtime.max_content_chars)
        attempts: list[dict[str, Any]] = []
        token = _OUTPUT_ATTEMPTS.set(attempts)
        try:
            result = self._agent.run_sync(prompt, deps=article)
            parsed: TriageResult = result.output
            raw_output = str(attempts[-1].get("raw_text") or "") if attempts else ""
            return TriageExecution(
                result=parsed,
                rendered_input=prompt,
                raw_output=raw_output,
                output_attempts=tuple(dict(item) for item in attempts),
            )
        except Exception as exc:
            raw_output = str(attempts[-1].get("raw_text") or "") if attempts else ""
            raise TriageExecutionError(
                cause=exc,
                rendered_input=prompt,
                raw_output=raw_output,
                output_attempts=tuple(dict(item) for item in attempts),
            ) from exc
        finally:
            _OUTPUT_ATTEMPTS.reset(token)
