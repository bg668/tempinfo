from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Iterable

from .collector_adapter import CollectorAdapter
from .config import AppConfig
from .contracts import CONTRACT_VERSION, CollectorArticle
from .scoring import calculate_total_score
from .skill import skill_sha256
from .stages.base import TriageExecutionError, TriageRuntime
from .store import NewsAgentStore, RunIdentity
from .tree_text import render_article

STAGE_VERSION = "article-triage.v1.2"


def build_identity(config: AppConfig, skill_text: str) -> RunIdentity:
    skill_hash = skill_sha256(skill_text)
    payload = {
        "stage_version": STAGE_VERSION,
        "contract_version": CONTRACT_VERSION,
        "skill_sha256": skill_hash,
        "provider": config.provider.model_dump(exclude={"api_key_env"}),
        "model": config.model.model_dump(),
        "runtime": config.runtime.model_dump(),
        "scoring": config.scoring.model_dump(),
    }
    signature = hashlib.sha256(
        json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()[:24]
    return RunIdentity(
        analysis_signature=signature,
        stage_version=STAGE_VERSION,
        contract_version=CONTRACT_VERSION,
        skill_sha256=skill_hash,
        model_name=config.model.name,
        skill_snapshot=skill_text,
    )


def article_input_sha256(article: CollectorArticle, max_content_chars: int) -> str:
    text = render_article(article, max_content_chars=max_content_chars)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _print_verbose_success(result, attempts: tuple[dict, ...]) -> None:
    scores = result.scores
    print(f"  category: {result.category.value}")
    print(f"  nature: {result.content_nature.value}")
    print(
        "  scores: "
        f"relevance={scores.relevance} impact={scores.impact} freshness={scores.freshness} "
        f"evidence_quality={scores.evidence_quality} audience_value={scores.audience_value}"
    )
    print(f"  reason: {result.reason}")
    invalid = [x for x in attempts if x.get("status") == "INVALID"]
    if invalid:
        print(f"  output_retries: {len(invalid)}")
        for item in invalid:
            print(
                f"    attempt[{item.get('attempt')}]: {item.get('error_type')}: "
                f"{item.get('error_message')}"
            )


@dataclass
class PipelineStats:
    processed: int = 0
    keep: int = 0
    drop: int = 0
    uncertain: int = 0
    failed: int = 0


class TriagePipeline:
    def __init__(
        self,
        *,
        config: AppConfig,
        collector: CollectorAdapter,
        store: NewsAgentStore,
        runtime: TriageRuntime,
        skill_text: str,
    ):
        self.config = config
        self.collector = collector
        self.store = store
        self.runtime = runtime
        self.identity = build_identity(config, skill_text)

    def run(
        self,
        *,
        limit: int | None = None,
        only_ids: Iterable[str] | None = None,
        force: bool = False,
        verbose: bool = False,
    ) -> PipelineStats:
        excluded = set() if force else self.store.successful_ids(self.identity.analysis_signature)
        stats = PipelineStats()
        for article in self.collector.iter_fetched(
            exclude_ids=excluded,
            only_ids=only_ids,
            limit=limit,
        ):
            input_hash = article_input_sha256(article, self.config.runtime.max_content_chars)
            rendered_input = render_article(
                article, max_content_chars=self.config.runtime.max_content_chars
            )
            raw_output = ""
            output_attempts: tuple[dict, ...] = ()
            try:
                execution = self.runtime.run(article)
                result = execution.result
                rendered_input = execution.rendered_input
                raw_output = execution.raw_output
                output_attempts = execution.output_attempts
                total_score = calculate_total_score(result.scores, self.config.scoring)
                self.store.save_success(
                    identity=self.identity,
                    article=article,
                    input_sha256=input_hash,
                    result=result,
                    total_score=total_score,
                    rendered_input=rendered_input,
                    raw_output=raw_output,
                    output_attempts=output_attempts,
                )
                stats.processed += 1
                if result.decision.value == "KEEP":
                    stats.keep += 1
                elif result.decision.value == "DROP":
                    stats.drop += 1
                else:
                    stats.uncertain += 1
                print(
                    f"[{result.decision.value:<9}] {article.source_article_id} "
                    f"score={total_score:>5.1f} route={result.route.value:<17} {article.title}"
                )
                if verbose:
                    _print_verbose_success(result, output_attempts)
            except Exception as exc:
                actual_error = exc
                if isinstance(exc, TriageExecutionError):
                    rendered_input = exc.rendered_input
                    raw_output = exc.raw_output
                    output_attempts = exc.output_attempts
                    actual_error = exc.cause
                self.store.save_failure(
                    identity=self.identity,
                    article=article,
                    input_sha256=input_hash,
                    rendered_input=rendered_input,
                    raw_output=raw_output,
                    output_attempts=output_attempts,
                    error=actual_error,
                )
                stats.processed += 1
                stats.failed += 1
                print(
                    f"[FAILED   ] {article.source_article_id} "
                    f"{type(actual_error).__name__}: {actual_error}"
                )
                if verbose and output_attempts:
                    for item in output_attempts:
                        print(
                            f"  attempt[{item.get('attempt')}]: {item.get('status')} "
                            f"{item.get('error_type') or ''} {item.get('error_message') or ''}".rstrip()
                        )
        return stats
