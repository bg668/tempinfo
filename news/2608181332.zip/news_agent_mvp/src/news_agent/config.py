from __future__ import annotations

import os
from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, model_validator


class ProviderConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    type: Literal["openai_compatible"] = "openai_compatible"
    base_url: str = Field(min_length=1)
    api_key_env: str = "NEWS_AGENT_API_KEY"


class ModelConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(min_length=1)
    api_mode: Literal["chat", "responses"] = "chat"
    thinking: Literal["minimal", "low", "medium", "high", "xhigh"] | None = None
    max_tokens: int | None = Field(default=4096, gt=0)
    temperature: float | None = None


class RuntimeConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    output_retries: int = Field(default=2, ge=0, le=5)
    max_content_chars: int = Field(default=50000, ge=1000)


class ScoringConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    relevance: float = Field(default=0.2, ge=0)
    impact: float = Field(default=0.2, ge=0)
    freshness: float = Field(default=0.2, ge=0)
    evidence_quality: float = Field(default=0.2, ge=0)
    audience_value: float = Field(default=0.2, ge=0)

    @model_validator(mode="after")
    def validate_weight_sum(self) -> "ScoringConfig":
        total = sum(self.model_dump().values())
        if total <= 0:
            raise ValueError("at least one scoring weight must be positive")
        return self


class AppConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    provider: ProviderConfig
    model: ModelConfig
    runtime: RuntimeConfig = RuntimeConfig()
    scoring: ScoringConfig = ScoringConfig()

    def api_key(self) -> str:
        value = os.getenv(self.provider.api_key_env)
        if not value:
            raise RuntimeError(
                f"environment variable {self.provider.api_key_env!r} is required for the provider API key"
            )
        return value


def load_config(path: str | Path) -> AppConfig:
    path = Path(path)
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    return AppConfig.model_validate(raw)
