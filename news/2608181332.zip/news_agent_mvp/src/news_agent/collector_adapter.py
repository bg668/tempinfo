from __future__ import annotations

import sqlite3
from collections.abc import Iterable
from pathlib import Path

from .contracts import CollectorArticle


class CollectorSchemaError(RuntimeError):
    pass


_REQUIRED_FEED = {"id", "stable_id", "url", "fetch_status"}
_REQUIRED_CONTENT = {"article_id", "title", "account", "published_at", "content"}


def _columns(conn: sqlite3.Connection, table: str) -> set[str]:
    return {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}


def validate_collector_schema(conn: sqlite3.Connection) -> None:
    feed = _columns(conn, "feed_items")
    content = _columns(conn, "article_contents")
    missing_feed = _REQUIRED_FEED - feed
    missing_content = _REQUIRED_CONTENT - content
    if missing_feed or missing_content:
        raise CollectorSchemaError(
            f"collector schema mismatch: feed_items missing={sorted(missing_feed)}, "
            f"article_contents missing={sorted(missing_content)}"
        )


class CollectorAdapter:
    """Read-only compatibility boundary around the Collector SQLite database."""

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        if not self.db_path.exists():
            raise FileNotFoundError(self.db_path)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(f"file:{self.db_path}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        validate_collector_schema(conn)
        return conn

    def get(self, source_article_id: str) -> CollectorArticle | None:
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT
                    f.stable_id AS source_article_id,
                    COALESCE(a.account, '') AS account,
                    COALESCE(a.title, '') AS title,
                    f.url AS url,
                    a.published_at AS published_at,
                    a.content AS content
                FROM feed_items f
                JOIN article_contents a ON a.article_id = f.id
                WHERE f.fetch_status = 'FETCHED'
                  AND a.content IS NOT NULL
                  AND length(trim(a.content)) > 0
                  AND f.stable_id = ?
                """,
                (source_article_id,),
            ).fetchone()
        return CollectorArticle.model_validate(dict(row)) if row else None

    def iter_fetched(
        self,
        *,
        exclude_ids: Iterable[str] = (),
        only_ids: Iterable[str] | None = None,
        limit: int | None = None,
    ) -> Iterable[CollectorArticle]:
        excluded = set(exclude_ids)
        requested = set(only_ids) if only_ids is not None else None
        yielded = 0
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT
                    f.stable_id AS source_article_id,
                    COALESCE(a.account, '') AS account,
                    COALESCE(a.title, '') AS title,
                    f.url AS url,
                    a.published_at AS published_at,
                    a.content AS content
                FROM feed_items f
                JOIN article_contents a ON a.article_id = f.id
                WHERE f.fetch_status = 'FETCHED'
                  AND a.content IS NOT NULL
                  AND length(trim(a.content)) > 0
                ORDER BY COALESCE(a.published_at, f.published_at, f.discovered_at) DESC, f.id DESC
                """
            )
            for row in rows:
                article_id = row["source_article_id"]
                if article_id in excluded:
                    continue
                if requested is not None and article_id not in requested:
                    continue
                yield CollectorArticle.model_validate(dict(row))
                yielded += 1
                if limit is not None and yielded >= limit:
                    break
