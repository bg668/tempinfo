from __future__ import annotations

import json
from pathlib import Path
from typing import Literal

from .contracts import (
    EventCandidateDraft,
    EventMatchResult,
    IncidentResult,
    PolicyResult,
    TriageResult,
)

SchemaStage = Literal[
    "article-triage",
    "incident-extract",
    "policy-extract",
    "event-match",
    "candidate-compose",
]

_MODELS = {
    "article-triage": TriageResult,
    "incident-extract": IncidentResult,
    "policy-extract": PolicyResult,
    "event-match": EventMatchResult,
    "candidate-compose": EventCandidateDraft,
}

_DEFAULT_PATHS = {
    "article-triage": Path("skills/article-triage/schema.json"),
    "incident-extract": Path("skills/incident-extract/schema.json"),
    "policy-extract": Path("skills/policy-extract/schema.json"),
    "event-match": Path("skills/event-match/schema.json"),
    "candidate-compose": Path("skills/candidate-compose/schema.json"),
}


def export_schema(stage: SchemaStage, path: str | Path | None = None) -> Path:
    output = Path(path) if path is not None else _DEFAULT_PATHS[stage]
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(_MODELS[stage].model_json_schema(), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return output


def export_triage_schema(path: str | Path) -> None:
    export_schema("article-triage", path)


def export_all_schemas() -> list[Path]:
    return [export_schema(stage) for stage in _MODELS]
