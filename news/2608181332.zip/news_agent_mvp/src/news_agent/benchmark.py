from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from .store import NewsAgentStore


@dataclass
class BenchmarkCase:
    source_article_id: str
    expected_decision: str
    expected_route: str
    note: str = ""
    status: str = "MISSING"
    actual_decision: str | None = None
    actual_route: str | None = None
    row: object | None = None

    @property
    def decision_correct(self) -> bool:
        return self.status == "SUCCESS" and self.actual_decision == self.expected_decision

    @property
    def route_correct(self) -> bool:
        return self.status == "SUCCESS" and self.actual_route == self.expected_route

    @property
    def matched(self) -> bool:
        return self.decision_correct and self.route_correct


@dataclass
class BenchmarkSummary:
    total: int = 0
    available: int = 0
    decision_correct: int = 0
    route_correct: int = 0
    cases: list[BenchmarkCase] = field(default_factory=list)

    @property
    def decision_accuracy(self) -> float:
        return self.decision_correct / self.available if self.available else 0.0

    @property
    def route_accuracy(self) -> float:
        return self.route_correct / self.available if self.available else 0.0

    @property
    def mismatches(self) -> list[BenchmarkCase]:
        return [case for case in self.cases if case.status == "SUCCESS" and not case.matched]

    @property
    def unavailable(self) -> list[BenchmarkCase]:
        return [case for case in self.cases if case.status != "SUCCESS"]


def load_labels(path: str | Path) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def evaluate(
    store: NewsAgentStore,
    *,
    analysis_signature: str,
    labels_path: str | Path,
) -> BenchmarkSummary:
    summary = BenchmarkSummary()
    for label in load_labels(labels_path):
        case = BenchmarkCase(
            source_article_id=label["source_article_id"],
            expected_decision=label["expected_decision"],
            expected_route=label["expected_route"],
            note=label.get("note", ""),
        )
        summary.total += 1
        row = store.get_result(case.source_article_id, analysis_signature)
        if row is None:
            summary.cases.append(case)
            continue
        case.status = row["status"]
        case.actual_decision = row["decision"]
        case.actual_route = row["route"]
        case.row = row
        if row["status"] != "SUCCESS":
            summary.cases.append(case)
            continue
        summary.available += 1
        summary.decision_correct += int(case.decision_correct)
        summary.route_correct += int(case.route_correct)
        summary.cases.append(case)
    return summary
