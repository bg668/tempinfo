from __future__ import annotations

from typing import Any

from .config import AppConfig


def build_model(config: AppConfig) -> tuple[Any, Any]:
    """Build a Pydantic AI OpenAI-compatible model and model settings.

    Imports stay local so contract/adapter tests can run without provider packages.
    """
    from pydantic_ai import ModelSettings
    from pydantic_ai.models.openai import OpenAIChatModel, OpenAIResponsesModel
    from pydantic_ai.providers.openai import OpenAIProvider

    provider = OpenAIProvider(
        base_url=config.provider.base_url,
        api_key=config.api_key(),
    )
    if config.model.api_mode == "chat":
        model = OpenAIChatModel(config.model.name, provider=provider)
    else:
        model = OpenAIResponsesModel(config.model.name, provider=provider)

    settings_kwargs: dict[str, object] = {}
    if config.model.max_tokens is not None:
        settings_kwargs["max_tokens"] = config.model.max_tokens
    if config.model.temperature is not None:
        settings_kwargs["temperature"] = config.model.temperature
    if config.model.thinking is not None:
        settings_kwargs["thinking"] = config.model.thinking
    return model, ModelSettings(**settings_kwargs)
