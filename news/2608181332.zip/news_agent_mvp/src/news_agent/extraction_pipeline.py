from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Iterable, Literal

from .collector_adapter import CollectorAdapter
from .config import AppConfig
from .contracts import INCIDENT_CONTRACT_VERSION, POLICY_CONTRACT_VERSION
from .skill import skill_sha256
from .stages.base import (
    IncidentExecutionError,
    IncidentRuntime,
    PolicyExecutionError,
    PolicyRuntime,
    StageExecutionError,
)
from .store import NewsAgentStore, RunIdentity
from .tree_text import render_article

StageName = Literal["incident", "policy"]

_INCIDENT_STAGE_VERSION = "incident-extract.v1"
_POLICY_STAGE_VERSION = "policy-extract.v1"


def build_extraction_identity(
    config: AppConfig, skill_text: str, *, stage: StageName
) -> RunIdentity:
    if stage == "incident":
        stage_version = _INCIDENT_STAGE_VERSION
        contract_version = INCIDENT_CONTRACT_VERSION
    else:
        stage_version = _POLICY_STAGE_VERSION
        contract_version = POLICY_CONTRACT_VERSION
    skill_hash = skill_sha256(skill_text)
    payload = {
        "stage_version": stage_version,
        "contract_version": contract_version,
        "skill_sha256": skill_hash,
        "provider": config.provider.model_dump(exclude={"api_key_env"}),
        "model": config.model.model_dump(),
        "runtime": config.runtime.model_dump(),
    }
    signature = hashlib.sha256(
        json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()[:24]
    return RunIdentity(
        analysis_signature=signature,
        stage_version=stage_version,
        contract_version=contract_version,
        skill_sha256=skill_hash,
        model_name=config.model.name,
        skill_snapshot=skill_text,
    )


def extraction_input_sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


@dataclass
class ExtractionStats:
    eligible: int = 0
    processed: int = 0
    succeeded: int = 0
    failed: int = 0
    skipped_existing: int = 0
    missing_article: int = 0


def _print_invalid_attempts(attempts: tuple[dict, ...]) -> None:
    invalid = [x for x in attempts if x.get("status") == "INVALID"]
    if not invalid:
        return
    print(f"  output_retries: {len(invalid)}")
    for item in invalid:
        print(
            f"    attempt[{item.get('attempt')}]: {item.get('error_type')}: "
            f"{item.get('error_message')}"
        )


class ExtractionPipeline:
    def __init__(
        self,
        *,
        stage: StageName,
        config: AppConfig,
        collector: CollectorAdapter,
        store: NewsAgentStore,
        runtime: IncidentRuntime | PolicyRuntime,
        skill_text: str,
    ) -> None:
        self.stage = stage
        self.config = config
        self.collector = collector
        self.store = store
        self.runtime = runtime
        self.identity = build_extraction_identity(config, skill_text, stage=stage)
        self.route = "security_event" if stage == "incident" else "compliance_policy"

    def run(
        self,
        *,
        limit: int | None = None,
        only_ids: Iterable[str] | None = None,
        triage_signature: str | None = None,
        force: bool = False,
        verbose: bool = False,
    ) -> ExtractionStats:
        triage_rows = self.store.iter_kept_triage(
            route=self.route,
            triage_signature=triage_signature,
            only_ids=only_ids,
            limit=limit,
        )
        stats = ExtractionStats(eligible=len(triage_rows))
        for triage_row in triage_rows:
            source_id = triage_row["source_article_id"]
            upstream_signature = triage_row["analysis_signature"]
            if not force and self.store.extraction_success_exists(
                stage=self.stage,
                source_article_id=source_id,
                upstream_triage_signature=upstream_signature,
                analysis_signature=self.identity.analysis_signature,
            ):
                stats.skipped_existing += 1
                continue

            article = self.collector.get(source_id)
            if article is None:
                stats.missing_article += 1
                stats.failed += 1
                print(f"[MISSING  ] {source_id} Collector article not found")
                continue

            rendered_input = render_article(
                article, max_content_chars=self.config.runtime.max_content_chars
            )
            input_hash = extraction_input_sha256(rendered_input)
            raw_output = ""
            attempts: tuple[dict, ...] = ()
            stats.processed += 1
            try:
                execution = self.runtime.run(article)
                rendered_input = execution.rendered_input
                raw_output = execution.raw_output
                attempts = execution.output_attempts
                result = execution.result
                if self.stage == "incident":
                    self.store.save_incident_success(
                        identity=self.identity,
                        upstream_triage_signature=upstream_signature,
                        article=article,
                        input_sha256=input_hash,
                        result=result,
                        rendered_input=rendered_input,
                        raw_output=raw_output,
                        output_attempts=attempts,
                    )
                    counts = result.ioc.counts()
                    print(
                        f"[INCIDENT ] {source_id} victim={result.entities.victim.value:<18} "
                        f"ioc={counts['ip_count']}/{counts['domain_count']}/{counts['url_count']}/"
                        f"{counts['hash_count']}/{counts['file_path_count']} {result.title}"
                    )
                    if verbose:
                        print(f"  event_time: {result.event_time}")
                        print(
                            f"  attacker: {result.entities.attacker.value} "
                            f"({result.entities.attacker.certainty.value})"
                        )
                        print(f"  vector/cause: {result.entities.attack_vector_or_cause}")
                        print(f"  affected_system: {result.entities.affected_system}")
                        print(f"  impact: {result.entities.impact}")
                        print(f"  data_breach_scope: {result.data_breach_scope}")
                        print(f"  lesson: {result.lesson}")
                        print(f"  summary: {result.summary}")
                        _print_invalid_attempts(attempts)
                else:
                    self.store.save_policy_success(
                        identity=self.identity,
                        upstream_triage_signature=upstream_signature,
                        article=article,
                        input_sha256=input_hash,
                        result=result,
                        rendered_input=rendered_input,
                        raw_output=raw_output,
                        output_attempts=attempts,
                    )
                    print(
                        f"[POLICY   ] {source_id} status={result.policy_status.value:<17} "
                        f"issuer={result.issuer} {result.title}"
                    )
                    if verbose:
                        print(f"  policy_time: {result.policy_time}")
                        print(f"  effective_time: {result.effective_time}")
                        print(f"  affected_entities: {'; '.join(result.affected_entities) or '[]'}")
                        print(f"  requirements: {'; '.join(result.requirements) or '[]'}")
                        print(f"  key_changes: {'; '.join(result.key_changes) or '[]'}")
                        print(f"  impact: {result.impact}")
                        print(f"  summary: {result.summary}")
                        _print_invalid_attempts(attempts)
                stats.succeeded += 1
            except Exception as exc:
                actual_error = exc
                if isinstance(exc, StageExecutionError):
                    rendered_input = exc.rendered_input
                    raw_output = exc.raw_output
                    attempts = exc.output_attempts
                    actual_error = exc.cause
                if self.stage == "incident":
                    self.store.save_incident_failure(
                        identity=self.identity,
                        upstream_triage_signature=upstream_signature,
                        article=article,
                        input_sha256=input_hash,
                        rendered_input=rendered_input,
                        raw_output=raw_output,
                        output_attempts=attempts,
                        error=actual_error,
                    )
                else:
                    self.store.save_policy_failure(
                        identity=self.identity,
                        upstream_triage_signature=upstream_signature,
                        article=article,
                        input_sha256=input_hash,
                        rendered_input=rendered_input,
                        raw_output=raw_output,
                        output_attempts=attempts,
                        error=actual_error,
                    )
                stats.failed += 1
                print(
                    f"[FAILED   ] {source_id} {self.stage}: "
                    f"{type(actual_error).__name__}: {actual_error}"
                )
                if verbose:
                    _print_invalid_attempts(attempts)
        return stats
