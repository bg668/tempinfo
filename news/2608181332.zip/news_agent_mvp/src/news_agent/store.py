from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .contracts import (
    CollectorArticle,
    EventCandidateResult,
    EventMatchResult,
    IncidentResult,
    PolicyCandidateResult,
    PolicyResult,
    TriageResult,
)

SCHEMA_VERSION = "4"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS article_triage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_article_id TEXT NOT NULL,
    analysis_signature TEXT NOT NULL,
    stage_version TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    skill_sha256 TEXT NOT NULL,
    model_name TEXT NOT NULL,
    input_sha256 TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('SUCCESS', 'FAILED')),
    decision TEXT,
    route TEXT,
    category TEXT,
    content_nature TEXT,
    relevance INTEGER,
    impact INTEGER,
    freshness INTEGER,
    evidence_quality INTEGER,
    audience_value INTEGER,
    total_score REAL,
    reason TEXT,
    rendered_input TEXT,
    raw_output TEXT,
    output_attempts_json TEXT NOT NULL DEFAULT '[]',
    skill_snapshot TEXT NOT NULL DEFAULT '',
    error_type TEXT,
    error_message TEXT,
    analyzed_at TEXT NOT NULL,
    UNIQUE(source_article_id, analysis_signature)
);

CREATE INDEX IF NOT EXISTS idx_article_triage_signature_status
ON article_triage(analysis_signature, status);

CREATE TABLE IF NOT EXISTS article_incident_facts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_article_id TEXT NOT NULL,
    upstream_triage_signature TEXT NOT NULL,
    analysis_signature TEXT NOT NULL,
    stage_version TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    skill_sha256 TEXT NOT NULL,
    model_name TEXT NOT NULL,
    input_sha256 TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('SUCCESS', 'FAILED')),
    event_time TEXT,
    title TEXT,
    source_url TEXT,
    summary TEXT,
    victim_value TEXT,
    victim_certainty TEXT,
    attacker_value TEXT,
    attacker_certainty TEXT,
    attack_vector_or_cause TEXT,
    affected_system TEXT,
    impact TEXT,
    data_breach_scope TEXT,
    lesson TEXT,
    ioc_json TEXT,
    ip_count INTEGER,
    domain_count INTEGER,
    url_count INTEGER,
    hash_count INTEGER,
    file_path_count INTEGER,
    result_json TEXT,
    rendered_input TEXT,
    raw_output TEXT,
    output_attempts_json TEXT NOT NULL DEFAULT '[]',
    skill_snapshot TEXT NOT NULL DEFAULT '',
    error_type TEXT,
    error_message TEXT,
    analyzed_at TEXT NOT NULL,
    UNIQUE(source_article_id, upstream_triage_signature, analysis_signature)
);

CREATE INDEX IF NOT EXISTS idx_incident_signature_status
ON article_incident_facts(analysis_signature, status);

CREATE TABLE IF NOT EXISTS article_policy_facts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_article_id TEXT NOT NULL,
    upstream_triage_signature TEXT NOT NULL,
    analysis_signature TEXT NOT NULL,
    stage_version TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    skill_sha256 TEXT NOT NULL,
    model_name TEXT NOT NULL,
    input_sha256 TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('SUCCESS', 'FAILED')),
    policy_time TEXT,
    title TEXT,
    source_url TEXT,
    issuer TEXT,
    policy_name TEXT,
    policy_status TEXT,
    effective_time TEXT,
    affected_entities_json TEXT,
    requirements_json TEXT,
    key_changes_json TEXT,
    impact TEXT,
    summary TEXT,
    result_json TEXT,
    rendered_input TEXT,
    raw_output TEXT,
    output_attempts_json TEXT NOT NULL DEFAULT '[]',
    skill_snapshot TEXT NOT NULL DEFAULT '',
    error_type TEXT,
    error_message TEXT,
    analyzed_at TEXT NOT NULL,
    UNIQUE(source_article_id, upstream_triage_signature, analysis_signature)
);

CREATE INDEX IF NOT EXISTS idx_policy_signature_status
ON article_policy_facts(analysis_signature, status);

CREATE TABLE IF NOT EXISTS event_match_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    upstream_triage_signature TEXT NOT NULL,
    upstream_incident_signature TEXT NOT NULL,
    analysis_signature TEXT NOT NULL,
    input_sha256 TEXT NOT NULL,
    stage_version TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    skill_sha256 TEXT NOT NULL,
    model_name TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('SUCCESS', 'FAILED')),
    group_count INTEGER,
    result_json TEXT,
    rendered_input TEXT,
    raw_output TEXT,
    output_attempts_json TEXT NOT NULL DEFAULT '[]',
    skill_snapshot TEXT NOT NULL DEFAULT '',
    error_type TEXT,
    error_message TEXT,
    analyzed_at TEXT NOT NULL,
    UNIQUE(upstream_triage_signature, upstream_incident_signature, analysis_signature, input_sha256)
);

CREATE TABLE IF NOT EXISTS event_candidates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id TEXT NOT NULL,
    upstream_triage_signature TEXT NOT NULL,
    upstream_incident_signature TEXT NOT NULL,
    upstream_event_match_signature TEXT NOT NULL,
    analysis_signature TEXT NOT NULL,
    stage_version TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    skill_sha256 TEXT NOT NULL,
    model_name TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('SUCCESS', 'FAILED')),
    title TEXT,
    event_time TEXT,
    source_article_ids_json TEXT,
    source_urls_json TEXT,
    summary TEXT,
    victim TEXT,
    attacker TEXT,
    attack_vector_or_cause TEXT,
    affected_system TEXT,
    impact TEXT,
    data_breach_scope TEXT,
    lesson TEXT,
    ioc_counts_json TEXT,
    result_json TEXT,
    rendered_input TEXT,
    raw_output TEXT,
    output_attempts_json TEXT NOT NULL DEFAULT '[]',
    skill_snapshot TEXT NOT NULL DEFAULT '',
    error_type TEXT,
    error_message TEXT,
    analyzed_at TEXT NOT NULL,
    UNIQUE(event_id, upstream_event_match_signature, analysis_signature)
);

CREATE TABLE IF NOT EXISTS policy_candidates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    policy_id TEXT NOT NULL,
    upstream_triage_signature TEXT NOT NULL,
    upstream_policy_signature TEXT NOT NULL,
    compose_version TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('SUCCESS', 'FAILED')),
    result_json TEXT,
    error_type TEXT,
    error_message TEXT,
    generated_at TEXT NOT NULL,
    UNIQUE(policy_id, upstream_triage_signature, upstream_policy_signature, compose_version)
);
"""

_MIGRATION_COLUMNS = {
    "rendered_input": "TEXT",
    "output_attempts_json": "TEXT NOT NULL DEFAULT '[]'",
    "skill_snapshot": "TEXT NOT NULL DEFAULT ''",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True)
class RunIdentity:
    analysis_signature: str
    stage_version: str
    contract_version: str
    skill_sha256: str
    model_name: str
    skill_snapshot: str = ""


class NewsAgentStore:
    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def init_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(_SCHEMA)
            existing = {
                row[1] for row in conn.execute("PRAGMA table_info(article_triage)").fetchall()
            }
            for name, ddl in _MIGRATION_COLUMNS.items():
                if name not in existing:
                    conn.execute(f"ALTER TABLE article_triage ADD COLUMN {name} {ddl}")
            conn.execute(
                "INSERT INTO meta(key, value) VALUES('schema_version', ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (SCHEMA_VERSION,),
            )

    # ---------------- Stage 1 triage ----------------
    def successful_ids(self, analysis_signature: str) -> set[str]:
        with self._connect() as conn:
            return {
                row[0]
                for row in conn.execute(
                    "SELECT source_article_id FROM article_triage "
                    "WHERE analysis_signature=? AND status='SUCCESS'",
                    (analysis_signature,),
                )
            }

    def save_success(
        self,
        *,
        identity: RunIdentity,
        article: CollectorArticle,
        input_sha256: str,
        result: TriageResult,
        total_score: float,
        rendered_input: str,
        raw_output: str,
        output_attempts: tuple[dict[str, Any], ...] | list[dict[str, Any]] = (),
    ) -> None:
        values = (
            article.source_article_id,
            identity.analysis_signature,
            identity.stage_version,
            identity.contract_version,
            identity.skill_sha256,
            identity.model_name,
            input_sha256,
            "SUCCESS",
            result.decision.value,
            result.route.value,
            result.category.value,
            result.content_nature.value,
            result.scores.relevance,
            result.scores.impact,
            result.scores.freshness,
            result.scores.evidence_quality,
            result.scores.audience_value,
            total_score,
            result.reason,
            rendered_input,
            raw_output,
            json.dumps(output_attempts, ensure_ascii=False),
            identity.skill_snapshot,
            None,
            None,
            utc_now(),
        )
        self._upsert_triage(values)

    def save_failure(
        self,
        *,
        identity: RunIdentity,
        article: CollectorArticle,
        input_sha256: str,
        rendered_input: str,
        raw_output: str,
        output_attempts: tuple[dict[str, Any], ...] | list[dict[str, Any]],
        error: Exception,
    ) -> None:
        values = (
            article.source_article_id,
            identity.analysis_signature,
            identity.stage_version,
            identity.contract_version,
            identity.skill_sha256,
            identity.model_name,
            input_sha256,
            "FAILED",
            None, None, None, None,
            None, None, None, None, None,
            None, None,
            rendered_input,
            raw_output,
            json.dumps(output_attempts, ensure_ascii=False),
            identity.skill_snapshot,
            type(error).__name__,
            str(error)[:4000],
            utc_now(),
        )
        self._upsert_triage(values)

    def _upsert_triage(self, values: tuple[object, ...]) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO article_triage(
                    source_article_id, analysis_signature, stage_version, contract_version,
                    skill_sha256, model_name, input_sha256, status,
                    decision, route, category, content_nature,
                    relevance, impact, freshness, evidence_quality, audience_value,
                    total_score, reason, rendered_input, raw_output, output_attempts_json,
                    skill_snapshot, error_type, error_message, analyzed_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(source_article_id, analysis_signature) DO UPDATE SET
                    stage_version=excluded.stage_version,
                    contract_version=excluded.contract_version,
                    skill_sha256=excluded.skill_sha256,
                    model_name=excluded.model_name,
                    input_sha256=excluded.input_sha256,
                    status=excluded.status,
                    decision=excluded.decision,
                    route=excluded.route,
                    category=excluded.category,
                    content_nature=excluded.content_nature,
                    relevance=excluded.relevance,
                    impact=excluded.impact,
                    freshness=excluded.freshness,
                    evidence_quality=excluded.evidence_quality,
                    audience_value=excluded.audience_value,
                    total_score=excluded.total_score,
                    reason=excluded.reason,
                    rendered_input=excluded.rendered_input,
                    raw_output=excluded.raw_output,
                    output_attempts_json=excluded.output_attempts_json,
                    skill_snapshot=excluded.skill_snapshot,
                    error_type=excluded.error_type,
                    error_message=excluded.error_message,
                    analyzed_at=excluded.analyzed_at
                """,
                values,
            )

    def get_result(self, source_article_id: str, analysis_signature: str) -> sqlite3.Row | None:
        with self._connect() as conn:
            return conn.execute(
                "SELECT * FROM article_triage WHERE source_article_id=? AND analysis_signature=?",
                (source_article_id, analysis_signature),
            ).fetchone()

    def get_latest_result(self, source_article_id: str) -> sqlite3.Row | None:
        with self._connect() as conn:
            return conn.execute(
                "SELECT * FROM article_triage WHERE source_article_id=? "
                "ORDER BY id DESC LIMIT 1",
                (source_article_id,),
            ).fetchone()

    def iter_kept_triage(
        self,
        *,
        route: str | None = None,
        triage_signature: str | None = None,
        only_ids: Iterable[str] | None = None,
        limit: int | None = None,
    ) -> list[sqlite3.Row]:
        requested = set(only_ids) if only_ids is not None else None
        with self._connect() as conn:
            if triage_signature:
                rows = conn.execute(
                    "SELECT * FROM article_triage WHERE analysis_signature=? "
                    "AND status='SUCCESS' AND decision='KEEP' ORDER BY id DESC",
                    (triage_signature,),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT t.*
                    FROM article_triage t
                    JOIN (
                        SELECT source_article_id, MAX(id) AS latest_id
                        FROM article_triage
                        WHERE status='SUCCESS'
                        GROUP BY source_article_id
                    ) latest ON latest.latest_id = t.id
                    WHERE t.decision='KEEP'
                    ORDER BY t.id DESC
                    """
                ).fetchall()
        result: list[sqlite3.Row] = []
        for row in rows:
            if route and row["route"] != route:
                continue
            if requested is not None and row["source_article_id"] not in requested:
                continue
            result.append(row)
            if limit is not None and len(result) >= limit:
                break
        return result

    # ---------------- Stage 2 article facts ----------------
    def extraction_success_exists(
        self,
        *,
        stage: str,
        source_article_id: str,
        upstream_triage_signature: str,
        analysis_signature: str,
    ) -> bool:
        table = self._fact_table(stage)
        with self._connect() as conn:
            row = conn.execute(
                f"SELECT 1 FROM {table} WHERE source_article_id=? "
                "AND upstream_triage_signature=? AND analysis_signature=? "
                "AND status='SUCCESS' LIMIT 1",
                (source_article_id, upstream_triage_signature, analysis_signature),
            ).fetchone()
        return row is not None

    @staticmethod
    def _fact_table(stage: str) -> str:
        if stage == "incident":
            return "article_incident_facts"
        if stage == "policy":
            return "article_policy_facts"
        raise ValueError(f"unsupported fact stage: {stage}")

    def save_incident_success(
        self,
        *,
        identity: RunIdentity,
        upstream_triage_signature: str,
        article: CollectorArticle,
        input_sha256: str,
        result: IncidentResult,
        rendered_input: str,
        raw_output: str,
        output_attempts: tuple[dict[str, Any], ...] | list[dict[str, Any]] = (),
    ) -> None:
        counts = result.ioc.counts()
        values = (
            article.source_article_id, upstream_triage_signature, identity.analysis_signature,
            identity.stage_version, identity.contract_version, identity.skill_sha256,
            identity.model_name, input_sha256, "SUCCESS",
            result.event_time, result.title, result.source_url, result.summary,
            result.entities.victim.value, result.entities.victim.certainty.value,
            result.entities.attacker.value, result.entities.attacker.certainty.value,
            result.entities.attack_vector_or_cause, result.entities.affected_system,
            result.entities.impact, result.data_breach_scope, result.lesson,
            result.ioc.model_dump_json(), counts["ip_count"], counts["domain_count"],
            counts["url_count"], counts["hash_count"], counts["file_path_count"],
            result.model_dump_json(), rendered_input, raw_output,
            json.dumps(output_attempts, ensure_ascii=False), identity.skill_snapshot,
            None, None, utc_now(),
        )
        self._upsert_incident(values)

    def save_incident_failure(
        self,
        *,
        identity: RunIdentity,
        upstream_triage_signature: str,
        article: CollectorArticle,
        input_sha256: str,
        rendered_input: str,
        raw_output: str,
        output_attempts: tuple[dict[str, Any], ...] | list[dict[str, Any]],
        error: Exception,
    ) -> None:
        values = (
            article.source_article_id, upstream_triage_signature, identity.analysis_signature,
            identity.stage_version, identity.contract_version, identity.skill_sha256,
            identity.model_name, input_sha256, "FAILED",
            *([None] * 20),
            rendered_input, raw_output, json.dumps(output_attempts, ensure_ascii=False),
            identity.skill_snapshot, type(error).__name__, str(error)[:4000], utc_now(),
        )
        self._upsert_incident(values)

    def _upsert_incident(self, values: tuple[object, ...]) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO article_incident_facts(
                    source_article_id, upstream_triage_signature, analysis_signature,
                    stage_version, contract_version, skill_sha256, model_name, input_sha256, status,
                    event_time, title, source_url, summary,
                    victim_value, victim_certainty, attacker_value, attacker_certainty,
                    attack_vector_or_cause, affected_system, impact, data_breach_scope, lesson,
                    ioc_json, ip_count, domain_count, url_count, hash_count, file_path_count,
                    result_json, rendered_input, raw_output, output_attempts_json, skill_snapshot,
                    error_type, error_message, analyzed_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(source_article_id, upstream_triage_signature, analysis_signature) DO UPDATE SET
                    stage_version=excluded.stage_version, contract_version=excluded.contract_version,
                    skill_sha256=excluded.skill_sha256, model_name=excluded.model_name,
                    input_sha256=excluded.input_sha256, status=excluded.status,
                    event_time=excluded.event_time, title=excluded.title, source_url=excluded.source_url,
                    summary=excluded.summary, victim_value=excluded.victim_value,
                    victim_certainty=excluded.victim_certainty, attacker_value=excluded.attacker_value,
                    attacker_certainty=excluded.attacker_certainty,
                    attack_vector_or_cause=excluded.attack_vector_or_cause,
                    affected_system=excluded.affected_system, impact=excluded.impact,
                    data_breach_scope=excluded.data_breach_scope, lesson=excluded.lesson,
                    ioc_json=excluded.ioc_json, ip_count=excluded.ip_count,
                    domain_count=excluded.domain_count, url_count=excluded.url_count,
                    hash_count=excluded.hash_count, file_path_count=excluded.file_path_count,
                    result_json=excluded.result_json, rendered_input=excluded.rendered_input,
                    raw_output=excluded.raw_output, output_attempts_json=excluded.output_attempts_json,
                    skill_snapshot=excluded.skill_snapshot, error_type=excluded.error_type,
                    error_message=excluded.error_message, analyzed_at=excluded.analyzed_at
                """,
                values,
            )

    def save_policy_success(
        self,
        *,
        identity: RunIdentity,
        upstream_triage_signature: str,
        article: CollectorArticle,
        input_sha256: str,
        result: PolicyResult,
        rendered_input: str,
        raw_output: str,
        output_attempts: tuple[dict[str, Any], ...] | list[dict[str, Any]] = (),
    ) -> None:
        values = (
            article.source_article_id, upstream_triage_signature, identity.analysis_signature,
            identity.stage_version, identity.contract_version, identity.skill_sha256,
            identity.model_name, input_sha256, "SUCCESS",
            result.policy_time, result.title, result.source_url, result.issuer,
            result.policy_name, result.policy_status.value, result.effective_time,
            json.dumps(result.affected_entities, ensure_ascii=False),
            json.dumps(result.requirements, ensure_ascii=False),
            json.dumps(result.key_changes, ensure_ascii=False),
            result.impact, result.summary, result.model_dump_json(), rendered_input, raw_output,
            json.dumps(output_attempts, ensure_ascii=False), identity.skill_snapshot,
            None, None, utc_now(),
        )
        self._upsert_policy(values)

    def save_policy_failure(
        self,
        *,
        identity: RunIdentity,
        upstream_triage_signature: str,
        article: CollectorArticle,
        input_sha256: str,
        rendered_input: str,
        raw_output: str,
        output_attempts: tuple[dict[str, Any], ...] | list[dict[str, Any]],
        error: Exception,
    ) -> None:
        values = (
            article.source_article_id, upstream_triage_signature, identity.analysis_signature,
            identity.stage_version, identity.contract_version, identity.skill_sha256,
            identity.model_name, input_sha256, "FAILED",
            *([None] * 13),
            rendered_input, raw_output, json.dumps(output_attempts, ensure_ascii=False),
            identity.skill_snapshot, type(error).__name__, str(error)[:4000], utc_now(),
        )
        self._upsert_policy(values)

    def _upsert_policy(self, values: tuple[object, ...]) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO article_policy_facts(
                    source_article_id, upstream_triage_signature, analysis_signature,
                    stage_version, contract_version, skill_sha256, model_name, input_sha256, status,
                    policy_time, title, source_url, issuer, policy_name, policy_status, effective_time,
                    affected_entities_json, requirements_json, key_changes_json, impact, summary,
                    result_json, rendered_input, raw_output, output_attempts_json, skill_snapshot,
                    error_type, error_message, analyzed_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(source_article_id, upstream_triage_signature, analysis_signature) DO UPDATE SET
                    stage_version=excluded.stage_version, contract_version=excluded.contract_version,
                    skill_sha256=excluded.skill_sha256, model_name=excluded.model_name,
                    input_sha256=excluded.input_sha256, status=excluded.status,
                    policy_time=excluded.policy_time, title=excluded.title, source_url=excluded.source_url,
                    issuer=excluded.issuer, policy_name=excluded.policy_name,
                    policy_status=excluded.policy_status, effective_time=excluded.effective_time,
                    affected_entities_json=excluded.affected_entities_json,
                    requirements_json=excluded.requirements_json,
                    key_changes_json=excluded.key_changes_json, impact=excluded.impact,
                    summary=excluded.summary, result_json=excluded.result_json,
                    rendered_input=excluded.rendered_input, raw_output=excluded.raw_output,
                    output_attempts_json=excluded.output_attempts_json,
                    skill_snapshot=excluded.skill_snapshot, error_type=excluded.error_type,
                    error_message=excluded.error_message, analyzed_at=excluded.analyzed_at
                """,
                values,
            )

    def get_latest_fact(self, stage: str, source_article_id: str) -> sqlite3.Row | None:
        table = self._fact_table(stage)
        with self._connect() as conn:
            return conn.execute(
                f"SELECT * FROM {table} WHERE source_article_id=? ORDER BY id DESC LIMIT 1",
                (source_article_id,),
            ).fetchone()

    def get_fact(
        self, stage: str, source_article_id: str, analysis_signature: str
    ) -> sqlite3.Row | None:
        table = self._fact_table(stage)
        with self._connect() as conn:
            return conn.execute(
                f"SELECT * FROM {table} WHERE source_article_id=? AND analysis_signature=? "
                "ORDER BY id DESC LIMIT 1",
                (source_article_id, analysis_signature),
            ).fetchone()

    # ---------------- Stage 3 event matching / Stage 4 candidates ----------------
    def list_success_facts(
        self,
        stage: str,
        *,
        upstream_triage_signature: str,
        analysis_signature: str,
        only_ids: Iterable[str] | None = None,
    ) -> list[sqlite3.Row]:
        table = self._fact_table(stage)
        requested = set(only_ids) if only_ids is not None else None
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM {table} WHERE upstream_triage_signature=? "
                "AND analysis_signature=? AND status='SUCCESS' ORDER BY id ASC",
                (upstream_triage_signature, analysis_signature),
            ).fetchall()
        if requested is None:
            return list(rows)
        return [row for row in rows if row["source_article_id"] in requested]

    def save_event_match_success(
        self,
        *,
        identity: RunIdentity,
        upstream_triage_signature: str,
        upstream_incident_signature: str,
        input_sha256: str,
        result: EventMatchResult,
        rendered_input: str,
        raw_output: str,
        output_attempts: tuple[dict[str, Any], ...] | list[dict[str, Any]] = (),
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO event_match_runs(
                    upstream_triage_signature, upstream_incident_signature, analysis_signature, input_sha256,
                    stage_version, contract_version, skill_sha256, model_name, status,
                    group_count, result_json, rendered_input, raw_output, output_attempts_json,
                    skill_snapshot, error_type, error_message, analyzed_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(upstream_triage_signature, upstream_incident_signature, analysis_signature, input_sha256)
                DO UPDATE SET
                    stage_version=excluded.stage_version, contract_version=excluded.contract_version,
                    skill_sha256=excluded.skill_sha256, model_name=excluded.model_name,
                    status=excluded.status, group_count=excluded.group_count,
                    result_json=excluded.result_json, rendered_input=excluded.rendered_input,
                    raw_output=excluded.raw_output, output_attempts_json=excluded.output_attempts_json,
                    skill_snapshot=excluded.skill_snapshot, error_type=NULL, error_message=NULL,
                    analyzed_at=excluded.analyzed_at
                """,
                (
                    upstream_triage_signature, upstream_incident_signature,
                    identity.analysis_signature, input_sha256, identity.stage_version, identity.contract_version,
                    identity.skill_sha256, identity.model_name, "SUCCESS", len(result.groups),
                    result.model_dump_json(), rendered_input, raw_output,
                    json.dumps(output_attempts, ensure_ascii=False), identity.skill_snapshot,
                    None, None, utc_now(),
                ),
            )

    def save_event_match_failure(
        self,
        *,
        identity: RunIdentity,
        upstream_triage_signature: str,
        upstream_incident_signature: str,
        input_sha256: str,
        rendered_input: str,
        raw_output: str,
        output_attempts: tuple[dict[str, Any], ...] | list[dict[str, Any]],
        error: Exception,
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO event_match_runs(
                    upstream_triage_signature, upstream_incident_signature, analysis_signature, input_sha256,
                    stage_version, contract_version, skill_sha256, model_name, status,
                    group_count, result_json, rendered_input, raw_output, output_attempts_json,
                    skill_snapshot, error_type, error_message, analyzed_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(upstream_triage_signature, upstream_incident_signature, analysis_signature, input_sha256)
                DO UPDATE SET
                    stage_version=excluded.stage_version, contract_version=excluded.contract_version,
                    skill_sha256=excluded.skill_sha256, model_name=excluded.model_name,
                    status=excluded.status, group_count=NULL, result_json=NULL,
                    rendered_input=excluded.rendered_input, raw_output=excluded.raw_output,
                    output_attempts_json=excluded.output_attempts_json,
                    skill_snapshot=excluded.skill_snapshot, error_type=excluded.error_type,
                    error_message=excluded.error_message, analyzed_at=excluded.analyzed_at
                """,
                (
                    upstream_triage_signature, upstream_incident_signature,
                    identity.analysis_signature, input_sha256, identity.stage_version, identity.contract_version,
                    identity.skill_sha256, identity.model_name, "FAILED", None, None,
                    rendered_input, raw_output, json.dumps(output_attempts, ensure_ascii=False),
                    identity.skill_snapshot, type(error).__name__, str(error)[:4000], utc_now(),
                ),
            )

    def get_event_match_run(
        self,
        *,
        upstream_triage_signature: str,
        upstream_incident_signature: str,
        analysis_signature: str,
        input_sha256: str,
    ) -> sqlite3.Row | None:
        with self._connect() as conn:
            return conn.execute(
                "SELECT * FROM event_match_runs WHERE upstream_triage_signature=? "
                "AND upstream_incident_signature=? AND analysis_signature=? AND input_sha256=? LIMIT 1",
                (upstream_triage_signature, upstream_incident_signature, analysis_signature, input_sha256),
            ).fetchone()

    def save_event_candidate_success(
        self,
        *,
        identity: RunIdentity,
        upstream_triage_signature: str,
        upstream_incident_signature: str,
        upstream_event_match_signature: str,
        result: EventCandidateResult,
        rendered_input: str,
        raw_output: str,
        output_attempts: tuple[dict[str, Any], ...] | list[dict[str, Any]] = (),
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO event_candidates(
                    event_id, upstream_triage_signature, upstream_incident_signature,
                    upstream_event_match_signature, analysis_signature, stage_version,
                    contract_version, skill_sha256, model_name, status, title, event_time,
                    source_article_ids_json, source_urls_json, summary, victim, attacker,
                    attack_vector_or_cause, affected_system, impact, data_breach_scope, lesson,
                    ioc_counts_json, result_json, rendered_input, raw_output, output_attempts_json,
                    skill_snapshot, error_type, error_message, analyzed_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(event_id, upstream_event_match_signature, analysis_signature)
                DO UPDATE SET
                    upstream_triage_signature=excluded.upstream_triage_signature,
                    upstream_incident_signature=excluded.upstream_incident_signature,
                    stage_version=excluded.stage_version, contract_version=excluded.contract_version,
                    skill_sha256=excluded.skill_sha256, model_name=excluded.model_name,
                    status=excluded.status, title=excluded.title, event_time=excluded.event_time,
                    source_article_ids_json=excluded.source_article_ids_json,
                    source_urls_json=excluded.source_urls_json, summary=excluded.summary,
                    victim=excluded.victim, attacker=excluded.attacker,
                    attack_vector_or_cause=excluded.attack_vector_or_cause,
                    affected_system=excluded.affected_system, impact=excluded.impact,
                    data_breach_scope=excluded.data_breach_scope, lesson=excluded.lesson,
                    ioc_counts_json=excluded.ioc_counts_json, result_json=excluded.result_json,
                    rendered_input=excluded.rendered_input, raw_output=excluded.raw_output,
                    output_attempts_json=excluded.output_attempts_json,
                    skill_snapshot=excluded.skill_snapshot, error_type=NULL, error_message=NULL,
                    analyzed_at=excluded.analyzed_at
                """,
                (
                    result.event_id, upstream_triage_signature, upstream_incident_signature,
                    upstream_event_match_signature, identity.analysis_signature,
                    identity.stage_version, identity.contract_version, identity.skill_sha256,
                    identity.model_name, "SUCCESS", result.title, result.event_time,
                    json.dumps(result.source_article_ids, ensure_ascii=False),
                    json.dumps(result.source_urls, ensure_ascii=False), result.summary,
                    result.victim, result.attacker, result.attack_vector_or_cause,
                    result.affected_system, result.impact, result.data_breach_scope, result.lesson,
                    result.ioc.model_dump_json(), result.model_dump_json(), rendered_input,
                    raw_output, json.dumps(output_attempts, ensure_ascii=False),
                    identity.skill_snapshot, None, None, utc_now(),
                ),
            )

    def save_event_candidate_failure(
        self,
        *,
        identity: RunIdentity,
        event_id: str,
        upstream_triage_signature: str,
        upstream_incident_signature: str,
        upstream_event_match_signature: str,
        rendered_input: str,
        raw_output: str,
        output_attempts: tuple[dict[str, Any], ...] | list[dict[str, Any]],
        error: Exception,
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO event_candidates(
                    event_id, upstream_triage_signature, upstream_incident_signature,
                    upstream_event_match_signature, analysis_signature, stage_version,
                    contract_version, skill_sha256, model_name, status,
                    source_article_ids_json, source_urls_json, output_attempts_json,
                    rendered_input, raw_output, skill_snapshot, error_type, error_message, analyzed_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(event_id, upstream_event_match_signature, analysis_signature)
                DO UPDATE SET status=excluded.status, rendered_input=excluded.rendered_input,
                    raw_output=excluded.raw_output, output_attempts_json=excluded.output_attempts_json,
                    skill_snapshot=excluded.skill_snapshot, error_type=excluded.error_type,
                    error_message=excluded.error_message, analyzed_at=excluded.analyzed_at
                """,
                (
                    event_id, upstream_triage_signature, upstream_incident_signature,
                    upstream_event_match_signature, identity.analysis_signature,
                    identity.stage_version, identity.contract_version, identity.skill_sha256,
                    identity.model_name, "FAILED", "[]", "[]",
                    json.dumps(output_attempts, ensure_ascii=False), rendered_input, raw_output,
                    identity.skill_snapshot, type(error).__name__, str(error)[:4000], utc_now(),
                ),
            )

    def save_policy_candidate(
        self,
        *,
        result: PolicyCandidateResult,
        upstream_triage_signature: str,
        upstream_policy_signature: str,
        compose_version: str,
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO policy_candidates(
                    policy_id, upstream_triage_signature, upstream_policy_signature,
                    compose_version, status, result_json, error_type, error_message, generated_at
                ) VALUES (?,?,?,?,?,?,?,?,?)
                ON CONFLICT(policy_id, upstream_triage_signature, upstream_policy_signature, compose_version)
                DO UPDATE SET status=excluded.status, result_json=excluded.result_json,
                    error_type=NULL, error_message=NULL, generated_at=excluded.generated_at
                """,
                (
                    result.policy_id, upstream_triage_signature, upstream_policy_signature,
                    compose_version, "SUCCESS", result.model_dump_json(), None, None, utc_now(),
                ),
            )

    def list_event_candidates(
        self,
        *,
        upstream_triage_signature: str,
        upstream_event_match_signature: str,
        analysis_signature: str,
    ) -> list[sqlite3.Row]:
        with self._connect() as conn:
            return conn.execute(
                "SELECT * FROM event_candidates WHERE upstream_triage_signature=? "
                "AND upstream_event_match_signature=? AND analysis_signature=? "
                "AND status='SUCCESS' ORDER BY id ASC",
                (upstream_triage_signature, upstream_event_match_signature, analysis_signature),
            ).fetchall()

    def list_policy_candidates(
        self,
        *,
        upstream_triage_signature: str,
        upstream_policy_signature: str,
        compose_version: str,
    ) -> list[sqlite3.Row]:
        with self._connect() as conn:
            return conn.execute(
                "SELECT * FROM policy_candidates WHERE upstream_triage_signature=? "
                "AND upstream_policy_signature=? AND compose_version=? "
                "AND status='SUCCESS' ORDER BY id ASC",
                (upstream_triage_signature, upstream_policy_signature, compose_version),
            ).fetchall()

    def event_candidate_success_exists(
        self,
        *,
        event_id: str,
        upstream_event_match_signature: str,
        analysis_signature: str,
    ) -> bool:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT 1 FROM event_candidates WHERE event_id=? "
                "AND upstream_event_match_signature=? AND analysis_signature=? "
                "AND status='SUCCESS' LIMIT 1",
                (event_id, upstream_event_match_signature, analysis_signature),
            ).fetchone()
        return row is not None

    def get_latest_event_match_run(self) -> sqlite3.Row | None:
        with self._connect() as conn:
            return conn.execute("SELECT * FROM event_match_runs ORDER BY id DESC LIMIT 1").fetchone()

    def get_latest_event_candidate(self, event_id: str) -> sqlite3.Row | None:
        with self._connect() as conn:
            return conn.execute(
                "SELECT * FROM event_candidates WHERE event_id=? ORDER BY id DESC LIMIT 1",
                (event_id,),
            ).fetchone()
