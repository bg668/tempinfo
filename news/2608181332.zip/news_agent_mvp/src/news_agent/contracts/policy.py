from __future__ import annotations

from enum import StrEnum
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, field_validator

POLICY_CONTRACT_VERSION = "policy.v1"


class PolicyStatus(StrEnum):
    OFFICIALLY_ISSUED = "officially_issued"
    DRAFT_FOR_COMMENT = "draft_for_comment"
    OTHER = "other"
    UNKNOWN = "unknown"


PolicyListItem = Annotated[str, Field(min_length=1, max_length=1200)]


class PolicyResult(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    source_article_id: str = Field(min_length=1)
    policy_time: str = Field(min_length=1, max_length=300)
    title: str = Field(min_length=1, max_length=300)
    source_url: str = Field(min_length=1, max_length=2000)
    issuer: str = Field(min_length=1, max_length=500)
    policy_name: str = Field(min_length=1, max_length=500)
    policy_status: PolicyStatus
    effective_time: str = Field(min_length=1, max_length=300)
    affected_entities: list[PolicyListItem] = Field(default_factory=list)
    requirements: list[PolicyListItem] = Field(default_factory=list)
    key_changes: list[PolicyListItem] = Field(default_factory=list)
    impact: str = Field(min_length=1, max_length=2000)
    summary: str = Field(min_length=1, max_length=2000)

    @field_validator("affected_entities", "requirements", "key_changes", mode="after")
    @classmethod
    def normalize_unique(cls, values: list[str]) -> list[str]:
        result: list[str] = []
        seen: set[str] = set()
        for item in values:
            value = item.strip()
            key = value.casefold()
            if key not in seen:
                result.append(value)
                seen.add(key)
        return result
