from __future__ import annotations

from enum import StrEnum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

CONTRACT_VERSION = "triage.v1"


class Decision(StrEnum):
    KEEP = "KEEP"
    DROP = "DROP"
    UNCERTAIN = "UNCERTAIN"


class Route(StrEnum):
    SECURITY_EVENT = "security_event"
    COMPLIANCE_POLICY = "compliance_policy"
    NON_TARGET = "non_target"
    UNCERTAIN = "uncertain"


class Category(StrEnum):
    SECURITY_INCIDENT = "security_incident"
    THREAT_ACTIVITY = "threat_activity"
    VULNERABILITY = "vulnerability"
    DATA_BREACH = "data_breach"
    RANSOMWARE = "ransomware"
    COMPLIANCE_POLICY = "compliance_policy"
    RESEARCH = "research"
    PRODUCT = "product"
    OTHER = "other"


class ContentNature(StrEnum):
    REAL_WORLD_EVENT = "real_world_event"
    POLICY = "policy"
    CTF_OR_SIMULATION = "ctf_or_simulation"
    RESEARCH_OR_TUTORIAL = "research_or_tutorial"
    MARKETING = "marketing"
    RECRUITMENT = "recruitment"
    CONFERENCE_OR_TRAINING = "conference_or_training"
    PROCUREMENT = "procurement"
    OTHER = "other"


class CollectorArticle(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    source_article_id: str = Field(min_length=1)
    account: str = ""
    title: str = ""
    url: str = Field(min_length=1)
    published_at: str | None = None
    content: str = Field(min_length=1)


class TriageScores(BaseModel):
    model_config = ConfigDict(extra="forbid")

    relevance: int = Field(ge=0, le=5)
    impact: int = Field(ge=0, le=5)
    freshness: int = Field(ge=0, le=5)
    evidence_quality: int = Field(ge=0, le=5)
    audience_value: int = Field(ge=0, le=5)


class TriageResult(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    source_article_id: str = Field(min_length=1)
    decision: Decision
    route: Route
    category: Category
    content_nature: ContentNature
    scores: TriageScores
    reason: str = Field(min_length=1, max_length=500)

    @model_validator(mode="after")
    def validate_route_consistency(self) -> "TriageResult":
        if self.decision == Decision.KEEP and self.route not in {
            Route.SECURITY_EVENT,
            Route.COMPLIANCE_POLICY,
        }:
            raise ValueError("KEEP must route to security_event or compliance_policy")
        if self.decision == Decision.DROP and self.route != Route.NON_TARGET:
            raise ValueError("DROP must route to non_target")
        if self.decision == Decision.UNCERTAIN and self.route != Route.UNCERTAIN:
            raise ValueError("UNCERTAIN must route to uncertain")
        if self.route == Route.COMPLIANCE_POLICY and self.category != Category.COMPLIANCE_POLICY:
            raise ValueError("compliance_policy route requires compliance_policy category")
        if self.route == Route.COMPLIANCE_POLICY and self.content_nature != ContentNature.POLICY:
            raise ValueError("compliance_policy route requires policy content_nature")
        if self.route == Route.SECURITY_EVENT and self.category not in {
            Category.SECURITY_INCIDENT,
            Category.THREAT_ACTIVITY,
            Category.VULNERABILITY,
            Category.DATA_BREACH,
            Category.RANSOMWARE,
        }:
            raise ValueError("security_event route requires an event category")
        if self.content_nature in {
            ContentNature.CTF_OR_SIMULATION,
            ContentNature.RESEARCH_OR_TUTORIAL,
            ContentNature.MARKETING,
            ContentNature.RECRUITMENT,
            ContentNature.CONFERENCE_OR_TRAINING,
            ContentNature.PROCUREMENT,
        } and self.decision == Decision.KEEP:
            raise ValueError(f"{self.content_nature} cannot be KEEP in Stage 1")
        return self
