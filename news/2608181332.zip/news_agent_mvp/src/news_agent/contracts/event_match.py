from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, field_validator

EVENT_MATCH_CONTRACT_VERSION = "event-match.v1"


class EventGroup(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    canonical_title: str = Field(min_length=1, max_length=300)
    member_article_ids: list[str] = Field(min_length=1)
    match_reason: str = Field(min_length=1, max_length=1200)

    @field_validator("member_article_ids", mode="after")
    @classmethod
    def unique_members(cls, values: list[str]) -> list[str]:
        result: list[str] = []
        seen: set[str] = set()
        for value in values:
            item = value.strip()
            if item in seen:
                raise ValueError(f"duplicate member_article_id: {item}")
            seen.add(item)
            result.append(item)
        return result


class EventMatchResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    groups: dict[str, EventGroup] = Field(min_length=1)
