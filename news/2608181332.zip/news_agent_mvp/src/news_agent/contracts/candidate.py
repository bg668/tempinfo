from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

EVENT_CANDIDATE_CONTRACT_VERSION = "event-candidate.v1"
POLICY_CANDIDATE_CONTRACT_VERSION = "policy-candidate.v1"


class EventCandidateDraft(BaseModel):
    """LLM-authored narrative fields. Identity/source/IOC fields are attached by Python."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    event_time: str = Field(min_length=1, max_length=300)
    title: str = Field(min_length=1, max_length=300)
    summary: str = Field(min_length=1, max_length=1800)
    victim: str = Field(min_length=1, max_length=700)
    attacker: str = Field(min_length=1, max_length=700)
    attack_vector_or_cause: str = Field(min_length=1, max_length=1800)
    affected_system: str = Field(min_length=1, max_length=1800)
    impact: str = Field(min_length=1, max_length=2200)
    data_breach_scope: str = Field(min_length=1, max_length=1800)
    lesson: str = Field(min_length=1, max_length=1800)


class IOCCounters(BaseModel):
    model_config = ConfigDict(extra="forbid")

    ip_count: int = Field(ge=0)
    domain_count: int = Field(ge=0)
    url_count: int = Field(ge=0)
    hash_count: int = Field(ge=0)
    file_path_count: int = Field(ge=0)


class EventCandidateResult(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    event_id: str = Field(min_length=1, max_length=100)
    event_time: str = Field(min_length=1, max_length=300)
    title: str = Field(min_length=1, max_length=300)
    source_article_ids: list[str] = Field(min_length=1)
    source_urls: list[str] = Field(min_length=1)
    summary: str = Field(min_length=1, max_length=1800)
    victim: str = Field(min_length=1, max_length=700)
    attacker: str = Field(min_length=1, max_length=700)
    attack_vector_or_cause: str = Field(min_length=1, max_length=1800)
    affected_system: str = Field(min_length=1, max_length=1800)
    impact: str = Field(min_length=1, max_length=2200)
    data_breach_scope: str = Field(min_length=1, max_length=1800)
    lesson: str = Field(min_length=1, max_length=1800)
    ioc: IOCCounters


class PolicyCandidateResult(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    policy_id: str = Field(min_length=1, max_length=100)
    source_article_id: str = Field(min_length=1)
    policy_time: str = Field(min_length=1, max_length=300)
    title: str = Field(min_length=1, max_length=300)
    source_url: str = Field(min_length=1, max_length=2000)
    issuer: str = Field(min_length=1, max_length=500)
    policy_name: str = Field(min_length=1, max_length=500)
    policy_status: str = Field(min_length=1, max_length=100)
    effective_time: str = Field(min_length=1, max_length=300)
    affected_entities: list[str]
    requirements: list[str]
    key_changes: list[str]
    impact: str = Field(min_length=1, max_length=2000)
    summary: str = Field(min_length=1, max_length=2000)
