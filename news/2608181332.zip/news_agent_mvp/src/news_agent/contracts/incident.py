from __future__ import annotations

from enum import StrEnum
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

INCIDENT_CONTRACT_VERSION = "incident.v1"
UNKNOWN = "unknown"


class Certainty(StrEnum):
    CONFIRMED = "confirmed"
    REPORTED = "reported"
    SUSPECTED = "suspected"
    UNKNOWN = "unknown"


class EntityFact(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    value: str = Field(min_length=1, max_length=500)
    certainty: Certainty

    @model_validator(mode="after")
    def validate_unknown_pair(self) -> "EntityFact":
        value_unknown = self.value.casefold() == UNKNOWN
        certainty_unknown = self.certainty == Certainty.UNKNOWN
        if value_unknown != certainty_unknown:
            raise ValueError("value='unknown' and certainty='unknown' must appear together")
        return self


class IncidentEntities(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    victim: EntityFact
    attacker: EntityFact
    attack_vector_or_cause: str = Field(min_length=1, max_length=1500)
    affected_system: str = Field(min_length=1, max_length=1500)
    impact: str = Field(min_length=1, max_length=2000)


IOCItem = Annotated[str, Field(min_length=1, max_length=2000)]


class IOCValues(BaseModel):
    model_config = ConfigDict(extra="forbid")

    ips: list[IOCItem] = Field(default_factory=list)
    domains: list[IOCItem] = Field(default_factory=list)
    urls: list[IOCItem] = Field(default_factory=list)
    hashes: list[IOCItem] = Field(default_factory=list)
    file_paths: list[IOCItem] = Field(default_factory=list)

    @field_validator("ips", "domains", "urls", "hashes", "file_paths", mode="after")
    @classmethod
    def normalize_unique(cls, values: list[str]) -> list[str]:
        result: list[str] = []
        seen: set[str] = set()
        for item in values:
            value = item.strip()
            key = value.casefold()
            if key not in seen:
                result.append(value)
                seen.add(key)
        return result

    def counts(self) -> dict[str, int]:
        return {
            "ip_count": len(self.ips),
            "domain_count": len(self.domains),
            "url_count": len(self.urls),
            "hash_count": len(self.hashes),
            "file_path_count": len(self.file_paths),
        }


class IncidentResult(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    source_article_id: str = Field(min_length=1)
    event_time: str = Field(min_length=1, max_length=300)
    title: str = Field(min_length=1, max_length=300)
    source_url: str = Field(min_length=1, max_length=2000)
    summary: str = Field(min_length=1, max_length=2000)
    entities: IncidentEntities
    data_breach_scope: str = Field(min_length=1, max_length=2000)
    lesson: str = Field(min_length=1, max_length=2000)
    ioc: IOCValues
