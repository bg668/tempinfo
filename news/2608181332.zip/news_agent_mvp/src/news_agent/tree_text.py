from __future__ import annotations

from dataclasses import dataclass

from pydantic import ValidationError

from .contracts import CollectorArticle, IncidentResult, PolicyResult, TriageResult


class TreeTextError(ValueError):
    pass


@dataclass(frozen=True)
class _TreeLine:
    lineno: int
    indent: int
    text: str


def _clean_scalar(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        return value[1:-1]
    return value


def _parse_scalar(value: str) -> object:
    value = _clean_scalar(value)
    if value == "[]":
        return []
    if value.isdigit() or (value.startswith("-") and value[1:].isdigit()):
        return int(value)
    return value


def strip_code_fence(text: str) -> str:
    value = text.strip()
    if value.startswith("```") and value.endswith("```"):
        lines = value.splitlines()
        if len(lines) >= 3:
            return "\n".join(lines[1:-1]).strip()
    return value


def _tokenize_tree(text: str) -> list[_TreeLine]:
    tokens: list[_TreeLine] = []
    for lineno, raw in enumerate(text.splitlines(), start=1):
        if not raw.strip():
            continue
        prefix = raw[: len(raw) - len(raw.lstrip())]
        if "\t" in prefix:
            raise TreeTextError(f"line {lineno}: tabs are not allowed for indentation")
        indent = len(raw) - len(raw.lstrip(" "))
        if indent % 2:
            raise TreeTextError(f"line {lineno}: indentation must be multiples of two spaces")
        tokens.append(_TreeLine(lineno=lineno, indent=indent, text=raw.strip()))
    return tokens


def _parse_block(tokens: list[_TreeLine], index: int, indent: int) -> tuple[object, int]:
    if index >= len(tokens):
        raise TreeTextError("unexpected end of output")
    first = tokens[index]
    if first.indent != indent:
        raise TreeTextError(f"line {first.lineno}: invalid indentation jump")

    if first.text.startswith("-"):
        result: list[object] = []
        while index < len(tokens) and tokens[index].indent == indent:
            token = tokens[index]
            if not token.text.startswith("- "):
                raise TreeTextError(f"line {token.lineno}: list items must use '- value'")
            value = token.text[2:].strip()
            if not value:
                raise TreeTextError(f"line {token.lineno}: nested list items are not supported")
            result.append(_parse_scalar(value))
            index += 1
        return result, index

    result_map: dict[str, object] = {}
    while index < len(tokens) and tokens[index].indent == indent:
        token = tokens[index]
        if token.text.startswith("-"):
            raise TreeTextError(f"line {token.lineno}: mixed mapping/list block is not allowed")
        if ":" not in token.text:
            raise TreeTextError(f"line {token.lineno}: expected 'key: value'")
        key, value = token.text.split(":", 1)
        key = key.strip()
        if not key:
            raise TreeTextError(f"line {token.lineno}: empty key")
        if key in result_map:
            raise TreeTextError(f"line {token.lineno}: duplicate key '{key}'")

        value = value.strip()
        index += 1
        if value:
            result_map[key] = _parse_scalar(value)
            continue

        if index >= len(tokens) or tokens[index].indent <= indent:
            raise TreeTextError(
                f"line {token.lineno}: empty mapping value requires an indented child; use [] for an empty list"
            )
        if tokens[index].indent != indent + 2:
            raise TreeTextError(f"line {tokens[index].lineno}: invalid indentation jump")
        child, index = _parse_block(tokens, index, indent + 2)
        result_map[key] = child

    if index < len(tokens) and tokens[index].indent > indent:
        raise TreeTextError(f"line {tokens[index].lineno}: invalid indentation jump")
    return result_map, index


def parse_tree_mapping(text: str) -> dict[str, object]:
    """Parse the project's deliberately-small tree-text format.

    It supports nested two-space mappings and scalar string lists using ``- value``.
    Empty lists must be written as ``[]``. Arbitrary YAML features are intentionally
    unsupported so model output remains deterministic and portable.
    """
    text = strip_code_fence(text)
    if not text:
        raise TreeTextError("empty output")
    tokens = _tokenize_tree(text)
    if not tokens:
        raise TreeTextError("empty output")
    if tokens[0].indent != 0:
        raise TreeTextError(f"line {tokens[0].lineno}: top level must start at indentation 0")
    parsed, index = _parse_block(tokens, 0, 0)
    if index != len(tokens):
        token = tokens[index]
        raise TreeTextError(f"line {token.lineno}: could not parse remaining content")
    if not isinstance(parsed, dict):
        raise TreeTextError("top level must be a mapping")
    return parsed


def _parse_contract(text: str, top_key: str, model_type):
    parsed = parse_tree_mapping(text)
    if set(parsed) != {top_key}:
        raise TreeTextError(f"top level must contain only '{top_key}'")
    payload = parsed[top_key]
    if not isinstance(payload, dict):
        raise TreeTextError(f"{top_key} must be a mapping")
    try:
        return model_type.model_validate(payload)
    except ValidationError as exc:
        raise TreeTextError(str(exc)) from exc


def parse_triage_output(text: str) -> TriageResult:
    return _parse_contract(text, "triage_result", TriageResult)


def parse_incident_output(text: str) -> IncidentResult:
    return _parse_contract(text, "incident_result", IncidentResult)


def parse_policy_output(text: str) -> PolicyResult:
    return _parse_contract(text, "policy_result", PolicyResult)


def _indent_multiline(value: str, spaces: int) -> str:
    prefix = " " * spaces
    lines = value.splitlines() or [""]
    return "\n".join(prefix + line for line in lines)


def render_article(article: CollectorArticle, *, max_content_chars: int = 50000) -> str:
    content = article.content
    truncated = len(content) > max_content_chars
    if truncated:
        content = content[:max_content_chars]

    fields = [
        "article:",
        f"  source_article_id: {article.source_article_id}",
        f"  account: {article.account}",
        f"  title: {article.title}",
        f"  url: {article.url}",
        f"  published_at: {article.published_at or 'unknown'}",
        f"  content_chars: {len(article.content)}",
        f"  content_truncated: {'true' if truncated else 'false'}",
        "  content:",
        _indent_multiline(content, 4),
    ]
    return "\n".join(fields)


def parse_event_match_output(text: str):
    from .contracts import EventMatchResult

    return _parse_contract(text, "event_match_result", EventMatchResult)


def parse_event_candidate_output(text: str):
    from .contracts import EventCandidateDraft

    return _parse_contract(text, "event_candidate", EventCandidateDraft)


def _render_mapping_lines(value: object, *, indent: int = 0) -> list[str]:
    """Render JSON-like data to the project's small tree-text subset."""
    prefix = " " * indent
    if isinstance(value, dict):
        lines: list[str] = []
        for key, child in value.items():
            if isinstance(child, (dict, list)):
                if isinstance(child, list) and not child:
                    lines.append(f"{prefix}{key}: []")
                else:
                    lines.append(f"{prefix}{key}:")
                    lines.extend(_render_mapping_lines(child, indent=indent + 2))
            else:
                scalar = "unknown" if child is None else str(child)
                lines.append(f"{prefix}{key}: {scalar}")
        return lines
    if isinstance(value, list):
        return [f"{prefix}- {item}" for item in value]
    return [f"{prefix}{value}"]


def render_event_match_input(*, triage_signature: str, incident_signature: str, incidents: list[IncidentResult]) -> str:
    payload: dict[str, object] = {
        "event_match_input": {
            "triage_signature": triage_signature,
            "incident_signature": incident_signature,
            "incident_count": len(incidents),
            "incidents": {
                item.source_article_id: item.model_dump(mode="json") for item in incidents
            },
        }
    }
    return "\n".join(_render_mapping_lines(payload))


def render_event_candidate_input(*, event_id: str, canonical_title: str, match_reason: str, incidents: list[IncidentResult]) -> str:
    payload: dict[str, object] = {
        "event_candidate_input": {
            "event_id": event_id,
            "canonical_title": canonical_title,
            "match_reason": match_reason,
            "source_count": len(incidents),
            "incident_facts": {
                item.source_article_id: item.model_dump(mode="json") for item in incidents
            },
        }
    }
    return "\n".join(_render_mapping_lines(payload))
