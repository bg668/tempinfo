from __future__ import annotations

from .config import ScoringConfig
from .contracts import TriageScores


def calculate_total_score(scores: TriageScores, weights: ScoringConfig) -> float:
    weight_map = weights.model_dump()
    total_weight = sum(weight_map.values())
    weighted = sum(getattr(scores, name) * weight for name, weight in weight_map.items())
    # Each dimension is 0..5; normalize to 0..100.
    return round((weighted / total_weight) * 20.0, 2)
