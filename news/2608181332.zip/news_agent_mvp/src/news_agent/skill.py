from __future__ import annotations

import hashlib
from pathlib import Path


def load_skill(path: str | Path) -> str:
    text = Path(path).read_text(encoding="utf-8").strip()
    if not text:
        raise ValueError(f"empty skill: {path}")
    return text


def skill_sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()
