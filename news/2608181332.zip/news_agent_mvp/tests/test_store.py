import sqlite3

from news_agent.contracts import CollectorArticle, TriageResult
from news_agent.store import NewsAgentStore, RunIdentity


def _result():
    return TriageResult.model_validate(
        {
            "source_article_id": "sid",
            "decision": "DROP",
            "route": "non_target",
            "category": "other",
            "content_nature": "marketing",
            "scores": {
                "relevance": 0,
                "impact": 0,
                "freshness": 1,
                "evidence_quality": 3,
                "audience_value": 0,
            },
            "reason": "产品宣传",
        }
    )


def test_store_success_and_debug_fields(tmp_path):
    store = NewsAgentStore(tmp_path / "news.db")
    identity = RunIdentity("sig", "stage", "contract", "skill", "model", "skill body")
    article = CollectorArticle(
        source_article_id="sid",
        title="t",
        account="a",
        url="https://example.test",
        content="body",
    )
    store.save_success(
        identity=identity,
        article=article,
        input_sha256="input",
        result=_result(),
        total_score=16.0,
        rendered_input="rendered",
        raw_output="raw",
        output_attempts=({"attempt": 1, "status": "VALID", "raw_text": "raw"},),
    )
    assert store.successful_ids("sig") == {"sid"}
    row = store.get_result("sid", "sig")
    assert row["status"] == "SUCCESS"
    assert row["decision"] == "DROP"
    assert row["rendered_input"] == "rendered"
    assert row["skill_snapshot"] == "skill body"
    assert row["output_attempts_json"].startswith("[")


def test_store_migrates_v1_database_without_rebuild(tmp_path):
    db = tmp_path / "old.db"
    conn = sqlite3.connect(db)
    conn.executescript(
        """
        CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE article_triage (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_article_id TEXT NOT NULL,
            analysis_signature TEXT NOT NULL,
            stage_version TEXT NOT NULL,
            contract_version TEXT NOT NULL,
            skill_sha256 TEXT NOT NULL,
            model_name TEXT NOT NULL,
            input_sha256 TEXT NOT NULL,
            status TEXT NOT NULL,
            decision TEXT, route TEXT, category TEXT, content_nature TEXT,
            relevance INTEGER, impact INTEGER, freshness INTEGER,
            evidence_quality INTEGER, audience_value INTEGER,
            total_score REAL, reason TEXT, raw_output TEXT,
            error_type TEXT, error_message TEXT, analyzed_at TEXT NOT NULL,
            UNIQUE(source_article_id, analysis_signature)
        );
        """
    )
    conn.commit(); conn.close()

    NewsAgentStore(db)
    conn = sqlite3.connect(db)
    columns = {row[1] for row in conn.execute("PRAGMA table_info(article_triage)")}
    version = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0]
    conn.close()
    assert {"rendered_input", "output_attempts_json", "skill_snapshot"} <= columns
    assert version == "4"
