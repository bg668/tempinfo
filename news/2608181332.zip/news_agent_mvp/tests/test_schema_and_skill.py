import json
from pathlib import Path

from news_agent.contracts import TriageResult
from news_agent.schema_export import export_triage_schema


def test_exported_schema_matches_contract(tmp_path):
    path = tmp_path / "schema.json"
    export_triage_schema(path)
    assert json.loads(path.read_text(encoding="utf-8")) == TriageResult.model_json_schema()


def test_skill_contains_contract_field_names():
    skill = Path("skills/article-triage/SKILL.md").read_text(encoding="utf-8")
    for name in TriageResult.model_fields:
        assert name in skill


def test_extraction_skills_and_schemas_match_contracts(tmp_path):
    from news_agent.contracts import IncidentResult, PolicyResult
    from news_agent.schema_export import export_schema

    cases = [
        ("incident-extract", IncidentResult, Path("skills/incident-extract/SKILL.md")),
        ("policy-extract", PolicyResult, Path("skills/policy-extract/SKILL.md")),
    ]
    for stage, model, skill_path in cases:
        output = tmp_path / f"{stage}.json"
        export_schema(stage, output)
        assert json.loads(output.read_text(encoding="utf-8")) == model.model_json_schema()
        skill = skill_path.read_text(encoding="utf-8")
        for name in model.model_fields:
            assert name in skill
