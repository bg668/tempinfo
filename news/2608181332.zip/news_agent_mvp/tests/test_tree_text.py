import pytest

from news_agent.contracts import CollectorArticle
from news_agent.tree_text import TreeTextError, parse_triage_output, render_article


def test_parse_valid_triage_output():
    result = parse_triage_output(
        """triage_result:
  source_article_id: abc
  decision: KEEP
  route: security_event
  category: data_breach
  content_nature: real_world_event
  scores:
    relevance: 5
    impact: 4
    freshness: 4
    evidence_quality: 3
    audience_value: 5
  reason: Framework披露客户信息泄露。
"""
    )
    assert result.source_article_id == "abc"
    assert result.scores.relevance == 5


def test_contract_rejects_ctf_keep():
    with pytest.raises(TreeTextError):
        parse_triage_output(
            """triage_result:
  source_article_id: abc
  decision: KEEP
  route: security_event
  category: security_incident
  content_nature: ctf_or_simulation
  scores:
    relevance: 5
    impact: 5
    freshness: 5
    evidence_quality: 5
    audience_value: 5
  reason: CTF writeup.
"""
        )


def test_render_article_is_tree_text_and_truncates():
    article = CollectorArticle(
        source_article_id="x",
        account="a",
        title="t",
        url="https://example.test",
        published_at="2026-08-17T10:00:00",
        content="line1\nline2" + "z" * 2000,
    )
    text = render_article(article, max_content_chars=1000)
    assert "content_truncated: true" in text
    assert "  content:" in text
    assert "    line1" in text
