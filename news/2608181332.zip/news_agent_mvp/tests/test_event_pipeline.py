import json

from news_agent.config import AppConfig
from news_agent.contracts import (
    EventCandidateDraft,
    EventMatchResult,
    IncidentResult,
    PolicyResult,
)
from news_agent.event_pipeline import (
    CandidatePipeline,
    EventMatchPipeline,
    build_event_candidate_result,
    deterministic_event_id,
    export_candidates,
    materialize_groups,
)
from news_agent.stages.base import EventCandidateExecution, EventMatchExecution
from news_agent.store import NewsAgentStore, RunIdentity


def config():
    return AppConfig.model_validate(
        {"provider": {"base_url": "http://127.0.0.1:8000/v1"}, "model": {"name": "test"}}
    )


def incident(source_id: str, url: str, title: str, ip: str | None = None) -> IncidentResult:
    return IncidentResult.model_validate(
        {
            "source_article_id": source_id,
            "event_time": "2026-08-17",
            "title": title,
            "source_url": url,
            "summary": title,
            "entities": {
                "victim": {"value": "Victim", "certainty": "reported"},
                "attacker": {"value": "unknown", "certainty": "unknown"},
                "attack_vector_or_cause": "vector",
                "affected_system": "system",
                "impact": "impact",
            },
            "data_breach_scope": "unknown",
            "lesson": "lesson",
            "ioc": {
                "ips": [ip] if ip else [],
                "domains": [], "urls": [], "hashes": [], "file_paths": [],
            },
        }
    )


def policy(source_id: str, url: str) -> PolicyResult:
    return PolicyResult.model_validate(
        {
            "source_article_id": source_id,
            "policy_time": "2026-08-17",
            "title": "政策",
            "source_url": url,
            "issuer": "机构",
            "policy_name": "规定",
            "policy_status": "officially_issued",
            "effective_time": "unknown",
            "affected_entities": ["单位"],
            "requirements": ["要求"],
            "key_changes": ["变化"],
            "impact": "影响",
            "summary": "政策摘要",
        }
    )


def seed_fact(store: NewsAgentStore, result: IncidentResult, *, triage="triage", sig="incident"):
    from news_agent.contracts import CollectorArticle
    article = CollectorArticle(
        source_article_id=result.source_article_id,
        title=result.title,
        account="a",
        url=result.source_url,
        content="x",
    )
    store.save_incident_success(
        identity=RunIdentity(sig, "stage", "contract", "skill", "model", "skill"),
        upstream_triage_signature=triage,
        article=article,
        input_sha256="input",
        result=result,
        rendered_input="rendered",
        raw_output="raw",
    )


class FakeMatchRuntime:
    def run(self, data):
        ids = [x.source_article_id for x in data.incidents]
        result = EventMatchResult.model_validate(
            {
                "groups": {
                    "g1": {
                        "canonical_title": "同一事件",
                        "member_article_ids": ids,
                        "match_reason": "两篇事实描述同一事件",
                    }
                }
            }
        )
        return EventMatchExecution(result, "rendered-match", "raw-match")


class FakeCandidateRuntime:
    def run(self, data):
        draft = EventCandidateDraft.model_validate(
            {
                "event_time": "2026-08-17",
                "title": "最终事件",
                "summary": "Victim 遭遇同一安全事件，两篇报道提供互补事实。",
                "victim": "Victim",
                "attacker": "unknown",
                "attack_vector_or_cause": "vector",
                "affected_system": "system",
                "impact": "impact",
                "data_breach_scope": "unknown",
                "lesson": "lesson",
            }
        )
        return EventCandidateExecution(draft, "rendered-candidate", "raw-candidate")


def test_event_match_and_candidate_pipeline(tmp_path):
    store = NewsAgentStore(tmp_path / "news.db")
    a = incident("a", "https://x/a", "事件A", "1.2.3.4")
    b = incident("b", "https://x/b", "事件A复盘", "1.2.3.4")
    seed_fact(store, a)
    seed_fact(store, b)

    match = EventMatchPipeline(
        config=config(), store=store, runtime=FakeMatchRuntime(), skill_text="match skill"
    )
    groups, stats = match.run(triage_signature="triage", incident_signature="incident")
    assert stats.incident_count == 2 and stats.group_count == 1
    assert groups[0].event_id == deterministic_event_id(["a", "b"])

    candidates = CandidatePipeline(
        config=config(), store=store, runtime=FakeCandidateRuntime(), skill_text="candidate skill"
    )
    cstats = candidates.compose_events(
        groups=groups,
        triage_signature="triage",
        incident_signature="incident",
        event_match_signature=match.identity.analysis_signature,
    )
    assert cstats.event_succeeded == 1
    rows = store.list_event_candidates(
        upstream_triage_signature="triage",
        upstream_event_match_signature=match.identity.analysis_signature,
        analysis_signature=candidates.identity.analysis_signature,
    )
    result = json.loads(rows[0]["result_json"])
    assert result["source_article_ids"] == ["a", "b"]
    assert result["ioc"]["ip_count"] == 1  # exact duplicate across reports counted once


def test_policy_candidate_and_export(tmp_path):
    from news_agent.contracts import CollectorArticle

    store = NewsAgentStore(tmp_path / "news.db")
    p = policy("p", "https://x/p")
    article = CollectorArticle(
        source_article_id="p", title="政策", account="a", url="https://x/p", content="x"
    )
    store.save_policy_success(
        identity=RunIdentity("policy-sig", "stage", "contract", "skill", "model", "skill"),
        upstream_triage_signature="triage",
        article=article,
        input_sha256="input",
        result=p,
        rendered_input="r",
        raw_output="o",
    )
    pipeline = CandidatePipeline(
        config=config(), store=store, runtime=FakeCandidateRuntime(), skill_text="candidate skill"
    )
    assert pipeline.compose_policies(triage_signature="triage", policy_signature="policy-sig") == 1
    json_path, md_path = export_candidates(
        store=store,
        output_dir=tmp_path / "out",
        triage_signature="triage",
        incident_signature="incident-sig",
        policy_signature="policy-sig",
        event_match_signature="match-sig",
        event_candidate_signature="candidate-sig",
    )
    payload = json.loads(json_path.read_text(encoding="utf-8"))
    assert payload["manifest"]["policy_count"] == 1
    assert payload["policies"][0]["issuer"] == "机构"
    assert "合规政策候选" in md_path.read_text(encoding="utf-8")


def test_materialize_groups_event_id_stable():
    result = EventMatchResult.model_validate(
        {"groups": {"anything": {"canonical_title": "x", "member_article_ids": ["b", "a"], "match_reason": "same"}}}
    )
    group = materialize_groups(result)[0]
    assert group.event_id == deterministic_event_id(["a", "b"])


def test_tree_parsers_for_event_match_and_candidate():
    from news_agent.tree_text import parse_event_candidate_output, parse_event_match_output

    match = parse_event_match_output(
        """event_match_result:\n  groups:\n    group_1:\n      canonical_title: 同一事件\n      member_article_ids:\n        - a\n        - b\n      match_reason: 核心事实一致\n"""
    )
    assert match.groups["group_1"].member_article_ids == ["a", "b"]

    draft = parse_event_candidate_output(
        """event_candidate:\n  event_time: 2026-08-17\n  title: 事件\n  summary: 摘要\n  victim: Victim\n  attacker: unknown\n  attack_vector_or_cause: vector\n  affected_system: system\n  impact: impact\n  data_breach_scope: unknown\n  lesson: lesson\n"""
    )
    assert draft.title == "事件"
