import json

from news_agent.benchmark import evaluate
from news_agent.contracts import CollectorArticle, TriageResult
from news_agent.store import NewsAgentStore, RunIdentity


def test_benchmark_exposes_mismatch_details(tmp_path):
    store = NewsAgentStore(tmp_path / "news.db")
    identity = RunIdentity("sig", "stage", "contract", "skill", "model", "skill")
    article = CollectorArticle(
        source_article_id="sid",
        title="title",
        url="https://example.test",
        content="body",
    )
    result = TriageResult.model_validate(
        {
            "source_article_id": "sid",
            "decision": "DROP",
            "route": "non_target",
            "category": "research",
            "content_nature": "research_or_tutorial",
            "scores": {
                "relevance": 4,
                "impact": 2,
                "freshness": 4,
                "evidence_quality": 3,
                "audience_value": 1,
            },
            "reason": "被判断为研究文章。",
        }
    )
    store.save_success(
        identity=identity,
        article=article,
        input_sha256="hash",
        result=result,
        total_score=56.0,
        rendered_input="input",
        raw_output="output",
    )
    labels = tmp_path / "labels.jsonl"
    labels.write_text(
        json.dumps(
            {
                "source_article_id": "sid",
                "expected_decision": "KEEP",
                "expected_route": "security_event",
                "note": "真实事件复盘",
            },
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    summary = evaluate(store, analysis_signature="sig", labels_path=labels)
    assert len(summary.mismatches) == 1
    case = summary.mismatches[0]
    assert case.actual_decision == "DROP"
    assert case.row["reason"] == "被判断为研究文章。"
