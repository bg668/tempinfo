from news_agent.config import ScoringConfig
from news_agent.contracts import TriageScores
from news_agent.scoring import calculate_total_score


def test_equal_weights_are_normalized_to_100():
    scores = TriageScores(
        relevance=5,
        impact=5,
        freshness=5,
        evidence_quality=5,
        audience_value=5,
    )
    assert calculate_total_score(scores, ScoringConfig()) == 100.0


def test_mixed_equal_scores():
    scores = TriageScores(
        relevance=5,
        impact=4,
        freshness=3,
        evidence_quality=2,
        audience_value=1,
    )
    assert calculate_total_score(scores, ScoringConfig()) == 60.0
