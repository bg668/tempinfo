import sqlite3

from news_agent.collector_adapter import CollectorAdapter


def make_collector(path):
    conn = sqlite3.connect(path)
    conn.executescript(
        """
        CREATE TABLE feed_items(
            id INTEGER PRIMARY KEY,
            stable_id TEXT,
            url TEXT,
            fetch_status TEXT,
            published_at TEXT,
            discovered_at TEXT
        );
        CREATE TABLE article_contents(
            article_id INTEGER,
            title TEXT,
            account TEXT,
            published_at TEXT,
            content TEXT
        );
        """
    )
    conn.execute(
        "INSERT INTO feed_items VALUES(1,'sid','https://mp.weixin.qq.com/s/x','FETCHED','x','x')"
    )
    conn.execute(
        "INSERT INTO article_contents VALUES(1,'正常标题','正常账号','2026-08-17T10:00:00','正文')"
    )
    conn.commit()
    conn.close()


def test_adapter_uses_article_contents_metadata(tmp_path):
    db = tmp_path / "collector.db"
    make_collector(db)
    article = next(iter(CollectorAdapter(db).iter_fetched()))
    assert article.source_article_id == "sid"
    assert article.title == "正常标题"
    assert article.account == "正常账号"
    assert article.content == "正文"
