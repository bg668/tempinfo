import pytest

from news_agent.contracts import Certainty
from news_agent.tree_text import TreeTextError, parse_incident_output, parse_policy_output


def test_parse_incident_with_ioc_lists():
    result = parse_incident_output(
        """incident_result:
  source_article_id: sid
  event_time: 2026-08-17
  title: Framework客户信息泄露
  source_url: https://example.test/a
  summary: Framework披露客户信息被未授权访问。
  entities:
    victim:
      value: Framework
      certainty: confirmed
    attacker:
      value: unknown
      certainty: unknown
    attack_vector_or_cause: unknown
    affected_system: 客户信息系统
    impact: 客户信息泄露
  data_breach_scope: 客户联系信息
  lesson: 应加强第三方与客户数据访问控制。
  ioc:
    ips:
      - 1.2.3.4
    domains: []
    urls: []
    hashes:
      - 0123456789abcdef0123456789abcdef
    file_paths: []
"""
    )
    assert result.entities.victim.value == "Framework"
    assert result.entities.attacker.certainty == Certainty.UNKNOWN
    assert result.ioc.ips == ["1.2.3.4"]
    assert result.ioc.counts()["hash_count"] == 1


def test_parse_policy_with_lists():
    result = parse_policy_output(
        """policy_result:
  source_article_id: sid
  policy_time: 2026-08-17
  title: 大型个人信息处理者个人信息保护规定公开征求意见
  source_url: https://example.test/p
  issuer: 国家互联网信息办公室
  policy_name: 大型个人信息处理者个人信息保护规定（征求意见稿）
  policy_status: draft_for_comment
  effective_time: unknown
  affected_entities:
    - 大型个人信息处理者
  requirements:
    - 建立个人信息保护负责人制度
    - 履行规定的个人信息保护义务
  key_changes: []
  impact: 对大型个人信息处理者提出更明确的合规要求。
  summary: 国家互联网信息办公室就相关规定公开征求意见。
"""
    )
    assert result.policy_status.value == "draft_for_comment"
    assert len(result.requirements) == 2
    assert result.key_changes == []


def test_entity_unknown_pair_must_be_consistent():
    with pytest.raises(TreeTextError):
        parse_incident_output(
            """incident_result:
  source_article_id: sid
  event_time: unknown
  title: 事件
  source_url: https://example.test/a
  summary: 摘要
  entities:
    victim:
      value: unknown
      certainty: confirmed
    attacker:
      value: unknown
      certainty: unknown
    attack_vector_or_cause: unknown
    affected_system: unknown
    impact: unknown
  data_breach_scope: unknown
  lesson: unknown
  ioc:
    ips: []
    domains: []
    urls: []
    hashes: []
    file_paths: []
"""
        )
