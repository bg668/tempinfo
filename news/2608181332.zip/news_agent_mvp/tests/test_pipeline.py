import sqlite3

from news_agent.collector_adapter import CollectorAdapter
from news_agent.config import AppConfig
from news_agent.contracts import TriageResult
from news_agent.pipeline import TriagePipeline
from news_agent.stages.base import TriageExecution
from news_agent.store import NewsAgentStore


class FakeRuntime:
    def run(self, article):
        result = TriageResult.model_validate(
            {
                "source_article_id": article.source_article_id,
                "decision": "DROP",
                "route": "non_target",
                "category": "other",
                "content_nature": "procurement",
                "scores": {
                    "relevance": 0,
                    "impact": 1,
                    "freshness": 4,
                    "evidence_quality": 4,
                    "audience_value": 0,
                },
                "reason": "招投标信息，不属于目标资讯。",
            }
        )
        return TriageExecution(
            result=result,
            rendered_input="article:\n  source_article_id: sid",
            raw_output="raw output",
            output_attempts=(
                {
                    "attempt": 1,
                    "status": "INVALID",
                    "raw_text": "bad",
                    "error_type": "TreeTextError",
                    "error_message": "bad format",
                },
                {
                    "attempt": 2,
                    "status": "VALID",
                    "raw_text": "raw output",
                    "error_type": None,
                    "error_message": None,
                },
            ),
        )


def make_collector(path):
    conn = sqlite3.connect(path)
    conn.executescript(
        """
        CREATE TABLE feed_items(id INTEGER PRIMARY KEY, stable_id TEXT, url TEXT, fetch_status TEXT, published_at TEXT, discovered_at TEXT);
        CREATE TABLE article_contents(article_id INTEGER, title TEXT, account TEXT, published_at TEXT, content TEXT);
        INSERT INTO feed_items VALUES(1,'sid','https://x','FETCHED','2026-08-17','2026-08-17');
        INSERT INTO article_contents VALUES(1,'中标信息','账号','2026-08-17','某项目中标。');
        """
    )
    conn.commit(); conn.close()


def test_pipeline_is_incremental_and_persists_debug_trace(tmp_path):
    collector_db = tmp_path / "collector.db"
    make_collector(collector_db)
    config = AppConfig.model_validate(
        {
            "provider": {"base_url": "http://127.0.0.1:8000/v1"},
            "model": {"name": "test-model"},
        }
    )
    store = NewsAgentStore(tmp_path / "news.db")
    pipeline = TriagePipeline(
        config=config,
        collector=CollectorAdapter(collector_db),
        store=store,
        runtime=FakeRuntime(),
        skill_text="skill",
    )
    first = pipeline.run()
    second = pipeline.run()
    assert first.processed == 1 and first.drop == 1
    assert second.processed == 0
    row = store.get_result("sid", pipeline.identity.analysis_signature)
    assert row["rendered_input"].startswith("article:")
    assert row["skill_snapshot"] == "skill"
    assert '"status": "INVALID"' in row["output_attempts_json"]
