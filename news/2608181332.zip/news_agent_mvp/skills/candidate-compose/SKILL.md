# candidate-compose

## 目标

把一个已经完成 event-match 的安全 Event，整理成可以直接交给人工审核的候选资讯。输入是同一 Event 的一篇或多篇 `IncidentResult`，不是原始网页。

## 事实规则

- 只能使用输入 incident facts 中已有的信息；不联网、不补常识、不推测缺失事实。
- 多篇来源的信息一致时可以合并表达。
- 多篇来源存在冲突时，不擅自选择一个版本；用谨慎表达体现冲突，或写 `unknown`。
- 输入中的 `unknown` 不得自行补全。
- 不输出来源 ID、来源 URL 或 IOC 数量；这些由 Python 根据事件成员确定性附加。
- 不把一般背景知识、厂商宣传或作者观点写成事件事实。

## 字段要求

- `event_time`：事件实际发生/披露时间；无法确定写 `unknown`。
- `title`：面向人工审核的一句话标题，直接说明主体和核心安全事件，不追求营销化表达。
- `summary`：约 200~400 个中文字符，优先回答“谁、发生什么攻击/安全失效、如何进入或原因、影响什么系统、造成什么影响”。信息不足时宁可短，不凑字数。
- `victim`：确认的受害/目标主体；没有明确受害者写 `unknown`。
- `attacker`：已报道的攻击主体；未知写 `unknown`，不要把漏洞研究者或测试机构当成攻击者。
- `attack_vector_or_cause`：进入路径、利用方式、配置原因或安全失效原因。
- `affected_system`：被攻击或受影响的系统、产品、设备、服务。
- `impact`：已经发生或明确报道的后果；不要把“可能造成”改成“已经造成”。
- `data_breach_scope`：只记录有证据的数据泄露范围；没有数据泄露或范围未知写 `unknown`。
- `lesson`：从事件事实直接得到的安全启示，1~3 句，避免泛化口号。

## 输出

只输出以下树状文本，不要 Markdown 代码块，不要增加字段：

```text
event_candidate:
  event_time: ...
  title: ...
  summary: ...
  victim: ...
  attacker: ...
  attack_vector_or_cause: ...
  affected_system: ...
  impact: ...
  data_breach_scope: ...
  lesson: ...
```
