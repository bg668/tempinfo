from __future__ import annotations

import importlib
import os
import sqlite3
from datetime import datetime, time, timezone
from zoneinfo import ZoneInfo
import subprocess
import sys
from pathlib import Path

from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
SOURCE_DB = ROOT / 'tests' / 'test_source.db'
ANALYSIS_DB = ROOT / 'tests' / 'test_analysis.db'
subprocess.run(
    [sys.executable, str(ROOT/'scripts'/'init_demo_db.py'), str(SOURCE_DB), str(ANALYSIS_DB)],
    check=True, capture_output=True, text=True
)
os.environ['THREAT_SOURCE_DB_PATH'] = str(SOURCE_DB)
os.environ['THREAT_ANALYSIS_DB_PATH'] = str(ANALYSIS_DB)
os.environ['SOURCE_ARTICLE_KEY'] = 'id'

main = importlib.import_module('app.main')
client = TestClient(main.app)
HEAD = {'X-Requested-With':'XMLHttpRequest'}


def test_pages_and_navigation_cross_database():
    with client:
        for path in ['/', '/candidates', '/favorites', '/articles', '/feedback', '/candidates/c001', '/articles/1']:
            r = client.get(path)
            assert r.status_code == 200, (path, r.text)
        html = client.get('/').text
        assert '收藏' in html and '反馈记录' in html
        assert '累计采集' in html and '累计候选' in html and '今日新增数据' in html
        assert '来源原文' in html and '更多候选' in html and '今日新增分布' in html and '今日处理结果' in html
        assert '每项结论，都能回到它的来源' not in html
        assert '原始资讯、AI 分析与人工标记，分层保留' not in html
        assert '示例原始资讯 1' in html and '研究组1' in html
        assert '乱码标题1' not in html and '乱码来源1' not in html
        detail = client.get('/candidates/c001').text
        assert '示例原始资讯 1' in detail
        article = client.get('/articles/1').text
        assert '示例原始资讯 1' in article and '研究组1' in article
        assert '乱码标题1' not in article and '乱码来源1' not in article


def test_review_status_and_conflict_write_only_analysis_db():
    with client:
        before = SOURCE_DB.read_bytes()
        r = client.put('/api/v1/candidates/c001/review-status', headers=HEAD, json={'review_status':'starred','expected_review_version':0})
        assert r.status_code == 200, r.text
        data = r.json()
        assert data['review_status']=='starred' and data['review_version']==1 and data['reviewer_id']=='root'
        idem = client.put('/api/v1/candidates/c001/review-status', headers=HEAD, json={'review_status':'starred','expected_review_version':0})
        assert idem.status_code==200 and idem.json()['review_version']==1
        conflict = client.put('/api/v1/candidates/c001/review-status', headers=HEAD, json={'review_status':'ignored','expected_review_version':0})
        assert conflict.status_code==409 and conflict.json()['current']['review_status']=='starred'
        fav = client.get('/favorites')
        assert '示例候选 1' in fav.text
        assert SOURCE_DB.read_bytes() == before


def test_feedback_idempotency_and_validation():
    with client:
        payload={'feedback_id':'fb-1','target_type':'candidate','target_id':'c001','content':'证据不足，请复核归属。'}
        r=client.post('/api/v1/feedback',headers=HEAD,json=payload); assert r.status_code==201, r.text
        r2=client.post('/api/v1/feedback',headers=HEAD,json=payload); assert r2.status_code==201 and r2.json()==r.json()
        changed={**payload,'content':'不同内容'}
        r3=client.post('/api/v1/feedback',headers=HEAD,json=changed); assert r3.status_code==409
        blank=client.post('/api/v1/feedback',headers=HEAD,json={**payload,'feedback_id':'fb-2','content':'   '}); assert blank.status_code==422
        missing=client.post('/api/v1/feedback',headers=HEAD,json={**payload,'feedback_id':'fb-3','target_id':'missing'}); assert missing.status_code==404
        page=client.get('/feedback'); assert '证据不足，请复核归属。' in page.text
        with sqlite3.connect(ANALYSIS_DB) as conn:
            assert conn.execute("SELECT COUNT(*) FROM feedback WHERE feedback_id='fb-1'").fetchone()[0] == 1


def test_processing_item_feedback_and_write_guard():
    with client:
        payload={'feedback_id':'fb-p','target_type':'processing_item','target_id':'p001','content':'处理判断需要补充证据。'}
        r=client.post('/api/v1/feedback',headers=HEAD,json=payload); assert r.status_code==201
        no_guard=client.post('/api/v1/feedback',json={**payload,'feedback_id':'fb-no-guard'}); assert no_guard.status_code==403


def test_source_database_is_opened_read_only():
    with client:
        conn = main.repo.source_connect()
        try:
            try:
                conn.execute("CREATE TABLE should_fail(x INTEGER)")
                raised = False
            except sqlite3.OperationalError:
                raised = True
            assert raised
        finally:
            conn.close()



def test_candidate_type_filters_use_canonical_enums_everywhere():
    with client:
        event_page = client.get('/candidates?type=security_event')
        assert event_page.status_code == 200
        assert '示例候选 1' in event_page.text
        assert '示例候选 3' not in event_page.text
        assert 'value="security_event" selected' in event_page.text

        policy_page = client.get('/candidates?type=compliance_policy')
        assert policy_page.status_code == 200
        assert '示例候选 3' in policy_page.text
        assert '示例候选 1' not in policy_page.text
        assert 'value="compliance_policy" selected' in policy_page.text

        home = client.get('/').text
        assert 'data-home-type="security_event"' in home
        assert 'data-home-type="compliance_policy"' in home
        assert 'data-home-candidate-type="security_event"' in home
        assert 'data-home-candidate-type="compliance_policy"' in home
        assert '/candidates?type=security_event' in home
        assert '/candidates?type=compliance_policy' in home


def test_today_statistics_convert_offsets_to_business_timezone():
    tz = ZoneInfo('Asia/Shanghai')
    business_day = datetime.now(tz).date()
    local_boundary = datetime.combine(business_day, time(0, 30), tzinfo=tz)
    utc_text = local_boundary.astimezone(timezone.utc).isoformat()

    with client:
        before = main.repo.dashboard()
        with sqlite3.connect(SOURCE_DB) as conn:
            old_source = conn.execute('SELECT discovered_at FROM feed_items WHERE id=1').fetchone()[0]
            conn.execute('UPDATE feed_items SET discovered_at=? WHERE id=1', (utc_text,))
            conn.commit()
        with sqlite3.connect(ANALYSIS_DB) as conn:
            old_candidate = conn.execute("SELECT created_at FROM candidates WHERE candidate_record_id='c001'").fetchone()[0]
            old_processing = conn.execute("SELECT created_at FROM processing_items WHERE item_id='p001'").fetchone()[0]
            conn.execute("UPDATE candidates SET created_at=? WHERE candidate_record_id='c001'", (utc_text,))
            conn.execute("UPDATE processing_items SET created_at=? WHERE item_id='p001'", (utc_text,))
            conn.commit()
        try:
            after = main.repo.dashboard()
            assert after['source_today'] == before['source_today']
            assert after['candidate_today'] == before['candidate_today']
            assert after['processing_today'] == before['processing_today']
            # 00:30 Asia/Shanghai must land in the first half-hour bin even though its UTC date is previous day.
            assert any(b['label'] == '00:30' and (b['sources'] or b['candidates']) for b in after['activity']) or after['source_today'] > 0
        finally:
            with sqlite3.connect(SOURCE_DB) as conn:
                conn.execute('UPDATE feed_items SET discovered_at=? WHERE id=1', (old_source,))
                conn.commit()
            with sqlite3.connect(ANALYSIS_DB) as conn:
                conn.execute("UPDATE candidates SET created_at=? WHERE candidate_record_id='c001'", (old_candidate,))
                conn.execute("UPDATE processing_items SET created_at=? WHERE item_id='p001'", (old_processing,))
                conn.commit()


def test_wrong_source_article_key_fails_fast():
    from app.config import Settings
    from app.db import Repository, SchemaError
    bad_repo = Repository(Settings(
        source_db_path=SOURCE_DB,
        analysis_db_path=ANALYSIS_DB,
        source_article_key='stable_id',
    ))
    try:
        bad_repo.migrate_web_schema()
        raised = False
    except SchemaError as exc:
        raised = True
        assert 'SOURCE_ARTICLE_KEY=stable_id' in str(exc)
        assert '无法关联' in str(exc)
    assert raised

def test_legacy_single_database_env_is_not_supported(monkeypatch):
    from app.config import get_settings
    monkeypatch.delenv('THREAT_SOURCE_DB_PATH', raising=False)
    monkeypatch.delenv('THREAT_ANALYSIS_DB_PATH', raising=False)
    monkeypatch.setenv('THREAT_DB_PATH', str(ANALYSIS_DB))
    monkeypatch.setenv('SOURCE_ARTICLE_KEY', 'id')
    try:
        get_settings()
        raised = False
    except RuntimeError as exc:
        raised = True
        assert 'THREAT_SOURCE_DB_PATH' in str(exc)
    assert raised


def test_batch1_accessibility_contracts():
    with client:
        home = client.get('/').text
        candidates = client.get('/candidates').text
        assert '<label class="visually-hidden" for="feedback-content">反馈内容</label>' in home
        assert 'aria-label="人工标记"' in candidates
        assert 'aria-label="候选类型"' in candidates
        assert 'aria-label="排序方式"' in candidates
        assert '<kbd>/</kbd>' not in home

    js = (ROOT / 'app' / 'static' / 'app.js').read_text(encoding='utf-8')
    css = (ROOT / 'app' / 'static' / 'app.css').read_text(encoding='utf-8')
    mvp_css = (ROOT / 'app' / 'static' / 'mvp.css').read_text(encoding='utf-8')

    assert "!editable&&e.key==='/'" not in js
    assert "e.key.toLowerCase()==='k'&&(e.ctrlKey||e.metaKey)" in js
    assert 'outline:none!important' not in css
    assert '.search-field input:focus-visible,.search-dialog-head input:focus-visible{outline:3px solid #5b6a7a' in css
    assert '.review-select:focus-visible{outline:3px solid #5b6a7a' in mvp_css
    assert '.feedback-body textarea:focus-visible{outline:3px solid #5b6a7a' in mvp_css


def test_batch2_contrast_tokens_and_time_formatting():
    with client:
        home = client.get('/').text
        candidates = client.get('/candidates').text
        candidate_detail = client.get('/candidates/c001').text
        articles = client.get('/articles').text
        article_detail = client.get('/articles/1').text

        # UI timestamps are presentation-formatted in the configured business timezone.
        home_template = (ROOT / 'app' / 'templates' / 'home.html').read_text(encoding='utf-8')
        assert '[11:16]' not in home_template
        for html in (candidates, candidate_detail, articles, article_detail):
            assert 'T08:' not in html
        assert 'datetime="' in home

        api = client.get('/api/v1/processing-items/p001')
        assert api.status_code == 200
        assert api.json()['created_at_display']
        assert 'T' not in api.json()['created_at_display']

    css = (ROOT / 'app' / 'static' / 'app.css').read_text(encoding='utf-8')
    mvp_css = (ROOT / 'app' / 'static' / 'mvp.css').read_text(encoding='utf-8')
    assert '--muted:#5d6a79' in css
    assert '--muted:#5d6b61' in css
    assert '.h3-panel-head>a,.h3-icon-btn{color:#5f7a68' in css
    assert '.evidence-summary .icon{color:#7f90a2' in css
    assert '#667382' in mvp_css
    assert '#cbe2d1' in mvp_css
    assert '#5d6b5f' in mvp_css


def test_batch3_semantic_structure_and_home_url_state():
    with client:
        home = client.get('/?type=security_event')
        assert home.status_code == 200
        html = home.text
        assert 'role="tablist"' not in html
        assert '<nav class="mini-tabs" aria-label="候选类型筛选">' in html
        assert 'data-home-type="security_event"' in html
        assert 'class="active" aria-current="true">安全事件</a>' in html
        assert 'id="home-filter-status"' in html
        assert 'id="home-rows" role="tabpanel"' not in html
        assert '<table class="visually-hidden"><caption>今日半小时新增数量</caption>' in html
        assert 'h3-feature-controls' not in html
        assert '上一条焦点' not in html and '下一条焦点' not in html

        candidates = client.get('/candidates').text
        assert 'id="candidate-results-heading" class="visually-hidden">候选结果</h2>' in candidates
        assert '<span class="visually-hidden">推荐评分 </span>' in candidates
        assert '<span class="visually-hidden">来源 </span>' in candidates

        articles = client.get('/articles').text
        assert 'id="source-results-heading" class="visually-hidden">原始资讯列表</h2>' in articles

        feedback = client.get('/feedback').text
        assert 'id="feedback-results-heading" class="visually-hidden">反馈列表</h2>' in feedback

        detail_template = (ROOT / 'app' / 'templates' / 'candidate_detail.html').read_text(encoding='utf-8')
        assert 'class="ioc-tabs" role="group" aria-label="指标类型"' not in detail_template
        assert 'class="ioc-summary"' in detail_template


def test_batch3_interaction_and_low_priority_polish_contracts():
    js = (ROOT / 'app' / 'static' / 'app.js').read_text(encoding='utf-8')
    css = (ROOT / 'app' / 'static' / 'mvp.css').read_text(encoding='utf-8')
    base = (ROOT / 'app' / 'templates' / 'base.html').read_text(encoding='utf-8')

    assert "url.searchParams.set('type',selected)" in js
    assert "url.searchParams.delete('type')" in js
    assert "history.replaceState({homeType:selected}" in js
    assert "setAttribute('aria-selected'" not in js
    assert "['ArrowLeft','ArrowRight','Home','End']" not in js
    assert "setAttribute('aria-current','true')" in js
    assert "statusClasses = new Set" in js
    assert 'id="announcer"' in base and 'aria-atomic="true"' in base

    assert '--app-header-h:76px' in css
    assert 'overscroll-behavior:contain' in css
    assert '.preserve-lines{overflow-wrap:anywhere;word-break:break-word}' in css
    assert '.ioc-row{grid-template-columns:64px minmax(0,1fr) 40px}' in css
    assert '.row-feedback{padding:7px 10px}' in css
    assert '.h3-bar{transition:opacity .15s}' in css



def test_batch4_mvp_value_fixes():
    with client:
        home = client.get('/?type=security_event').text
        candidates = client.get('/candidates').text
        candidate_detail = client.get('/candidates/c001').text
        article_detail = client.get('/articles/1').text

        # Home filter is ordinary URL-backed navigation, not a fake ARIA tab pattern.
        assert 'role="tab"' not in home
        assert 'role="tabpanel"' not in home
        assert 'aria-current="true">安全事件</a>' in home

        # Footer is document-level, outside main.
        for html in (home, candidates, candidate_detail, article_detail):
            assert html.index('</main>') < html.index('<footer class="footer container" role="contentinfo">')

        # Repeated controls carry row/item context.
        assert 'aria-label="人工标记：示例候选 1"' in candidates
        assert 'aria-label="人工标记：示例候选 1"' in candidate_detail

        # Server no longer lies about the current report section.
        assert '<nav class="report-tabs" aria-label="报告章节" data-report-nav><a href="#overview">情报概览</a>' in candidate_detail
        assert '<a href="#original-text" class="active">' not in article_detail

    mvp_css = (ROOT / 'app' / 'static' / 'mvp.css').read_text(encoding='utf-8')
    js = (ROOT / 'app' / 'static' / 'app.js').read_text(encoding='utf-8')
    base = (ROOT / 'app' / 'templates' / 'base.html').read_text(encoding='utf-8')
    detail_template = (ROOT / 'app' / 'templates' / 'candidate_detail.html').read_text(encoding='utf-8')

    # Interactive controls have a dedicated visible boundary; chart marks use stronger muted colors.
    assert '--line-strong:#8695a6' in mvp_css
    assert '.search-field,.select-field select,.review-select,.feedback-body textarea{border-color:var(--line-strong)}' in mvp_css
    assert '.h3-no-results{color:#5e7254}' in mvp_css
    assert '.h3-ring .ring-amber{stroke:#ad7b2f}' in mvp_css
    assert '.h3-bar.original{background:#6d8fb4}' in mvp_css
    assert '.h3-decision-meter .keep{background:#5b8a66}' in mvp_css

    # One home-filter live region only, and candidate report nav reflects scroll position dynamically.
    assert 'announce(`${homeTypeNames[selected]}' not in js
    assert "window.addEventListener('scroll',schedule,{passive:true})" in js
    assert "setAttribute('aria-current','location')" in js

    # IOC summary no longer masquerades as a tab; copy controls identify the value.
    assert 'ioc-tab-static active' not in detail_template
    assert 'aria-label="复制指标 {{ value|e }}"' in detail_template

    # Footer is centralized in base so individual pages cannot accidentally nest it in <main> again.
    assert '{% include "_footer.html" %}' in base
