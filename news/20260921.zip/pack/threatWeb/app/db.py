from __future__ import annotations

import contextlib
import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, time, timedelta, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from .config import Settings

VALID_REVIEW_STATUSES = {"pending", "starred", "ignored"}
VALID_CANDIDATE_TYPES = {"security_event", "compliance_policy"}
CANDIDATE_TYPE_NAMES = {"security_event": "安全事件", "compliance_policy": "合规政策"}
CANDIDATE_TYPE_ALIASES = {
    "security_event": "security_event",
    "compliance_policy": "compliance_policy",
    "安全事件": "security_event",
    "合规政策": "compliance_policy",
}


class DataStoreError(RuntimeError):
    pass


class NotFoundError(DataStoreError):
    pass


@dataclass
class ConflictError(DataStoreError):
    message: str
    current: dict[str, Any] | None = None

    def __str__(self) -> str:
        return self.message


class SchemaError(DataStoreError):
    pass


class Repository:
    """Two-database Web repository.

    source DB: feed_items/article_contents, opened read-only.
    analysis DB: processing_items/candidates/feedback, read-write.
    Cross-database relations are assembled in Python; SQLite ATTACH is intentionally not used.
    """

    def __init__(self, settings: Settings):
        self.settings = settings
        self.source_db_path = Path(settings.source_db_path)
        self.analysis_db_path = Path(settings.analysis_db_path)
        self.tz = ZoneInfo(settings.business_timezone)
        self._source_key = settings.source_article_key

    @staticmethod
    def _open(path: Path, *, readonly: bool) -> sqlite3.Connection:
        if not path.exists():
            raise SchemaError(f"数据库不存在: {path}")
        if readonly:
            uri = f"file:{path.resolve().as_posix()}?mode=ro"
            conn = sqlite3.connect(uri, uri=True, timeout=5.0)
            conn.execute("PRAGMA query_only=ON")
        else:
            conn = sqlite3.connect(path, timeout=5.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def source_connect(self) -> sqlite3.Connection:
        return self._open(self.source_db_path, readonly=True)

    def analysis_connect(self) -> sqlite3.Connection:
        conn = self._open(self.analysis_db_path, readonly=False)
        try:
            conn.execute("PRAGMA journal_mode=WAL")
        except sqlite3.DatabaseError:
            pass
        return conn

    @contextlib.contextmanager
    def analysis_transaction(self):
        conn = self.analysis_connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    @staticmethod
    def _tables(conn: sqlite3.Connection) -> set[str]:
        return {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}

    def _columns(self, conn: sqlite3.Connection, table: str) -> set[str]:
        return {r[1] for r in conn.execute(f"PRAGMA table_info({self._qi(table)})")}

    @staticmethod
    def _qi(name: str) -> str:
        if not name.replace("_", "").isalnum():
            raise SchemaError(f"非法标识符: {name}")
        return f'"{name}"'

    def _parse_timestamp(self, value: Any) -> datetime | None:
        """Parse stored timestamps and convert them to the configured business timezone.

        Offset-aware values are converted normally. Naive values are treated as already being
        in the configured business timezone, which matches the local Collector/Agent contract.
        """
        if value in (None, ""):
            return None
        text = str(value).strip()
        if not text:
            return None
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        try:
            dt = datetime.fromisoformat(text)
        except ValueError:
            return None
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=self.tz)
        return dt.astimezone(self.tz)

    def _is_business_day(self, value: Any, day) -> bool:
        dt = self._parse_timestamp(value)
        return dt is not None and dt.date() == day

    def _business_day_bounds_utc(self, day) -> tuple[str, str]:
        start_local = datetime.combine(day, time.min, tzinfo=self.tz)
        end_local = datetime.combine(day + timedelta(days=1), time.min, tzinfo=self.tz)
        return (start_local.astimezone(timezone.utc).isoformat(), end_local.astimezone(timezone.utc).isoformat())

    def _day_range_sql(self, column: str) -> str:
        q = self._qi(column)
        return f"julianday({q}) >= julianday(?) AND julianday({q}) < julianday(?)"

    def _candidate_type(self, value: Any) -> str:
        raw = str(value or "").strip()
        return CANDIDATE_TYPE_ALIASES.get(raw, raw)

    def migrate_web_schema(self) -> None:
        if not self.source_db_path.exists():
            raise SchemaError(
                f"Source DB 不存在: {self.source_db_path}. 请设置 THREAT_SOURCE_DB_PATH 指向包含 feed_items/article_contents 的数据库。"
            )
        if not self.analysis_db_path.exists():
            raise SchemaError(
                f"Analysis DB 不存在: {self.analysis_db_path}. 请设置 THREAT_ANALYSIS_DB_PATH 指向包含 candidates/processing_items 的数据库。"
            )

        # Source DB is validation-only and remains read-only.
        with self.source_connect() as conn:
            tables = self._tables(conn)
            for table in ("feed_items", "article_contents"):
                if table not in tables:
                    raise SchemaError(f"Source DB 缺少必要表: {table}")
            fcols = self._columns(conn, "feed_items")
            if self.source_key not in fcols:
                raise SchemaError(f"Source DB 的 feed_items 缺少 SOURCE_ARTICLE_KEY 指定字段: {self.source_key}")
            if "id" not in fcols:
                raise SchemaError("Source DB 的 feed_items 缺少 id，无法关联 article_contents.article_id")
            acols = self._columns(conn, "article_contents")
            required_article = {"article_id", "title", "account", "published_at", "url", "content"}
            missing_article = required_article - acols
            if missing_article:
                raise SchemaError("article_contents 缺少字段: " + ", ".join(sorted(missing_article)))

        # All Web schema changes happen only in Analysis DB.
        with self.analysis_transaction() as conn:
            tables = self._tables(conn)
            for table in ("candidates", "processing_items"):
                if table not in tables:
                    raise SchemaError(f"Analysis DB 缺少必要表: {table}")
            pcols = self._columns(conn, "processing_items")
            if "source_article_id" not in pcols:
                raise SchemaError("Analysis DB 的 processing_items 缺少 source_article_id")
            ccols = self._columns(conn, "candidates")
            required = {"candidate_record_id", "title", "summary"}
            missing = required - ccols
            if missing:
                raise SchemaError(f"candidates 缺少字段: {', '.join(sorted(missing))}")
            additions = {
                "review_status": "TEXT",
                "reviewer_id": "TEXT",
                "reviewed_at": "TEXT",
                "updated_at": "TEXT",
                "review_version": "INTEGER NOT NULL DEFAULT 0",
            }
            for name, ddl in additions.items():
                if name not in ccols:
                    conn.execute(f"ALTER TABLE candidates ADD COLUMN {self._qi(name)} {ddl}")
            conn.execute("UPDATE candidates SET review_status='pending' WHERE review_status IS NULL OR TRIM(review_status)='' ")
            bad = conn.execute(
                "SELECT review_status, COUNT(*) n FROM candidates WHERE review_status NOT IN ('pending','starred','ignored') GROUP BY review_status"
            ).fetchall()
            if bad:
                values = ", ".join(f"{r['review_status']}({r['n']})" for r in bad)
                raise SchemaError(
                    "检测到旧/未知人工状态，拒绝自动猜测迁移: " + values + ". 请先显式迁移为 pending/starred/ignored。"
                )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS feedback (
                    feedback_id TEXT PRIMARY KEY,
                    target_type TEXT NOT NULL CHECK(target_type IN ('candidate','processing_item')),
                    target_id TEXT NOT NULL,
                    content TEXT NOT NULL CHECK(length(trim(content)) > 0 AND length(content) <= 5000),
                    created_at TEXT NOT NULL
                )
                """
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_feedback_target ON feedback(target_type,target_id,created_at DESC)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_feedback_created ON feedback(created_at DESC)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_candidates_review_status ON candidates(review_status, reviewed_at DESC, candidate_record_id DESC)")

        self._validate_source_key_alignment()

    def _validate_source_key_alignment(self) -> None:
        """Fail fast when SOURCE_ARTICLE_KEY cannot resolve any real processing source id."""
        with self.analysis_connect() as aconn:
            sample = [str(r[0]) for r in aconn.execute(
                "SELECT DISTINCT source_article_id FROM processing_items WHERE source_article_id IS NOT NULL AND TRIM(CAST(source_article_id AS TEXT))!='' LIMIT 50"
            ).fetchall()]
        if not sample:
            return
        placeholders = ",".join("?" for _ in sample)
        with self.source_connect() as sconn:
            matched = sconn.execute(
                f"SELECT COUNT(*) FROM feed_items WHERE CAST({self._qi(self.source_key)} AS TEXT) IN ({placeholders})",
                sample,
            ).fetchone()[0]
        if matched == 0:
            preview = ", ".join(sample[:3])
            raise SchemaError(
                f"SOURCE_ARTICLE_KEY={self.source_key} 无法关联 processing_items.source_article_id（样例: {preview}）。"
                "请确认实际关联键；当前处理结果常见为 feed_items.id。"
            )

    @property
    def source_key(self) -> str:
        return self._source_key

    @staticmethod
    def _rowdict(row: sqlite3.Row | None) -> dict[str, Any] | None:
        return dict(row) if row else None

    @staticmethod
    def _jsonish(value: Any) -> Any:
        if value is None or isinstance(value, (dict, list, int, float, bool)):
            return value
        if isinstance(value, str):
            s = value.strip()
            if s and s[0] in "[{":
                try:
                    return json.loads(s)
                except json.JSONDecodeError:
                    return value
        return value

    def _normalize_candidate(self, row: sqlite3.Row) -> dict[str, Any]:
        d = dict(row)
        for k, v in list(d.items()):
            if k.endswith("_json"):
                d[k] = self._jsonish(v)
        d.setdefault("review_status", "pending")
        d.setdefault("review_version", 0)
        if "candidate_type" in d:
            d["candidate_type"] = self._candidate_type(d.get("candidate_type"))
        return d

    def _candidate_select_columns(self, conn: sqlite3.Connection) -> list[str]:
        cols = self._columns(conn, "candidates")
        wanted = [
            "candidate_record_id","candidate_id","run_id","candidate_type","primary_item_id","title","summary",
            "reason","total_score","facts_json","ioc_json","excluded_iocs_json","quality_warnings_json",
            "score_strategy","score_source_item_id","match_reason","created_at","updated_at",
            "review_status","reviewer_id","reviewed_at","review_version",
            "relevance","impact","freshness","evidence_quality","audience_value",
        ]
        return [c for c in wanted if c in cols]

    def list_candidates(self, *, status: str | None = None, q: str = "", candidate_type: str | None = None,
                        page: int = 1, page_size: int = 20, sort: str = "score", favorites: bool = False) -> dict[str, Any]:
        with self.analysis_connect() as conn:
            cols = self._candidate_select_columns(conn)
            where, args = [], []
            if favorites:
                where.append("review_status='starred'")
            elif status and status != "all":
                if status not in VALID_REVIEW_STATUSES:
                    raise ValueError("非法人工状态")
                where.append("review_status=?"); args.append(status)
            if candidate_type and candidate_type != "all":
                canonical_type = self._candidate_type(candidate_type)
                if canonical_type not in VALID_CANDIDATE_TYPES:
                    raise ValueError("非法候选类型")
                # Legacy Chinese values are included only as read compatibility; all new data uses canonical enums.
                aliases = [k for k, v in CANDIDATE_TYPE_ALIASES.items() if v == canonical_type]
                where.append("candidate_type IN (" + ",".join("?" for _ in aliases) + ")")
                args.extend(aliases)
            if q.strip():
                where.append("(title LIKE ? OR summary LIKE ? OR reason LIKE ?)")
                pat = f"%{q.strip()}%"; args.extend([pat, pat, pat])
            sql_where = (" WHERE " + " AND ".join(where)) if where else ""
            total = conn.execute("SELECT COUNT(*) FROM candidates" + sql_where, args).fetchone()[0]
            page_size = max(1, min(page_size, self.settings.page_size_max))
            pages = max(1, (total + page_size - 1) // page_size)
            page = max(1, min(page, pages))
            if favorites:
                order = "CASE WHEN reviewed_at IS NULL THEN 1 ELSE 0 END, reviewed_at DESC, candidate_record_id DESC"
            elif sort == "newest":
                order = "created_at DESC, candidate_record_id DESC"
            else:
                order = "total_score DESC, created_at DESC, candidate_record_id DESC"
            selected = ",".join("c." + self._qi(c) for c in cols)
            rows = conn.execute(
                f"""SELECT {selected},
                    (SELECT COUNT(DISTINCT p.source_article_id) FROM processing_items p
                     WHERE p.candidate_record_id=c.candidate_record_id) AS source_count
                    FROM candidates c{sql_where} ORDER BY {order} LIMIT ? OFFSET ?""",
                [*args, page_size, (page-1)*page_size]
            ).fetchall()
            return {"items":[self._normalize_candidate(r) for r in rows],"total":total,"page":page,"page_size":page_size,"pages":pages}

    def get_candidate(self, candidate_record_id: str) -> dict[str, Any]:
        with self.analysis_connect() as conn:
            cols = self._candidate_select_columns(conn)
            row = conn.execute(
                f"SELECT {','.join(self._qi(c) for c in cols)} FROM candidates WHERE candidate_record_id=?",
                (candidate_record_id,),
            ).fetchone()
            if not row:
                raise NotFoundError("候选不存在")
            result = self._normalize_candidate(row)
        result["processing_items"] = self.list_processing_for_candidate(candidate_record_id)
        result["sources"] = self.sources_for_candidate(candidate_record_id)
        return result

    @staticmethod
    def _excerpt(value: Any, limit: int = 180) -> str:
        if not value:
            return ""
        text = " ".join(str(value).split())
        return text if len(text) <= limit else text[:limit].rstrip() + "…"

    def _source_select_sql(self) -> str:
        # article_contents is the readable article layer. feed_items keeps identity/discovery metadata.
        return f"""
            SELECT
                f.id AS id,
                f.stable_id AS stable_id,
                f.source AS source,
                f.source_id AS source_id,
                COALESCE(NULLIF(ac.account,''), f.account) AS account,
                COALESCE(NULLIF(ac.title,''), f.title) AS title,
                COALESCE(NULLIF(ac.published_at,''), f.published_at) AS published_at,
                f.discovered_at AS discovered_at,
                COALESCE(NULLIF(ac.url,''), f.url) AS url,
                ac.content AS content
            FROM feed_items f
            LEFT JOIN article_contents ac ON ac.article_id=f.id
        """

    def _normalize_source(self, row: sqlite3.Row | dict[str, Any]) -> dict[str, Any]:
        d = dict(row)
        d["excerpt"] = self._excerpt(d.get("content"))
        return d

    def _source_rows_by_ids(self, source_ids: list[str]) -> dict[str, dict[str, Any]]:
        ids = [str(x) for x in source_ids if x is not None]
        if not ids:
            return {}
        unique = list(dict.fromkeys(ids))
        placeholders = ",".join("?" for _ in unique)
        with self.source_connect() as conn:
            rows = conn.execute(
                self._source_select_sql()
                + f" WHERE CAST(f.{self._qi(self.source_key)} AS TEXT) IN ({placeholders})",
                unique,
            ).fetchall()
        result: dict[str, dict[str, Any]] = {}
        for row in rows:
            d = self._normalize_source(row)
            result[str(d[self.source_key])] = d
        return result

    def list_processing_for_candidate(self, candidate_record_id: str) -> list[dict[str, Any]]:
        with self.analysis_connect() as conn:
            cols = self._columns(conn, "processing_items")
            wanted = ["item_id","source_article_id","candidate_record_id","item_kind","item_key","source_heading","source_text",
                      "process_status","decision","title","summary","reason","facts_json","ioc_json","quality_warnings_json",
                      "errors_json","created_at","run_id","total_score","route","category"]
            selected = [c for c in wanted if c in cols]
            rows = conn.execute(
                f"SELECT {','.join(self._qi(c) for c in selected)} FROM processing_items WHERE candidate_record_id=? ORDER BY created_at ASC,item_id ASC",
                (candidate_record_id,),
            ).fetchall()
        items = [{k:self._jsonish(v) if k.endswith('_json') else v for k,v in dict(r).items()} for r in rows]
        source_map = self._source_rows_by_ids([x.get("source_article_id") for x in items])
        for item in items:
            src = source_map.get(str(item.get("source_article_id")))
            if src:
                for key in ("account","title","published_at","discovered_at"):
                    if key in src:
                        item[f"source_{key}"] = src[key]
        return items

    def sources_for_candidate(self, candidate_record_id: str) -> list[dict[str, Any]]:
        with self.analysis_connect() as conn:
            rows = conn.execute(
                "SELECT DISTINCT source_article_id FROM processing_items WHERE candidate_record_id=? AND source_article_id IS NOT NULL",
                (candidate_record_id,),
            ).fetchall()
        source_map = self._source_rows_by_ids([r[0] for r in rows])
        result = list(source_map.values())
        order_key = "published_at"
        result.sort(key=lambda x: str(x.get(order_key) or x.get("discovered_at") or ""), reverse=True)
        return result

    def _analysis_counts_for_sources(self, source_ids: list[str]) -> dict[str, tuple[int, int]]:
        ids = list(dict.fromkeys(str(x) for x in source_ids if x is not None))
        if not ids:
            return {}
        placeholders = ",".join("?" for _ in ids)
        with self.analysis_connect() as conn:
            rows = conn.execute(
                f"""SELECT CAST(source_article_id AS TEXT) sid,
                    SUM(CASE WHEN COALESCE(item_kind,'')!='brief_parent' THEN 1 ELSE 0 END) processing_count,
                    COUNT(DISTINCT candidate_record_id) candidate_count
                    FROM processing_items
                    WHERE CAST(source_article_id AS TEXT) IN ({placeholders})
                    GROUP BY CAST(source_article_id AS TEXT)""",
                ids,
            ).fetchall()
        return {str(r["sid"]):(int(r["processing_count"] or 0), int(r["candidate_count"] or 0)) for r in rows}

    def list_sources(self, *, q: str = "", page: int = 1, page_size: int = 20) -> dict[str, Any]:
        with self.source_connect() as conn:
            where, args = "", []
            if q.strip():
                pat = f"%{q.strip()}%"
                where = """ WHERE (
                    COALESCE(NULLIF(ac.title,''), f.title) LIKE ? OR
                    COALESCE(NULLIF(ac.account,''), f.account) LIKE ? OR
                    ac.content LIKE ?
                )"""
                args = [pat, pat, pat]
            total = conn.execute(
                "SELECT COUNT(*) FROM feed_items f LEFT JOIN article_contents ac ON ac.article_id=f.id" + where,
                args,
            ).fetchone()[0]
            page_size = max(1, min(page_size, self.settings.page_size_max))
            pages = max(1, (total + page_size - 1) // page_size)
            page = max(1, min(page, pages))
            rows = conn.execute(
                self._source_select_sql() + where
                + " ORDER BY COALESCE(NULLIF(ac.published_at,''), f.published_at, f.discovered_at) DESC, f.id DESC LIMIT ? OFFSET ?",
                [*args, page_size, (page-1)*page_size],
            ).fetchall()
        items = [self._normalize_source(r) for r in rows]
        counts = self._analysis_counts_for_sources([x.get(self.source_key) for x in items])
        for item in items:
            pc, cc = counts.get(str(item.get(self.source_key)), (0,0))
            item["processing_count"] = pc
            item["candidate_count"] = cc
        return {"items":items,"total":total,"page":page,"page_size":page_size,"pages":pages}

    def get_source(self, source_id: str) -> dict[str, Any]:
        with self.source_connect() as conn:
            row = conn.execute(
                self._source_select_sql() + f" WHERE CAST(f.{self._qi(self.source_key)} AS TEXT)=?",
                (str(source_id),),
            ).fetchone()
            if not row:
                raise NotFoundError("原始资讯不存在")
            result = self._normalize_source(row)
        with self.analysis_connect() as conn:
            pcols = self._columns(conn,"processing_items")
            pwanted = [c for c in ["item_id","source_article_id","candidate_record_id","item_kind","item_key","source_heading","source_text","process_status","decision","title","summary","reason","created_at"] if c in pcols]
            prows = conn.execute(
                f"SELECT {','.join(self._qi(c) for c in pwanted)} FROM processing_items WHERE CAST(source_article_id AS TEXT)=? ORDER BY created_at ASC,item_id ASC",
                (str(source_id),),
            ).fetchall()
            result["processing_items"] = [dict(r) for r in prows]
        return result

    def get_processing_item(self, item_id: str) -> dict[str, Any]:
        with self.analysis_connect() as conn:
            row = conn.execute("SELECT * FROM processing_items WHERE item_id=?",(item_id,)).fetchone()
            if not row:
                raise NotFoundError("处理记录不存在")
            return {k:self._jsonish(v) if k.endswith('_json') else v for k,v in dict(row).items()}

    def set_review_status(self, candidate_record_id: str, status: str, expected_version: int) -> dict[str, Any]:
        if status not in VALID_REVIEW_STATUSES:
            raise ValueError("非法人工状态")
        now = datetime.now(self.tz).isoformat(timespec="seconds")
        with self.analysis_transaction() as conn:
            row = conn.execute("SELECT candidate_record_id,review_status,review_version,reviewer_id,reviewed_at,updated_at FROM candidates WHERE candidate_record_id=?",(candidate_record_id,)).fetchone()
            if not row:
                raise NotFoundError("候选不存在")
            current = dict(row); current["review_version"] = int(current.get("review_version") or 0)
            if current["review_status"] == status:
                return current
            if current["review_version"] != expected_version:
                raise ConflictError("人工标记已被其他页面修改", current=current)
            new_version = current["review_version"] + 1
            cur = conn.execute(
                "UPDATE candidates SET review_status=?,reviewer_id='root',reviewed_at=?,updated_at=?,review_version=? WHERE candidate_record_id=? AND review_version=?",
                (status,now,now,new_version,candidate_record_id,expected_version),
            )
            if cur.rowcount != 1:
                fresh = conn.execute("SELECT candidate_record_id,review_status,review_version,reviewer_id,reviewed_at,updated_at FROM candidates WHERE candidate_record_id=?",(candidate_record_id,)).fetchone()
                raise ConflictError("人工标记写入冲突", current=self._rowdict(fresh))
            return dict(conn.execute("SELECT candidate_record_id,review_status,review_version,reviewer_id,reviewed_at,updated_at FROM candidates WHERE candidate_record_id=?",(candidate_record_id,)).fetchone())

    def create_feedback(self, *, feedback_id: str, target_type: str, target_id: str, content: str) -> dict[str, Any]:
        now = datetime.now(self.tz).isoformat(timespec="seconds")
        with self.analysis_transaction() as conn:
            table,key = ("candidates","candidate_record_id") if target_type=="candidate" else ("processing_items","item_id")
            exists = conn.execute(f"SELECT 1 FROM {self._qi(table)} WHERE {self._qi(key)}=?",(target_id,)).fetchone()
            if not exists:
                raise NotFoundError("反馈目标不存在")
            old = conn.execute("SELECT feedback_id,target_type,target_id,content,created_at FROM feedback WHERE feedback_id=?",(feedback_id,)).fetchone()
            if old:
                od = dict(old)
                if od["target_type"]==target_type and od["target_id"]==target_id and od["content"]==content:
                    return od
                raise ConflictError("feedback_id 已被另一条反馈使用")
            conn.execute("INSERT INTO feedback(feedback_id,target_type,target_id,content,created_at) VALUES(?,?,?,?,?)",(feedback_id,target_type,target_id,content,now))
            return dict(conn.execute("SELECT feedback_id,target_type,target_id,content,created_at FROM feedback WHERE feedback_id=?",(feedback_id,)).fetchone())

    def list_feedback(self, *, target_type: str | None = None, target_id: str | None = None, page: int = 1, page_size: int = 20) -> dict[str, Any]:
        with self.analysis_connect() as conn:
            where,args=[],[]
            if target_type:
                if target_type not in {"candidate","processing_item"}:
                    raise ValueError("非法反馈目标类型")
                where.append("wf.target_type=?"); args.append(target_type)
            if target_id:
                where.append("wf.target_id=?"); args.append(target_id)
            sql_where = (" WHERE "+" AND ".join(where)) if where else ""
            total = conn.execute("SELECT COUNT(*) FROM feedback wf"+sql_where,args).fetchone()[0]
            page_size=max(1,min(page_size,self.settings.page_size_max)); pages=max(1,(total+page_size-1)//page_size); page=max(1,min(page,pages))
            rows=conn.execute(
                """SELECT wf.*,
                    CASE WHEN wf.target_type='candidate' THEN c.title ELSE COALESCE(p.title,p.source_heading,p.item_id) END AS target_title,
                    CASE WHEN wf.target_type='candidate' THEN c.candidate_record_id ELSE p.candidate_record_id END AS candidate_record_id,
                    CASE WHEN wf.target_type='processing_item' THEN p.source_article_id ELSE NULL END AS source_article_id
                    FROM feedback wf
                    LEFT JOIN candidates c ON wf.target_type='candidate' AND c.candidate_record_id=wf.target_id
                    LEFT JOIN processing_items p ON wf.target_type='processing_item' AND p.item_id=wf.target_id
                """+sql_where+" ORDER BY wf.created_at DESC,wf.feedback_id DESC LIMIT ? OFFSET ?",
                [*args,page_size,(page-1)*page_size],
            ).fetchall()
            return {"items":[dict(r) for r in rows],"total":total,"page":page,"page_size":page_size,"pages":pages}

    def dashboard(self) -> dict[str, Any]:
        now = datetime.now(self.tz)
        today_date = now.date()
        today = today_date.isoformat()
        day_start_utc, day_end_utc = self._business_day_bounds_utc(today_date)

        with self.analysis_connect() as aconn:
            ccols = self._columns(aconn, "candidates")
            pcols = self._columns(aconn, "processing_items")
            candidate_total = aconn.execute("SELECT COUNT(*) FROM candidates").fetchone()[0]
            counts = {r["review_status"]: r["n"] for r in aconn.execute("SELECT review_status,COUNT(*) n FROM candidates GROUP BY review_status")}

            candidate_time = "created_at" if "created_at" in ccols else None
            candidate_today = 0
            today_review_counts: dict[str, int] = {}
            today_type_counts: dict[str, int] = {}
            cand_time_values: list[Any] = []
            if candidate_time:
                day_sql = self._day_range_sql(candidate_time)
                day_args = (day_start_utc, day_end_utc)
                candidate_today = aconn.execute(
                    f"SELECT COUNT(*) FROM candidates WHERE {day_sql}", day_args
                ).fetchone()[0]
                if "review_status" in ccols:
                    today_review_counts = {r["review_status"]: r["n"] for r in aconn.execute(
                        f"SELECT review_status,COUNT(*) n FROM candidates WHERE {day_sql} GROUP BY review_status", day_args
                    )}
                if "candidate_type" in ccols:
                    raw_type_counts = aconn.execute(
                        f"SELECT candidate_type,COUNT(*) n FROM candidates WHERE {day_sql} GROUP BY candidate_type", day_args
                    ).fetchall()
                    for row in raw_type_counts:
                        ctype = self._candidate_type(row["candidate_type"])
                        if ctype:
                            today_type_counts[ctype] = today_type_counts.get(ctype, 0) + int(row["n"] or 0)
                cand_time_values = [r[0] for r in aconn.execute(
                    f"SELECT {self._qi(candidate_time)} FROM candidates WHERE {day_sql}", day_args
                ).fetchall()]

            processing_clauses = []
            processing_args: list[Any] = []
            if "item_kind" in pcols:
                processing_clauses.append("COALESCE(item_kind,'')!='brief_parent'")
            if "created_at" in pcols:
                processing_clauses.append(self._day_range_sql("created_at"))
                processing_args.extend((day_start_utc, day_end_utc))
            processing_where = (" WHERE " + " AND ".join(processing_clauses)) if processing_clauses else ""
            processing_today = aconn.execute(
                "SELECT COUNT(*) FROM processing_items" + processing_where, processing_args
            ).fetchone()[0]
            decision_counts_today: dict[str, int] = {}
            if "decision" in pcols:
                decision_counts_today = {r["decision"] or "UNKNOWN": r["n"] for r in aconn.execute(
                    "SELECT decision,COUNT(*) n FROM processing_items" + processing_where + " GROUP BY decision", processing_args
                )}

            primary_item_ids = []
            top = self.list_candidates(page=1, page_size=10, sort="score")["items"]
            for c in top:
                if c.get("primary_item_id"):
                    primary_item_ids.append(str(c["primary_item_id"]))

            primary_source_by_item: dict[str, str] = {}
            if primary_item_ids:
                placeholders = ",".join("?" for _ in primary_item_ids)
                rows = aconn.execute(
                    f"SELECT item_id,source_article_id FROM processing_items WHERE item_id IN ({placeholders})",
                    primary_item_ids,
                ).fetchall()
                primary_source_by_item = {str(r["item_id"]): str(r["source_article_id"]) for r in rows if r["source_article_id"] is not None}

        with self.source_connect() as sconn:
            fcols = self._columns(sconn, "feed_items")
            source_total = sconn.execute("SELECT COUNT(*) FROM feed_items").fetchone()[0]
            source_time = "discovered_at" if "discovered_at" in fcols else ("published_at" if "published_at" in fcols else None)
            source_today = 0
            src_time_values: list[Any] = []
            if source_time:
                source_day_sql = self._day_range_sql(source_time)
                source_day_args = (day_start_utc, day_end_utc)
                source_today = sconn.execute(
                    f"SELECT COUNT(*) FROM feed_items WHERE {source_day_sql}", source_day_args
                ).fetchone()[0]
                src_time_values = [r[0] for r in sconn.execute(
                    f"SELECT {self._qi(source_time)} FROM feed_items WHERE {source_day_sql}", source_day_args
                ).fetchall()]
            source_accounts_total = sconn.execute(
                "SELECT COUNT(DISTINCT COALESCE(NULLIF(ac.account,''),f.account)) FROM feed_items f LEFT JOIN article_contents ac ON ac.article_id=f.id"
            ).fetchone()[0]

        for c in top:
            c["sources"] = self.sources_for_candidate(c["candidate_record_id"])
            primary_source_id = primary_source_by_item.get(str(c.get("primary_item_id") or ""))
            c["primary_source"] = next(
                (src for src in c["sources"] if primary_source_id is not None and str(src.get(self.source_key)) == primary_source_id),
                c["sources"][0] if c["sources"] else None,
            )

        latest_sources = self.list_sources(page=1, page_size=5)["items"]

        def minute_of(value: Any) -> int | None:
            dt = self._parse_timestamp(value)
            if dt is None or dt.date() != today_date:
                return None
            return dt.hour * 60 + dt.minute

        src_times = [minute_of(v) for v in src_time_values]
        cand_times = [minute_of(v) for v in cand_time_values]
        times = [t for t in [*src_times, *cand_times] if t is not None]
        current_minute = now.hour * 60 + now.minute
        last = (max(times) // 30) * 30 if times else (current_minute // 30) * 30
        first = max(0, last - 150)
        activity = []
        for i in range(6):
            start = first + i * 30
            activity.append({
                "start": start,
                "label": f"{start//60:02d}:{start%60:02d}",
                "sources": sum(1 for t in src_times if t is not None and start <= t < start + 30),
                "candidates": sum(1 for t in cand_times if t is not None and start <= t < start + 30),
            })
        activity_max = max([1, *[max(x["sources"], x["candidates"]) for x in activity]])

        return {
            "today": today, "weekday": "星期" + "一二三四五六日"[now.weekday()], "activity_day": today,
            "candidate_total": candidate_total, "source_total": source_total, "source_accounts_total": source_accounts_total,
            "candidate_today": candidate_today, "source_today": source_today, "today_added": source_today + candidate_today,
            "pending": counts.get("pending", 0), "starred": counts.get("starred", 0), "ignored": counts.get("ignored", 0),
            "today_pending": today_review_counts.get("pending", 0), "today_starred": today_review_counts.get("starred", 0), "today_ignored": today_review_counts.get("ignored", 0),
            "top_candidates": top, "focus_candidate": top[0] if top else None, "latest_sources": latest_sources,
            "type_counts_today": today_type_counts, "processing_today": processing_today, "decision_counts_today": decision_counts_today,
            "activity": activity, "activity_max": activity_max,
        }

