from __future__ import annotations

from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from urllib.parse import urlencode
from contextlib import asynccontextmanager
from typing import Literal

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import ValidationError

from .config import get_settings
from .db import CANDIDATE_TYPE_NAMES, ConflictError, NotFoundError, Repository, SchemaError
from .models import FeedbackCreate, FeedbackResult, ReviewStatusResult, ReviewStatusUpdate

BASE = Path(__file__).resolve().parent
settings = get_settings()
repo = Repository(settings)

@asynccontextmanager
async def lifespan(app: FastAPI):
    repo.migrate_web_schema()
    yield

app = FastAPI(title="Threat Briefing Web MVP", version="1.0.0", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")
templates = Jinja2Templates(directory=BASE / "templates")

_DISPLAY_TZ = ZoneInfo(settings.business_timezone)

def _parse_display_timestamp(value):
    if value in (None, ""):
        return None
    text = str(value).strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=_DISPLAY_TZ)
    return dt.astimezone(_DISPLAY_TZ)

def format_display_timestamp(value, mode: str = "datetime") -> str:
    """Format persisted timestamps for UI only; storage/API source values stay unchanged."""
    dt = _parse_display_timestamp(value)
    if dt is None:
        return str(value).strip() if value not in (None, "") else "时间未提供"
    if mode == "time":
        return dt.strftime("%H:%M")
    if mode == "date":
        return dt.strftime("%Y.%m.%d")
    return dt.strftime("%m-%d %H:%M")

templates.env.filters["fmt_dt"] = lambda value: format_display_timestamp(value, "datetime")
templates.env.filters["fmt_time"] = lambda value: format_display_timestamp(value, "time")
templates.env.filters["fmt_date"] = lambda value: format_display_timestamp(value, "date")


def no_cache(response):
    response.headers["Cache-Control"] = "no-store, max-age=0"
    response.headers["Pragma"] = "no-cache"
    return response


@app.exception_handler(SchemaError)
def schema_error(_: Request, exc: SchemaError):
    return JSONResponse({"detail": str(exc), "code": "schema_error"}, status_code=503)


@app.exception_handler(NotFoundError)
def not_found(_: Request, exc: NotFoundError):
    return JSONResponse({"detail": str(exc), "code": "not_found"}, status_code=404)


@app.exception_handler(ConflictError)
def conflict(_: Request, exc: ConflictError):
    payload={"detail":str(exc),"code":"conflict"}
    if exc.current is not None: payload["current"]=exc.current
    return JSONResponse(payload,status_code=409)


def page_response(request: Request, template: str, context: dict):
    response=templates.TemplateResponse(request=request,name=template,context=context)
    return no_cache(response)


def pagination_url(path: str, params: dict, page: int) -> str:
    clean={k:v for k,v in params.items() if v not in (None,"", "all")}
    clean["page"]=page
    return path+"?"+urlencode(clean)


def common(request: Request, active: str, title: str) -> dict:
    return {
        "request": request,
        "active": active,
        "page_title": title,
        "status_names": {"pending": "未审核", "starred": "收藏", "ignored": "忽略"},
        "candidate_type_names": CANDIDATE_TYPE_NAMES,
        "source_key": repo.source_key,
    }


def require_same_origin_write(request: Request) -> None:
    if request.headers.get("X-Requested-With") != "XMLHttpRequest":
        raise HTTPException(403, "缺少受信任的写请求标识")
    origin = request.headers.get("Origin")
    if origin and origin.rstrip("/") != str(request.base_url).rstrip("/"):
        raise HTTPException(403, "跨站写请求被拒绝")


@app.get("/", response_class=HTMLResponse)
def home(
    request: Request,
    type: Literal["all", "security_event", "compliance_policy"] = "all",
):
    data=repo.dashboard()
    pool=(data.get("top_candidates") or [])[1:10]
    home_filter_count=sum(1 for c in pool if type == "all" or c.get("candidate_type") == type)
    return page_response(
        request,
        "home.html",
        {
            **common(request,"home","首页"),
            **data,
            "home_type": type,
            "home_filter_count": home_filter_count,
        },
    )


@app.get("/candidates", response_class=HTMLResponse)
def candidates(
    request: Request,
    status: Literal["all", "pending", "starred", "ignored"] = "all",
    q: str = "",
    type: Literal["all", "security_event", "compliance_policy"] = "all",
    sort: Literal["score", "newest"] = "score",
    page: int = 1,
    page_size: int = 20,
):
    data=repo.list_candidates(status=status,q=q,candidate_type=type,page=page,page_size=page_size,sort=sort)
    params={"status":status,"q":q,"type":type,"sort":sort,"page_size":page_size}
    return page_response(request,"candidate_list.html",{**common(request,"candidates","情报候选"),**data,"status":status,"q":q,"candidate_type":type,"sort":sort,"favorites":False,"page_url":lambda p:pagination_url('/candidates',params,p)})


@app.get("/favorites", response_class=HTMLResponse)
def favorites(request: Request, q: str="", page: int=1, page_size: int=20):
    data=repo.list_candidates(q=q,page=page,page_size=page_size,favorites=True)
    params={"q":q,"page_size":page_size}
    return page_response(request,"candidate_list.html",{**common(request,"favorites","收藏"),**data,"status":"starred","q":q,"candidate_type":"all","sort":"reviewed","favorites":True,"page_url":lambda p:pagination_url('/favorites',params,p)})


@app.get("/candidates/{candidate_record_id}", response_class=HTMLResponse)
def candidate_detail(request: Request, candidate_record_id: str):
    try: c=repo.get_candidate(candidate_record_id)
    except NotFoundError:
        raise HTTPException(404,"候选不存在")
    feedback=repo.list_feedback(target_type="candidate",target_id=candidate_record_id,page=1,page_size=10)
    return page_response(request,"candidate_detail.html",{**common(request,"candidates",c.get('title') or '候选详情'),"candidate":c,"feedback":feedback})


@app.get("/articles", response_class=HTMLResponse)
def articles(request: Request, q: str="", page: int=1, page_size: int=20):
    data=repo.list_sources(q=q,page=page,page_size=page_size)
    params={"q":q,"page_size":page_size}
    return page_response(request,"article_list.html",{**common(request,"articles","原始资讯"),**data,"q":q,"page_url":lambda p:pagination_url('/articles',params,p)})


@app.get("/articles/{source_id}", response_class=HTMLResponse)
def article_detail(request: Request, source_id: str):
    try: article=repo.get_source(source_id)
    except NotFoundError: raise HTTPException(404,"原始资讯不存在")
    return page_response(request,"article_detail.html",{**common(request,"articles",article.get('title') or '原文详情'),"article":article,"source_id":source_id})


@app.get("/feedback", response_class=HTMLResponse)
def feedback_page(request: Request, target_type: str|None=None, target_id: str|None=None, page: int=1, page_size: int=20):
    data=repo.list_feedback(target_type=target_type,target_id=target_id,page=page,page_size=page_size)
    params={"target_type":target_type,"target_id":target_id,"page_size":page_size}
    return page_response(request,"feedback_list.html",{**common(request,"feedback","反馈记录"),**data,"target_type":target_type,"target_id":target_id,"page_url":lambda p:pagination_url('/feedback',params,p)})


@app.put("/api/v1/candidates/{candidate_record_id}/review-status", response_model=ReviewStatusResult)
def update_review_status(request: Request, candidate_record_id: str, body: ReviewStatusUpdate):
    require_same_origin_write(request)
    return repo.set_review_status(candidate_record_id,body.review_status,body.expected_review_version)


@app.post("/api/v1/feedback", response_model=FeedbackResult, status_code=201)
def create_feedback(request: Request, body: FeedbackCreate):
    require_same_origin_write(request)
    return repo.create_feedback(feedback_id=body.feedback_id,target_type=body.target_type,target_id=body.target_id,content=body.content)


@app.get("/api/v1/feedback")
def list_feedback(target_type: str|None=None,target_id: str|None=None,page: int=1,page_size: int=20):
    return repo.list_feedback(target_type=target_type,target_id=target_id,page=page,page_size=page_size)


@app.get("/api/v1/processing-items/{item_id}")
def processing_item(item_id: str):
    item = repo.get_processing_item(item_id)
    item["created_at_display"] = format_display_timestamp(item.get("created_at"), "datetime")
    return item
