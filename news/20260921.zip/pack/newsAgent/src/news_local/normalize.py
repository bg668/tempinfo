"""Collector mapping and validation; the canonical contract is shared with the DSL."""

import hashlib
import json
from dataclasses import dataclass

from .article_contract import canonical_json, normalize_article
from .errors import ContractError
from .timeutils import normalize_time

PLACEHOLDERS = {"「点击可全屏观看」", "点击可全屏观看"}


def source_fingerprint(row: dict | None, source_id: int | None = None) -> str:
    """Stable fingerprint for collector rows that fail canonical normalization.

    This is only used for deterministic local failures.  Once the source is
    corrected, the raw record changes and becomes eligible again.
    """
    if row is None:
        payload = {"article_id": source_id, "missing": True}
    else:
        keys = ("article_id", "account", "title", "url", "published_at", "fetched_at", "content")
        payload = {key: row.get(key) for key in keys if key in row}
        if source_id is not None and "article_id" not in payload:
            payload["article_id"] = source_id
    serialized = json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str
    )
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class Article:
    source_id: int
    payload: dict
    input_hash: str
    fetched_at: str
    digest: bool

    def to_dict(self) -> dict:
        return {
            "source_id": self.source_id,
            "payload": self.payload,
            "input_hash": self.input_hash,
            "fetched_at": self.fetched_at,
            "digest": self.digest,
        }


def prepare_article(row: dict, max_chars: int, keywords: tuple[str, ...]) -> Article:
    sid = row["article_id"]
    if type(sid) is not int or sid <= 0:
        raise ContractError("article_id 必须为正整数")
    content = str(row.get("content") or "").strip()
    if not content or content in PLACEHOLDERS:
        raise ContractError("缺少可分析正文，请补抓原文")
    try:
        published = normalize_time(row["published_at"])
        fetched = normalize_time(row["fetched_at"])
        payload = normalize_article(
            {
                "source_article_id": str(sid),
                "account": row.get("account"),
                "title": row.get("title"),
                "url": row.get("url"),
                "published_at": published,
                "content": content,
            },
            max_chars,
        )
    except (ValueError, TypeError, KeyError) as exc:
        raise ContractError(str(exc)) from exc
    digest = any(keyword in payload["title"] for keyword in keywords)
    if digest and payload["content_truncated"]:
        raise ContractError("快讯正文将被截断，无法保证子项覆盖；请调整单篇容量")
    serialized = canonical_json(payload)
    if len(serialized) > 200000:
        raise ContractError("单篇规范化 JSON 超过主控的 200000 字符限制")
    fingerprint = hashlib.sha256(serialized.encode("utf-8")).hexdigest()
    return Article(sid, payload, fingerprint, fetched, digest)
