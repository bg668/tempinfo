"""Errors that can be shown to an operator without a Python traceback."""


class NewsError(Exception):
    pass


class ContractError(NewsError):
    pass


class ConflictError(NewsError):
    pass


class PendingRun(NewsError):
    """The remote execution may still be running. Never resubmit automatically."""


class RemoteFailure(NewsError):
    pass
