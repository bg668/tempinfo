"""Small session journal plus checksummed immutable scope and batch reservations."""

import hashlib
import json
import re
from pathlib import Path

from .errors import NewsError
from .state import atomic_json

SESSION_PATTERN = re.compile(r"session_[a-f0-9]{32}")


class SessionStore:
    def __init__(self, root: Path):
        self.root = root

    def directory(self, session_id: str) -> Path:
        if not SESSION_PATTERN.fullmatch(session_id):
            raise NewsError("连续任务 ID 格式无效")
        return self.root / "sessions" / session_id

    def save(self, session: dict) -> None:
        atomic_json(self.directory(session["session_id"]) / "session.json", session)

    def load(self, session_id: str) -> dict:
        path = self.directory(session_id) / "session.json"
        if not path.is_file():
            raise NewsError("找不到连续任务")
        return json.loads(path.read_text(encoding="utf-8"))

    def list(self) -> list[dict]:
        sessions = []
        for path in (self.root / "sessions").glob("session_*/session.json"):
            sessions.append(json.loads(path.read_text(encoding="utf-8")))
        return sorted(sessions, key=lambda value: value["started_at"], reverse=True)

    def active(self) -> dict | None:
        for session in self.list():
            if session["phase"] not in {"COMPLETED", "ABANDONED"}:
                return session
        return None

    def write_snapshot(self, session_id: str, name: str, value: dict) -> str:
        path = self.directory(session_id) / name
        atomic_json(path, value)
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def read_snapshot(self, session_id: str, name: str, fingerprint: str) -> dict:
        data = (self.directory(session_id) / name).read_bytes()
        if hashlib.sha256(data).hexdigest() != fingerprint:
            raise NewsError("连续任务快照已改变：" + name)
        return json.loads(data)
