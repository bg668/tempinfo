"""Actionable deployment diagnostics, independent of transport and CLI rendering."""

import re

ARRAY_ERROR = re.compile(
    r"""length of output variable [`'"](?P<variable>[^`'"]+)[`'"] """
    r"must be less than (?P<limit>\d+) elements",
    re.IGNORECASE,
)


def diagnose(error: str) -> dict | None:
    match = ARRAY_ERROR.search(error)
    if not match:
        return None
    if match["variable"] in {"errors", "review_items", "nonkeep"}:
        return {
            "code": "DIFY_OBSOLETE_ARRAY_OUTPUT",
            "output_variable": match["variable"],
            "reported_limit": int(match["limit"]),
            "scope": "旧版主控仍声明了已移除的冗余数组输出",
            "action": (
                "请更新并发布 v1.2 主控 DSL，同时更新子流程 01、03、04 及工具定义。"
                "这些数组已从节点输出移除，完整记录和错误仍通过 JSON 文件入库；"
                "无需为这些冗余字段修改 Docker 容量。确认 API 指向新版已发布主控后重新 run。"
            ),
        }
    return {
        "code": "DIFY_CODE_ARRAY_LIMIT",
        "output_variable": match["variable"],
        "reported_limit": int(match["limit"]),
        "scope": "Dify API/Worker 服务端 Code 输出校验",
        "suggested_environment": {
            "CODE_MAX_STRING_ARRAY_LENGTH": "2000",
            "CODE_MAX_OBJECT_ARRAY_LENGTH": "2000",
        },
        "action": (
            "将容量配置传入 Dify 的 api 和 worker 并重新创建相关容器；"
            "可使用 deploy/dify.capacity.override.yml。"
            "本地 uv --env-file .env 不会修改 Dify 服务端限制。"
            "确认生效后重新执行 run；本次远程运行已失败，不能通过 resume 继续。"
        ),
    }
