-- Application-owned tables only. Source collector tables are never migrated.

CREATE TABLE IF NOT EXISTS processing_items (
    item_id TEXT PRIMARY KEY NOT NULL,
    run_id TEXT NOT NULL,
    source_article_id INTEGER NOT NULL,
    candidate_record_id TEXT,
    item_kind TEXT NOT NULL,
    item_key TEXT NOT NULL,
    title TEXT,
    summary TEXT,
    source_heading TEXT,
    source_text TEXT,
    process_status TEXT NOT NULL CHECK (process_status IN ('SUCCESS','FAILED')),
    decision TEXT CHECK (decision IN ('KEEP','DROP','UNCERTAIN')),
    route TEXT,
    category TEXT,
    content_nature TEXT,
    relevance INTEGER CHECK (relevance BETWEEN 0 AND 5),
    impact INTEGER CHECK (impact BETWEEN 0 AND 5),
    freshness INTEGER CHECK (freshness BETWEEN 0 AND 5),
    evidence_quality INTEGER CHECK (evidence_quality BETWEEN 0 AND 5),
    audience_value INTEGER CHECK (audience_value BETWEEN 0 AND 5),
    total_score INTEGER CHECK (total_score BETWEEN 0 AND 100),
    reason TEXT,
    facts_json TEXT,
    ioc_json TEXT,
    excluded_iocs_json TEXT NOT NULL,
    quality_warnings_json TEXT NOT NULL,
    errors_json TEXT NOT NULL,
    input_hash TEXT,
    input_meta_json TEXT NOT NULL,
    processing_version TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE (run_id, source_article_id, item_key),
    FOREIGN KEY (candidate_record_id) REFERENCES candidates(candidate_record_id) DEFERRABLE INITIALLY DEFERRED
);

CREATE TABLE IF NOT EXISTS candidates (
    candidate_record_id TEXT PRIMARY KEY NOT NULL,
    candidate_id TEXT NOT NULL,
    run_id TEXT NOT NULL,
    candidate_type TEXT NOT NULL CHECK (candidate_type IN ('security_event','compliance_policy')),
    primary_item_id TEXT NOT NULL,
    title TEXT NOT NULL,
    summary TEXT NOT NULL,
    facts_json TEXT,
    relevance INTEGER NOT NULL CHECK (relevance BETWEEN 0 AND 5),
    impact INTEGER NOT NULL CHECK (impact BETWEEN 0 AND 5),
    freshness INTEGER NOT NULL CHECK (freshness BETWEEN 0 AND 5),
    evidence_quality INTEGER NOT NULL CHECK (evidence_quality BETWEEN 0 AND 5),
    audience_value INTEGER NOT NULL CHECK (audience_value BETWEEN 0 AND 5),
    total_score INTEGER NOT NULL CHECK (total_score BETWEEN 0 AND 100),
    reason TEXT NOT NULL,
    score_strategy TEXT NOT NULL,
    score_source_item_id TEXT,
    match_reason TEXT,
    ioc_json TEXT,
    excluded_iocs_json TEXT NOT NULL,
    quality_warnings_json TEXT NOT NULL,
    review_status TEXT NOT NULL CHECK (review_status IN ('pending','starred','ignored')),
    review_reason_code TEXT,
    review_comment TEXT,
    reviewed_title TEXT,
    reviewed_summary TEXT,
    review_corrections_json TEXT,
    reviewer_id TEXT,
    reviewed_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE (run_id, candidate_id),
    FOREIGN KEY (primary_item_id) REFERENCES processing_items(item_id) DEFERRABLE INITIALLY DEFERRED,
    FOREIGN KEY (score_source_item_id) REFERENCES processing_items(item_id) DEFERRABLE INITIALLY DEFERRED
);

CREATE INDEX IF NOT EXISTS news_processing_source_hash ON processing_items(source_article_id,input_hash,run_id);

CREATE INDEX IF NOT EXISTS news_processing_run ON processing_items(run_id);

CREATE INDEX IF NOT EXISTS news_processing_candidate ON processing_items(candidate_record_id);

CREATE INDEX IF NOT EXISTS news_candidate_review ON candidates(review_status,created_at);

CREATE INDEX IF NOT EXISTS news_candidate_run ON candidates(run_id);


CREATE TABLE IF NOT EXISTS feedback (
    feedback_id TEXT PRIMARY KEY NOT NULL,
    target_type TEXT NOT NULL CHECK (target_type IN ('candidate','processing_item')),
    target_id TEXT NOT NULL CHECK (length(trim(target_id)) > 0),
    content TEXT NOT NULL CHECK (length(trim(content)) BETWEEN 1 AND 5000),
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS news_feedback_created ON feedback(created_at DESC,feedback_id DESC);

CREATE INDEX IF NOT EXISTS news_feedback_target ON feedback(target_type,target_id,created_at DESC,feedback_id DESC);
