"""Finite continuous processing. One shared lock, one active batch, no blind retries."""

import json
import logging
import uuid

from .errors import NewsError
from .log_context import log_scope
from .planner import capture_scope, select_from_scope
from .service import Runner, TERMINAL_PHASES
from .session_reporting import summarize_session
from .session_state import SessionStore
from .state import atomic_json
from .timeutils import now_text

LOG = logging.getLogger(__name__)
CONFIG_KEYS = (
    "source_db", "result_db", "api_base", "batch_size", "max_content_chars",
    "max_input_chars", "grouping_mode", "digest_keywords", "accounts",
    "published_from", "published_to",
)


def configuration(settings) -> dict:
    # Secrets are never journaled; timeouts, file URL and logging can change on recovery.
    return json.loads(json.dumps({key: getattr(settings, key) for key in CONFIG_KEYS}, default=str))


class SessionRunner:
    def __init__(self, runner: Runner):
        self.runner = runner
        self.store = SessionStore(runner.store.root)

    def start(self, force: bool = False) -> dict:
        with self.runner.store.lock():
            self.runner.store.ensure_no_active_session()
            unfinished = [r for r in self.runner.store.list() if r["phase"] not in TERMINAL_PHASES]
            if unfinished:
                raise NewsError("请先恢复未结束批次：" + unfinished[0]["run_id"])
            self.runner.settings.validate()
            self.runner.collector.check()
            self.runner.repository.initialize()
            scope = capture_scope(self.runner.collector, self.runner.settings)
            sid = "session_" + uuid.uuid4().hex
            scope_hash = self.store.write_snapshot(sid, "scope.json", scope)
            session = {
                "session_id": sid, "phase": "RUNNING", "started_at": now_text(),
                "finished_at": None, "force": force, "config": configuration(self.runner.settings),
                "scope_sha256": scope_hash, "entry_count": len(scope["entries"]),
                "query": {k: v for k, v in scope.items() if k != "entries"},
                "cursor": 0, "segments": [], "active": None,
            }
            self.store.save(session)
            LOG.info("连续任务开始｜session_id=%s｜范围记录=%s｜每批=%s",
                     sid, session["entry_count"], self.runner.settings.batch_size)
            return self._drive(session)

    def resume(self, session_id: str, workflow_run_id: str = "") -> dict:
        with self.runner.store.lock():
            session = self.store.load(session_id)
            if session["phase"] in {"COMPLETED", "ABANDONED"}:
                return self._report(session)
            if session["config"] != configuration(self.runner.settings):
                raise NewsError("连续任务的数据库、查询或处理配置已改变，请恢复原配置后 resume-all")
            if workflow_run_id and not session.get("active"):
                raise NewsError("没有当前批次可关联 workflow_run_id")
            session.update(phase="RUNNING", error=None, stop_reason=None, finished_at=None)
            self.store.save(session)
            return self._drive(session, workflow_run_id)

    def status(self, session_id: str) -> dict:
        return self._report(self.store.load(session_id), persist=False)

    def abandon(self, session_id: str) -> dict:
        """Release a stopped session only after its batch has a known terminal outcome."""
        with self.runner.store.lock():
            session = self.store.load(session_id)
            active = session.get("active")
            if active:
                path = self.runner.store.directory(active["run_id"]) / "run.json"
                if path.exists():
                    run = self.runner.store.load(active["run_id"])
                    if run["phase"] not in TERMINAL_PHASES:
                        raise NewsError("当前批次尚未明确结束，请先恢复或确认远程已停止后 abandon 批次")
            if session["phase"] == "COMPLETED":
                raise NewsError("连续任务已经完成")
            session.update(phase="ABANDONED", stop_reason="operator_abandoned", finished_at=now_text())
            self.store.save(session)
            return self._report(session)

    def _drive(self, session: dict, workflow_run_id: str = "") -> dict:
        try:
            scope = self.store.read_snapshot(session["session_id"], "scope.json", session["scope_sha256"])
            while session["cursor"] < session["entry_count"] or session.get("active"):
                number = sum(bool(s.get("run_id")) for s in session["segments"]) + 1
                with log_scope(session_id=session["session_id"], batch_number=number,
                               stage="批次调度", substep=""):
                    if not session.get("active"):
                        self._reserve_next(session, scope)
                        if not session.get("active"):
                            continue  # Only already-completed/deferred records were examined.
                    self._finish_active(session, workflow_run_id)
                    workflow_run_id = ""
            session.update(phase="COMPLETED", finished_at=now_text(), stop_reason="scope_exhausted", error=None)
            self.store.save(session)
        except KeyboardInterrupt:
            self._pause(session, "interrupted", "操作人员中断；恢复时先核对原批次执行状态")
        except (NewsError, OSError, ValueError) as exc:
            self._pause(session, "batch_or_local_error", str(exc))
        report = self._report(session)
        LOG.info("连续任务结束｜session_id=%s｜状态=%s｜批次=%s｜成功=%s/失败=%s｜候选=%s｜未检查=%s",
                 session["session_id"], report["status"], report["batch_count"],
                 report["completed_article_count"], report["failed_article_count"],
                 report["candidate_count"], report["remaining_unexamined_count"])
        return report

    @log_scope(stage="prepare", substep="本地选取")
    def _reserve_next(self, session: dict, scope: dict) -> None:
        plan, end = select_from_scope(self.runner.collector, self.runner.repository,
                                     self.runner.settings, scope, session["cursor"], session["force"])
        if end <= session["cursor"]:
            raise NewsError("批次选取没有推进游标，已停止连续任务")
        if not plan.articles and not plan.rejected:
            session["segments"].append({"run_id": None, "query": plan.query})
            session["cursor"] = end
            self.store.save(session)
            return
        run_id = "run_" + uuid.uuid4().hex
        name = run_id + ".json"
        fingerprint = self.store.write_snapshot(session["session_id"], name, {
            "run_id": run_id, "plan": plan.to_dict(), "start_cursor": session["cursor"],
            "end_cursor": end,
        })
        session["active"] = {"run_id": run_id, "snapshot": name, "sha256": fingerprint,
                             "end_cursor": end, "selected_count": len(plan.articles)}
        # Durable association exists before Runner can send POST.
        self.store.save(session)
        LOG.info("连续批次 %s｜run_id=%s｜提交=%s｜尚未检查=%s",
                 sum(bool(s.get("run_id")) for s in session["segments"]) + 1,
                 run_id, len(plan.articles), session["entry_count"] - end)

    def _finish_active(self, session: dict, workflow_run_id: str) -> None:
        active = session["active"]
        reservation = self.store.read_snapshot(session["session_id"], active["snapshot"], active["sha256"])
        run_id = active["run_id"]
        path = self.runner.store.directory(run_id) / "run.json"
        run = self.runner.store.load(run_id) if path.exists() else None
        if run and run.get("session_id") != session["session_id"]:
            raise NewsError("当前批次与连续任务关联不一致")
        if run is None or run["phase"] == "PREPARING":
            if workflow_run_id:
                raise NewsError("当前批次尚未提交，不能手动绑定远程执行")
            self.runner._run_locked(session["force"], plan=reservation["plan"],
                                    run_id=run_id, session_id=session["session_id"])
        elif run["phase"] not in TERMINAL_PHASES:
            self.runner._resume_locked(run_id, workflow_run_id)
        run = self.runner.store.load(run_id)
        if run["phase"] != "COMPLETED" or run.get("database", {}).get("status") != "SUCCESS":
            raise NewsError(f"当前批次 {run_id} 阶段={run['phase']}："
                            + str(run.get("error") or "尚未确认入库；终止批次请检查后 abandon-all"))
        # All article failures are now durable. Advance even if business summary says FAILED.
        session["segments"].append({"run_id": run_id, "query": reservation["plan"]["query"]})
        session["cursor"] = reservation["end_cursor"]
        session["active"] = None
        self.store.save(session)
        report = self._report(session)
        LOG.info("累计进度｜已提交=%s｜成功=%s/失败=%s｜候选=%s｜已检查=%s/%s",
                 report["submitted_count"], report["completed_article_count"], report["failed_article_count"],
                 report["candidate_count"], session["cursor"], session["entry_count"])

    def _pause(self, session: dict, reason: str, error: str) -> None:
        # Reload last durable checkpoint: an unsuccessful write must not advance in-memory state.
        durable = self.store.load(session["session_id"])
        session.clear()
        session.update(durable)
        session.update(phase="PAUSED", stop_reason=reason, error=error, finished_at=None)
        self.store.save(session)
        LOG.error("连续任务暂停｜session_id=%s｜%s", session["session_id"], error)

    def _report(self, session: dict, *, persist: bool = True) -> dict:
        runs = {run["run_id"]: run for run in self.runner.store.list()}
        report = summarize_session(session, runs)
        if persist:
            atomic_json(self.store.directory(session["session_id"]) / "summary.json", report)
        return report
