"""Structured progress events stored beside each durable run journal."""

import json
import threading
from pathlib import Path

from .log_context import current_context
from .timeutils import now_text
from .workflow_stages import STAGE_NUMBERS, STAGE_TOTAL, STAGES

_WRITE_LOCK = threading.Lock()
_STAGE_NO = STAGE_NUMBERS


def stage_meta(stage: str | None) -> dict:
    if stage not in _STAGE_NO:
        return {}
    return {
        "stage_id": stage,
        "stage_no": _STAGE_NO[stage],
        "stage_total": STAGE_TOTAL,
        "stage_name": STAGES[stage],
    }


def emit_progress(event: str, **values) -> dict:
    """Append one compact JSONL progress event when a run progress path is in scope."""
    context = current_context()
    record = {
        "timestamp": now_text(),
        "event": event,
    }
    for key in ("run_id", "batch_number", "unit_type", "item_index", "item_total", "item_id", "item_title", "substep"):
        if context.get(key) is not None and context.get(key) != "":
            record[key] = context[key]
    marker = object()
    requested_stage = values.pop("stage", marker)
    stage = context.get("stage") if requested_stage is marker else requested_stage
    if stage:
        record.update(stage_meta(stage))
    for key, value in values.items():
        if value is not None and value != "":
            record[key] = value

    path = context.get("progress_path")
    if path:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(record, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        with _WRITE_LOCK:
            with target.open("a", encoding="utf-8", newline="\n") as handle:
                handle.write(line + "\n")
                handle.flush()
    return record
