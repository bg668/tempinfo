"""Long-lived worker over durable per-batch run journals.

There is no session boundary in daemon mode.  The database is the durable
checkpoint for completed/failed business inputs, while ``RunStore`` keeps only
the currently executing remote batch recoverable across process restarts.
"""

import logging
import threading

from .errors import NewsError
from .log_context import log_scope
from .service import TERMINAL_PHASES
from .timeutils import now_text

LOG = logging.getLogger(__name__)


class ContinuousTrigger:
    def __init__(self, runner, interval_seconds: float = 30.0):
        if not isinstance(interval_seconds, (int, float)) or isinstance(interval_seconds, bool):
            raise ValueError("interval_seconds 必须为数字")
        if interval_seconds < 1:
            raise ValueError("interval_seconds 不能小于 1 秒")
        self.runner = runner
        self.interval_seconds = float(interval_seconds)

    def _unfinished(self) -> list[dict]:
        return [run for run in self.runner.store.list() if run.get("phase") not in TERMINAL_PHASES]


    def _next_batch_number(self) -> int:
        """Persist a readable batch sequence through existing run journals.

        Legacy daemon versions wrote batch_number=1 for every run, so the run
        count is also considered to avoid restarting at B002 after many runs.
        """
        runs = self.runner.store.list()
        numbers = [r.get("batch_number") for r in runs if type(r.get("batch_number")) is int]
        return max([len(runs), *numbers], default=0) + 1

    def run_once(self) -> dict:
        """Recover one unfinished run, otherwise execute one newly selected batch."""
        with self.runner.store.lock():
            self.runner.collector.check()
            self.runner.repository.initialize()
            unfinished = self._unfinished()
            if len(unfinished) > 1:
                ids = ", ".join(run["run_id"] for run in unfinished)
                raise NewsError("检测到多个未结束批次，违反单 Worker 约束：" + ids)
            if unfinished:
                run = unfinished[0]
                LOG.info("发现未结束批次，自动断点恢复｜run_id=%s｜phase=%s", run["run_id"], run["phase"])
                result = self.runner._resume_locked(
                    run["run_id"], allow_resubmit_ambiguous=True
                )
                return dict(result, recovered=True)

            plan = self.runner.preview(False)
            if not plan["articles"] and not plan["rejected"]:
                return {"status": "NO_WORK", "checked_at": now_text()}
            batch_number = self._next_batch_number()
            with log_scope(batch_number=batch_number):
                processed = len(self.runner.repository.processed_inputs())
                query = plan.get("query") or {}
                LOG.info(
                    "后台进度｜累计已处理输入=%s｜本批输入=%s｜剩余待扫描≈%s",
                    processed, len(plan["articles"]) + len(plan.get("rejected") or []),
                    query.get("unexamined_count", "未知"),
                )
                return self.runner._run_locked(False, plan=plan)

    @staticmethod
    def _should_wait(result: dict) -> bool:
        """Backlog drains immediately; idle/recoverable infrastructure states back off."""
        if result.get("status") == "NO_WORK":
            return True
        if result.get("status") in {"WAITING", "NEEDS_RECOVERY", "ERROR"}:
            return True
        # A committed bundle can legitimately have business status FAILED/PARTIAL.
        database = result.get("database") or {}
        if result.get("status") == "FAILED" and database.get("status") != "SUCCESS":
            return True
        return False

    def run_forever(self, stop_event: threading.Event | None = None) -> dict:
        """Recover, drain backlog, then poll for newly committed collector rows."""
        stop_event = stop_event or threading.Event()
        cycles = 0
        last = None
        LOG.info("后台 Worker 启动｜空闲检查间隔=%s 秒", self.interval_seconds)
        while not stop_event.is_set():
            try:
                last = self.run_once()
                cycles += 1
                status = last.get("status")
                if status == "NO_WORK":
                    LOG.debug("后台检查完成｜暂无新增工作")
                elif last.get("recovered"):
                    with log_scope(batch_number=last.get("batch_number")):
                        LOG.info("断点恢复结果｜run=%s｜状态=%s", str(last.get("run_id", ""))[4:12], status)
                else:
                    with log_scope(batch_number=last.get("batch_number")):
                        LOG.info("批次完成｜状态=%s｜文章成功=%s｜失败=%s｜候选=%s｜耗时=%ss",
                                 status, last.get("completed_article_count", 0),
                                 last.get("failed_article_count", 0), last.get("candidate_count", 0),
                                 last.get("elapsed_seconds", "未知"))
            except KeyboardInterrupt:
                break
            except (NewsError, OSError, ValueError) as exc:
                last = {"status": "ERROR", "error": str(exc)}
                cycles += 1
                LOG.error("后台单轮失败｜%s", exc)

            if last is not None and not self._should_wait(last):
                # Do not sleep while there may still be backlog.
                continue
            try:
                if stop_event.wait(self.interval_seconds):
                    break
            except KeyboardInterrupt:
                break

        result = {"status": "STOPPED", "cycle_count": cycles, "stopped_at": now_text()}
        if last is not None:
            result["last_cycle"] = last
        LOG.info("后台 Worker 停止｜处理轮次=%s", cycles)
        return result
