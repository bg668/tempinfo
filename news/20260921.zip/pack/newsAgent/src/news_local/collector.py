"""Read-only access to the collector database. No AI or result-table knowledge."""

import sqlite3
from contextlib import contextmanager
from pathlib import Path

from .errors import NewsError


class Collector:
    def __init__(self, path: Path):
        self.path = path.resolve()

    @contextmanager
    def connect(self):
        if not self.path.is_file():
            raise NewsError("采集库不存在：" + str(self.path))
        connection = sqlite3.connect(self.path.as_uri() + "?mode=ro", uri=True, timeout=15)
        connection.row_factory = sqlite3.Row
        try:
            yield connection
        except sqlite3.Error as exc:
            raise NewsError("读取采集库失败：" + str(exc)) from exc
        finally:
            connection.close()

    def check(self) -> dict:
        with self.connect() as db:
            required = {
                "article_id",
                "title",
                "account",
                "url",
                "content",
                "published_at",
                "fetched_at",
            }
            actual = {r["name"] for r in db.execute("PRAGMA table_info(article_contents)")}
            if not required <= actual:
                raise NewsError(
                    "article_contents 缺少字段：" + ", ".join(sorted(required - actual))
                )
            orphans = db.execute(
                "SELECT count(*) FROM article_contents a LEFT JOIN feed_items f "
                "ON f.id=a.article_id WHERE f.id IS NULL"
            ).fetchone()[0]
            return {
                "article_count": db.execute("SELECT count(*) FROM article_contents").fetchone()[0],
                "orphan_count": orphans,
            }

    def metadata(self) -> list[dict]:
        with self.connect() as db:
            rows = db.execute(
                "SELECT a.article_id, COALESCE(NULLIF(a.title,''),f.title) title, "
                "COALESCE(NULLIF(a.account,''),f.account) account, a.url, "
                "COALESCE(NULLIF(a.published_at,''),f.published_at) published_at, a.fetched_at "
                "FROM article_contents a JOIN feed_items f ON f.id=a.article_id"
            )
            return [dict(row) for row in rows]

    def get(self, source_id: int) -> dict | None:
        with self.connect() as db:
            row = db.execute(
                "SELECT a.article_id, COALESCE(NULLIF(a.title,''),f.title) title, "
                "COALESCE(NULLIF(a.account,''),f.account) account, a.url, a.content, "
                "COALESCE(NULLIF(a.published_at,''),f.published_at) published_at, a.fetched_at "
                "FROM article_contents a JOIN feed_items f ON f.id=a.article_id WHERE a.article_id=?",
                (source_id,),
            ).fetchone()
            return dict(row) if row else None
