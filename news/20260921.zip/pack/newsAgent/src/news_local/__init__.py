"""SQLite → Dify → SQLite. Standard-library command-line batch processing."""

import logging

__version__ = "1.8.1"
logging.getLogger(__name__).addHandler(logging.NullHandler())
