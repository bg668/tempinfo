"""Validate the file contract before opening a database write transaction."""

import json
from collections import defaultdict
from copy import deepcopy
from pathlib import Path

from .errors import ContractError
from .state import RUN_PATTERN

FIELD_DEFINITIONS = json.loads(
    Path(__file__).with_name("table_fields.json").read_text(encoding="utf-8")
)
FIELDS = {table: tuple(f["name"] for f in columns) for table, columns in FIELD_DEFINITIONS.items()}
SCORES = ("relevance", "impact", "freshness", "evidence_quality", "audience_value")
IOC_KEYS = {"ips", "domains", "urls", "hashes", "file_paths", "vulnerabilities"}
REVIEW_FIELDS = {
    "review_status",
    "review_reason_code",
    "review_comment",
    "reviewed_title",
    "reviewed_summary",
    "review_corrections_json",
    "reviewer_id",
    "reviewed_at",
}
JSON_FIELDS = {k for fields in FIELDS.values() for k in fields if k.endswith("_json")}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ContractError(message)


def source_id(value) -> int:
    require(not isinstance(value, bool), "原文 ID 不能为布尔值")
    try:
        number = int(value)
    except (ValueError, TypeError, OverflowError) as exc:
        raise ContractError("原文 ID 不是整数") from exc
    require(number > 0 and str(number) == str(value), "原文 ID 格式无效")
    return number


def validate_scores(row: dict, required: bool) -> None:
    values = [row[k] for k in SCORES]
    if not required and all(v is None for v in values):
        require(row["total_score"] is None, "没有分项评分却有总分")
        return
    require(all(type(v) is int and 0 <= v <= 5 for v in values), "分项评分必须是 0–5 整数")
    require(
        type(row["total_score"]) is int and row["total_score"] == sum(values) * 4,
        "总分与分项不一致",
    )


def validate_row(row: dict, table: str, run_id: str) -> None:
    require(isinstance(row, dict) and set(row) == set(FIELDS[table]), table + " 字段与契约不符")
    require(row["run_id"] == run_id, "结果包含其他批次")
    for field in FIELD_DEFINITIONS[table]:
        key, value = field["name"], row[field["name"]]
        if field["logical_type"] in {"TEXT", "DATETIME"} and key != "source_article_id":
            require(value is None or isinstance(value, str), key + " 必须为字符串或 null")
    for key in ("excluded_iocs_json", "quality_warnings_json"):
        require(isinstance(row[key], list), key + " 必须为数组")
    require(row["facts_json"] is None or isinstance(row["facts_json"], dict), "facts_json 格式无效")
    ioc = row["ioc_json"]
    if ioc is not None:
        require(isinstance(ioc, dict) and set(ioc) == IOC_KEYS, "IOC 六类字段不完整")
        require(
            all(isinstance(v, list) and all(isinstance(x, str) for x in v) for v in ioc.values()),
            "IOC 必须为字符串数组",
        )


def validate_bundle(raw: dict, run_id: str, expected: list[dict]) -> dict:
    require(isinstance(raw, dict), "结果文件必须为对象")
    require(raw.get("schema_version") == "news-result-bundle-v1", "不支持的结果文件版本")
    require(
        RUN_PATTERN.fullmatch(run_id) is not None and raw.get("run_id") == run_id, "批次 ID 不一致"
    )
    require(
        isinstance(raw.get("processing_version"), str) and bool(raw["processing_version"]),
        "缺少处理版本",
    )
    require(
        raw.get("process_status") in {"SUCCESS", "PARTIAL_SUCCESS", "FAILED", "PARTIAL"},
        "结果状态无效",
    )
    require(isinstance(raw.get("stats"), dict), "缺少统计对象")
    require(
        isinstance(raw.get("errors"), list) and isinstance(raw.get("warnings"), list),
        "错误和提示格式无效",
    )
    require(all(isinstance(raw.get(k), list) for k in FIELDS), "缺少两张结果表")
    bundle = deepcopy(raw)
    expected_by_id = {int(a["source_id"]): a for a in expected}
    items, candidates = {}, {}
    by_source = defaultdict(list)
    for row in bundle["processing_items"]:
        validate_row(row, "processing_items", run_id)
        sid = row["source_article_id"] = source_id(row["source_article_id"])
        require(sid in expected_by_id, "结果出现未提交的原文")
        require(row["input_hash"] == expected_by_id[sid]["input_hash"], "输入哈希不一致")
        require(row["processing_version"] == bundle["processing_version"], "处理版本不一致")
        require(row["process_status"] in {"SUCCESS", "FAILED"}, "逐条处理状态无效")
        require(
            isinstance(row["errors_json"], list) and isinstance(row["input_meta_json"], dict),
            "处理审计格式无效",
        )
        require(bool(row["item_id"]) and row["item_id"] not in items, "处理记录 ID 重复或为空")
        require(row["item_kind"] in {"normal", "digest_parent", "digest_child"}, "条目类型无效")
        validate_scores(row, row["decision"] is not None)
        if row["decision"] is not None:
            require(
                (row["decision"], row["route"])
                in {
                    ("KEEP", "security_event"),
                    ("KEEP", "compliance_policy"),
                    ("DROP", "non_target"),
                    ("UNCERTAIN", "uncertain"),
                },
                "筛选结论与路由不一致",
            )
        else:
            require(row["route"] is None, "没有结论时不能伪造路由")
            require(
                row["item_kind"] == "digest_parent" or row["process_status"] == "FAILED",
                "成功叶子条目缺少筛选结论",
            )
        items[row["item_id"]] = row
        by_source[sid].append(row)
    require(set(by_source) == set(expected_by_id), "结果未覆盖本批全部原文")
    for sid, rows in by_source.items():
        require(len({r["item_key"] for r in rows}) == len(rows), "同一原文子项键重复")
        if expected_by_id[sid]["digest"]:
            parents = [r for r in rows if r["item_kind"] == "digest_parent"]
            require(
                len(parents) == 1 and not any(r["item_kind"] == "normal" for r in rows),
                "快讯父子结构无效",
            )
            require(parents[0]["process_status"] == "FAILED" or len(rows) > 1, "快讯成功却没有子项")
        else:
            require(len(rows) == 1 and rows[0]["item_kind"] == "normal", "普通文章结构无效")
    for row in bundle["candidates"]:
        validate_row(row, "candidates", run_id)
        cid = row["candidate_record_id"]
        require(bool(cid) and cid not in candidates, "候选记录 ID 重复或为空")
        require(row["candidate_type"] in {"security_event", "compliance_policy"}, "候选类型无效")
        require(bool(row["title"]) and bool(row["summary"]), "候选标题或概述为空")
        require(
            row["review_status"] == "pending"
            and all(row[k] is None for k in REVIEW_FIELDS - {"review_status"}),
            "模型输出不能设置人工反馈",
        )
        validate_scores(row, True)
        for field in ("primary_item_id", "score_source_item_id"):
            require(
                row[field] in items and items[row[field]]["candidate_record_id"] == cid,
                "候选来源不属于该候选",
            )
        score_source = items[row["score_source_item_id"]]
        require(
            all(row[k] == score_source[k] for k in (*SCORES, "total_score", "reason")),
            "评分来源不一致",
        )
        candidates[cid] = row
    for row in items.values():
        cid = row["candidate_record_id"]
        if cid is not None:
            require(
                cid in candidates
                and row["decision"] == "KEEP"
                and row["process_status"] == "SUCCESS",
                "候选关联指向失败、非 KEEP 或不存在的记录",
            )
            require(row["route"] == candidates[cid]["candidate_type"], "候选类型与来源路由不一致")
        elif row["decision"] == "KEEP" and row["process_status"] == "SUCCESS":
            raise ContractError("成功 KEEP 记录没有最终候选")
    return bundle


def rejected_records(rejected: list[dict], run_id: str, version: str) -> list[dict]:
    """Only deterministic input errors are created outside Dify."""
    import hashlib

    records = []
    for error in rejected:
        sid = source_id(error["source_article_id"])
        row = dict.fromkeys(FIELDS["processing_items"])
        row.update(
            {
                "item_id": "item_"
                + hashlib.sha256(f"{run_id}:{sid}:input_error".encode()).hexdigest()[:28],
                "run_id": run_id,
                "source_article_id": sid,
                "item_kind": "normal",
                "item_key": "input_error",
                "process_status": "FAILED",
                "processing_version": version,
                "excluded_iocs_json": [],
                "quality_warnings_json": [],
                "input_hash": error.get("input_hash"),
                "input_meta_json": error.get("input_meta_json") or {},
                "errors_json": [
                    {"stage": "local_prepare", "code": error["code"], "message": error["message"]}
                ],
            }
        )
        records.append(row)
    return records
