"""One explicit business timezone, independent of the host and Docker timezone."""

from datetime import datetime, timedelta, timezone

BEIJING = timezone(timedelta(hours=8))


def parse_time(value: str) -> datetime:
    value = value.strip()
    if len(value) == 10:
        raise ValueError("需要完整时间，不能将仅有日期的值假定为零点")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=BEIJING)
    return parsed.astimezone(BEIJING)


def normalize_time(value: str) -> str:
    return parse_time(value).isoformat(timespec="microseconds")


def now_text() -> str:
    return datetime.now(BEIJING).isoformat(timespec="microseconds")
