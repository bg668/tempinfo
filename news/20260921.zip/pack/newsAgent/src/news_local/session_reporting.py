"""Rebuild totals from acknowledged runs, never increment them on resume."""

from collections import Counter

from .timeutils import now_text, parse_time

COUNT_FIELDS = (
    "submitted_count", "normal_article_count", "digest_article_count",
    "input_quality_error_count", "completed_article_count", "failed_article_count",
    "processing_item_count", "failed_item_count", "digest_child_count",
    "event_before_count", "event_group_count", "candidate_count",
    "warning_article_count", "warning_count",
)
MAP_FIELDS = ("digest_types", "decisions", "candidate_types")


def summarize_session(session: dict, runs: dict[str, dict]) -> dict:
    totals = Counter({name: 0 for name in COUNT_FIELDS})
    maps = {name: Counter() for name in MAP_FIELDS}
    maps["decisions"].update({key: 0 for key in ("KEEP", "DROP", "UNCERTAIN")})
    maps["candidate_types"].update({key: 0 for key in ("security_event", "compliance_policy")})
    errors, export_errors, deferred = [], [], []
    excluded = batch_count = 0
    batch_issues = False
    for segment in session["segments"]:
        query = segment["query"]
        excluded += query["excluded_completed_count"]
        deferred.extend(query.get("deferred_articles", []))
        if not segment.get("run_id"):
            continue
        run_id = segment["run_id"]
        run = runs[run_id]
        summary = run["summary"]
        batch_count += 1
        totals.update({name: summary.get(name, 0) for name in COUNT_FIELDS})
        for name in MAP_FIELDS:
            maps[name].update(summary.get(name, {}))
        errors.extend({"run_id": run_id, "detail": error} for error in summary.get("errors", []))
        export_errors.extend({"run_id": run_id, "message": error}
                             for error in run.get("export_errors", []))
        batch_issues |= summary["status"] in {"PARTIAL", "FAILED"}
    result = "SUCCESS"
    if batch_issues or totals["failed_article_count"] or export_errors or deferred:
        result = "PARTIAL" if (totals["completed_article_count"] or totals["candidate_count"]
                               or excluded or deferred) else "FAILED"
    elif not totals["processing_item_count"] and not totals["candidate_count"]:
        result = "NO_WORK"
    phase = session["phase"]
    finished = session.get("finished_at")
    active = session.get("active") or {}
    active_run = runs.get(active.get("run_id"), {})
    return {
        "session_id": session["session_id"], "phase": phase,
        "status": result if phase == "COMPLETED" else phase,
        "stop_reason": session.get("stop_reason"), "error": session.get("error"),
        "started_at": session["started_at"], "finished_at": finished,
        "elapsed_seconds": round((parse_time(finished or now_text())
                                  - parse_time(session["started_at"])).total_seconds(), 2),
        "query": session["query"], "batch_size": session["config"]["batch_size"],
        "batch_count": batch_count, "run_ids": [s["run_id"] for s in session["segments"]
                                                   if s.get("run_id")],
        "scanned_record_count": active.get("end_cursor", session["cursor"]),
        "checkpoint_record_count": session["cursor"],
        "excluded_completed_count": excluded,
        "remaining_unexamined_count": session["entry_count"] - active.get("end_cursor", session["cursor"]),
        "active_run_id": active.get("run_id"), "active_phase": active_run.get("phase"),
        "active_selected_count": active.get("selected_count", 0),
        "active_submitted_count": active_run.get("query", {}).get("selected_count", 0)
        if active_run.get("workflow_run_id") else (
            None if active_run.get("phase") in {"SUBMITTING", "RUNNING", "WAITING", "NEEDS_RECOVERY"}
            else 0),
        "deferred_article_count": len(deferred), "deferred_articles": deferred,
        **dict(totals), **{name: dict(value) for name, value in maps.items()},
        "grouping_mode": session["config"]["grouping_mode"],
        "errors": errors, "export_errors": export_errors,
        "database": {"committed_batch_count": batch_count,
                     "processing_items_committed": totals["processing_item_count"],
                     "candidates_committed": totals["candidate_count"]},
        "count_scope": "acknowledged_committed_batches; active batch reported separately",
    }
