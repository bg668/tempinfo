"""Operational metrics have explicit units: articles, leaf items and candidates."""

from collections import Counter, defaultdict

from .timeutils import now_text, parse_time


def summarize(run: dict, bundle: dict, database: dict) -> dict:
    rows, candidates = bundle["processing_items"], bundle["candidates"]
    by_article = defaultdict(list)
    for row in rows:
        by_article[row["source_article_id"]].append(row)
    completed = sum(
        all(r["process_status"] == "SUCCESS" for r in items) for items in by_article.values()
    )
    leaves = [r for r in rows if r["item_kind"] != "digest_parent"]
    decisions = Counter(r["decision"] for r in leaves if r["decision"] is not None)
    kinds = Counter(r["candidate_type"] for r in candidates)
    digest_types = Counter()
    for article in run["plan"]["articles"]:
        if not article["digest"]:
            continue
        title = article["payload"]["title"]
        digest_types["weekly" if "周报" in title else "daily" if "日报" in title else "other"] += 1
    finished = now_text()
    status = "SUCCESS"
    if bundle.get("process_status") != "SUCCESS" or any(
        r["process_status"] == "FAILED" for r in rows
    ):
        status = "PARTIAL" if completed or candidates else "FAILED"
    if not rows and not candidates:
        status = "NO_WORK" if not bundle.get("errors") else "FAILED"
    return {
        "run_id": run["run_id"],
        "batch_number": run.get("batch_number"),
        "status": status,
        "started_at": run["started_at"],
        "finished_at": finished,
        "elapsed_seconds": round(
            (parse_time(finished) - parse_time(run["started_at"])).total_seconds(), 2
        ),
        "query": run["plan"]["query"],
        "submitted_count": len(run["plan"]["articles"]),
        "normal_article_count": sum(not a["digest"] for a in run["plan"]["articles"]),
        "digest_article_count": sum(digest_types.values()),
        "digest_types": dict(digest_types),
        "input_quality_error_count": len(run["plan"]["rejected"]),
        "completed_article_count": completed,
        "failed_article_count": len(by_article) - completed,
        "processing_item_count": len(rows),
        "failed_item_count": sum(r["process_status"] == "FAILED" for r in rows),
        "digest_child_count": sum(r["item_kind"] == "digest_child" for r in rows),
        "decisions": {k: decisions[k] for k in ("KEEP", "DROP", "UNCERTAIN")},
        "grouping_mode": run["grouping_mode"],
        "event_before_count": bundle["stats"].get("normal_incident_count", 0),
        "event_group_count": bundle["stats"].get("event_group_count", 0),
        "candidate_count": len(candidates),
        "candidate_types": {k: kinds[k] for k in ("security_event", "compliance_policy")},
        "warning_article_count": sum(
            any(r["quality_warnings_json"] for r in items) for items in by_article.values()
        ),
        "warning_count": len(bundle.get("warnings", [])),
        "errors": bundle.get("errors", []),
        "database": database,
        "files": run.get("files", {}),
        "export_errors": run.get("export_errors", []),
    }
