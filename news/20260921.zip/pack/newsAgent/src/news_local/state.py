"""Atomic local run journal and an OS-held runner lock; not a third business table."""

import hashlib
import json
import os
import re
import tempfile
from contextlib import contextmanager
from pathlib import Path

from .errors import NewsError

RUN_PATTERN = re.compile(r"run_[a-f0-9]{32}")


def atomic_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".writing-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(value, handle, ensure_ascii=False, allow_nan=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class RunStore:
    def __init__(self, root: Path):
        self.root = root

    def directory(self, run_id: str) -> Path:
        if not RUN_PATTERN.fullmatch(run_id):
            raise NewsError("批次 ID 格式无效")
        return self.root / "runs" / run_id

    def save(self, run: dict) -> None:
        directory = self.directory(run["run_id"])
        if "plan" in run and not run.get("input_sha256"):
            snapshot = {"plan": run["plan"], "inputs": run.get("inputs")}
            atomic_json(directory / "input.json", snapshot)
            run["input_sha256"] = hashlib.sha256(
                (directory / "input.json").read_bytes()
            ).hexdigest()
        metadata = {k: v for k, v in run.items() if k not in {"plan", "inputs"}}
        if "plan" in run:
            metadata["query"] = run["plan"]["query"]
        atomic_json(directory / "run.json", metadata)

    def load(self, run_id: str) -> dict:
        path = self.directory(run_id) / "run.json"
        if not path.is_file():
            raise NewsError("找不到本地批次")
        run = json.loads(path.read_text(encoding="utf-8"))
        if run.get("input_sha256"):
            data = (path.parent / "input.json").read_bytes()
            if hashlib.sha256(data).hexdigest() != run["input_sha256"]:
                raise NewsError("本地输入快照已改变，拒绝自动恢复")
            run.update(json.loads(data))
        return run

    def list(self) -> list[dict]:
        runs = []
        for path in (self.root / "runs").glob("run_*/run.json"):
            runs.append(json.loads(path.read_text(encoding="utf-8")))
        return sorted(runs, key=lambda x: x["started_at"], reverse=True)

    def ensure_no_active_session(self) -> None:
        # Shared by single-batch and continuous entry points, under runner.lock.
        for path in (self.root / "sessions").glob("session_*/session.json"):
            session = json.loads(path.read_text(encoding="utf-8"))
            if session["phase"] not in {"COMPLETED", "ABANDONED"}:
                raise NewsError("请先恢复连续任务：resume-all " + session["session_id"])

    @contextmanager
    def lock(self):
        self.root.mkdir(parents=True, exist_ok=True)
        handle = (self.root / "runner.lock").open("a+b")
        handle.seek(0)
        if handle.read(1) == b"":
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        acquired = False
        try:
            try:
                if os.name == "nt":
                    import msvcrt

                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                acquired = True
            except OSError as exc:
                raise NewsError("已有本地批次正在执行") from exc
            yield
        finally:
            if acquired:
                handle.seek(0)
                if os.name == "nt":
                    import msvcrt

                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            handle.close()
