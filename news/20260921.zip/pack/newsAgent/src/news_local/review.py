"""Minimal human review contract used by the separate Web backend."""

from .contracts import require

REVIEW_STATUSES = frozenset({"pending", "starred", "ignored"})
REVIEWER_ID = "root"


def review_changes(payload: dict) -> tuple[str, str]:
    """Validate a status-only review request and return status/version."""
    require(isinstance(payload, dict), "审核内容必须为对象")
    require(
        set(payload) <= {"review_status", "expected_updated_at"},
        "审核请求只能修改 review_status",
    )
    status = payload.get("review_status")
    require(status in REVIEW_STATUSES, "审核状态无效")
    version = payload.get("expected_updated_at")
    require(isinstance(version, str) and bool(version), "缺少编辑版本，请刷新候选")
    return status, version
