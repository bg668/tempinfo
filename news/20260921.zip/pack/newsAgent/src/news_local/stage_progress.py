"""Independent stage lifecycles; parallel branches never share a current-stage variable."""

import logging
import time
from dataclasses import dataclass

from .log_context import log_scope
from .progress_events import emit_progress

LOG = logging.getLogger("news_local.progress")


@dataclass
class StageState:
    started: float | None = None
    ended: bool = False
    skipped: bool = False
    anomalies: int = 0


class StageProgress:
    def __init__(self, counts: dict | None = None):
        self.states: dict[str, StageState] = {}
        self.counts = counts or {}
        self.notes: set[str] = set()

    def skip(self, stage: str) -> None:
        state = self.states.get(stage)
        if state and (state.ended or state.anomalies):
            return
        self.states[stage] = StageState(ended=True, skipped=True)
        with log_scope(stage=stage, substep=""):
            LOG.info("跳过｜输入=0")
            emit_progress("stage_skipped", stage=stage, status="skipped", input_count=0)

    def start(self, stage: str, *, has_start: bool = True) -> None:
        if stage in self.states:
            return
        self.states[stage] = StageState(started=time.monotonic() if has_start else None)
        with log_scope(stage=stage, substep=""):
            count = self.counts.get(stage)
            if has_start:
                LOG.info("开始%s", "｜输入=" + str(count) if count is not None else "")
            else:
                LOG.warning("收到阶段事件但缺少开始事件%s",
                            "｜输入=" + str(count) if count is not None else "")
            emit_progress(
                "stage_started",
                stage=stage,
                status="running",
                input_count=count,
                start_event_missing=not has_start,
            )

    def anomaly(self, stage: str) -> None:
        self.start(stage, has_start=False)
        self.states[stage].anomalies += 1

    def finish(self, stage: str, status: str) -> None:
        self.start(stage, has_start=False)
        state = self.states[stage]
        if state.ended:
            return
        state.ended = True
        elapsed = time.monotonic() - state.started if state.started is not None else None
        with log_scope(stage=stage, substep=""):
            log = LOG.warning if state.anomalies or status in {"failed", "exception"} else LOG.info
            elapsed_text = f"{elapsed:.2f}s" if elapsed is not None else "未知"
            log("完成｜状态=%s｜耗时=%s｜异常=%s", status, elapsed_text, state.anomalies)
            emit_progress(
                "stage_finished",
                stage=stage,
                status=status,
                elapsed_sec=round(elapsed, 3) if elapsed is not None else None,
                anomaly_count=state.anomalies,
            )

    def note(self, stage: str, key: str, text: str) -> None:
        if key in self.notes:
            return
        self.notes.add(key)
        with log_scope(stage=stage, substep=""):
            LOG.info("%s", text)
            emit_progress("stage_note", stage=stage, note=key, message=text)

    def close(self, workflow_finished: bool) -> None:
        for stage, state in self.states.items():
            if state.ended:
                continue
            state.ended = True
            with log_scope(stage=stage, substep=""):
                LOG.warning("%s｜未收到阶段结束事件，不推断成功或耗时",
                            "工作流已返回" if workflow_finished else "事件接收中断")
                emit_progress(
                    "stage_incomplete",
                    stage=stage,
                    status="unknown",
                    reason="workflow_finished" if workflow_finished else "stream_interrupted",
                )
