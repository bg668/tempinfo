"""Application orchestration. Adapters are injected for offline end-to-end tests."""

import hashlib
import json
import logging
import uuid

from .config import Settings
from .contracts import rejected_records, validate_bundle
from .diagnostics import diagnose
from .errors import NewsError, PendingRun, RemoteFailure
from .log_context import current_context, local_stage, log_scope
from .planner import select_batch
from .ports import CollectorPort, DifyPort, ResultPort
from .progress import report_business_results, report_result_errors
from .progress_events import emit_progress
from .reporting import summarize
from .state import RunStore, atomic_json
from .timeutils import now_text

TERMINAL_PHASES = {"COMPLETED", "FAILED", "ABANDONED"}
LOG = logging.getLogger(__name__)
PHASE_MESSAGES = {
    "PREPARED": "输入准备完成",
    "SUBMITTING": "提交 Dify，等待远程处理",
    "RUNNING": "Dify 执行已关联",
    "DOWNLOADING": "Dify 已返回，获取导出结果",
    "SAVING": "校验完成，开始事务入库",
}


class Runner:
    def __init__(
        self,
        settings: Settings,
        collector: CollectorPort,
        repository: ResultPort,
        client: DifyPort,
        store: RunStore,
    ):
        self.settings, self.collector, self.repository = settings, collector, repository
        self.client, self.store = client, store

    @log_scope(stage="prepare", substep="本地选取")
    def preview(self, force: bool = False) -> dict:
        self.collector.check()
        return select_batch(self.collector, self.repository, self.settings, force).to_dict()

    def run(self, force: bool = False) -> dict:
        with self.store.lock():
            return self._run_locked(force)

    def _run_locked(
        self, force: bool = False, *, plan: dict | None = None,
        run_id: str | None = None, session_id: str | None = None,
    ) -> dict:
        """Log context is scoped to this call, including heartbeat threads created inside it."""
        run_id = run_id or "run_" + uuid.uuid4().hex
        with log_scope(
            run_id=run_id,
            batch_number=current_context().get("batch_number", 1),
            progress_path=str(self.store.directory(run_id) / "progress.jsonl"),
            stage="prepare",
            substep="本地准备",
        ):
            return self._run_batch(force, plan=plan, run_id=run_id, session_id=session_id)

    def _run_batch(
        self, force: bool = False, *, plan: dict | None = None,
        run_id: str | None = None, session_id: str | None = None,
    ) -> dict:
        """Caller owns the shared execution lock; a supplied plan is already frozen."""
        unfinished = [
            r for r in self.store.list() if r["phase"] not in TERMINAL_PHASES
            and not (r["run_id"] == run_id and r["phase"] == "PREPARING"
                     and not r.get("workflow_run_id"))
        ]
        if unfinished:
            raise NewsError("请先恢复未结束批次：" + unfinished[0]["run_id"])
        self.collector.check()
        self.repository.initialize()
        run = {
            "run_id": run_id or "run_" + uuid.uuid4().hex,
            "started_at": now_text(),
            "batch_number": current_context().get("batch_number", 1),
            "phase": "PREPARING",
            "workflow_run_id": None,
            "grouping_mode": self.settings.grouping_mode,
            "files": {},
            "export_errors": [],
        }
        if session_id:
            run["session_id"] = session_id
        self.store.save(run)
        try:
            run["plan"] = plan if plan is not None else self.preview(force)
            selected = len(run["plan"]["articles"])
            rejected = len(run["plan"].get("rejected") or [])
            remaining = run["plan"].get("query", {}).get("unexamined_count")
            LOG.info(
                "批次开始｜输入=%s｜输入异常=%s｜剩余待扫描≈%s｜run=%s",
                selected, rejected, remaining if remaining is not None else "未知", run["run_id"][4:12],
            )
            emit_progress(
                "batch_started",
                stage=None,
                status="running",
                input_count=selected,
                rejected_count=rejected,
                remaining_scan_count=remaining,
            )
            self._preflight(run)
            run["inputs"] = self._inputs(run)
            self._phase(run, "PREPARED")
            return self._execute_prepared(run)
        except (NewsError, OSError, ValueError) as exc:
            return self._record_failure(run, exc)

    @log_scope(stage="远程执行", substep="")
    def _execute_prepared(self, run: dict) -> dict:
        """Only PREPARED inputs can start a new remote execution."""
        if not run["plan"]["articles"]:
            LOG.info("没有可提交原文，直接保存本地处理概况")
            return self._commit(run, self._empty_bundle(run))
        run["submit_attempt_count"] = int(run.get("submit_attempt_count") or 0) + 1
        self._phase(run, "SUBMITTING")
        try:
            detail = self.client.start(
                run["inputs"], lambda value: self._execution_id(run, value)
            )
        except PendingRun as exc:
            LOG.warning("%s", exc)
            if not run["workflow_run_id"]:
                raise
            detail = self.client.detail(run["workflow_run_id"])
        return self._receive(run, detail)

    def resume(
        self, run_id: str, workflow_run_id: str = "", *, allow_resubmit_ambiguous: bool = False
    ) -> dict:
        with self.store.lock():
            return self._resume_locked(
                run_id, workflow_run_id, allow_resubmit_ambiguous=allow_resubmit_ambiguous
            )

    def _resume_locked(
        self, run_id: str, workflow_run_id: str = "", *, allow_resubmit_ambiguous: bool = False
    ) -> dict:
        """Caller owns the same lock as run().

        Interactive resume stays conservative.  The daemon may explicitly
        replay an ambiguous submit using the same run_id and frozen inputs.
        """
        run = self.store.load(run_id)
        with log_scope(
            run_id=run_id,
            batch_number=run.get("batch_number", current_context().get("batch_number", 1)),
            progress_path=str(self.store.directory(run_id) / "progress.jsonl"),
            stage="恢复处理",
            substep="",
        ):
            return self._resume_run(
                run, workflow_run_id, allow_resubmit_ambiguous=allow_resubmit_ambiguous
            )

    def _resume_run(
        self, run: dict, workflow_run_id: str = "", *, allow_resubmit_ambiguous: bool = False
    ) -> dict:
        run_id = run["run_id"]
        LOG.info("恢复模式｜沿用原执行；缺失的历史阶段日志不补造")
        LOG.info("恢复原批次｜run_id=%s｜本地阶段=%s", run_id, run["phase"])
        retry_exports = run["phase"] == "COMPLETED" and bool(run.get("export_errors"))
        if run["phase"] in TERMINAL_PHASES and not retry_exports:
            raise NewsError("批次已结束；重新入库请使用 ingest，重新处理请创建新批次")
        try:
            if run["phase"] == "PREPARING" and not run.get("plan"):
                # No frozen input and no remote submission can exist. Discard
                # this incomplete journal; the daemon will plan again safely.
                run["error"] = "准备阶段中断且尚未形成输入快照；已安全放弃并重新选取"
                self._phase(run, "ABANDONED")
                return {
                    "run_id": run_id, "status": "ABANDONED", "error": run["error"],
                    "database": {"status": "NOT_COMMITTED"},
                }
            if run["phase"] == "PREPARED" and not run.get("workflow_run_id"):
                if workflow_run_id:
                    raise NewsError("当前批次尚未提交，不能手动绑定远程执行")
                self._preflight(run)
                return self._execute_prepared(run)
            if workflow_run_id:
                if run.get("workflow_run_id") and run["workflow_run_id"] != workflow_run_id:
                    raise NewsError("不能替换已经绑定的 Dify 执行 ID")
                self._execution_id(run, workflow_run_id)
            if retry_exports:
                return self._receive(run, self._refresh_detail(run))
            if (self.store.directory(run_id) / "bundle.validated.json").exists():
                bundle = self._read_validated(run)
                return self._commit(run, bundle)
            if run.get("remote_detail"):
                return self._receive(run, self._refresh_detail(run))
            if not run.get("workflow_run_id"):
                if allow_resubmit_ambiguous and run.get("plan") and run.get("inputs"):
                    LOG.warning(
                        "远程提交结果不确定，后台将复用同一 run_id 与输入快照重新提交｜run_id=%s",
                        run_id,
                    )
                    self._preflight(run)
                    return self._execute_prepared(run)
                raise PendingRun(
                    "没有 Dify 执行 ID；交互恢复需在 Dify 日志确认后用 "
                    "resume --workflow-run-id 关联；run-forever 会复用原 run_id 自动恢复"
                )
            return self._receive(run, self.client.detail(run["workflow_run_id"]))
        except (NewsError, OSError, ValueError) as exc:
            return self._record_failure(run, exc)

    def reingest(self, run_id: str) -> dict:
        with self.store.lock():
            run = self.store.load(run_id)
            path = self.store.directory(run_id) / "bundle.validated.json"
            if not path.is_file():
                raise NewsError("没有经过校验的本地结果，请先 resume")
            bundle = self._read_validated(run)
            LOG.info("重新导入已校验结果｜run_id=%s", run_id)
            result = self.repository.ingest(bundle)
            LOG.info("重新入库完成｜%s", result)
            return result

    def abandon(self, run_id: str) -> None:
        with self.store.lock():
            run = self.store.load(run_id)
            if run["phase"] in TERMINAL_PHASES:
                raise NewsError("批次已经结束")
            run["error"] = "操作人员显式放弃本地恢复；此动作不会停止 Dify 远程任务"
            self._phase(run, "ABANDONED")

    @log_scope(stage="prepare", substep="容量检查")
    def _preflight(self, run: dict) -> None:
        serialized = json.dumps(
            [a["payload"] for a in run["plan"]["articles"]],
            ensure_ascii=False,
            separators=(",", ":"),
        )
        if len(serialized) > self.settings.max_input_chars:
            raise NewsError("本批输入超过 max_input_chars；未提交、未缩减文章、未拆分归并")
        if run["plan"]["articles"] and not self.settings.api_key:
            raise NewsError("DIFY_API_KEY 未设置")
        LOG.debug(
            "批次输入容量｜实际=%s 字符｜本地上限=%s 字符",
            len(serialized),
            self.settings.max_input_chars,
        )
        if len(run["plan"]["articles"]) > 30:
            LOG.debug(
                "本批超过 Dify 默认 30 项数组上限；部署端需应用 deploy/dify.capacity.override.yml。"
                "应用 API 不提供这些环境变量，本地未验证其生效值。"
            )

    def _refresh_detail(self, run: dict) -> dict:
        if run.get("workflow_run_id"):
            return self.client.detail(run["workflow_run_id"])
        return run["remote_detail"]

    def _inputs(self, run: dict) -> dict:
        return {
            "run_id": run["run_id"],
            "articles_json": json.dumps(
                [a["payload"] for a in run["plan"]["articles"]],
                ensure_ascii=False,
                separators=(",", ":"),
            ),
            "grouping_mode": run["grouping_mode"],
            "digest_keywords": self.settings.digest_keywords,
            "max_content_chars": self.settings.max_content_chars,
        }

    def _execution_id(self, run: dict, value: str) -> None:
        uuid.UUID(value)
        if run.get("workflow_run_id") and run["workflow_run_id"] != value:
            raise NewsError("事件流出现不同的 Dify 执行 ID")
        if run.get("workflow_run_id") != value:
            run["workflow_run_id"] = value
            self._phase(run, "RUNNING")
            LOG.info("workflow_run_id=%s", value)

    def _receive(self, run: dict, detail: dict) -> dict:
        if not isinstance(detail, dict):
            raise NewsError("Dify 执行详情不是对象")
        status = detail.get("status")
        if status in {"running", "paused", "pending"}:
            raise PendingRun("Dify 任务尚未完成，请稍后 resume 查询")
        if status not in {"succeeded", "partial-succeeded"}:
            raise RemoteFailure("Dify 执行未成功：" + str(detail.get("error") or status))
        LOG.info("远程执行返回｜状态=%s｜耗时=%s 秒", status, detail.get("elapsed_time", "未知"))
        return self._download_and_commit(run, detail)

    @local_stage("store")
    def _download_and_commit(self, run: dict, detail: dict) -> dict:
        run["remote_detail"] = detail
        self._phase(run, "DOWNLOADING")
        directory = self.store.directory(run["run_id"])
        outputs = detail.get("outputs") or {}
        raw_path = directory / "result.json"
        if not raw_path.exists():
            self.client.download(outputs, "result_json_file", raw_path)
        else:
            LOG.debug("复用已下载 result.json")
        run["files"]["result_json"] = "result.json"
        run["export_errors"] = []
        try:
            csv_path = directory / "review.csv"
            if not csv_path.exists():
                self.client.download(outputs, "review_csv_file", csv_path)
            else:
                LOG.debug("复用已下载 review.csv")
            run["files"]["review_csv"] = "review.csv"
        except NewsError as exc:
            run["export_errors"].append(str(exc))
            LOG.warning("CSV 导出未完成，有效 JSON 仍可入库｜%s", exc)
        LOG.info("校验结果｜批次、输入哈希、来源覆盖、评分及候选关联")
        bundle = validate_bundle(
            json.loads(raw_path.read_text(encoding="utf-8-sig")),
            run["run_id"],
            run["plan"]["articles"],
        )
        bundle["processing_items"].extend(
            rejected_records(run["plan"]["rejected"], run["run_id"], bundle["processing_version"])
        )
        report_result_errors(bundle.get("errors") or [])
        return self._commit(run, bundle)

    @local_stage("store")
    def _commit(self, run: dict, bundle: dict) -> dict:
        path = self.store.directory(run["run_id"])
        atomic_json(path / "bundle.validated.json", bundle)
        run["validated_sha256"] = hashlib.sha256(
            (path / "bundle.validated.json").read_bytes()
        ).hexdigest()
        self._phase(run, "SAVING")
        database = self.repository.ingest(bundle)
        run["database"] = database
        run["summary"] = summarize(run, bundle, database)
        if run.get("export_errors") and run["summary"]["status"] == "SUCCESS":
            run["summary"]["status"] = "PARTIAL"
        run.pop("error", None)
        self._phase(run, "COMPLETED")
        atomic_json(path / "summary.json", run["summary"])
        summary = run["summary"]
        report_business_results(bundle)
        LOG.info(
            "处理完成｜状态=%s｜文章成功=%s/失败=%s｜KEEP=%s/DROP=%s/UNCERTAIN=%s｜候选=%s",
            summary["status"],
            summary["completed_article_count"],
            summary["failed_article_count"],
            *(summary["decisions"][k] for k in ("KEEP", "DROP", "UNCERTAIN")),
            summary["candidate_count"],
        )
        LOG.info("入库完成｜新增处理记录=%s｜新增候选=%s｜重复跳过=%s｜概况=%s",
                 database.get("processing_items_inserted", 0), database.get("candidates_inserted", 0),
                 database.get("duplicates_skipped", 0), path / "summary.json")
        emit_progress(
            "batch_finished",
            stage=None,
            status=summary["status"],
            elapsed_sec=summary["elapsed_seconds"],
            completed_article_count=summary["completed_article_count"],
            failed_article_count=summary["failed_article_count"],
            candidate_count=summary["candidate_count"],
        )
        return run["summary"]

    def _read_validated(self, run: dict) -> dict:
        path = self.store.directory(run["run_id"]) / "bundle.validated.json"
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != run.get("validated_sha256"):
            raise NewsError("本地校验结果已改变，拒绝自动入库")
        return json.loads(data)

    @staticmethod
    def _empty_bundle(run: dict) -> dict:
        return {
            "schema_version": "news-result-bundle-v1",
            "run_id": run["run_id"],
            "processing_version": "local-input-v1",
            "process_status": "SUCCESS",
            "stats": {},
            "errors": [],
            "warnings": [],
            "candidates": [],
            "processing_items": rejected_records(
                run["plan"]["rejected"], run["run_id"], "local-input-v1"
            ),
        }

    def _phase(self, run: dict, value: str) -> None:
        run["phase"] = value
        self.store.save(run)
        if value in PHASE_MESSAGES:
            LOG.info("%s", PHASE_MESSAGES[value])

    @log_scope(stage="批次调度", substep="")
    def _record_failure(self, run: dict, exc: Exception) -> dict:
        run["error"] = str(exc)
        diagnostic = diagnose(str(exc))
        if diagnostic:
            run["diagnostic"] = diagnostic
        phase = run["phase"]
        if isinstance(exc, RemoteFailure) or phase in {"PREPARING", "PREPARED"}:
            phase = "FAILED"
        else:
            phase = "WAITING" if isinstance(exc, PendingRun) else "NEEDS_RECOVERY"
        if run.get("summary"):
            run["summary"]["status"] = phase
        self._phase(run, phase)
        LOG.error("批次未完成｜run_id=%s｜状态=%s｜%s", run["run_id"], phase, exc)
        if diagnostic:
            LOG.error(
                "修复方法｜%s｜建议配置=%s",
                diagnostic["action"],
                diagnostic.get("suggested_environment", {}),
            )
        result = {
            "run_id": run["run_id"],
            "batch_number": run.get("batch_number"),
            "status": phase,
            "error": str(exc),
            "workflow_run_id": run.get("workflow_run_id"),
            "started_at": run["started_at"],
            "query": run.get("plan", {}).get("query", {}),
            "database": run.get(
                "database",
                {"status": "UNKNOWN" if run["phase"] == "NEEDS_RECOVERY" else "NOT_COMMITTED"},
            ),
        }
        if diagnostic:
            result["diagnostic"] = diagnostic
        return result
