"""Human-readable console progress plus bounded structured workflow metadata."""

import json
import logging
import sys
import threading
import time
from collections import Counter
from contextvars import copy_context
from datetime import datetime

from .article_contract import parse_digest_keywords
from .log_context import ContextFilter, log_scope
from .progress_events import emit_progress
from .stage_progress import StageProgress
from .timeutils import BEIJING
from .workflow_stages import (
    ITEM_TERMINAL_NODES,
    ITERATION_NODES,
    NODE_STAGES,
    STAGE_NUMBERS,
    STAGE_TOTAL,
    STAGES,
    SUBSTEPS,
    TERMINAL_NODES,
    error_stage,
)

LOG = logging.getLogger("news_local.progress")
LEVELS = {"detailed": logging.DEBUG, "key": logging.INFO}
_STAGE_NO = STAGE_NUMBERS


def one_line(value: object, limit: int = 500) -> str:
    """Keep remote titles/errors from injecting terminal control sequences or new lines."""
    text = " ".join(str(value).split())
    return "".join(c for c in text if c.isprintable())[:limit]


class BeijingFormatter(logging.Formatter):
    def format(self, record):
        timestamp = datetime.fromtimestamp(record.created, BEIJING).isoformat(timespec="seconds")
        label = {10: "详细", 20: "信息", 30: "警告", 40: "错误"}.get(record.levelno, "信息")
        batch = getattr(record, "batch_number", None)
        stage = getattr(record, "stage", "")
        substep = getattr(record, "substep", "")
        unit_type = getattr(record, "unit_type", "")
        item_index = getattr(record, "item_index", None)
        item_total = getattr(record, "item_total", None)

        prefix = f"[B{batch:03d}]" if type(batch) is int else ""
        if stage:
            if stage in _STAGE_NO:
                prefix += f"[S {_STAGE_NO[stage]}/{STAGE_TOTAL} {one_line(STAGES[stage], 120)}]"
            else:
                name = "未分类节点" if stage == "unknown" else str(stage)
                prefix += "[" + one_line(name, 120) + "]"
        if type(item_index) is int:
            unit = one_line(unit_type or "条目", 30)
            total = str(item_total) if type(item_total) is int and item_total > 0 else "?"
            prefix += f"[{unit}{item_index}/{total}]"
        if substep:
            prefix += "[" + one_line(str(substep), 80) + "]"
        return f"{timestamp} [{label}] {prefix} {one_line(record.getMessage(), 2000)}"


def configure(level: str = "key", stream=None) -> None:
    """Configure this application's logger, leaving host/root loggers untouched."""
    logger = logging.getLogger("news_local")
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
        handler.close()
    handler = logging.StreamHandler(stream if stream is not None else sys.stderr)
    handler.setFormatter(BeijingFormatter())
    handler.addFilter(ContextFilter())
    logger.addHandler(handler)
    logger.setLevel(LEVELS[level])
    logger.propagate = False


def input_progress_meta(inputs: dict) -> dict:
    """Build non-sensitive progress metadata from the submitted article envelope."""
    try:
        articles = json.loads(inputs["articles_json"])
        if not isinstance(articles, list) or not all(isinstance(a, dict) for a in articles):
            return {"counts": {}, "items": {}}
        keywords = parse_digest_keywords(inputs.get("digest_keywords", ""))
        items = {"digest": [], "normal": []}
        for article in articles:
            target = "digest" if any(k in str(article.get("title") or "") for k in keywords) else "normal"
            items[target].append({
                "item_id": one_line(article.get("source_article_id") or "", 80),
                "item_title": one_line(article.get("title") or "", 100),
            })
        return {
            "counts": {
                "prepare": len(articles),
                "digest": len(items["digest"]),
                "normal": len(items["normal"]),
            },
            "items": items,
        }
    except (KeyError, ValueError, TypeError):
        return {"counts": {}, "items": {}}


def input_counts(inputs: dict) -> dict:
    """Compatibility helper retained for tests/callers that only need counts."""
    return input_progress_meta(inputs)["counts"]


class DifyProgress:
    """Translate SSE metadata into Batch → Stage → Item progress without payload logging."""

    def __init__(
        self,
        interval: float = 30,
        counts: dict | None = None,
        items: dict | None = None,
    ):
        self.interval = interval
        self.started = time.monotonic()
        self.last_event = "等待 Dify 事件"
        self.last_stage = "远程执行"
        self.last_substep = ""
        self.action_started = self.started
        self.stop = threading.Event()
        self.thread = None
        self.stages = StageProgress(counts)
        self.item_catalog = items or {}
        self.iterations: dict[str, dict] = {}
        self.seen = set()
        self.unknown_nodes = set()
        self.finished = False

    def __enter__(self):
        context = copy_context()
        self.thread = threading.Thread(target=context.run, args=(self._heartbeat,), daemon=True)
        self.thread.start()
        return self

    def __exit__(self, *_):
        self.stop.set()
        if self.thread:
            self.thread.join(timeout=1)
        self.stages.close(self.finished)

    def _item_values(self, stage: str) -> dict:
        item = self.iterations.get(stage) or {}
        if not item.get("active"):
            return {}
        return {
            "unit_type": item.get("unit_type", "条目"),
            "item_index": item.get("item_index"),
            "item_total": item.get("item_total"),
            "item_id": item.get("item_id", ""),
            "item_title": item.get("item_title", ""),
        }

    def _heartbeat(self):
        while not self.stop.wait(self.interval):
            stage = self.last_stage
            values = self._item_values(stage)
            with log_scope(stage=stage, substep=self.last_substep, **values):
                action_elapsed = max(0.0, time.monotonic() - self.action_started)
                LOG.info("处理中｜当前动作已等待=%.0f秒｜批次已运行=%.0f秒",
                         action_elapsed, time.monotonic() - self.started)
                emit_progress(
                    "heartbeat",
                    stage=stage,
                    status="running",
                    action=self.last_substep or self.last_event,
                    elapsed_sec=round(action_elapsed, 3),
                )

    def _duplicate(self, kind: str, data: dict) -> bool:
        execution = data.get("id") or data.get("node_execution_id")
        if not execution or kind == "node_retry":
            # Without an execution identity, identical events may be different iterations.
            return False
        key = (kind, str(execution), str(data.get("node_id")),
               str(data.get("index")), str(data.get("status")))
        if key in self.seen:
            return True
        self.seen.add(key)
        return False

    def _iteration_start(self, node: str, data: dict) -> None:
        stage, unit_type, catalog_key = ITERATION_NODES[node]
        total = data.get("iterator_length")
        if type(total) is not int:
            total = len(self.item_catalog.get(catalog_key, [])) or self.stages.counts.get(stage)
        self.iterations[stage] = {
            "active": False,
            "unit_type": unit_type,
            "item_index": None,
            "item_total": total if type(total) is int else None,
        }

    def _iteration_next(self, node: str, data: dict) -> None:
        stage, unit_type, catalog_key = ITERATION_NODES[node]
        state = self.iterations.setdefault(stage, {"unit_type": unit_type})
        raw_index = data.get("index")
        item_index = raw_index + 1 if type(raw_index) is int else None
        total = data.get("iterator_length")
        if type(total) is not int:
            total = state.get("item_total") or len(self.item_catalog.get(catalog_key, [])) or self.stages.counts.get(stage)
        state.update(
            active=True,
            unit_type=unit_type,
            item_index=item_index,
            item_total=total if type(total) is int else None,
            started=time.monotonic(),
            item_id="",
            item_title="",
        )
        if type(item_index) is int:
            catalog = self.item_catalog.get(catalog_key, [])
            if item_index <= len(catalog):
                state.update(catalog[item_index - 1])
        values = self._item_values(stage)
        with log_scope(stage=stage, substep="", **values):
            title = state.get("item_title")
            LOG.info("开始%s", "｜标题=" + title if title else "")
            emit_progress("item_started", stage=stage, status="running")

    def _finish_item(self, stage: str, status: str) -> None:
        state = self.iterations.get(stage)
        if not state or not state.get("active"):
            return
        values = self._item_values(stage)
        elapsed = time.monotonic() - state["started"] if state.get("started") else None
        with log_scope(stage=stage, substep="", **values):
            log = LOG.warning if status in {"failed", "exception"} else LOG.info
            suffix = f"｜耗时={elapsed:.1f}s" if elapsed is not None else ""
            log("完成｜状态=%s%s", status, suffix)
            emit_progress(
                "item_finished",
                stage=stage,
                status=status,
                elapsed_sec=round(elapsed, 3) if elapsed is not None else None,
            )
        state["active"] = False

    def event(self, event: dict) -> None:
        kind, data = event.get("event"), event.get("data") or {}
        if not isinstance(data, dict):
            return
        if kind == "workflow_started":
            self.last_event = "工作流已开始"
            emit_progress("remote_started", status="running")
            return
        if kind == "workflow_finished":
            self.last_event = "工作流已返回"
            self.finished = True
            self.stages.close(True)
            emit_progress("remote_finished", status=one_line(data.get("status") or "unknown", 40))
            return
        supported = {
            "node_started", "node_finished", "node_retry",
            "iteration_started", "iteration_next", "iteration_completed",
        }
        if kind not in supported or self._duplicate(kind, data):
            return
        node = one_line(data.get("node_id") or "?", 80)
        stage = NODE_STAGES.get(node, "unknown")
        title = one_line(data.get("title") or data.get("node_type") or "未命名节点", 160)
        status = one_line(data.get("status") or "未知", 60)
        bad = bool(data.get("error")) or status in {"failed", "exception"}
        substep = SUBSTEPS.get(node, "")
        self.last_stage = stage
        self.last_substep = substep or title
        if kind in {"node_started", "iteration_next"}:
            self.action_started = time.monotonic()

        if node in ITERATION_NODES and kind == "iteration_started":
            self._iteration_start(node, data)
        if node in ITERATION_NODES and kind == "iteration_next":
            self._iteration_next(node, data)

        item_values = self._item_values(stage)
        with log_scope(stage=stage, substep=substep, **item_values):
            if stage == "unknown":
                if node not in self.unknown_nodes:
                    self.unknown_nodes.add(node)
                    LOG.warning("未映射节点｜编号=%s｜%s；保留原始执行信息", node, title)
            else:
                length = data.get("iterator_length")
                if node in ITERATION_NODES and type(length) is int and length == 0:
                    self.stages.skip(stage)
                self.stages.start(stage, has_start=kind in {"node_started", "iteration_started"})
                if bad or kind == "node_retry":
                    self.stages.anomaly(stage)
                if node == "4130":
                    self.stages.note(stage, "singleton", "采用确定性单篇分组｜该分支不调用归并模型")

            suffix = "｜错误=" + one_line(data["error"]) if data.get("error") else ""
            if data.get("source_article_id") is not None:
                suffix += "｜原文=" + one_line(data["source_article_id"], 80)
            if data.get("index") is not None:
                suffix += "｜index=" + one_line(data["index"], 40)
            self.last_event = f"{kind} {node} {title} {status}"
            log = LOG.warning if bad or kind == "node_retry" else LOG.debug
            if kind == "node_started":
                LOG.debug("节点开始｜编号=%s｜%s%s", node, title, suffix)
            elif kind in {"node_finished", "node_retry"}:
                log("节点返回｜编号=%s｜%s｜状态=%s｜耗时=%s 秒%s", node, title,
                    "retry" if kind == "node_retry" else status,
                    one_line(data.get("elapsed_time", "未知"), 30), suffix)
            else:
                log("遍历事件｜编号=%s｜%s｜事件=%s｜index=%s｜状态=%s%s", node, title,
                    kind, one_line(data.get("index", "未知"), 30), status, suffix)

        if kind == "node_finished" and ITEM_TERMINAL_NODES.get(stage) == node:
            self._finish_item(stage, status)
        if node in ITERATION_NODES and kind == "iteration_completed":
            self._finish_item(stage, status)
        if node in TERMINAL_NODES and kind in {"node_finished", "iteration_completed"}:
            self.stages.finish(stage, status)


def report_result_errors(errors: list) -> None:
    """Show preserved business/tool failures even when the outer workflow succeeded."""
    causes = Counter()
    for error in errors:
        if not isinstance(error, dict):
            error = {"message": str(error)}
        key = tuple(
            one_line(error.get(k) or "", 800)
            for k in ("node_id", "stage", "code", "error_type", "message")
        )
        causes[key] += 1
        LOG.debug(
            "处理错误定位｜节点=%s｜原文=%s｜条目=%s｜事件=%s",
            key[0] or "未知",
            one_line(error.get("source_article_id") or ""),
            one_line(error.get("item_id") or ""),
            one_line(error.get("event_id") or ""),
            extra={"stage": error_stage(key[0], key[1]), "substep": "结果校验"},
        )
    for (node, stage, code, error_type, message), count in causes.items():
        LOG.warning(
            "处理错误｜节点=%s｜阶段=%s｜代码=%s｜类型=%s｜记录数=%d｜%s",
            node or "未知", stage, code, error_type, count, message,
            extra={"stage": error_stage(node, stage), "substep": "结果校验"},
        )


def report_business_results(bundle: dict) -> None:
    """Emit validated business outcomes at S 6/6 without jumping back to old stages."""
    rows = bundle.get("processing_items") or []

    def stats_for(kinds):
        selected = [r for r in rows if r["item_kind"] in kinds and r["item_key"] != "input_error"]
        decisions = Counter(
            r["decision"] for r in selected
            if r["item_kind"] != "digest_parent" and r["process_status"] == "SUCCESS"
        )
        sources = {r["source_article_id"] for r in selected}
        failed = {r["source_article_id"] for r in selected if r["process_status"] == "FAILED"}
        return len(sources), len(failed), decisions

    digest_sources, digest_failed, digest_decisions = stats_for({"digest_parent", "digest_child"})
    normal_sources, normal_failed, normal_decisions = stats_for({"normal"})
    with log_scope(stage="store", substep="业务校验"):
        LOG.info(
            "文章结果｜普通=%s(失败%s) KEEP=%s/DROP=%s/UNCERTAIN=%s｜快讯=%s(失败%s) KEEP=%s/DROP=%s/UNCERTAIN=%s",
            normal_sources, normal_failed, *(normal_decisions[k] for k in ("KEEP", "DROP", "UNCERTAIN")),
            digest_sources, digest_failed, *(digest_decisions[k] for k in ("KEEP", "DROP", "UNCERTAIN")),
        )
        stats = bundle.get("stats") or {}
        LOG.info(
            "归并与候选｜事件事实=%s｜事件分组=%s｜候选=%s｜处理记录=%s",
            stats.get("normal_incident_count", 0), stats.get("event_group_count", 0),
            len(bundle.get("candidates") or []), len(rows),
        )
        emit_progress(
            "business_result",
            stage="store",
            normal_article_count=normal_sources,
            normal_failed_count=normal_failed,
            normal_keep=normal_decisions["KEEP"],
            normal_drop=normal_decisions["DROP"],
            normal_uncertain=normal_decisions["UNCERTAIN"],
            digest_article_count=digest_sources,
            digest_failed_count=digest_failed,
            candidate_count=len(bundle.get("candidates") or []),
            processing_item_count=len(rows),
            event_fact_count=stats.get("normal_incident_count", 0),
            event_group_count=stats.get("event_group_count", 0),
        )
