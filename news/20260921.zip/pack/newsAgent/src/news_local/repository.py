"""Short SQLite transactions. The collector and Dify are not dependencies here."""

import json
import re
import sqlite3
from collections import defaultdict
from contextlib import contextmanager
from pathlib import Path

from .contracts import FIELDS, JSON_FIELDS, REVIEW_FIELDS
from .errors import ConflictError, NewsError
from .review import REVIEWER_ID, REVIEW_STATUSES, review_changes
from .timeutils import now_text

FEEDBACK_TARGETS = {
    "candidate": ("candidates", "candidate_record_id"),
    "processing_item": ("processing_items", "item_id"),
}
MAX_FEEDBACK_CHARS = 5000


def decode_row(row) -> dict:
    result = dict(row)
    for key in JSON_FIELDS & result.keys():
        if result[key] is not None:
            result[key] = json.loads(result[key])
    return result


def encode_value(key: str, value):
    if key in JSON_FIELDS and value is not None:
        return json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
        )
    return value


class Repository:
    def __init__(self, path: Path):
        self.path = path.resolve()

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA busy_timeout=15000")
        try:
            yield db
        except sqlite3.Error as exc:
            raise NewsError("SQLite 操作失败：" + str(exc)) from exc
        finally:
            db.close()

    def initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            for table, fields in FIELDS.items():
                self._validate_table_contract(db, table, fields)
            feedback_fields = {
                row["name"] for row in db.execute("PRAGMA table_info(feedback)")
            }
            expected_feedback = {"feedback_id", "target_type", "target_id", "content", "created_at"}
            if feedback_fields and feedback_fields != expected_feedback:
                raise NewsError("feedback 已存在但字段不兼容；必须保持最小五字段契约")
            self._migrate_review_constraint(db)
            schema = Path(__file__).with_name("schema.sql").read_text(encoding="utf-8")
            db.executescript("BEGIN IMMEDIATE;\n" + schema + "\nCOMMIT;")


    @staticmethod
    def _validate_table_contract(db, table: str, fields: tuple[str, ...]) -> None:
        """Allow non-owning components to append safe columns to shared result tables.

        This process only owns the columns in ``FIELDS``.  Extra columns are
        compatible when inserts can omit them (nullable or with a DEFAULT).
        Required columns must still exist with the expected SQLite affinity.
        """
        rows = list(db.execute(f"PRAGMA table_info({table})"))
        if not rows:
            return
        definitions = {row["name"]: row for row in rows}
        required = set(fields)
        missing = sorted(required - set(definitions))
        if missing:
            raise NewsError(
                table + " 缺少处理程序必需字段：" + ", ".join(missing) + "；请先迁移结果库"
            )

        integer_fields = {
            "source_article_id",
            "relevance",
            "impact",
            "freshness",
            "evidence_quality",
            "audience_value",
            "total_score",
        }
        wrong_types = []
        for key in fields:
            actual = (definitions[key]["type"] or "").upper()
            expected = "INTEGER" if key in integer_fields else "TEXT"
            if actual != expected:
                wrong_types.append(f"{key}={actual or '<empty>'}(期望 {expected})")
        if wrong_types:
            raise NewsError(
                table + " 字段类型与当前 SQLite 契约不兼容：" + ", ".join(wrong_types)
            )

        blocking_extras = []
        for key in sorted(set(definitions) - required):
            row = definitions[key]
            if row["notnull"] and row["dflt_value"] is None and not row["pk"]:
                blocking_extras.append(key)
        if blocking_extras:
            raise NewsError(
                table
                + " 存在处理程序无法省略的扩展字段（NOT NULL 且无 DEFAULT）："
                + ", ".join(blocking_extras)
            )

    @staticmethod
    def _migrate_review_constraint(db) -> None:
        """Safely replace the legacy review CHECK when no ambiguous old state exists."""
        row = db.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='candidates'"
        ).fetchone()
        if not row or not row[0]:
            return
        sql = row[0]
        if "'accepted'" not in sql and "'rejected'" not in sql and "'deferred'" not in sql:
            return
        counts = {
            status: count
            for status, count in db.execute(
                "SELECT review_status,count(*) FROM candidates "
                "WHERE review_status NOT IN ('pending','starred','ignored') GROUP BY review_status"
            )
        }
        if counts:
            details = ", ".join(f"{key}={value}" for key, value in sorted(counts.items()))
            raise NewsError(
                "检测到旧人工审核状态，不能自动猜测三态映射："
                + details
                + "；请显式迁移为 pending/starred/ignored 后重试"
            )

        create_new = re.sub(
            r"^CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?candidates\s*\(",
            "CREATE TABLE candidates_review_migration (",
            sql,
            count=1,
            flags=re.I,
        )
        create_new, changed = re.subn(
            r"(review_status\s+TEXT\s+NOT\s+NULL\s+CHECK\s*\(\s*review_status\s+IN\s*\()"
            r"\s*'pending'\s*,\s*'accepted'\s*,\s*'rejected'\s*,\s*'deferred'\s*"
            r"(\)\s*\))",
            r"\1'pending','starred','ignored'\2",
            create_new,
            count=1,
            flags=re.I,
        )
        if changed != 1 or "candidates_review_migration" not in create_new:
            raise NewsError("无法安全改写 candidates 的旧审核状态约束")

        columns = [row["name"] for row in db.execute("PRAGMA table_info(candidates)")]
        preserved_objects = [
            row["sql"]
            for row in db.execute(
                "SELECT sql FROM sqlite_master "
                "WHERE tbl_name='candidates' AND type IN ('index','trigger') "
                "AND sql IS NOT NULL ORDER BY type,name"
            )
        ]
        db.execute("PRAGMA foreign_keys=OFF")
        try:
            db.execute("BEGIN IMMEDIATE")
            db.execute("DROP TABLE IF EXISTS candidates_review_migration")
            db.execute(create_new)
            names = ",".join(f'"{name}"' for name in columns)
            db.execute(
                f"INSERT INTO candidates_review_migration ({names}) SELECT {names} FROM candidates"
            )
            db.execute("DROP TABLE candidates")
            db.execute("ALTER TABLE candidates_review_migration RENAME TO candidates")
            for object_sql in preserved_objects:
                db.execute(object_sql)
            violations = db.execute("PRAGMA foreign_key_check").fetchall()
            if violations:
                raise NewsError("候选审核三态迁移后外键检查失败")
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.execute("PRAGMA foreign_keys=ON")

    def processed_inputs(self) -> set[tuple[int, str]]:
        """Inputs with a durably committed business terminal record.

        ``processing_items`` is written transactionally, so SUCCESS and FAILED
        are both terminal business outcomes.  Infrastructure failures never
        create these rows and therefore remain eligible for recovery/retry.
        """
        if not self.path.exists():
            return set()
        with self.connect() as db:
            exists = db.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='processing_items'"
            ).fetchone()
            if not exists:
                return set()
            groups = defaultdict(list)
            for row in db.execute(
                "SELECT source_article_id,input_hash,run_id,item_kind,item_key,process_status "
                "FROM processing_items WHERE input_hash IS NOT NULL"
            ):
                groups[(row["source_article_id"], row["input_hash"], row["run_id"])].append(row)
        processed = set()
        for (sid, fingerprint, _), rows in groups.items():
            # A committed normal/input_error row is terminal. For digests, a
            # FAILED parent is itself a terminal business result; a SUCCESS
            # parent must still have at least one child so a damaged/incomplete
            # database cannot accidentally suppress reprocessing.
            if any(r["item_kind"] == "normal" for r in rows):
                processed.add((int(sid), fingerprint))
                continue
            parents = [r for r in rows if r["item_kind"] == "digest_parent"]
            children = [r for r in rows if r["item_kind"] == "digest_child"]
            if any(r["process_status"] == "FAILED" for r in parents) or (parents and children):
                processed.add((int(sid), fingerprint))
        return processed

    # Compatibility for callers outside this package. New scheduling uses
    # processed_inputs because business FAILED is intentionally terminal.
    def completed_inputs(self) -> set[tuple[int, str]]:
        return self.processed_inputs()

    def ingest(self, bundle: dict) -> dict:
        counts = {"processing_items_inserted": 0, "candidates_inserted": 0, "duplicates_skipped": 0}
        timestamp = now_text()
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                for table in FIELDS:
                    for original in bundle[table]:
                        row = dict(original, created_at=timestamp)
                        if table == "candidates":
                            row["updated_at"] = timestamp
                        if self._insert(db, table, row):
                            counts[table + "_inserted"] += 1
                        else:
                            counts["duplicates_skipped"] += 1
                db.commit()
            except BaseException:
                db.rollback()
                raise
        return dict(counts, status="SUCCESS", committed_at=timestamp)

    @staticmethod
    def _insert(db, table: str, row: dict) -> bool:
        columns = FIELDS[table]
        primary = "item_id" if table == "processing_items" else "candidate_record_id"
        existing = db.execute(
            f"SELECT * FROM {table} WHERE {primary}=?", (row[primary],)
        ).fetchone()
        if existing:
            previous = decode_row(existing)
            ignored = {"created_at", "updated_at"} | (
                REVIEW_FIELDS if table == "candidates" else set()
            )
            if any(previous[key] != row[key] for key in columns if key not in ignored):
                raise ConflictError("同一记录 ID 的业务内容发生冲突：" + row[primary])
            return False
        placeholders = ",".join("?" for _ in columns)
        db.execute(
            f"INSERT INTO {table} ({','.join(columns)}) VALUES ({placeholders})",
            [encode_value(key, row[key]) for key in columns],
        )
        return True

    def candidates(
        self, run_id: str = "", status: str = "", offset: int = 0, limit: int = 50
    ) -> dict:
        if status and status not in REVIEW_STATUSES:
            raise NewsError("审核状态无效")
        self._page(offset, limit)
        clauses, parameters = [], []
        for column, value in (("run_id", run_id), ("review_status", status)):
            if value:
                clauses.append(column + "=?")
                parameters.append(value)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        with self.connect() as db:
            total = db.execute("SELECT count(*) FROM candidates" + where, parameters).fetchone()[0]
            rows = db.execute(
                "SELECT * FROM candidates"
                + where
                + " ORDER BY created_at DESC,total_score DESC,candidate_record_id LIMIT ? OFFSET ?",
                parameters + [limit, offset],
            ).fetchall()
        return {"total": total, "items": [decode_row(r) for r in rows]}

    def candidate_detail(self, candidate_id: str) -> dict | None:
        with self.connect() as db:
            row = db.execute(
                "SELECT * FROM candidates WHERE candidate_record_id=?", (candidate_id,)
            ).fetchone()
            if row is None:
                return None
            items = db.execute(
                "SELECT * FROM processing_items WHERE candidate_record_id=? ORDER BY item_id",
                (candidate_id,),
            ).fetchall()
        return dict(candidate=decode_row(row), sources=[decode_row(r) for r in items])

    def processing(self, run_id: str, offset: int = 0, limit: int = 50) -> dict:
        self._page(offset, limit)
        with self.connect() as db:
            total = db.execute(
                "SELECT count(*) FROM processing_items WHERE run_id=?", (run_id,)
            ).fetchone()[0]
            rows = db.execute(
                "SELECT * FROM processing_items WHERE run_id=? ORDER BY source_article_id,item_key "
                "LIMIT ? OFFSET ?",
                (run_id, limit, offset),
            ).fetchall()
        return {"total": total, "items": [decode_row(row) for row in rows]}

    def review(self, candidate_id: str, review_status: str, expected_updated_at: str) -> dict:
        status, expected_updated_at = review_changes(
            {"review_status": review_status, "expected_updated_at": expected_updated_at}
        )
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                row = db.execute(
                    "SELECT * FROM candidates WHERE candidate_record_id=?", (candidate_id,)
                ).fetchone()
                if row is None:
                    raise NewsError("候选不存在")
                current = decode_row(row)
                # Same-target retries are side-effect free, even with a stale version.
                if current["review_status"] == status:
                    db.commit()
                    return current
                if current["updated_at"] != expected_updated_at:
                    raise ConflictError("候选已被修改，请刷新后重新提交")
                timestamp = now_text()
                db.execute(
                    "UPDATE candidates SET review_status=?,reviewer_id=?,reviewed_at=?,updated_at=? "
                    "WHERE candidate_record_id=?",
                    (status, REVIEWER_ID, timestamp, timestamp, candidate_id),
                )
                db.commit()
            except BaseException:
                db.rollback()
                raise
        return self.candidate_detail(candidate_id)["candidate"]

    def create_feedback(
        self, feedback_id: str, target_type: str, target_id: str, content: str
    ) -> dict:
        feedback_id = self._nonempty_text(feedback_id, "feedback_id")
        target_id = self._nonempty_text(target_id, "target_id")
        if target_type not in FEEDBACK_TARGETS:
            raise NewsError("反馈 target_type 无效")
        if not isinstance(content, str):
            raise NewsError("反馈 content 必须为文本")
        content = content.strip()
        if not content:
            raise NewsError("反馈 content 不能为空")
        if len(content) > MAX_FEEDBACK_CHARS:
            raise NewsError("反馈 content 不能超过 5000 字符")

        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                existing = db.execute(
                    "SELECT * FROM feedback WHERE feedback_id=?", (feedback_id,)
                ).fetchone()
                if existing is not None:
                    saved = dict(existing)
                    if (
                        saved["target_type"] == target_type
                        and saved["target_id"] == target_id
                        and saved["content"] == content
                    ):
                        db.commit()
                        return saved
                    raise ConflictError("feedback_id 已用于不同反馈内容")

                table, primary = FEEDBACK_TARGETS[target_type]
                target = db.execute(
                    f"SELECT 1 FROM {table} WHERE {primary}=?", (target_id,)
                ).fetchone()
                if target is None:
                    raise NewsError("反馈目标不存在")
                created_at = now_text()
                db.execute(
                    "INSERT INTO feedback(feedback_id,target_type,target_id,content,created_at) "
                    "VALUES(?,?,?,?,?)",
                    (feedback_id, target_type, target_id, content, created_at),
                )
                db.commit()
            except BaseException:
                db.rollback()
                raise
        return {
            "feedback_id": feedback_id,
            "target_type": target_type,
            "target_id": target_id,
            "content": content,
            "created_at": created_at,
        }

    def feedback(
        self,
        *,
        target_type: str = "",
        target_id: str = "",
        offset: int = 0,
        limit: int = 50,
    ) -> dict:
        self._page(offset, limit)
        if target_type and target_type not in FEEDBACK_TARGETS:
            raise NewsError("反馈 target_type 无效")
        if target_id and not target_type:
            raise NewsError("按 target_id 查询时必须提供 target_type")
        clauses, parameters = [], []
        if target_type:
            clauses.append("target_type=?")
            parameters.append(target_type)
        if target_id:
            clauses.append("target_id=?")
            parameters.append(target_id)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        with self.connect() as db:
            total = db.execute("SELECT count(*) FROM feedback" + where, parameters).fetchone()[0]
            rows = db.execute(
                "SELECT * FROM feedback"
                + where
                + " ORDER BY created_at DESC,feedback_id DESC LIMIT ? OFFSET ?",
                parameters + [limit, offset],
            ).fetchall()
        return {"total": total, "items": [dict(row) for row in rows]}

    def feedback_for_target(
        self, target_type: str, target_id: str, offset: int = 0, limit: int = 50
    ) -> dict:
        return self.feedback(
            target_type=target_type, target_id=target_id, offset=offset, limit=limit
        )

    @staticmethod
    def _nonempty_text(value, field: str) -> str:
        if not isinstance(value, str) or not value.strip():
            raise NewsError(field + " 必须为非空字符串")
        return value.strip()

    @staticmethod
    def _page(offset: int, limit: int) -> None:
        if type(offset) is not int or offset < 0:
            raise NewsError("offset 必须为非负整数")
        if type(limit) is not int or not 1 <= limit <= 100:
            raise NewsError("limit 必须为 1–100")
