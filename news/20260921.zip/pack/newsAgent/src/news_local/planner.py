"""Fixed query scopes and newest-first batch selection; no execution side effects."""

import logging
from dataclasses import dataclass

from .article_contract import parse_digest_keywords
from .config import Settings
from .errors import ContractError
from .normalize import Article, prepare_article, source_fingerprint
from .ports import CollectorPort, ResultPort
from .timeutils import now_text, parse_time

LOG = logging.getLogger(__name__)


@dataclass
class Plan:
    articles: list[Article]
    rejected: list[dict]
    query: dict

    def to_dict(self) -> dict:
        return {
            "articles": [a.to_dict() for a in self.articles],
            "rejected": self.rejected,
            "query": self.query,
        }


def capture_scope(collector: CollectorPort, settings: Settings) -> dict:
    """Freeze identities/order, not article bodies or a long-lived SQLite transaction."""
    cutoff = now_text()
    until = parse_time(settings.published_to or cutoff)
    since = parse_time(settings.published_from) if settings.published_from else None
    metadata, invalid = [], []
    for row in collector.metadata():
        if settings.accounts and row["account"] not in settings.accounts:
            continue
        sid = row["article_id"]
        try:
            published = parse_time(row["published_at"])
            fetched = parse_time(row["fetched_at"])
            if published > until or (since and published < since) or fetched > parse_time(cutoff):
                continue
        except (ValueError, TypeError, AttributeError) as exc:
            LOG.warning("原文时间无效｜source_article_id=%s｜%s", sid, exc)
            raw = collector.get(sid)
            invalid.append({"source_article_id": sid, "error": {
                "source_article_id": sid, "code": "invalid_time",
                "message": str(exc), "title": row["title"],
                "input_hash": source_fingerprint(raw or row, sid),
                "input_meta_json": {"hash_basis": "raw_collector_record_v1"},
            }})
            continue
        metadata.append((published, sid))
    metadata.sort(reverse=True)
    LOG.info("固定查询范围｜%s 至 %s｜范围内=%s｜时间异常=%s", since or "不限起点",
             until.isoformat(), len(metadata), len(invalid))
    return {
        "cutoff": cutoff, "published_from": settings.published_from or None,
        "published_to": until.isoformat(), "accounts": list(settings.accounts),
        "order": "published_at DESC, article_id DESC",
        "scope_article_count": len(metadata), "invalid_time_count": len(invalid),
        "scope_record_count": len(metadata) + len(invalid),
        # Invalid times cannot be attributed to the requested date interval.
        "entries": invalid + [{"source_article_id": sid} for _, sid in metadata],
    }


def select_from_scope(
    collector: CollectorPort, repository: ResultPort, settings: Settings,
    scope: dict, cursor: int = 0, force: bool = False,
) -> tuple[Plan, int]:
    """Return a proposed checkpoint. The caller advances it only after commit."""
    keywords = parse_digest_keywords(settings.digest_keywords)
    processed = repository.processed_inputs()
    until, cutoff = parse_time(scope["published_to"]), parse_time(scope["cutoff"])
    since = parse_time(scope["published_from"]) if scope["published_from"] else None
    entries = scope["entries"]
    start = cursor
    articles, rejected, deferred = [], [], []
    excluded = examined = 0
    while cursor < len(entries) and len(articles) < settings.batch_size:
        entry = entries[cursor]
        cursor += 1
        sid = entry["source_article_id"]
        if "error" in entry:
            error = entry["error"]
            fingerprint = error.get("input_hash")
            if not force and fingerprint and (sid, fingerprint) in processed:
                excluded += 1
                LOG.debug("跳过已处理输入异常｜source_article_id=%s", sid)
                continue
            rejected.append(error)
            continue
        examined += 1
        row = collector.get(sid)
        try:
            if row is None:
                raise ValueError("选取期间原文已删除")
            article = prepare_article(row, settings.max_content_chars, keywords)
        except (ValueError, TypeError, KeyError, ContractError) as exc:
            LOG.warning("原文质量检查失败｜source_article_id=%s｜%s", sid, exc)
            fingerprint = source_fingerprint(row, sid)
            if not force and (sid, fingerprint) in processed:
                excluded += 1
                LOG.debug("跳过已处理输入异常｜source_article_id=%s", sid)
                continue
            rejected.append({
                "source_article_id": sid, "code": "invalid_input",
                "message": str(exc), "title": row.get("title", "") if row else "",
                "input_hash": fingerprint,
                "input_meta_json": {"hash_basis": "raw_collector_record_v1"},
            })
            continue
        published = parse_time(article.payload["published_at"])
        if (parse_time(article.fetched_at) > cutoff or published > until
                or (since and published < since)
                or (scope["accounts"] and article.payload["account"] not in scope["accounts"])):
            deferred.append({"source_article_id": sid, "reason": "source_changed_outside_scope"})
            continue
        if not force and (sid, article.input_hash) in processed:
            excluded += 1
            LOG.debug("跳过已处理原文｜source_article_id=%s", sid)
            continue
        articles.append(article)
        LOG.debug("选入 %s/%s｜source_article_id=%s｜%s｜%s", len(articles),
                  settings.batch_size, sid, "快讯" if article.digest else "普通资讯",
                  article.payload["title"])
    LOG.info("选取完成｜扫描=%s｜排除已处理=%s｜选中=%s｜输入异常=%s｜推迟=%s",
             cursor - start, excluded, len(articles), len(rejected), len(deferred))
    query = {k: v for k, v in scope.items() if k != "entries"}
    query.update(
        limit=settings.batch_size, examined_article_count=examined,
        scanned_record_count=cursor - start, excluded_processed_count=excluded,
        # Compatibility alias retained for existing reports/legacy session summaries.
        excluded_completed_count=excluded,
        selected_count=len(articles), unexamined_count=len(entries) - cursor, force=force,
        deferred_articles=deferred,
        selected_published_from=min((a.payload["published_at"] for a in articles), default=None),
        selected_published_to=max((a.payload["published_at"] for a in articles), default=None),
    )
    return Plan(articles, rejected, query), cursor


def select_batch(
    collector: CollectorPort, repository: ResultPort, settings: Settings, force: bool = False,
) -> Plan:
    scope = capture_scope(collector, settings)
    return select_from_scope(collector, repository, settings, scope, force=force)[0]
