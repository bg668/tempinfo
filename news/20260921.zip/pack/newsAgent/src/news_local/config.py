"""Parse configuration once at the application boundary."""

import logging
import os
import tomllib
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from .article_contract import parse_digest_keywords
from .errors import NewsError


@dataclass(frozen=True)
class Settings:
    source_db: Path
    result_db: Path
    state_dir: Path
    api_base: str = "http://127.0.0.1/v1"
    api_key: str = ""
    batch_size: int = 25
    max_content_chars: int = 50000
    max_input_chars: int = 4000000
    grouping_mode: str = "event_match"
    digest_keywords: str = ",".join(parse_digest_keywords(""))
    accounts: tuple[str, ...] = ()
    published_from: str = ""
    published_to: str = ""
    io_timeout: int = 60
    run_timeout: int = 3600
    max_download_bytes: int = 50 * 1024 * 1024
    file_base_url: str = ""
    log_level: str = "key"

    @classmethod
    def load(cls, path: Path) -> "Settings":
        path = path.resolve()
        with path.open("rb") as handle:
            raw = tomllib.load(handle)
        known = set(cls.__dataclass_fields__) - {"api_key"}
        legacy_web = {"reviewer_id", "host", "port"} & set(raw)
        if legacy_web:
            logging.getLogger(__name__).warning(
                "本版本仅提供命令行，忽略旧网页配置：%s", ", ".join(sorted(legacy_web))
            )
        unknown = set(raw) - known - {"api_key_env"} - legacy_web
        if unknown:
            raise NewsError("未知配置项：" + ", ".join(sorted(unknown)))
        values = {k: v for k, v in raw.items() if k in known}
        for name in ("source_db", "result_db", "state_dir"):
            if name not in values:
                raise NewsError("缺少配置项：" + name)
            values[name] = (path.parent / values[name]).resolve()
        accounts = values.get("accounts", [])
        if not isinstance(accounts, list):
            raise NewsError("accounts 必须为媒体名称字符串列表")
        values["accounts"] = tuple(accounts)
        values["api_key"] = os.getenv(raw.get("api_key_env", "DIFY_API_KEY"), "")
        result = cls(**values)
        result.validate()
        return result

    def validate(self) -> None:
        for name in (
            "batch_size",
            "max_content_chars",
            "max_input_chars",
            "io_timeout",
            "run_timeout",
            "max_download_bytes",
        ):
            if type(getattr(self, name)) is not int:
                raise NewsError(name + " 必须为整数")
        if self.log_level not in {"detailed", "key"}:
            raise NewsError("log_level 必须为 detailed（详细）或 key（关键信息）")
        if not all(isinstance(value, str) for value in self.accounts):
            raise NewsError("accounts 必须为媒体名称字符串列表")
        if not 1 <= self.batch_size <= 50:
            raise NewsError("batch_size 必须为 1–50")
        if not 1000 <= self.max_content_chars <= 100000:
            raise NewsError("max_content_chars 必须为 1000–100000")
        if self.grouping_mode not in {"event_match", "singleton"}:
            raise NewsError("grouping_mode 无效")
        for address in (self.api_base, self.file_base_url):
            if address and urlparse(address).scheme not in {"http", "https"}:
                raise NewsError("Dify 地址必须为 HTTP(S)")
        if (
            min(self.io_timeout, self.run_timeout, self.max_download_bytes, self.max_input_chars)
            <= 0
        ):
            raise NewsError("容量和超时配置必须大于零")
