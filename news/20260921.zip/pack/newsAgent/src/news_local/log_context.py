"""Scoped log metadata, independent of database, transport and workflow execution."""

import logging
import time
from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps

CONTEXT = ContextVar("news_log_context", default=None)


def current_context() -> dict:
    return dict(CONTEXT.get() or {})


@contextmanager
def log_scope(**values):
    token = CONTEXT.set(dict(current_context(), **values))
    try:
        yield
    finally:
        CONTEXT.reset(token)


class ContextFilter(logging.Filter):
    def filter(self, record):
        for key, value in current_context().items():
            if not hasattr(record, key):
                setattr(record, key, value)
        return True


def local_stage(stage: str):
    """Label/timestamp a local operation; nested operations in the same stage stay quiet."""
    def decorate(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            if current_context().get("stage") == stage:
                return function(*args, **kwargs)
            logger = logging.getLogger("news_local.progress")
            started = time.monotonic()
            with log_scope(stage=stage, substep=""):
                logger.info("开始｜本地操作")
                from .progress_events import emit_progress
                emit_progress("stage_started", stage=stage, status="running", local=True)
                try:
                    result = function(*args, **kwargs)
                except BaseException:
                    elapsed = time.monotonic() - started
                    logger.warning("未完成｜耗时=%.2fs", elapsed)
                    emit_progress("stage_finished", stage=stage, status="failed", elapsed_sec=round(elapsed, 3), local=True)
                    raise
                elapsed = time.monotonic() - started
                logger.info("完成｜耗时=%.2fs", elapsed)
                emit_progress("stage_finished", stage=stage, status="succeeded", elapsed_sec=round(elapsed, 3), local=True)
                return result
        return wrapped
    return decorate
