"""Business-stage vocabulary for the deployed single workflow; no runtime YAML dependency."""

# Internal execution branches remain distinct, while digest/normal share one user-facing stage.
STAGE_ORDER = ("prepare", "digest", "normal", "match", "candidate", "export", "store")
STAGE_TOTAL = 6
STAGE_NUMBERS = {
    "prepare": 1,
    "digest": 2,
    "normal": 2,
    "match": 3,
    "candidate": 4,
    "export": 5,
    "store": 6,
}

STAGES = {
    "prepare": "批次准备与文章分流",
    "digest": "资讯处理-快讯拆分与研判",
    "normal": "资讯处理-普通资讯筛选与抽取",
    "match": "处理结果汇总与事件归并",
    "candidate": "安全事件候选生成",
    "export": "两表整理与文件导出",
    "store": "本地校验与入库",
}

# Explicit IDs prevent an edited node title from silently changing its business stage.
STAGE_NODES = {
    "prepare": ("1000", "1100"),
    "digest": ("2000", "2000start", "2050", "2110", "2120"),
    "normal": (
        "3000", "3000start", "3050", "3110", "3120", "3130",
        "3140", "3150", "3160", "3170", "3180", "3190",
    ),
    "match": ("4000", "4050", "4070", "4100", "4120", "4130", "4150", "4200"),
    "candidate": ("5000", "5000start", "5050", "5110", "5120"),
    "export": ("6000", "6050", "6060", "6100", "6200", "6500", "7000"),
}
NODE_STAGES = {node: stage for stage, nodes in STAGE_NODES.items() for node in nodes}
TERMINAL_NODES = {
    "1100": "prepare", "2000": "digest", "3000": "normal",
    "4200": "match", "5000": "candidate", "7000": "export",
}

# A serial iteration item is complete when this child node finishes.
ITEM_TERMINAL_NODES = {
    "digest": "2120",
    "normal": "3190",
    "candidate": "5120",
}
ITERATION_NODES = {
    "2000": ("digest", "快讯", "digest"),
    "3000": ("normal", "文章", "normal"),
    "5000": ("candidate", "事件组", "candidate"),
}

SUBSTEPS = {
    "2050": "文章准备", "2110": "拆分研判", "2120": "结果校验",
    "3050": "文章准备", "3110": "价值筛选", "3120": "筛选校验", "3130": "结果路由",
    "3140": "事件事实抽取", "3150": "事件事实校验",
    "3160": "政策事实抽取", "3170": "政策事实校验",
    "3180": "丢弃或待确认", "3190": "单篇结果汇总",
    "4000": "文章结果汇总", "4100": "模型归并", "4120": "覆盖校验与修复",
    "4130": "确定性分组", "4200": "分组校验",
    "5110": "候选文案生成", "5120": "候选校验",
    "6000": "两表整理", "6060": "JSON导出", "6200": "CSV导出",
}
ERROR_STAGES = {
    "prepare": "prepare", "local_prepare": "prepare",
    "digest": "digest", "normal": "normal", "triage": "normal",
    "incident": "normal", "policy": "normal",
    "event_match": "match", "match": "match", "grouping": "match",
    "candidate": "candidate", "compose": "candidate", "event_candidate": "candidate",
    "finalize": "export", "export": "export", "storage": "store",
}


def error_stage(node: object, stage: object) -> str:
    return NODE_STAGES.get(str(node)) or ERROR_STAGES.get(str(stage), "unknown")
