> 历史多工作流版本记录；当前部署请使用 [单工作流说明](DIFY_SETUP.md)。

# 工具返回与本次故障

附件批次 `run_0364a823ade14bfaaef2a2c78d205891`，25 篇普通资讯、0 篇快讯、0 候选，使用 v1.2 主控。异常统计：

| code | 数量 | 解释 |
|---|---:|---|
| workflow_tool_execution_failed | 25 | 主控 3110 default_value 中的固定占位错误，未记录工具原始异常 |
| unexpected_source_article_id | 25 | 占位 JSON 没有 article.source_article_id |
| missing_child_result | 25 | 汇总未收到对应原文 ID 的合法结果 |
| source_article_id_mismatch | 25 | 逐条建表时再次检查来源 |
| event_match | 1 | 4200 对 None 执行 json.loads；未取到 4100.result_json |

最初附件只能定位到工具调用/结果交接层，未保存原始异常。用户后来补充了 3110 的 `ToolRuntimeResolutionError`，具体为旧 provider `38b85447-5c1d-4001-a62b-38e86d0704be` 不存在；随后提供了包含四个工具的最新临时 DSL。因此此次修复已明确针对过期工具绑定，不修改 LLM 提示词。

官方 Dify 1.17.1 的 [WorkflowTool 实现](https://github.com/langgenius/dify/blob/1.17.1/api/core/tools/workflow_as_tool/tool.py) 会遍历子流程 End 输出创建自定义变量，同时调用 `create_text_message(json.dumps(outputs, ensure_ascii=False))` 返回标准文本。由此可知：不能笼统说 Dify 不支持 result_json；用户看不到自定义变量可能涉及工具输出 schema 或发布版本。

[工具节点 UI 源码](https://github.com/langgenius/dify/blob/1.17.1/web/app/components/workflow/nodes/tool/default.ts) 从当前工具 output_schema 生成自定义变量列表；没有 schema/properties 时显示标准 text/files/json。使用标准 text 可避免主控依赖自定义输出在工具面板中的注册状态，但不修复工具本身执行失败。

[官方错误处理文档](https://docs.dify.ai/zh/cloud/use-dify/build/predefined-error-handling-logic) 说明 default value / fail branch 可提供 error_message 与 error_type。旧 DSL 只写固定结果占位，未消费这两个变量，是本项目的错误记录遗漏。

本次增加 2120、3120、4120、5120 四个适配节点：成功解析两层 JSON；调用失败携带真实错误和源身份；输出缺字段作为契约错误单独记录。主控 4200 改为读取 4120.result_json；三个遍历改为收集适配节点输出。四个子流程与 v1.2 字节一致。

v1.3.1 同步更新四个 provider ID，并将归并工具的实际调用名更新为 `03work`。主控仍通过四个适配节点消费标准 text 输出；绑定修复和结果解包各自处理对应问题。具体映射见 DIFY_SETUP.md。尚未访问用户服务进行运行验证。

已有数据库里的失败记录保留，新批次仍可选取相同未成功原文，不需要清表。新运行是重新处理，不是从已经失败的模型任务恢复。
