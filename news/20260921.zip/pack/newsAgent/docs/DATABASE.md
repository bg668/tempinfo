# SQLite 结果表字段

两张表保持既定业务字段。模型和工作流传输中的 JSON 对象在入库时序列化为 TEXT；未执行提取保存 SQL NULL，不替换为空对象。

source_article_id 在传给 Dify 时为字符串，写入 SQLite 前严格转换为采集库整数 ID。所有日期时间字段存为带 +08:00 的 TEXT。

## processing_items

| 字段 | SQLite 类型 | 说明 |
|---|---|---|
| `item_id` | TEXT | 处理记录主键 |
| `run_id` | TEXT | 本次批次 |
| `source_article_id` | INTEGER | 采集库原文关联ID |
| `candidate_record_id` | TEXT | 本批次候选记录ID |
| `item_kind` | TEXT | 普通/快讯父记录/快讯子项 |
| `item_key` | TEXT | 批次内原文的条目键 |
| `title` | TEXT | AI标题 |
| `summary` | TEXT | AI摘要 |
| `source_heading` | TEXT | 快讯原始小标题 |
| `source_text` | TEXT | 快讯子项原文 |
| `process_status` | TEXT | 整条应执行路径的SUCCESS/FAILED |
| `decision` | TEXT | 有效筛选结论 |
| `route` | TEXT | 业务路由 |
| `category` | TEXT | 细分类别 |
| `content_nature` | TEXT | 内容性质 |
| `relevance` | INTEGER | 相关性0–5 |
| `impact` | INTEGER | 影响程度0–5 |
| `freshness` | INTEGER | 时效性0–5 |
| `evidence_quality` | INTEGER | 证据质量0–5 |
| `audience_value` | INTEGER | 受众价值0–5 |
| `total_score` | INTEGER | 五项评分之和×4 |
| `reason` | TEXT | 判断理由 |
| `facts_json` | TEXT | 完整事实对象；JSON序列化文本 |
| `ioc_json` | TEXT | 六类IOC数组对象；null表示无有效提取结果；JSON序列化文本 |
| `excluded_iocs_json` | TEXT | 排除IOC与依据；JSON序列化文本 |
| `quality_warnings_json` | TEXT | 质量提示；JSON序列化文本 |
| `errors_json` | TEXT | 阶段、代码、说明；JSON序列化文本 |
| `input_hash` | TEXT | 规范化单篇JSON的UTF-8字节SHA-256 |
| `input_meta_json` | TEXT | 规范化正文长度、实际长度、截断和可选原文版本；JSON序列化文本 |
| `processing_version` | TEXT | 交付配置版本 |
| `created_at` | TEXT | 实际入库时间；北京时间 +08:00 |

## candidates

| 字段 | SQLite 类型 | 说明 |
|---|---|---|
| `candidate_record_id` | TEXT | 本批次候选记录ID |
| `candidate_id` | TEXT | 工作流候选标识 |
| `run_id` | TEXT | 本次批次 |
| `candidate_type` | TEXT | 安全事件/合规政策 |
| `primary_item_id` | TEXT | 主要来源记录 |
| `title` | TEXT | AI标题 |
| `summary` | TEXT | AI摘要 |
| `facts_json` | TEXT | 完整事实对象；JSON序列化文本 |
| `relevance` | INTEGER | 相关性0–5 |
| `impact` | INTEGER | 影响程度0–5 |
| `freshness` | INTEGER | 时效性0–5 |
| `evidence_quality` | INTEGER | 证据质量0–5 |
| `audience_value` | INTEGER | 受众价值0–5 |
| `total_score` | INTEGER | 五项评分之和×4 |
| `reason` | TEXT | 判断理由 |
| `score_strategy` | TEXT | 评分来源选择策略 |
| `score_source_item_id` | TEXT | 评分来源记录 |
| `match_reason` | TEXT | 多来源归并理由 |
| `ioc_json` | TEXT | 六类IOC数组对象；null表示无有效提取结果；JSON序列化文本 |
| `excluded_iocs_json` | TEXT | 排除IOC与依据；JSON序列化文本 |
| `quality_warnings_json` | TEXT | 质量提示；JSON序列化文本 |
| `review_status` | TEXT | pending/starred/ignored |
| `review_reason_code` | TEXT | 旧版兼容列；新审核契约不写入 |
| `review_comment` | TEXT | 旧版兼容列；新反馈写入独立 feedback 表 |
| `reviewed_title` | TEXT | 旧版兼容列；新审核契约不写入 |
| `reviewed_summary` | TEXT | 旧版兼容列；新审核契约不写入 |
| `review_corrections_json` | TEXT | 旧版兼容列；新审核契约不写入 |
| `reviewer_id` | TEXT | 新状态变更固定写 root |
| `reviewed_at` | TEXT | 审核提交时间；北京时间 +08:00 |
| `created_at` | TEXT | 实际入库时间；北京时间 +08:00 |
| `updated_at` | TEXT | 最近修改时间；北京时间 +08:00 |


## feedback

独立人工反馈表只保留五个字段，Web 响应层不在本包实现。

| 字段 | 类型 | 说明 |
|---|---|---|
| `feedback_id` | TEXT | 前端首次提交生成的唯一 ID；主键 |
| `target_type` | TEXT | `candidate` / `processing_item` |
| `target_id` | TEXT | `candidate_record_id` 或 `item_id` |
| `content` | TEXT | trim 后非空，最多 5000 字符 |
| `created_at` | TEXT | 服务端生成，UTC+08:00 |

`Repository.create_feedback()` 校验目标真实存在。同一 `feedback_id` + 相同规范化载荷重复提交返回原记录；同一 ID 携带不同载荷抛出冲突。同一目标可以用不同 ID 追加多条反馈。
