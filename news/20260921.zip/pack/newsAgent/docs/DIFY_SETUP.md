# 单工作流导入说明

当前部署入口只有 `dify/00_安全资讯处理_单工作流.yml`，不需要导入 01–04 或绑定四个 Workflow Tool。

## 导入

新建 Workflow，导入 YAML，确认 File Tools 可用。文件仍带有先前的 `langgenius/openai_api_compatible` 模型配置；检查 2110、3110、3140、3160、4100、5110 六个 LLM 节点，在本机名称不同时选择实际模型。API Key 留在 Dify 的模型提供商配置中，不写入 DSL。

所有画布节点采用中文名称。三个遍历容器根据子节点边界和分支间距计算尺寸；普通资讯的事件、政策、DROP/UNCERTAIN 三条分支通过变量聚合器汇合。快讯和普通资讯两路并行分流结果由 Code 汇总。

开始节点输入：articles_json（JSON 数组字符串）、digest_keywords（标题关键词）、grouping_mode（singleton/event_match）、max_content_chars（默认 50000）、run_id（可空，本地程序会传入批次 ID）。文章数组元素是原文对象，不是 source_id/payload 外层包装。

手动测试可将 `dify/examples/articles_25_replay.json` 的完整内容填入 articles_json。先确认 48083 返回 DROP/non_target 且无 ID 校验错误，再确认 48285 拆分、汇总错误与候选文件。在模型正确遵守契约时，实际候选数量由当前模型处理结果决定。

测试完成后发布这个工作流。本地 `.env` 使用它的应用 API Key，保留原 config.toml、SQLite 和 state_dir，保持 batch_size=25，再执行新 run。旧失败结果不能靠修改 error 标记变成成功，KEEP 仍需要完成事实抽取与候选生成。

## 输出与失败隔离

结束节点只返回 run_id、run_status、stats、export_status、error_summary、result_json_file、review_csv_file。完整 processing_items、candidates 和错误位于 JSON 文件，CSV 用于人工筛选；结束节点不展开完整候选正文。

父级错误包括 ID 不一致、完整性/覆盖、原文片段来源及顺序错误，阻断整篇快讯。分类枚举、单条标题或事实校验错误只阻断相应子项。父记录有子项错误时标记 FAILED，成功子项可关联候选，整篇尚未完整成功，因此仍可在下批重试。全部出错与部分成功均保留真实错误，不生成假 UNCERTAIN。

observed_keep/drop/uncertain 是校验前的模型决定数量；原有 digest_keep/drop/uncertain 只统计通过校验且父级未阻断的子项。digest_partial_parent_count 是部分子项失败但父级校验通过的快讯数；digest_failed_parent_count 是整篇阻断数；digest_error_count 包括以上部分失败和整篇阻断。普通资讯的 observed_* 同样包含后来抽取失败的初筛决定。最终 candidate_count 以候选表为准。

模型与文件保存仍需要实际部署支持，本地验证未调用用户模型或 Dify 服务。官方能力依据：[Iteration](https://docs.dify.ai/en/cloud/use-dify/nodes/iteration)、[Variable Aggregator](https://docs.dify.ai/en/cloud/use-dify/nodes/variable-aggregator)。
