# 职责边界

本地 Python 读取采集 SQLite、排除同一输入已经形成持久化业务终态的文章、按发布时间取最新批次，调用一个 Dify Workflow；下载并校验 JSON 结果后，以短事务写入 processing_items 与 candidates，最后生成本地运行概况。候选人工状态与五字段 feedback 由本地 SQLite 数据层保存；页面和 HTTP 响应层由已有 Web 系统管理。

Dify 单图：规范化原文 → 快讯/普通资讯遍历 → 汇总处理结果 → 事件归并 → 候选遍历 → 两表投影 → JSON/CSV 导出。模型边界始终为树状纯文本；JSON 负责节点间确定性交换。没有 Workflow Tool、Agent V2 或 Workspace Skill 运行绑定；两个 Tool 节点仅用于文件保存。

源码保持业务模块划分，构建时将模块编译到同一画布。`dify/source/nodes` 管业务，`common.py` 管共享规则，`prompt_contracts.py` 管契约提示词同步，`single_workflow.py` 管编排与布局。以后需要拆分时可复用这些职责边界，当前只维护一个部署入口。

部分子项失败时，父记录可标记 FAILED，成功叶子项和候选仍正常入库；只要整批结果已事务提交，该输入版本即视为业务终态，常驻 Worker 不自动重复处理。候选评分、来源 ID、IOC 与 AI 结果契约沿用原定义；人工状态收缩为 pending/starred/ignored，反馈改为独立五字段表。原文数据库与结果数据库可以不同 SQLite 文件；Dify 不直接访问 SQLite。

## 连续调度（v1.7.0）

`continuous.py` 现在直接围绕 `Runner` 和 `RunStore` 实现单 Worker 常驻处理，不再使用 session 作为运行边界。每批仍生成一个 `run_xxx` 远程执行 journal；启动时先恢复唯一未结束 run，恢复完成后重新扫描 Collector。`Repository.processed_inputs()` 从事务提交的 `processing_items` 判断业务终态，SUCCESS 与业务 FAILED 都不会自动重复处理，输入内容变化后 hash 改变才重新进入队列。

`session.py/session_state.py/session_reporting.py` 仅作为旧 `run-all` 兼容路径保留，不参与 `run-forever`。未知 POST 且没有 execution ID 时，daemon 复用同一 run_id/input snapshot 重提；已有 execution ID 时只查询原执行。

## 分层进度（v1.8.1）

`workflow_stages.py` 固定六个主阶段及 iteration/Item 边界；快讯与普通资讯作为 S 2/6 的平级分支独立维护；`log_context.py` 传播 Batch/Stage/Item 上下文；`stage_progress.py` 管阶段生命周期；`progress.py` 将 SSE 转换为面向人的 Batch → Stage → Item 进度；`progress_events.py` 将同一状态写成每个 run 独立的 `progress.jsonl`。`continuous.py` 从 durable run journal 续接 Batch 序号，恢复时沿用原编号。节点事件只属于 detailed 排障层，不再承担 Item 身份。日志和 ProgressEvent 都不进入业务表，也不改变 Dify 输入输出契约。完整说明见 LOGGING.md。
