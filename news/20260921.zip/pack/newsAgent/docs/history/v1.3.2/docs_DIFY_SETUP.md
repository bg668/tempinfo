# Dify 接入与容量

## 当前 v1.3.2 更新

主控及 01–04 的公共解析器已更新，修复数字 ID 类型和前导零；02 修复解析失败后的级联误报。主控和 Python 关键词默认补入“安全简讯”，显式旧配置需同步添加。按 [节点更新说明](PARSER_FIX.md) 替换 8 个节点代码并发布，可以保留模型设置和实际工具绑定；本轮不能只更新主控。下文 v1.3 / v1.3.1 的升级描述属于历史范围。

## v1.3.1 工具绑定更新

本次绑定来源为用户最新导出的临时 DSL `d2814f1b-3a67-4a47-b614-8134e8f38f40.yml`。四个工具的实际绑定如下，输入引用均沿用主控：

| 主控节点 | 实际 tool_name | provider_id | 输入来源 |
|---|---|---|---|
| 2110 | news_digest_process | 6255c2e8-5b7f-4a05-a42d-f0ff220461b4 | article_json ← 2000.item |
| 3110 | news_article_process | bbeb55fb-2627-4853-a511-2e3a5ce422f0 | article_json ← 3000.item |
| 4100 | 03work | 0c778540-2d76-40b6-abba-d068cb1f9755 | incidents_json ← 4000.incidents_json；grouping_mode ← 1000.grouping_mode |
| 5110 | news_event_candidate | a898dbb7-8e44-44f0-8b5a-780498ded70b | group_json ← 5000.item |

相对 v1.3，仅需更新并发布主控到该导出所属 Workspace。四个子流程与 Python 运行逻辑没有修改。若导入为新主控应用，需要把本地 `DIFY_API_KEY` 换成该新应用的密钥；更新原主控应用则沿用原密钥。保留现有工具，无需为了此次修复重建它们。

绑定资料同时保存为 `dify/tool_bindings.json`。后续换 Workspace 或重新创建工具，应使用新的临时 DSL。对改名工具显式指定业务角色与实际调用名，不按相似输入猜测角色：

```bash
python dify/tools/bind_main_workflow.py --template dify/source/templates/00_主控工作流_最终_Dify1.17_CSV.yml --tool-dsl tools.yml --tool-alias news_event_match=03work --output dify/source/templates/00_主控工作流_最终_Dify1.17_CSV.yml
python tools/build_dsl.py
```

此示例的 `03work` 对应当前导出；将来以实际调用名为准。也可用 `--bindings-json dify/tool_bindings.json` 复用当前绑定。绑定脚本保留主控连线、遍历归属、参数引用及错误策略；构建后从 `dify/` 获取最终 YAML。新 Workspace UUID 需要用户实际导出，文件静态校验无法确认服务端工具此刻仍存在。

## v1.3 接口升级

从 v1.2 升级只需发布新主控并更新 Python。四个子流程文件字节不变；保留用户在 Dify 内配置的本地模型。主控增加四个工具返回适配节点，拓扑为 25 节点 / 23 条边，三个遍历容器按实际子节点边界计算尺寸。

01–04 的 End 仍输出 `result_json`，但主控不再从 Workflow Tool 直接选择该自定义变量。使用工具标准 `text` 解包 End 对象，再提取内部 `result_json`。因此工具 UI 没有展示自定义输出时，也不再产生悬空字段选择器。若子流程实际没有发布正确的 End 输出，适配节点会明确记录 `missing_result_json_in_tool_text`。

工具默认值改为标准 `text=''`。官方错误机制另提供 `error_message` / `error_type`，由适配节点保存。工具失败不再产出无来源 ID 的静态业务 JSON。完整错误、来源 ID 及节点 ID 会进入批次结果和逐条处理记录。

v1.3 当时沿用了原 provider ID；v1.3.1 已按上表替换四处绑定。File Tools 保持原配置。不要仅保存草稿却继续调用旧版发布应用。

保留 `batch_size=25`。本次没有修改用户 Docker；真正用于遍历的数组仍受其容量限制。完整错误作为 JSON 文本和文件保留，仍受字符串长度、变量大小、模型输出与文件插件的限制，不承诺无限容量。

从更早版本升级时仍须先完成 v1.2 的子流程接口调整：01 输入仅 `article_json`，01/04 End 仅 `result_json`，再发布本次主控。已运行 v1.2 的用户无需重复更新这些子流程。

## 可选的容量扩展

`normal_article_jsons` 是主控 1100 的字符串数组；用于普通资讯遍历，不能按冗余输出删除。Dify 默认的两类 Code 数组上限均为 30，由 API/Worker 执行校验。变量说明见 [Dify 官方环境变量说明](https://docs.dify.ai/en/self-host/deploy/configuration/environments)。

### 使用本包的 Compose 覆盖文件（需要扩容时）

把 `deploy/dify.capacity.override.yml` 复制到实际 Dify Compose 部署目录，不覆盖原配置文件。这个文件只合并 api、worker 的七项容量变量，不改变镜像、端口、数据库、卷或密钥。

在没有其他活跃任务时，进入该部署目录执行以下标准示例。如果原部署使用额外的 `-p`、`--env-file` 或多个 `-f` 参数，请全部沿用，并把新文件放在 `-f` 列表最后；服务名也应对应实际部署。

```bash
docker compose -f docker-compose.yaml -f dify.capacity.override.yml up -d --no-deps --force-recreate api worker
```

重新创建会中断相关服务当前任务，因此应在空闲时应用；无需删除容器卷或执行 `down -v`。`restart` 不会重新创建容器环境，仅重启 Sandbox 也不生效。[Compose 合并规则](https://docs.docker.com/compose/how-tos/multiple-compose-files/merge/)、[up / force-recreate](https://docs.docker.com/reference/cli/docker/compose/up/)。

确认两个服务的环境都已更新：

```bash
docker compose -f docker-compose.yaml -f dify.capacity.override.yml exec -T api printenv CODE_MAX_STRING_ARRAY_LENGTH CODE_MAX_OBJECT_ARRAY_LENGTH
docker compose -f docker-compose.yaml -f dify.capacity.override.yml exec -T worker printenv CODE_MAX_STRING_ARRAY_LENGTH CODE_MAX_OBJECT_ARRAY_LENGTH
```

每条命令都应输出 `2000`、`2000`。这只显示目标变量，不需要输出包含密钥的完整环境。若仍是 30，检查是否进入了正确部署目录、使用了原 Compose 项目名、是否重建了实际执行工作的 API/Worker。以后重建或升级也要继续带该覆盖文件。

若不是 Docker Compose 部署，则在真正启动 API/Worker 的进程环境或服务配置中填同名值后重启相应进程。不可把这些设置只放在本地 Python 的 `.env`。不同 Dify 发行版本的环境文件组织可能不同；显式 Compose environment 合并可避免依赖某一版 `.env` 文件布局。

本次 `run_314aa8b650b446e897f0d351b684a38a` 的远程任务已经明确失败，数据库为 `NOT_COMMITTED`。修复后执行新 `run` 即可，无需清表、`--force` 或恢复失败任务。新批次会重新按当前范围选取，不保证与旧批次的 50 条完全相同。

当前 v1.3 相对 v1.2 仅修改主控，四个子流程均未修改。容量覆盖文件本身不属于 DSL。

## 导入

使用同一个 Workspace 导入 `00_主控工作流_最终_Dify1.17_CSV.yml`。其四个 Workflow Tool provider ID 来自此前用户导出的实际配置，File Tools 使用 `kurokobo/file_tools:0.0.2`。如果工具被重建或换了 Workspace，先把四个新工具拖入临时流程并导出，再使用 `dify/tools/bind_main_workflow.py --help` 按其参数重新绑定。包内不能预先知道其他 Workspace 的 UUID。

01–04 保留 JSON 输入 → Code 渲染树文本 → LLM → 树文本解析 → JSON 输出。运行期没有 Agent V2 / Workspace Skill 绑定。各 LLM 解析入口保留完整前导 `<think>...</think>` 过滤；不闭合的推理标签或空结果会报错，不从不完整内容猜测业务结论。

00 继续接收可选 `run_id`（`run_` 加 32 位十六进制字符），不传时自动生成；文章数组入口为 4,000,000 字符。遍历节点相对位置、中文名称和真实工具绑定保留。执行边无需增删；已清除的都是字段选择器和工具参数引用。

发布后用应用 API 页面提供的 Base URL（通常形如 `http://127.0.0.1/v1`）和应用 API Key 配置 Python。`check --remote` 会检查发布应用的参数中是否包含新 `run_id`；该接口不公开服务端容量变量，因此容量结果固定说明为 `NOT_VERIFIED`。

## 容量起始配置

以下是适用于本交付批量场景的起始值，不代表已经在用户设备实测。实际还受模型上下文、输出 token、插件和机器资源限制。它们是允许上限，并不在每次运行预分配对应内存。

```dotenv
CODE_MAX_STRING_LENGTH=20000000
CODE_MAX_STRING_ARRAY_LENGTH=2000
CODE_MAX_OBJECT_ARRAY_LENGTH=2000
MAX_VARIABLE_SIZE=67108864
WORKFLOW_MAX_EXECUTION_STEPS=2000
WORKFLOW_MAX_EXECUTION_TIME=3600
APP_MAX_EXECUTION_TIME=3600
```

默认字符串数组上限 30 小于 50，所以这项必须核对。快讯子项可能多于输入篇数，因此数组配置留有余量。Code 输出限制由 API 和 Worker 读取；修改后应确认 Compose 把变量传入相关服务，并重新创建相关容器，仅重启 Sandbox 无效。变量含义和当前默认值见 [Dify 官方环境变量说明](https://docs.dify.ai/en/self-host/deploy/configuration/environments)。

Python 默认 `max_input_chars=4000000` 对齐主控入口；单篇 `max_content_chars=50000` 保持原流程默认。超限会明确报错，不自动减少选中文章或拆散本批归并。快讯正文会被裁剪时，Python 报输入质量错误；普通文章保留截断元数据。按实际完整 50 篇在部署环境验证后再调整。

## API 与文件

调用 `POST /v1/workflows/run`，使用 `streaming` 和固定 API `user=news-local`。本地业务 `run_id` 与 Dify `workflow_run_id` 是两个不同标识，都保存；断线后按后者查询原任务。官方接口：[运行工作流](https://docs.dify.ai/en/api-reference/workflow-runs/run-workflow)、[查询执行详情](https://docs.dify.ai/en/api-reference/workflow-runs/get-workflow-run-detail)。

结束节点继续输出 `run_id`、`run_status`、`stats`、`export_status`、`error_summary`、`result_json_file`、`review_csv_file`。Python 下载文件后校验，再入库；不会通过 CSV 还原复杂字段。

`FILES_URL` 必须能被运行 Python 的宿主机访问。若已生成地址的域名只在容器内有效，可在 `file_base_url` 配置宿主机可达的对应域名，程序保留路径和签名查询串。下载文件不附带应用 API Key。Dify 签名文件地址可能过期，应及时下载；已下载产物可直接恢复入库。

本交付未访问用户 Dify 服务，未自动发布流程，也未修改任何部署环境变量。

## 日志事件的能力边界

本地仍使用 streaming，不调用额外节点日志 API。详细日志读取 Dify 返回的 `node_started`、`node_finished`、`node_retry` 和 `iteration_*` 的标题、编号、状态、耗时、index；忽略节点 inputs/outputs、文本和推理增量。字段依据 [Dify 官方事件实体源码](https://github.com/langgenius/dify/blob/main/api/core/app/entities/task_entities.py)。

Workflow Tool 内部若不向外层流转发子节点事件，只能看到外层工具节点等待及完成；不会伪造细粒度进度。已断开的 SSE 也不会通过一次状态查询恢复历史日志。详细档每 30 秒输出客户端等待提示，关键信息档不输出等待提示。
