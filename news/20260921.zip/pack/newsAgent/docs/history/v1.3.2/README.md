# 本地资讯处理 v1.3.2（命令行版）

从采集 SQLite 排除相同输入已完整处理成功的原文，再按发布时间选最新最多 50 篇，整批调用 Dify，下载 JSON/CSV，最终把结果写入 `processing_items` 和 `candidates`。时间统一为北京时间 `+08:00`。网页展示和人工审核由你现有系统负责，本版移除了网页服务。

运行仅需 Python 3.11+ 标准库。数据库两表结构、JSON/CSV 文件内容和最终结束节点的七项输出保持兼容。

## v1.3.2：数字 ID、级联错误与快讯分流

修复树文本解析将纯数字 ID 转为整数导致 24 条有效筛选被误拦截的问题，并保留前导零；02 解析失败后停止业务字段校验，封装节点不再重复追加评分错误。主控和 Python 默认关键词同步补入“安全简讯”。模型提示词、两表字段及输出接口保持兼容。

本轮需要更新主控和 01–04。推荐按 [更新说明](docs/PARSER_FIX.md) 使用 `dify/node_updates/` 的 8 个节点文件替换现有节点代码并发布，从而保留现有模型配置和工具 UUID。若使用完整 YAML 导入为新应用并重建工具，则须重新绑定实际 UUID。

Python 代码同步更新；既有配置若写明旧关键词，请将 `digest_keywords` 改为 `"日报,周报,快讯,安全简讯"`，Dify 手动测试同样使用此值。保留原 batch_size、数据库、state_dir、API 配置，失败原文执行新 run 重试。

116 项测试通过。25 份用户筛选内容重建树文本后全部通过（23 DROP / 2 KEEP），48083 返回 DROP / non_target、48 分；原文按新默认分流为 24 普通 / 1 快讯。完整数字 ID 合成链路已验证两表和 CSV 导出，未连接用户 Dify 运行真实模型。

## v1.3.1 历史修复：实际工具绑定

根据最新上传的 `d2814f1b-3a67-4a47-b614-8134e8f38f40.yml`，同步替换主控 2110、3110、4100、5110 的四个 Workspace Tool 绑定。4100 的实际调用名为 `03work`，已连同 provider ID 一起更新；入口 `grouping_mode` 仍透传，没有复制临时流程的固定 `singleton` 值。

v1.3.1 当时只更新主控绑定；当前 v1.3.2 请以上述更新范围为准。保留已配置的模型和已发布的工具；如果重新创建工具，UUID 会再次变化。请更新 Python API Key 对应的主控应用；若新建主控应用，则同时换成新应用的 API Key。

完整包同步更新了构建模板、工具绑定脚本和验证记录。绑定脚本支持显式 `--tool-alias news_event_match=03work`，校验真实参数定义，保留主控的参数引用与错误处理，并拒绝同名工具歧义及把两个业务角色误绑到同一个工具。当前绑定保存在 `dify/tool_bindings.json`，具体映射及重建方法见 [Dify 接入说明](docs/DIFY_SETUP.md)。

本地 41 项、工作流 68 项测试通过；主控 25 个节点、23 条边、70 处变量引用均通过静态检查。未连接用户 Dify 验证实际执行。

## v1.3 历史修复：工具返回适配与错误定位

本次修复主控对工具自定义 `result_json` 输出的直接依赖，以及失败占位值没有来源身份、丢失实际异常的问题。上一版 7 节点 / 13 冗余输出清理继续保留。

| 工具调用 | 新增适配节点 | 下游使用 |
|---|---|---|
| 2110 快讯工具 | 2120 读取快讯结果与异常 | 2000 遍历收集 2120.result_json |
| 3110 普通资讯工具 | 3120 读取资讯结果与异常 | 3000 遍历收集 3120.result_json |
| 4100 归并工具 | 4120 读取归并结果与异常 | 4200 从 4120.result_json 解析分组 |
| 5110 候选工具 | 5120 读取候选结果与异常 | 5000 遍历收集 5120.result_json |

四个适配节点只读取工具标准 `text`、错误变量 `error_message` / `error_type` 和当前输入。成功时先解析 `text` 得到 End 输出对象，再解析其 `result_json`；失败时记录实际异常和原文/事件 ID，不虚构筛选结论。标准 text 和自定义 result_json 是不同层级，不能只替换选择器而不解包。

同一条工具异常从批次和逐条路径重复汇总时合并为一条，保留关联信息。来源不匹配、结果缺失、业务校验失败仍分别检查，不通过强行改写成功结果的 ID 掩盖真实问题。JSON/CSV、两表字段和人工反馈保持兼容；外层结束节点仍只给概况和文件。

Python 在下载校验结果后输出实际失败原因。关键信息档按节点、类型、异常内容归类，详细档另列原文/条目/事件定位。默认详细，两档均不会展开文章正文或完整业务结果。

从早期版本升级至当前 v1.3.2，按上方更新说明同步主控、01–04 及 Python。保留子流程里的本地模型配置、SQLite、state_dir 以及 `batch_size=25`。本次不要求修改 Docker。失败文章可由新 `run` 再次选取，无需清表或 `--force`。

如果在新 Workspace 导入或重建工具，需要从该 Workspace 的实际临时 DSL 重新绑定 provider ID；使用包内 `dify/tools/bind_main_workflow.py`，不手写 UUID。主控更新应发布到 Python API Key 对应的应用，草稿不会替代 API 的已发布版本。

最初附件中 25 篇都命中了普通资讯工具失败占位，派生出共 101 条错误。随后提供的 3110 原始错误为 `ToolRuntimeResolutionError: workflow provider 38b85447-5c1d-4001-a62b-38e86d0704be not found`，已明确该次调用失败是旧工具绑定不可用。v1.3.1 用最新导出的四个实际工具完成重新绑定；保留 v1.3 的原始异常记录，便于区分后续可能出现的其他问题。

官方实现与定位依据见 [工具返回与本次故障](docs/TOOL_TRANSPORT_FIX.md)。实际使用的数组、字符串仍受部署容量限制；不截断错误和文章内容来掩盖超限。

## 更新与运行

解压到新目录，使用原来的 `config.toml`、本地 `.env`、数据库和 `state_dir`。配置中的相对路径以配置文件所在目录为基准；不要把旧配置移到新目录后无意改变数据库位置。旧 `host`、`port`、`reviewer_id` 配置会提示忽略，不影响运行。数据库表和历史批次无需重建。

沿用你的 uv 方式：

```bash
# 默认详细日志
uv run --env-file .env run.py --config config.toml run

# 关键信息日志
uv run --env-file .env run.py --config config.toml run --log-level key

# 显式详细日志
uv run --env-file .env run.py --config config.toml run --log-level detailed
```

也可在 `config.toml` 写 `log_level = "key"`；命令行优先，未设置时默认 `detailed`。可将参数放在子命令之前或之后。

首次接入时复制 `config.example.toml`，填写 SQLite 和 Dify API 地址，在环境变量 `DIFY_API_KEY` 中配置已发布主控的应用密钥，再执行：

```bash
python run.py --config config.toml init
python run.py --config config.toml check --remote
python run.py --config config.toml plan
python run.py --config config.toml run
```

纯 Python 不主动读取 `.env`，应由 shell 设置变量或使用上面的 uv 命令。`check --remote` 只验证公开应用参数，会明确将服务端容量标为 `NOT_VERIFIED`，不会假装可以读取 Dify 容器环境。

## 日志内容

| 档位 | 内容 |
|---|---|
| `key` 关键信息 | 批次 ID、查询范围、选取数量、提交与远程执行 ID、下载、校验、入库、最终数量、异常和修复建议 |
| `detailed` 详细（默认） | 包含关键信息，另有逐篇选取/跳过、输入长度、实际收到的 Dify 节点和遍历事件、节点状态/耗时、文件大小，每 30 秒等待提示 |

日志实时输出到 **stderr**，最终概况 JSON 输出到 **stdout**。业务时间和日志时间都为 `+08:00`。日志不会主动展开原文正文、模型提示词、模型回答、完整节点输入输出、API Key 或文件签名 URL。Dify 子 Workflow 内部没有向主调用返回的事件，本程序无法展示；不会编造完成百分比。

例如分开保存：

```bash
uv run --env-file .env run.py --config config.toml run 1>run-result.json 2>run-progress.log
```

## 命令与结果

| 命令 | 用途 |
|---|---|
| `plan` | 只读预览选取范围、排除计数、质量问题及文章清单 |
| `run` | 完整处理，默认最多 50 篇 |
| `run --limit 10` | 明确选择较小批次，不改变配置文件；不等同于完整 50 篇归并 |
| `run --force` | 显式忽略成功记录，生成新批次，保留旧反馈 |
| `status run_xxx` | 查看本地阶段、错误或最终概况，旧数组错误也能得到修复提示 |
| `resume run_xxx` | 查询未结束的原 Dify 执行，继续下载或入库；不会重发 POST |
| `resume run_xxx --workflow-run-id UUID` | 根据 Dify 日志关联丢失的远程执行 ID |
| `ingest run_xxx` | 重复导入已校验结果，保护人工反馈 |
| `abandon run_xxx` | 显式放弃本地恢复，不停止远程任务 |

`FAILED`、`WAITING`、`NEEDS_RECOVERY` 退出码为 2。`SUCCESS`、`PARTIAL`、`NO_WORK` 保留原来的退出码 0 和详细概况。输入异常与模型 DROP 分开记录；叶子条目的 KEEP/DROP/UNCERTAIN 均进入处理结果表。

你的网页可读取两张结果表，并读取 `state_dir/runs/<run_id>/summary.json` 展示最终概况。运行中或失败时读取轻量 `run.json` 获取阶段与错误。人工反馈仍放在 `candidates` 中，本地再次入库不会覆盖已保存反馈；审核身份与权限由你的网页系统管理。

每批保存的 `input.json` 是实际规范化输入快照，`result.json` 是远程结果，`review.csv` 是人工选题文件，`bundle.validated.json` 是校验后的入库依据。SQLite 两表在一个最终事务中提交，等待模型期间不持有写事务。

## 开发与验证

| 模块 | 职责 |
|---|---|
| `planner.py` / `normalize.py` | 选取、去重、规范化与哈希 |
| `dify_client.py` | HTTP、SSE、状态查询和文件下载 |
| `service.py` | 一批处理、恢复和最终提交 |
| `contracts.py` / `repository.py` | 结果校验和 SQLite 事务 |
| `reporting.py` / `state.py` | 最终概况与恢复状态 |
| `progress.py` | 两档日志、北京时间格式和 SSE 元数据展示 |
| `diagnostics.py` | 服务端错误识别与操作建议 |

```bash
python tools/run_tests.py
```

可选安装 PyYAML 后可运行包内 DSL 回归和静态图校验；运行程序不需要该依赖。只有更改工作流源码时才执行 `python tools/build_dsl.py`。`tools/create_demo.py <新目录>` 可生成隔离合成数据及结果，不访问真实模型。

本环境验证了本地控制流和模拟 Dify 接口；真实服务端配置生效与模型运行仍需在你的设备确认。详细结果见 [验证记录](docs/VALIDATION.md)。
