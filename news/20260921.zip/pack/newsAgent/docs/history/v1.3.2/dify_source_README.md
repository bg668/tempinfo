# 源码结构

- `common.py`：共用树文本、推理前缀、评分、IOC 和来源工具函数。
- `nodes/工作流编号_节点编号.py`：单节点职责；每个文件只有一个 main。
- `templates/`：保留图、节点接口、提示词和工具配置；Code 内容由构建填充。
- `build.py`：解析依赖、内嵌必要函数、检查单入口、计算 processing_version 并生成五份 DSL。

节点内部使用对象交接。Dify 边界所需 JSON 字符串只在对应出口编码。不同 DSL 节点中出现的共用函数副本是构建产物，维护时只改源文件。

v1.3.2：公共解析器将 `_id` / `_ids` 作为文本，评分保留整数；02 的 300/700 在解析失败后不继续校验空业务对象。分流关键词函数从 `src/news_local/article_contract.py` 同步到 common.py。构建同时更新 `dify/node_updates/` 的八份独立代码，便于保留现有 Dify 模型和工具绑定。

源码采用 Python 标准库，构建另需 PyYAML。格式整理使用 Black，但构建和运行不依赖 Black。


v1.2 输出清理：公共函数和节点内部对象仍用于构建完整结果，只有 Dify `main` 边界收紧为实际使用的字段。调整输出时必须同步修改 `nodes/`、`templates/` 的 outputs/variables、子流程 End 与主控工具参数。使用根目录 `tools/build_dsl.py` 构建，避免遗漏本地输入哈希契约。

测试逐次核对 Code 返回键与声明一致，静态扫描检查所有自定义 Code 输出都有消费者。历史图 fixture 保留；v1.3 使用经过检查的新图快照，同时独立验证拓扑、引用、工具标准输出和容器边界。`compare_release.py` 对照 v1.2 的完整导出产物，忽略版本号并固定随机批次 ID；异常诊断由专项用例验证。


v1.3 新增四个小型适配节点，共用 common.py 的 adapt_workflow_tool：只负责工具传输封装与异常身份，不参与 LLM 业务判断。其输入是工具 text/error_message/error_type 和本次来源 JSON；成功结果不补写来源 ID，只有工具失败的错误记录使用确定性的输入身份。
