# 长期后台处理与断点恢复（v1.7.0）

长期运行只需要一条命令：

```bash
uv run --env-file .env run.py --config config.toml run-forever --interval 30
```

`run-forever` 是单 Worker，不创建 session，不冻结“本轮范围”。现有 backlog 会按 `batch_size` 连续分批处理，批与批之间不等待；没有工作、远程仍在运行或发生可恢复基础设施错误时，才按 `--interval` 等待后重新检查。

## 断点依据

真正的 checkpoint 是结果库中的业务终态，而不是进程内游标：

1. 每次扫描 Collector，规范化文章并得到 `(source_article_id, input_hash)`。
2. `processing_items` 中已经事务提交过该输入版本的终态记录时跳过。
3. SUCCESS、业务 FAILED、以及本地确定性输入错误都属于终态；它们不会无限重复处理。
4. 原文内容/元数据修复后 hash 改变，会作为新输入版本重新进入队列。
5. 数据库失败、下载失败、远程状态不确定等没有形成业务终态，不会被误判成“已处理”。

普通文章只要有一条已提交 normal/input_error 记录即为终态。快讯父记录 FAILED 本身是终态；父记录 SUCCESS 时仍要求至少存在一个 digest_child，防止损坏/不完整数据库错误地屏蔽重处理。

本地输入质量错误使用 `raw_collector_record_v1` 指纹写入现有 `input_hash`，因此同一份坏数据只记录一次；采集器修复正文、时间等字段后指纹变化，会再次尝试。

## run 是恢复单元

每个 Dify 批次仍有 `run_xxx`：

- `runs/run_xxx/input.json`：冻结本批 plan 与 Dify 输入；带 SHA-256 校验。
- `runs/run_xxx/run.json`：阶段、`workflow_run_id`、提交次数、错误和数据库状态。
- `result.json/review.csv`：远程导出。
- `bundle.validated.json`：通过本地契约校验、可用于幂等入库的结果。
- `summary.json`：批次概况。

这些 run 文件不是用户任务隔离，而是远程执行 journal。进程退出不会删除它们。

## 重启行为

重新启动 `run-forever` 时先检查未结束 run：

| 本地状态 | 自动行为 |
|---|---|
| 没有未结束 run | 扫描 Collector，选下一批 |
| PREPARING 且尚未形成输入快照 | 安全放弃该空 journal，重新选取 |
| PREPARED，确定尚未 POST | 使用原 run_id 和输入快照提交 |
| 已有 `workflow_run_id` | 查询原 Dify 执行，不二次 POST |
| 已有 validated bundle 但未完成入库 | 只重试本地事务入库 |
| POST 结果不明且没有 execution ID | 后台模式复用原 run_id 与同一输入快照重新 POST |

最后一种是无法从客户端彻底消除的远程灰区。允许重复计算，但本地仍使用同一业务 `run_id`，结果 ID 稳定，SQLite 写入幂等，因此不会生成第二份业务记录。`submit_attempt_count` 会保留重提次数用于排查。

人工执行 `resume run_xxx` 仍保持保守：没有 execution ID 时不会自动重提，适合管理员排查。自动重提只由 `run-forever` 的恢复路径显式启用。

## Ctrl+C / 机器重启

不需要记 session_id，也不需要执行 `resume-all`：

```bash
# 停止
Ctrl+C

# 下次继续
uv run --env-file .env run.py --config config.toml run-forever --interval 30
```

如果中断发生在已经成功事务提交之后，下一次扫描直接跳过这些输入。如果中断发生在远程执行、下载或入库中间，则按上表恢复当前 `run_xxx`，完成后继续扫描剩余和后来新增的数据。

不要删除 `state_dir/runs`。数据库是“哪些输入已经完成”的业务依据，run journal 是“当前未完成远程批次如何恢复”的技术依据，两者职责不同。

## 与旧 session 命令的关系

`run-all / resume-all / status-all / abandon-all` 为 v1.5/v1.6 的兼容路径，仍可读取历史 session，但 `run-forever` 已不创建或依赖 session。新部署和常驻服务不要围绕 session 编排。
