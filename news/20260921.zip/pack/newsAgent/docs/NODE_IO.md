# 单工作流节点输入输出

每行一个节点；编号对应 Dify 画布。JSON 字段均为 JSON 字符串，模型的 text 为缩进树纯文本。只列本流程实际使用的变量。

| 编号 | 节点 | 输入字段、类型与来源 | 输出字段与类型 |
|---|---|---|---|
| 1000 | 开始 | — | articles_json: paragraph；digest_keywords: text-input；grouping_mode: select；max_content_chars: number；run_id: text-input |
| 1100 | 规范化文章JSON并分流 | articles_json: string ← 1000.articles_json；digest_keywords: string ← 1000.digest_keywords；max_content_chars: number ← 1000.max_content_chars；run_id: string ← 1000.run_id | prepare_errors_json: string；manifest_json: string；digest_article_jsons: array[string]；normal_article_jsons: array[string] |
| 2000 | 逐篇处理快讯汇总文章 | 遍历输入: array[string] ← 1100.digest_article_jsons | output: array[string] ← 2120.result_json；item: 当前元素；index: 当前序号（内部可用） |
| 2000start | 快讯遍历入口 | 由遍历 2000 启动 | — |
| 2050 | 校验JSON并渲染文章树 | article_json: string ← 2000.item | article_text: string；article_json: string |
| 2110 | 快讯拆分与研判 | 2050.article_text: 树文本 | text: 树文本字符串 |
| 2120 | 校验快讯树并生成候选 | raw: string ← 2110.text；article_text: string ← 2050.article_text；article_json: string ← 2050.article_json | result_json: string |
| 3000 | 逐篇处理普通资讯 | 遍历输入: array[string] ← 1100.normal_article_jsons | output: array[string] ← 3190.output；item: 当前元素；index: 当前序号（内部可用） |
| 3000start | 普通资讯遍历入口 | 由遍历 3000 启动 | — |
| 3050 | 校验JSON并渲染文章树 | article_json: string ← 3000.item | article_text: string；article_json: string |
| 3110 | 文章价值筛选 | 3050.article_text: 树文本 | text: 树文本字符串 |
| 3120 | 解析并校验筛选树 | raw: string ← 3110.text；article_text: string ← 3050.article_text | decision: string；route: string；triage_json: string；validation_error: string |
| 3130 | 按筛选结果路由 | 3120.decision；3120.route | 控制分支: security_event,compliance_policy,false |
| 3140 | 安全事件事实抽取 | 3050.article_text: 树文本 | text: 树文本字符串 |
| 3150 | 解析并校验事件事实树 | raw: string ← 3140.text；article_text: string ← 3050.article_text；triage_json: string ← 3120.triage_json；article_json: string ← 3050.article_json | result_json: string |
| 3160 | 政策合规事实抽取 | 3050.article_text: 树文本 | text: 树文本字符串 |
| 3170 | 解析并校验政策事实树 | raw: string ← 3160.text；article_text: string ← 3050.article_text；triage_json: string ← 3120.triage_json；article_json: string ← 3050.article_json | result_json: string |
| 3180 | 封装丢弃/待确认结果 | article_text: string ← 3050.article_text；triage_json: string ← 3120.triage_json；validation_error: string ← 3120.validation_error；article_json: string ← 3050.article_json | result_json: string |
| 3190 | 汇总单篇处理结果 | 3150.result_json；3170.result_json；3180.result_json | output: string（当前互斥分支） |
| 4000 | 汇总文章结果与分阶段统计 | digest_results: array[string] ← 2000.output；normal_results: array[string] ← 3000.output；prepare_errors_json: string ← 1100.prepare_errors_json；manifest_json: string ← 1100.manifest_json | incidents_json: string；errors_json: string；stage_stats_json: string；warnings_json: string；digest_candidates_json: string；policy_candidates_json: string |
| 4050 | 渲染事件归并输入树 | incidents_json: string ← 4000.incidents_json；grouping_mode: string ← 1000.grouping_mode | incidents_text: string；route: string |
| 4070 | 选择归并方式 | 4050.route | 控制分支: event_match,false |
| 4100 | 判断同一安全事件 | 4050.incidents_text: 树文本 | text: 树文本字符串 |
| 4120 | 精确覆盖校验与保守修复 | raw: string ← 4100.text；incidents_json: string ← 4000.incidents_json | result_json: string |
| 4130 | 确定性单篇分组 | incidents_json: string ← 4000.incidents_json | result_json: string |
| 4150 | 汇总分组结果 | 4120.result_json；4130.result_json | output: string（当前互斥分支） |
| 4200 | 解析事件分组 | result_json: string ← 4150.output；incidents_json: string ← 4000.incidents_json | group_jsons: array[string]；event_match_errors_json: string |
| 5000 | 逐个生成安全事件候选 | 遍历输入: array[string] ← 4200.group_jsons | output: array[string] ← 5120.result_json；item: 当前元素；index: 当前序号（内部可用） |
| 5000start | 候选遍历入口 | 由遍历 5000 启动 | — |
| 5050 | 渲染事件候选输入树 | group_json: string ← 5000.item | candidate_input_text: string |
| 5110 | 生成事件候选文案 | 5050.candidate_input_text: 树文本 | text: 树文本字符串 |
| 5120 | 解析候选树并补充确定性字段 | raw: string ← 5110.text；group_json: string ← 5000.item | result_json: string |
| 6000 | 汇总两表数据与人工审核列表 | digest_candidates_json: string ← 4000.digest_candidates_json；policy_candidates_json: string ← 4000.policy_candidates_json；event_results: array[string] ← 5000.output；errors_json: string ← 4000.errors_json；event_match_errors_json: string ← 4200.event_match_errors_json；stage_stats_json: string ← 4000.stage_stats_json；warnings_json: string ← 4000.warnings_json；group_jsons: array[string] ← 4200.group_jsons；digest_results: array[string] ← 2000.output；normal_results: array[string] ← 3000.output；manifest_json: string ← 1100.manifest_json | review_items_json: string；run_status: string；stats_json: string；errors_json: string；warnings_json: string；run_id: string；processing_version: string；processing_items_json: string；candidates_json: string |
| 6050 | 打包完整两表JSON | processing_items_json: string ← 6000.processing_items_json；candidates_json: string ← 6000.candidates_json；run_id: string ← 6000.run_id；processing_version: string ← 6000.processing_version；run_status: string ← 6000.run_status；stats_json: string ← 6000.stats_json；errors_json: string ← 6000.errors_json；warnings_json: string ← 6000.warnings_json | bundle_json: string；json_filename: string；csv_filename: string；stats_json: string |
| 6060 | 保存完整两表JSON | content ← 6050.bundle_json；encoding ← utf-8；filename ← 6050.json_filename；mime_type ← application/json | files: array[file] |
| 6100 | 生成人工审核CSV | review_items_json: string ← 6000.review_items_json | csv_text: string |
| 6200 | 保存人工审核CSV | content ← 6100.csv_text；encoding ← utf-8；filename ← 6050.csv_filename；mime_type ← text/csv | files: array[file] |
| 6500 | 汇总处理与导出情况 | run_status: string ← 6000.run_status；stats_json: string ← 6050.stats_json；errors_json: string ← 6000.errors_json；json_files: array[file] ← 6060.files；csv_files: array[file] ← 6200.files | run_status: string；stats: object；export_status: object；error_summary: string |
| 7000 | 输出处理情况与下载文件 | run_id ← 6000.run_id；run_status ← 6500.run_status；stats ← 6500.stats；export_status ← 6500.export_status；error_summary ← 6500.error_summary；result_json_file ← 6060.files；review_csv_file ← 6200.files | run_id: string；run_status: string；stats: object；export_status: object；error_summary: string；result_json_file: array[file]；review_csv_file: array[file] |
