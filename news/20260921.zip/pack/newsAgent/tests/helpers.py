"""Synthetic collector and deterministic Dify adapter. Never claims model quality."""

import hashlib
import json
import sqlite3
import uuid
from pathlib import Path

from news_local.article_contract import canonical_json
from news_local.contracts import FIELDS, SCORES


def collector_db(path: Path, count=8):
    with sqlite3.connect(path) as db:
        db.executescript("""
            CREATE TABLE feed_items(id INTEGER PRIMARY KEY, title TEXT, account TEXT,
              published_at TEXT, fetch_status TEXT);
            CREATE TABLE article_contents(id INTEGER PRIMARY KEY, article_id INTEGER UNIQUE,
              title TEXT, account TEXT, published_at TEXT, fetched_at TEXT, content TEXT, url TEXT);
        """)
        for sid in range(1, count + 1):
            title = f"安全日报 第{sid}期" if sid % 7 == 0 else f"某企业披露安全事件 {sid}"
            published = f"2026-08-{sid % 28 + 1:02d}T10:{sid % 60:02d}:00"
            db.execute(
                "INSERT INTO feed_items VALUES (?,?,?,?,?)",
                (sid, title, "示例媒体", published, "FETCHED"),
            )
            db.execute(
                "INSERT INTO article_contents VALUES (?,?,?,?,?,?,?,?)",
                (
                    1000 + sid,
                    sid,
                    title,
                    "示例媒体",
                    published,
                    "2026-08-31T05:00:00+00:00",
                    "某企业披露服务器受到攻击，影响范围正在调查。",
                    f"https://example.com/{sid}",
                ),
            )


def identity(prefix, *values):
    return prefix + hashlib.sha256(":".join(map(str, values)).encode()).hexdigest()[:28]


def bundle_for(inputs: dict) -> dict:
    run_id = inputs["run_id"]
    bundle = {
        "schema_version": "news-result-bundle-v1",
        "run_id": run_id,
        "processing_version": "synthetic-test-v1",
        "process_status": "SUCCESS",
        "stats": {},
        "errors": [],
        "warnings": [],
        "processing_items": [],
        "candidates": [],
    }
    for article in json.loads(inputs["articles_json"]):
        sid = article["source_article_id"]
        digest = "日报" in article["title"]
        layouts = (
            [
                ("digest_parent", "parent", None),
                ("digest_child", "item_001", "KEEP"),
                ("digest_child", "item_002", "DROP"),
            ]
            if digest
            else [
                (
                    "normal",
                    "article",
                    "DROP" if int(sid) % 5 == 0 else "UNCERTAIN" if int(sid) % 6 == 0 else "KEEP",
                )
            ]
        )
        for kind, key, decision in layouts:
            row = dict.fromkeys(FIELDS["processing_items"])
            route = {
                "KEEP": "security_event",
                "DROP": "non_target",
                "UNCERTAIN": "uncertain",
                None: None,
            }[decision]
            row.update(
                item_id=identity("item_", run_id, sid, key),
                run_id=run_id,
                source_article_id=sid,
                item_kind=kind,
                item_key=key,
                process_status="SUCCESS",
                decision=decision,
                route=route,
                input_hash=hashlib.sha256(canonical_json(article).encode()).hexdigest(),
                processing_version=bundle["processing_version"],
                excluded_iocs_json=[],
                quality_warnings_json=[],
                errors_json=[],
                input_meta_json={},
            )
            if decision:
                row.update({k: 4 for k in SCORES})
                row.update(
                    total_score=80,
                    reason="测试：依据原文进行判断",
                    category="data_breach",
                    content_nature="real_world_event",
                )
            if decision == "KEEP":
                row.update(
                    title=article["title"], summary="测试摘要：企业披露安全事件，影响范围仍在调查。"
                )
                candidate = dict.fromkeys(FIELDS["candidates"])
                cid = identity("candidate_", run_id, sid, key)
                row["candidate_record_id"] = cid
                candidate.update(
                    candidate_record_id=cid,
                    candidate_id=identity("event_", sid, key),
                    run_id=run_id,
                    candidate_type="security_event",
                    primary_item_id=row["item_id"],
                    title=row["title"],
                    summary=row["summary"],
                    total_score=80,
                    reason=row["reason"],
                    score_strategy="single_article",
                    score_source_item_id=row["item_id"],
                    excluded_iocs_json=[],
                    quality_warnings_json=[],
                    review_status="pending",
                )
                candidate.update({k: 4 for k in SCORES})
                bundle["candidates"].append(candidate)
            bundle["processing_items"].append(row)
    incident_count = sum(
        r["item_kind"] == "normal" and r["decision"] == "KEEP" for r in bundle["processing_items"]
    )
    bundle["stats"].update(normal_incident_count=incident_count, event_group_count=incident_count)
    return bundle


class FakeDify:
    def __init__(self):
        self.posts = 0
        self.bundle = None
        self.execution_id = str(uuid.uuid4())
        self.pending = False
        self.csv_failure = False

    def start(self, inputs, on_execution_id):
        self.posts += 1
        self.bundle = bundle_for(inputs)
        on_execution_id(self.execution_id)
        if self.pending:
            from news_local.errors import PendingRun

            raise PendingRun("synthetic disconnect")
        return self.detail(self.execution_id)

    def detail(self, execution_id):
        if self.pending:
            return {"status": "running"}
        return {"status": "succeeded", "outputs": {}}

    def download(self, outputs, variable, target):
        if variable == "result_json_file":
            target.write_text(json.dumps(self.bundle, ensure_ascii=False), encoding="utf-8")
        elif self.csv_failure:
            from news_local.errors import NewsError

            raise NewsError("synthetic file error")
        else:
            target.write_text("标题,类型\r\n测试,security_event\r\n", encoding="utf-8-sig")
