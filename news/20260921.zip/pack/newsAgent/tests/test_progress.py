import contextlib
import io
import json
import logging
import threading
import unittest
from unittest.mock import patch

from test_core import SystemCase

from news_local.cli import main, parser
from news_local.config import Settings
from news_local.diagnostics import diagnose
from news_local.dify_client import DifyClient
from news_local.progress import BeijingFormatter, DifyProgress, configure

ARRAY_ERROR = "The length of output variable `normal_article_jsons` must be less than 30 elements."


class ConsoleCase(unittest.TestCase):
    def setUp(self):
        logger = logging.getLogger("news_local")
        self.old = (logger.handlers[:], logger.level, logger.propagate)
        self.stream = io.StringIO()
        configure(stream=self.stream)

    def tearDown(self):
        logger = logging.getLogger("news_local")
        logger.handlers, logger.level, logger.propagate = self.old

    def test_detailed_logs_events_without_business_payloads(self):
        configure("detailed", self.stream)
        progress = DifyProgress()
        progress.event(
            {
                "event": "node_started",
                "data": {
                    "node_id": "1100",
                    "title": "文章预处理\n伪造日志\x1b[31m",
                    "inputs": {"api_key": "secret-key", "content": "private-body"},
                },
            }
        )
        progress.event(
            {
                "event": "node_finished",
                "data": {
                    "node_id": "1100",
                    "title": "文章预处理",
                    "status": "succeeded",
                    "elapsed_time": 1.25,
                    "outputs": {"text": "private-output"},
                },
            }
        )
        progress.event(
            {
                "event": "iteration_next",
                "data": {
                    "node_id": "3000",
                    "title": "普通资讯逐篇处理",
                    "index": 2,
                },
            }
        )
        progress.event({"event": "text_chunk", "data": {"text": "private-model-text"}})
        output = self.stream.getvalue()
        self.assertIn("节点开始", output)
        self.assertIn("1.25 秒", output)
        self.assertIn("index=2", output)
        details = [line for line in output.splitlines() if "[详细]" in line]
        self.assertEqual(len(details), 3)
        self.assertIn("[S 1/6 批次准备与文章分流] 完成", output)
        self.assertNotIn("\x1b", output)
        for secret in ("secret-key", "private-body", "private-output", "private-model-text"):
            self.assertNotIn(secret, output)

    def test_key_logs_hide_detail_and_keep_errors(self):
        configure("key", self.stream)
        progress = DifyProgress()
        progress.event({"event": "node_started", "data": {"node_id": "1100"}})
        progress.event(
            {
                "event": "node_finished",
                "data": {
                    "node_id": "1100",
                    "status": "failed",
                    "error": ARRAY_ERROR,
                },
            }
        )
        logging.getLogger("news_local.service").info("校验完成，开始事务入库")
        progress.event(
            {
                "event": "iteration_completed",
                "data": {
                    "node_id": "3000",
                    "status": "failed",
                    "error": "遍历子项异常",
                },
            }
        )
        output = self.stream.getvalue()
        self.assertNotIn("节点开始", output)
        self.assertIn(ARRAY_ERROR, output)
        self.assertIn("开始事务入库", output)
        self.assertIn("遍历子项异常", output)

    def test_redundant_array_error_directs_to_new_dsl(self):
        error = "The length of output variable `errors` must be less than 30 elements."
        result = diagnose(error)
        self.assertEqual(result["code"], "DIFY_OBSOLETE_ARRAY_OUTPUT")
        self.assertIn("v1.2", result["action"])
        self.assertNotIn("suggested_environment", result)

    def test_result_errors_show_original_tool_cause_in_key_log(self):
        from news_local.progress import report_result_errors

        configure("key", self.stream)
        report_result_errors(
            [
                {
                    "node_id": "3110",
                    "stage": "normal",
                    "code": "workflow_tool_execution_failed",
                    "error_type": "ToolInvokeError",
                    "source_article_id": str(i),
                    "message": "fixture: invalid model configuration",
                }
                for i in range(25)
            ]
        )
        output = self.stream.getvalue()
        self.assertIn("节点=3110", output)
        self.assertIn("记录数=25", output)
        self.assertIn("invalid model configuration", output)
        self.assertEqual(len(output.splitlines()), 1)

    def test_timezone_independent_of_machine(self):
        record = logging.LogRecord("news_local", logging.INFO, "", 0, "测试", (), None)
        record.created = 0
        self.assertTrue(BeijingFormatter().format(record).startswith("1970-01-01T08:00:00+08:00"))

    def test_heartbeat_runs_in_key_mode_and_stops_on_exit(self):
        received = threading.Event()
        original = logging.getLogger("news_local.progress").info
        def record(*args, **kwargs):
            original(*args, **kwargs)
            if args and str(args[0]).startswith("处理中"):
                received.set()
        configure("key", self.stream)
        with patch("news_local.progress.LOG.info", side_effect=record):
            with DifyProgress(interval=0.01) as progress:
                self.assertTrue(received.wait(1))
            self.assertFalse(progress.thread.is_alive())
        self.assertIn("处理中｜当前动作已等待=", self.stream.getvalue())

    def test_cli_log_options_and_default(self):
        p = parser()
        self.assertFalse(hasattr(p.parse_args(["run"]), "log_level"))
        self.assertEqual(p.parse_args(["--log-level", "key", "run"]).log_level, "key")
        self.assertEqual(p.parse_args(["run", "--log-level", "detailed"]).log_level, "detailed")
        self.assertEqual(Settings.__dataclass_fields__["log_level"].default, "key")
        self.assertNotIn("serve", p.format_help())

    def test_real_sse_adapter_emits_node_events(self):
        events = [
            {
                "event": "workflow_started",
                "workflow_run_id": "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            },
            {"event": "node_started", "data": {"node_id": "1100", "title": "文章预处理"}},
            {
                "event": "node_finished",
                "data": {"node_id": "1100", "status": "failed", "error": ARRAY_ERROR},
            },
            {"event": "workflow_finished", "data": {"status": "failed", "error": ARRAY_ERROR}},
        ]
        wire = "".join("data: " + json.dumps(e) + "\n\n" for e in events).encode()
        client = DifyClient(Settings(None, None, None))
        ids = []
        with patch.object(client, "_request", return_value=io.BytesIO(wire)):
            result = client.start({}, ids.append)
        self.assertEqual(result["status"], "failed")
        self.assertIn("1100", self.stream.getvalue())
        self.assertEqual(ids, ["aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"])


class WorkflowConsoleTests(SystemCase):
    def test_array_limit_failure_is_diagnosed_without_db_commit_or_retry(self):
        with patch.object(
            self.client, "detail", return_value={"status": "failed", "error": ARRAY_ERROR}
        ):
            result = self.runner.run()
        self.assertEqual(result["status"], "FAILED")
        self.assertEqual(result["database"]["status"], "NOT_COMMITTED")
        self.assertEqual(result["diagnostic"]["reported_limit"], 30)
        self.assertEqual(result["diagnostic"]["output_variable"], "normal_article_jsons")
        self.assertEqual(self.repository.processing(result["run_id"])["total"], 0)
        self.assertEqual(self.client.posts, 1)
        self.assertEqual(self.runner.preview()["query"]["selected_count"], 8)
        self.assertEqual(self.store.load(result["run_id"])["diagnostic"], result["diagnostic"])

    def test_cli_progress_goes_to_stderr_final_json_to_stdout(self):
        config = self.root / "config.toml"
        config.write_text('source_db="collector.db"\nresult_db="collector.db"\nstate_dir="state"\n')
        stdout, stderr = io.StringIO(), io.StringIO()
        logger = logging.getLogger("news_local")
        saved = (logger.handlers[:], logger.level, logger.propagate)
        try:
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                main(["--config", str(config), "plan"])
            result = json.loads(stdout.getvalue())
            self.assertEqual(result["query"]["selected_count"], 8)
            self.assertNotIn("选入 1/25", stderr.getvalue())
            self.assertIn("选取完成", stderr.getvalue())
            self.assertIn("+08:00", stderr.getvalue())
            stdout.seek(0)
            stdout.truncate()
            stderr.seek(0)
            stderr.truncate()
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                main(["--config", str(config), "plan", "--log-level", "detailed"])
            self.assertIn("选入 1/25", stderr.getvalue())
            self.assertIn("选取完成", stderr.getvalue())
            self.assertEqual(json.loads(stdout.getvalue())["query"]["selected_count"], 8)
        finally:
            logger.handlers, logger.level, logger.propagate = saved

    def test_old_web_config_is_accepted_but_not_active(self):
        config = self.root / "config.toml"
        config.write_text(
            'source_db="collector.db"\nresult_db="collector.db"\nstate_dir="state"\n'
            'host="127.0.0.1"\nport=8765\nreviewer_id="old"\nlog_level="key"\n'
        )
        with self.assertLogs("news_local.config", "WARNING") as logs:
            settings = Settings.load(config)
        self.assertEqual(settings.log_level, "key")
        self.assertFalse(hasattr(settings, "host"))
        self.assertIn("忽略旧网页配置", logs.output[0])

    def test_no_diagnosis_for_unrelated_model_failure(self):
        self.assertIsNone(diagnose("model timeout"))


def load_tests(loader, tests, pattern):
    suite = loader.loadTestsFromTestCase(ConsoleCase)
    suite.addTests(
        WorkflowConsoleTests(name)
        for name in WorkflowConsoleTests.__dict__
        if name.startswith("test_")
    )
    return suite
