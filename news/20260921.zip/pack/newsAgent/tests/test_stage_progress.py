"""Stage mapping, concurrency, recovery and logging safety against recorded event shapes."""

import io
import json
import logging
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

from news_local.log_context import current_context, log_scope
from news_local.progress import DifyProgress, configure, input_counts, input_progress_meta, report_business_results
from news_local.workflow_stages import NODE_STAGES


class StageLogTests(unittest.TestCase):
    def setUp(self):
        self.logger = logging.getLogger('news_local')
        self.old = self.logger.handlers[:], self.logger.level, self.logger.propagate
        self.stream = io.StringIO()
        configure(stream=self.stream)

    def tearDown(self):
        self.logger.handlers, self.logger.level, self.logger.propagate = self.old

    @staticmethod
    def emit(progress, kind, node, **data):
        progress.event({'event': kind, 'data': {'node_id': node, **data}})

    def test_interleaved_branches_finish_independently(self):
        p = DifyProgress()
        with log_scope(batch_number=3):
            self.emit(p, 'node_started', '2000', id='digest')
            self.emit(p, 'node_started', '3000', id='normal')
            self.emit(p, 'node_finished', '2000', id='digest', status='succeeded')
            self.assertFalse(p.stages.states['normal'].ended)
            self.emit(p, 'node_finished', '3000', id='normal', status='succeeded')
        out = self.stream.getvalue()
        self.assertEqual(out.count(' 开始\n'), 2)
        self.assertEqual(out.count(' 完成｜状态='), 2)
        self.assertIn('[B003][S 2/6 资讯处理-快讯拆分与研判] 完成', out)
        self.assertIn('[B003][S 2/6 资讯处理-普通资讯筛选与抽取] 完成', out)
        self.assertNotIn('业务结果已校验', out)
        self.assertEqual(current_context(), {})

    def test_duplicate_execution_is_hidden_but_new_iteration_is_retained(self):
        configure('detailed', self.stream)
        p = DifyProgress()
        for execution in ('exec-a', 'exec-a', 'exec-b'):
            self.emit(p, 'node_started', '3110', id=execution)
        self.assertEqual(self.stream.getvalue().count('节点开始'), 2)
        # Without execution identity, two identical nodes can belong to different items.
        for _ in range(2):
            self.emit(p, 'node_started', '3110')
        self.assertEqual(self.stream.getvalue().count('节点开始'), 4)

    def test_retry_is_visible_and_does_not_turn_business_result_into_success(self):
        configure('key', self.stream)
        p = DifyProgress()
        self.emit(p, 'node_started', '3000')
        self.emit(p, 'node_retry', '3110', id='exec-a', error='timeout')
        self.emit(p, 'node_finished', '3110', id='exec-b', status='succeeded')
        self.emit(p, 'iteration_completed', '3000', status='succeeded')
        out = self.stream.getvalue()
        self.assertIn('状态=retry', out)
        self.assertIn('异常=1', out)
        self.assertNotIn('节点开始', out)
        self.assertNotIn('业务结果已校验', out)

    def test_missing_start_and_stream_interruption_are_not_success(self):
        configure('key', self.stream)
        with DifyProgress() as p:
            self.emit(p, 'node_finished', '2000', status='succeeded')
            self.emit(p, 'node_started', '3110')
        out = self.stream.getvalue()
        self.assertIn('缺少开始事件', out)
        self.assertIn('耗时=未知', out)
        self.assertIn('事件接收中断｜未收到阶段结束事件', out)
        self.assertEqual(out.count(' 完成｜状态='), 1)

    def test_workflow_end_does_not_invent_missing_stage_end(self):
        p = DifyProgress()
        self.emit(p, 'node_started', '3110')
        p.event({'event': 'workflow_finished', 'data': {'status': 'succeeded'}})
        p.stages.close(True)
        out = self.stream.getvalue()
        self.assertEqual(out.count('未收到阶段结束事件'), 1)
        self.assertNotIn(' 完成｜状态=', out)

    def test_empty_branch_is_skipped_only_with_known_input_count(self):
        p = DifyProgress(counts={'digest': 0, 'normal': 25})
        p.event({'event': 'workflow_started'})
        self.emit(p, 'iteration_started', '2000', iterator_length=0)
        self.emit(p, 'iteration_completed', '2000', status='succeeded')
        self.emit(p, 'node_started', '5000')
        self.emit(p, 'iteration_started', '5000', iterator_length=0)
        out = self.stream.getvalue()
        self.assertEqual(out.count('跳过｜输入=0'), 2)
        self.assertNotIn('[S 2/6 资讯处理-快讯拆分与研判] 开始', out)
        self.assertNotIn('普通资讯', out)

    def test_unknown_node_is_reported_once_without_payloads(self):
        p = DifyProgress()
        for kind in ('node_started', 'node_finished'):
            self.emit(p, kind, 'new-node', title='新节点\n伪造\x1b',
                      inputs={'content': 'private-body'}, outputs={'secret': 'private-secret'})
        out = self.stream.getvalue()
        self.assertEqual(out.count('未映射节点'), 1)
        self.assertIn('[未分类节点]', out)
        self.assertNotIn('private-', out)
        self.assertNotIn('\x1b', out)
        self.assertEqual(len(out.splitlines()), 1)

    def test_article_identity_is_never_guessed_from_index(self):
        configure('detailed', self.stream)
        p = DifyProgress()
        self.emit(p, 'iteration_next', '3000', index=2)
        self.assertNotIn('原文=', self.stream.getvalue())
        self.emit(p, 'node_started', '3110', source_article_id='0048083')
        self.assertIn('原文=0048083', self.stream.getvalue())

    def test_heartbeat_inherits_batch_context(self):
        signal = threading.Event()
        original = logging.getLogger('news_local.progress').info
        def record(*args, **kwargs):
            original(*args, **kwargs)
            signal.set()
        with log_scope(batch_number=4):
            with patch('news_local.progress.LOG.info', side_effect=record):
                with DifyProgress(interval=0.01) as p:
                    self.assertTrue(signal.wait(1))
        self.assertIn('[B004][远程执行] 处理中｜当前动作已等待=', self.stream.getvalue())
        self.assertFalse(p.thread.is_alive())
        self.assertEqual(current_context(), {})

    def test_iteration_item_context_propagates_to_child_nodes_and_structured_progress(self):
        configure('detailed', self.stream)
        articles = [
            {'source_article_id': 'a1', 'title': '普通资讯A'},
            {'source_article_id': 'a2', 'title': '普通资讯B'},
        ]
        meta = input_progress_meta({'articles_json': json.dumps(articles), 'digest_keywords': '日报,周报,快讯'})
        with tempfile.TemporaryDirectory() as tmp:
            progress_path = Path(tmp) / 'progress.jsonl'
            with log_scope(batch_number=12, run_id='run_' + 'a' * 32, progress_path=str(progress_path)):
                p = DifyProgress(counts=meta['counts'], items=meta['items'])
                self.emit(p, 'iteration_started', '3000', iterator_length=2)
                self.emit(p, 'iteration_next', '3000', index=0)
                self.emit(p, 'node_started', '3110', title='文章价值筛选')
                self.emit(p, 'node_finished', '3110', title='文章价值筛选', status='succeeded', elapsed_time=1.2)
                self.emit(p, 'node_started', '3190', title='汇总单篇处理结果')
                self.emit(p, 'node_finished', '3190', title='汇总单篇处理结果', status='succeeded', elapsed_time=0.1)
                self.emit(p, 'iteration_next', '3000', index=1)
                self.emit(p, 'node_started', '3110', title='文章价值筛选')
            out = self.stream.getvalue()
            self.assertIn('[B012][S 2/6 资讯处理-普通资讯筛选与抽取][文章1/2] 开始｜标题=普通资讯A', out)
            self.assertIn('[B012][S 2/6 资讯处理-普通资讯筛选与抽取][文章1/2][价值筛选] 节点开始', out)
            self.assertIn('[B012][S 2/6 资讯处理-普通资讯筛选与抽取][文章2/2] 开始｜标题=普通资讯B', out)
            records = [json.loads(line) for line in progress_path.read_text(encoding='utf-8').splitlines()]
            starts = [r for r in records if r['event'] == 'item_started']
            self.assertEqual([(r['item_index'], r['item_total']) for r in starts], [(1, 2), (2, 2)])
            self.assertEqual(starts[0]['stage_no'], 2)
            self.assertEqual(starts[0]['stage_total'], 6)
            self.assertEqual(starts[0]['item_id'], 'a1')

    def test_heartbeat_shows_current_item_and_action(self):
        signal = threading.Event()
        original = logging.getLogger('news_local.progress').info
        def record(*args, **kwargs):
            original(*args, **kwargs)
            if args and str(args[0]).startswith('处理中'):
                signal.set()
        meta = input_progress_meta({
            'articles_json': json.dumps([{'source_article_id': 'a1', 'title': '普通资讯A'}]),
            'digest_keywords': '日报,周报,快讯',
        })
        with log_scope(batch_number=9):
            with patch('news_local.progress.LOG.info', side_effect=record):
                with DifyProgress(interval=0.01, counts=meta['counts'], items=meta['items']) as p:
                    self.emit(p, 'iteration_started', '3000', iterator_length=1)
                    self.emit(p, 'iteration_next', '3000', index=0)
                    self.emit(p, 'node_started', '3110', title='文章价值筛选')
                    self.assertTrue(signal.wait(1))
        out = self.stream.getvalue()
        self.assertIn('[B009][S 2/6 资讯处理-普通资讯筛选与抽取][文章1/1][价值筛选] 处理中', out)

    def test_input_counts_use_shared_routing_without_printing_content(self):
        articles = [{'title': '安全简讯', 'content': 'secret'}, {'title': '普通新闻'}]
        self.assertEqual(input_counts({'articles_json': json.dumps(articles)}),
                         {'prepare': 2, 'digest': 1, 'normal': 1})
        self.assertEqual(input_counts({'articles_json': 'bad'}), {})
        self.assertEqual(self.stream.getvalue(), '')

    def test_business_counts_exclude_failed_decisions_and_digest_parent(self):
        rows = [
            dict(source_article_id='1', item_kind='normal', item_key='article', decision='KEEP', process_status='FAILED'),
            dict(source_article_id='2', item_kind='normal', item_key='article', decision='DROP', process_status='SUCCESS'),
            dict(source_article_id='3', item_kind='digest_parent', item_key='parent', decision=None, process_status='SUCCESS'),
            dict(source_article_id='3', item_kind='digest_child', item_key='item_001', decision='KEEP', process_status='SUCCESS'),
        ]
        report_business_results({'processing_items': rows, 'candidates': [], 'stats': {}})
        out = self.stream.getvalue()
        self.assertIn('[S 6/6 本地校验与入库][业务校验] 文章结果', out)
        self.assertIn('普通=2(失败1) KEEP=0/DROP=1/UNCERTAIN=0', out)
        self.assertIn('快讯=1(失败0) KEEP=1/DROP=0/UNCERTAIN=0', out)

    def test_all_deployed_nodes_have_stage_mapping(self):
        from pathlib import Path
        try:
            import yaml
        except ImportError:
            self.skipTest('PyYAML required for DSL mapping check')
        dsl = next((Path(__file__).resolve().parents[1] / 'dify').glob('00*.yml'))
        nodes = yaml.safe_load(dsl.read_text())['workflow']['graph']['nodes']
        self.assertEqual(set(NODE_STAGES), {n['id'] for n in nodes})

    def session_fixture(self):
        import test_session
        fixture = test_session.SessionTests()
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        return fixture

    def test_continuous_batches_and_recovery_keep_original_batch_labels(self):
        from news_local.errors import NewsError
        fixture = self.session_fixture()
        ingest = fixture.repository.ingest
        calls = 0
        def fail_second(bundle):
            nonlocal calls
            calls += 1
            if calls == 2:
                raise NewsError('fixture: database unavailable')
            return ingest(bundle)
        with patch.object(fixture.repository, 'ingest', side_effect=fail_second):
            paused = fixture.session.start()
        self.assertEqual(paused['status'], 'PAUSED')
        for number in (1, 2):
            self.assertIn(f'[B{number:03d}][S 1/6 批次准备与文章分流][本地准备] 批次开始', self.stream.getvalue())
        self.assertNotIn('[B002][S 6/6 本地校验与入库][业务校验]', self.stream.getvalue())
        self.stream.seek(0)
        self.stream.truncate()
        resumed = fixture.session.resume(paused['session_id'])
        self.assertEqual(resumed['status'], 'SUCCESS')
        out = self.stream.getvalue()
        self.assertIn('[B002][恢复处理] 恢复模式', out)
        self.assertIn('[B002][S 6/6 本地校验与入库][业务校验]', out)
        self.assertIn('[B003][S 1/6 批次准备与文章分流][本地准备] 批次开始', out)
        self.assertNotIn('[B004]', out)
        self.assertEqual(fixture.client.posts, 3)
        self.assertEqual(current_context(), {})

    def test_remote_running_does_not_claim_local_store_stage_started(self):
        from news_local.errors import PendingRun
        fixture = self.session_fixture()
        with self.assertRaises(PendingRun):
            fixture.runner._receive({}, {'status': 'running'})
        self.assertNotIn('[S 6/6 本地校验与入库]', self.stream.getvalue())
