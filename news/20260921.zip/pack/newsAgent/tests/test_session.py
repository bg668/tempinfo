"""Continuous processing against real temporary SQLite and a deterministic Dify double."""

import contextlib
import io
import json
import logging
import sqlite3
import tempfile
import unittest
import uuid
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from helpers import FakeDify, bundle_for, collector_db
from news_local.cli import main, parser
from news_local.collector import Collector
from news_local.config import Settings
from news_local.continuous import ContinuousTrigger
from news_local.errors import NewsError, PendingRun
from news_local.repository import Repository
from news_local.service import Runner
from news_local.session import SessionRunner
from news_local.state import RunStore


class Crash(BaseException):
    pass


class SessionDify(FakeDify):
    def __init__(self):
        super().__init__()
        self.inputs = []
        self.bundles = {}
        self.hook = None
        self.failed_sources = set()
        self.fail_all = False
        self.remote_failure = False
        self.hide_id = False

    def start(self, inputs, on_execution_id):
        self.posts += 1
        self.inputs.append(json.loads(inputs["articles_json"]))
        self.execution_id = str(uuid.uuid4())
        self.bundle = bundle_for(inputs)
        for row in self.bundle["processing_items"]:
            if self.fail_all or int(row["source_article_id"]) in self.failed_sources:
                row.update(process_status="FAILED", candidate_record_id=None,
                           errors_json=[{"stage": "triage", "code": "llm_execution_failed",
                                         "message": "fixture"}])
        cids = {r["candidate_record_id"] for r in self.bundle["processing_items"] if r["candidate_record_id"]}
        self.bundle["candidates"] = [r for r in self.bundle["candidates"] if r["candidate_record_id"] in cids]
        if any(r["process_status"] == "FAILED" for r in self.bundle["processing_items"]):
            self.bundle["process_status"] = "PARTIAL"
        self.bundles[self.execution_id] = self.bundle
        if not self.hide_id:
            on_execution_id(self.execution_id)
        if self.hook:
            self.hook(self)
        if self.hide_id:
            raise PendingRun("fixture: response lost before execution id")
        return self.detail(self.execution_id)

    def detail(self, execution_id):
        self.bundle = self.bundles[execution_id]
        if self.remote_failure:
            return {"status": "failed", "error": "fixture: invalid model configuration"}
        return super().detail(execution_id)


class SessionTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source = self.root / "collector.db"
        collector_db(self.source, count=63)
        self.settings = Settings(self.source, self.source, self.root / "state", api_key="test-secret")
        self.collector, self.repository = Collector(self.source), Repository(self.source)
        self.client, self.store = SessionDify(), RunStore(self.settings.state_dir)
        self.runner = Runner(self.settings, self.collector, self.repository, self.client, self.store)
        self.session = SessionRunner(self.runner)

    def session_id(self):
        return next((self.settings.state_dir / "sessions").iterdir()).name

    def submitted_ids(self):
        return [int(a["source_article_id"]) for batch in self.client.inputs for a in batch]

    def test_63_articles_are_25_25_13_and_new_round_skips_all(self):
        report = self.session.start()
        self.assertEqual(report["status"], "SUCCESS", report)
        self.assertEqual([len(a) for a in self.client.inputs], [25, 25, 13])
        self.assertEqual(report["submitted_count"], 63)
        self.assertEqual(report["completed_article_count"], 63)
        self.assertEqual(report["remaining_unexamined_count"], 0)
        self.assertEqual(len(set(self.submitted_ids())), 63)
        self.assertTrue(report["finished_at"].endswith("+08:00"))
        again = self.session.start()
        self.assertEqual(again["status"], "NO_WORK")
        self.assertEqual(again["excluded_completed_count"], 63)
        self.assertEqual(self.client.posts, 3)
        self.assertNotIn("test-secret", (self.session.store.directory(report["session_id"]) / "session.json").read_text())


    def test_run_forever_discards_only_unsubmitted_preparing_journal(self):
        run_id = "run_" + "a" * 32
        self.store.save({
            "run_id": run_id, "started_at": "2026-09-20T10:00:00+08:00",
            "phase": "PREPARING", "workflow_run_id": None, "grouping_mode": "singleton",
            "files": {}, "export_errors": [],
        })
        trigger = ContinuousTrigger(self.runner, interval_seconds=1)
        recovered = trigger.run_once()
        self.assertEqual(recovered["status"], "ABANDONED", recovered)
        self.assertTrue(recovered["recovered"])
        self.assertEqual(self.client.posts, 0)
        next_batch = trigger.run_once()
        self.assertEqual(next_batch["status"], "SUCCESS", next_batch)
        self.assertEqual(self.client.posts, 1)

    def test_run_forever_restart_resumes_ctrl_c_checkpoint(self):
        trigger = ContinuousTrigger(self.runner, interval_seconds=1)
        self.client.hook = lambda client: (_ for _ in ()).throw(KeyboardInterrupt())
        with self.assertRaises(KeyboardInterrupt):
            trigger.run_once()
        run = next(r for r in self.store.list() if r["phase"] not in {"COMPLETED", "FAILED", "ABANDONED"})
        self.assertEqual(run["phase"], "RUNNING")
        self.assertEqual(self.client.posts, 1)
        self.client.hook = None
        resumed = trigger.run_once()
        self.assertEqual(resumed["status"], "SUCCESS", resumed)
        self.assertTrue(resumed["recovered"])
        self.assertEqual(resumed["run_id"], run["run_id"])
        self.assertEqual(self.client.posts, 1)

    def test_run_forever_picks_up_article_committed_after_first_round(self):
        trigger = ContinuousTrigger(self.runner, interval_seconds=1)

        class StopAfterTwoWaits:
            def __init__(inner):
                inner.waits = 0
                inner.stopped = False

            def is_set(inner):
                return inner.stopped

            def wait(inner, _seconds):
                inner.waits += 1
                if inner.waits == 1:
                    with sqlite3.connect(self.source) as db:
                        db.execute(
                            "INSERT INTO feed_items SELECT 100,title,account,published_at,fetch_status "
                            "FROM feed_items WHERE id=1"
                        )
                        db.execute(
                            "INSERT INTO article_contents "
                            "SELECT 1100,100,title,account,published_at,fetched_at,content,url "
                            "FROM article_contents WHERE article_id=1"
                        )
                else:
                    inner.stopped = True
                return inner.stopped

        stopped = StopAfterTwoWaits()
        result = trigger.run_forever(stopped)
        self.assertEqual(result["status"], "STOPPED")
        # Backlog drains immediately; sleeping only happens once no work remains.
        self.assertGreaterEqual(result["cycle_count"], 5)
        self.assertIn(100, self.submitted_ids())
        self.assertEqual(self.submitted_ids().count(100), 1)

    def test_run_forever_recovers_unfinished_run_without_resubmitting_known_execution(self):
        trigger = ContinuousTrigger(self.runner, interval_seconds=1)
        self.client.pending = True
        first = trigger.run_once()
        self.assertEqual(first["status"], "WAITING")
        posts = self.client.posts
        self.client.pending = False
        resumed = trigger.run_once()
        self.assertEqual(resumed["status"], "SUCCESS", resumed)
        self.assertTrue(resumed["recovered"])
        self.assertEqual(resumed["run_id"], first["run_id"])
        self.assertEqual(self.client.posts, posts)

    def test_run_forever_replays_ambiguous_submit_with_same_run_id(self):
        trigger = ContinuousTrigger(self.runner, interval_seconds=1)
        self.client.hide_id = True
        first = trigger.run_once()
        self.assertEqual(first["status"], "WAITING", first)
        self.assertEqual(self.client.posts, 1)
        run_id = first["run_id"]
        self.client.hide_id = False
        resumed = trigger.run_once()
        self.assertEqual(resumed["status"], "SUCCESS", resumed)
        self.assertEqual(resumed["run_id"], run_id)
        self.assertEqual(self.client.posts, 2)
        self.assertEqual(self.store.load(run_id)["submit_attempt_count"], 2)

    def test_run_forever_batch_sequence_persists_across_trigger_restart(self):
        trigger = ContinuousTrigger(self.runner, interval_seconds=1)
        first = trigger.run_once()
        second = trigger.run_once()
        self.assertEqual((first['batch_number'], second['batch_number']), (1, 2))
        restarted = ContinuousTrigger(self.runner, interval_seconds=1)
        third = restarted.run_once()
        self.assertEqual(third['batch_number'], 3)
        self.assertEqual(self.store.load(third['run_id'])['batch_number'], 3)

    def test_run_forever_does_not_create_session_journals(self):
        trigger = ContinuousTrigger(self.runner, interval_seconds=1)
        while True:
            result = trigger.run_once()
            if result["status"] == "NO_WORK":
                break
        sessions = self.settings.state_dir / "sessions"
        self.assertFalse(sessions.exists() and list(sessions.glob("session_*/session.json")))
        self.assertEqual(self.client.posts, 3)

    def test_single_failure_does_not_reenter_this_round(self):
        self.client.failed_sources = {2}
        report = self.session.start()
        self.assertEqual(report["status"], "PARTIAL", report)
        self.assertEqual(report["completed_article_count"], 62)
        self.assertEqual(report["failed_article_count"], 1)
        self.assertEqual(self.submitted_ids().count(2), 1)
        with sqlite3.connect(self.source) as db:
            failure = db.execute("SELECT process_status,errors_json FROM processing_items WHERE source_article_id=2").fetchone()
        self.assertEqual(failure[0], "FAILED")
        self.assertIn("llm_execution_failed", failure[1])
        self.client.failed_sources.clear()
        again = self.session.start()
        self.assertEqual(again["submitted_count"], 0)
        self.assertEqual(again["excluded_completed_count"], 63)
        self.assertEqual(self.submitted_ids().count(2), 1)
        # Changed source content gets a new input hash and becomes eligible again.
        with sqlite3.connect(self.source) as db:
            db.execute("UPDATE article_contents SET content=content||'修订。' WHERE article_id=2")
        changed = self.session.start()
        self.assertEqual(changed["submitted_count"], 1)
        self.assertEqual(self.submitted_ids().count(2), 2)

    def test_all_article_failures_commit_and_finish_finite_round(self):
        self.client.fail_all = True
        report = self.session.start()
        self.assertEqual(report["phase"], "COMPLETED", report)
        self.assertEqual(report["status"], "FAILED")
        self.assertEqual(report["failed_article_count"], 63)
        self.assertEqual(self.client.posts, 3)

    def test_partial_digest_keeps_candidate_and_parent_is_attempted_once(self):
        def partial(client):
            rows = [r for r in client.bundle["processing_items"] if int(r["source_article_id"]) == 7]
            for row in rows:
                if row["item_kind"] == "digest_parent" or row["item_key"] == "item_002":
                    row.update(process_status="FAILED", errors_json=[{"code": "invalid_category"}])
            if rows:
                client.bundle["process_status"] = "PARTIAL"
        self.client.hook = partial
        report = self.session.start()
        self.assertEqual(report["status"], "PARTIAL", report)
        self.assertEqual(report["failed_article_count"], 1)
        self.assertEqual(self.submitted_ids().count(7), 1)
        with sqlite3.connect(self.source) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM processing_items WHERE source_article_id=7 AND candidate_record_id IS NOT NULL").fetchone()[0], 1)

    def test_same_source_changed_after_success_is_eligible_next_round(self):
        self.session.start()
        with sqlite3.connect(self.source) as db:
            db.execute("UPDATE article_contents SET content=content||'补充调查。' WHERE article_id=2")
        report = self.session.start()
        self.assertEqual(report["submitted_count"], 1)
        self.assertEqual(self.submitted_ids().count(2), 2)

    def test_malformed_result_stops_before_other_batches_and_db_commit(self):
        self.client.hook = lambda client: client.bundle.update(run_id="run_" + "f" * 32)
        report = self.session.start()
        self.assertEqual(report["status"], "PAUSED", report)
        self.assertEqual(report["batch_count"], 0)
        self.assertEqual(self.client.posts, 1)
        with sqlite3.connect(self.source) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM processing_items").fetchone()[0], 0)

    def test_unknown_post_crash_without_id_never_resubmits_automatically(self):
        self.client.hide_id = True
        self.client.hook = lambda client: (_ for _ in ()).throw(Crash())
        with self.assertRaises(Crash):
            self.session.start()
        self.client.hook = None
        report = self.session.resume(self.session_id())
        self.assertEqual(report["status"], "PAUSED")
        self.assertEqual(self.client.posts, 1)

    def test_existing_unfinished_single_batch_blocks_new_session(self):
        self.client.pending = True
        self.runner.run()
        with self.assertRaises(NewsError):
            self.session.start()

    def test_invalid_sources_recorded_once_without_blocking_other_batches(self):
        with sqlite3.connect(self.source) as db:
            db.execute("UPDATE article_contents SET content='' WHERE article_id=1")
            db.execute("UPDATE article_contents SET published_at='bad' WHERE article_id=2")
        report = self.session.start()
        self.assertEqual(report["status"], "PARTIAL", report)
        self.assertEqual(report["input_quality_error_count"], 2)
        self.assertEqual(report["submitted_count"], 61)
        with sqlite3.connect(self.source) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM processing_items WHERE item_key='input_error'").fetchone()[0], 2)
        self.assertEqual(report["query"]["invalid_time_count"], 1)

    def test_only_invalid_input_is_saved_without_model_call(self):
        with sqlite3.connect(self.source) as db:
            db.execute("UPDATE article_contents SET content=''")
        report = self.session.start()
        self.assertEqual(report["status"], "FAILED", report)
        self.assertEqual(report["input_quality_error_count"], 63)
        self.assertEqual(report["processing_item_count"], 63)
        self.assertEqual(self.client.posts, 0)

    def test_empty_scope_is_no_work(self):
        self.runner.settings = replace(self.settings, accounts=("不存在的媒体",))
        report = self.session.start()
        self.assertEqual(report["status"], "NO_WORK")
        self.assertEqual(report["batch_count"], 0)
        self.assertEqual(self.client.posts, 0)

    def test_new_articles_are_deferred_to_next_session(self):
        def insert(client):
            client.hook = None
            with sqlite3.connect(self.source) as db:
                db.execute("INSERT INTO feed_items SELECT 100,title,account,published_at,fetch_status FROM feed_items WHERE id=1")
                db.execute("INSERT INTO article_contents SELECT 1100,100,title,account,published_at,fetched_at,content,url FROM article_contents WHERE article_id=1")
        self.client.hook = insert
        self.assertEqual(self.session.start()["submitted_count"], 63)
        self.assertNotIn(100, self.submitted_ids())
        self.assertEqual(self.session.start()["submitted_count"], 1)

    def test_changed_source_outside_scope_is_counted_as_deferred(self):
        def change(client):
            client.hook = None
            unselected = next(sid for sid in range(1, 64) if sid not in self.submitted_ids())
            with sqlite3.connect(self.source) as db:
                db.execute("UPDATE article_contents SET fetched_at='2099-01-01T00:00:00+08:00' WHERE article_id=?", (unselected,))
        self.client.hook = change
        report = self.session.start()
        self.assertEqual(report["status"], "PARTIAL", report)
        self.assertEqual(report["deferred_article_count"], 1)
        self.assertEqual(report["submitted_count"], 62)

    def test_disconnect_resumes_original_post_then_remaining_batches(self):
        self.client.pending = True
        report = self.session.start()
        self.assertEqual(report["status"], "PAUSED")
        self.assertEqual(report["remaining_unexamined_count"], 38)
        with self.assertRaises(NewsError):
            self.runner.run()
        with self.assertRaises(NewsError):
            self.session.start()
        with self.assertRaises(NewsError):
            self.session.abandon(report["session_id"])
        self.client.pending = False
        resumed = self.session.resume(report["session_id"])
        self.assertEqual(resumed["status"], "SUCCESS", resumed)
        self.assertEqual(self.client.posts, 3)
        self.assertEqual(resumed["completed_article_count"], 63)
        repeated = self.session.resume(report["session_id"])
        self.assertEqual(repeated["processing_item_count"], resumed["processing_item_count"])
        self.assertEqual(self.client.posts, 3)

    def test_missing_remote_id_requires_explicit_binding(self):
        self.client.hide_id = True
        report = self.session.start()
        still = self.session.resume(report["session_id"])
        self.assertEqual(still["status"], "PAUSED")
        self.assertEqual(self.client.posts, 1)
        execution_id = self.client.execution_id
        self.client.hide_id = False
        resumed = self.session.resume(report["session_id"], execution_id)
        self.assertEqual(resumed["status"], "SUCCESS", resumed)
        self.assertEqual(self.client.posts, 3)

    def test_database_failure_pauses_and_resume_does_not_repost(self):
        with patch.object(self.repository, "ingest", side_effect=NewsError("database unavailable")):
            report = self.session.start()
        self.assertEqual(report["status"], "PAUSED")
        self.assertEqual(self.session.resume(report["session_id"])["status"], "SUCCESS")
        self.assertEqual(self.client.posts, 3)

    def test_crash_after_db_commit_reconciles_without_duplicate_rows(self):
        original = self.repository.ingest
        def commit_then_crash(bundle):
            original(bundle)
            raise Crash()
        with patch.object(self.repository, "ingest", side_effect=commit_then_crash):
            with self.assertRaises(Crash):
                self.session.start()
        report = self.session.resume(self.session_id())
        self.assertEqual(report["status"], "SUCCESS", report)
        self.assertEqual(self.client.posts, 3)
        with sqlite3.connect(self.source) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM processing_items").fetchone()[0], report["processing_item_count"])
            self.assertEqual(db.execute("SELECT count(*) FROM candidates").fetchone()[0], report["candidate_count"])

    def test_crash_before_session_checkpoint_reconciles_completed_batch(self):
        original = self.session.store.save
        def crash_on_ack(session):
            if session["segments"]:
                raise Crash()
            original(session)
        with patch.object(self.session.store, "save", side_effect=crash_on_ack):
            with self.assertRaises(Crash):
                self.session.start()
        report = self.session.resume(self.session_id())
        self.assertEqual(report["completed_article_count"], 63, report)
        self.assertEqual(self.client.posts, 3)

    def test_failed_checkpoint_write_does_not_advance_memory_only(self):
        original = self.session.store.save
        failed = False
        def fail_once(session):
            nonlocal failed
            if session["segments"] and not failed:
                failed = True
                raise OSError("disk temporarily unavailable")
            original(session)
        with patch.object(self.session.store, "save", side_effect=fail_once):
            report = self.session.start()
        self.assertEqual(report["status"], "PAUSED")
        self.assertEqual(report["batch_count"], 0)
        report = self.session.resume(report["session_id"])
        self.assertEqual(report["completed_article_count"], 63)
        self.assertEqual(self.client.posts, 3)

    def test_reservation_before_run_survives_crash(self):
        with patch.object(self.runner, "_run_locked", side_effect=Crash):
            with self.assertRaises(Crash):
                self.session.start()
        report = self.session.resume(self.session_id())
        self.assertEqual(report["status"], "SUCCESS", report)
        self.assertEqual(self.client.posts, 3)

    def test_preparing_and_prepared_crashes_are_safe_to_start(self):
        for phase in ("PREPARING", "PREPARED"):
            with self.subTest(phase=phase):
                # Isolate the two recovery paths with new journals/results.
                self.runner.store = RunStore(self.root / phase)
                self.runner.repository = Repository(self.root / (phase + ".db"))
                session = SessionRunner(self.runner)
                original = self.runner.store.save
                def crash(run):
                    original(run)
                    if run["phase"] == phase:
                        raise Crash()
                before = self.client.posts
                with patch.object(self.runner.store, "save", side_effect=crash):
                    with self.assertRaises(Crash):
                        session.start()
                sid = next((self.runner.store.root / "sessions").iterdir()).name
                report = session.resume(sid)
                self.assertEqual(report["status"], "SUCCESS", report)
                self.assertEqual(self.client.posts - before, 3)

    def test_remote_failure_pauses_then_explicit_abandon_allows_new_round(self):
        self.client.remote_failure = True
        report = self.session.start()
        self.assertEqual(report["status"], "PAUSED")
        self.assertEqual(self.client.posts, 1)
        self.assertEqual(self.session.resume(report["session_id"])["status"], "PAUSED")
        self.assertEqual(self.client.posts, 1)
        self.session.abandon(report["session_id"])
        self.client.remote_failure = False
        self.assertEqual(self.session.start()["status"], "SUCCESS")

    def test_diagnostic_without_environment_advice_still_pauses(self):
        with patch.object(self.client, "detail", return_value={
            "status": "failed",
            "error": "The length of output variable `errors` must be less than 30 elements.",
        }):
            report = self.session.start()
        self.assertEqual(report["status"], "PAUSED", report)
        self.assertEqual(self.client.posts, 1)

    def test_csv_failure_continues_and_export_recovery_does_not_recount(self):
        self.client.csv_failure = True
        report = self.session.start()
        self.assertEqual(report["status"], "PARTIAL", report)
        self.assertEqual(len(report["export_errors"]), 3)
        self.client.csv_failure = False
        for run_id in report["run_ids"]:
            self.runner.resume(run_id)
        refreshed = self.session.status(report["session_id"])
        self.assertEqual(refreshed["status"], "SUCCESS", refreshed)
        self.assertEqual(refreshed["processing_item_count"], report["processing_item_count"])
        self.assertEqual(refreshed["candidate_count"], report["candidate_count"])
        self.assertEqual(self.client.posts, 3)

    def test_keyboard_interrupt_preserves_active_remote_task(self):
        self.client.hook = lambda client: (_ for _ in ()).throw(KeyboardInterrupt())
        report = self.session.start()
        self.assertEqual(report["stop_reason"], "interrupted")
        self.client.hook = None
        self.assertEqual(self.session.resume(report["session_id"])["status"], "SUCCESS")
        self.assertEqual(self.client.posts, 3)

    def test_corrupt_scope_or_reservation_blocks_resume_without_post(self):
        self.client.pending = True
        report = self.session.start()
        directory = self.session.store.directory(report["session_id"])
        state = self.session.store.load(report["session_id"])
        for name in ("scope.json", state["active"]["snapshot"]):
            path = directory / name
            data = path.read_bytes()
            path.write_bytes(data + b" ")
            resumed = self.session.resume(report["session_id"])
            self.assertEqual(resumed["status"], "PAUSED")
            self.assertIn("快照已改变", resumed["error"])
            self.assertEqual(self.client.posts, 1)
            path.write_bytes(data)

    def test_changed_config_blocks_resume_but_transport_settings_can_change(self):
        self.client.pending = True
        report = self.session.start()
        self.runner.settings = replace(self.settings, batch_size=10)
        with self.assertRaises(NewsError):
            self.session.resume(report["session_id"])
        self.runner.settings = replace(self.settings, io_timeout=120, log_level="key")
        self.client.pending = False
        self.assertEqual(self.session.resume(report["session_id"])["status"], "SUCCESS")

    def test_force_is_finite_and_lock_is_shared(self):
        self.session.start()
        report = self.session.start(force=True)
        self.assertEqual(report["submitted_count"], 63)
        self.assertEqual(self.client.posts, 6)
        with self.store.lock():
            with self.assertRaises(NewsError):
                self.session.start()

    def test_cli_continuous_commands_and_json_output(self):
        self.assertEqual(parser().parse_args(["run-all", "--limit", "25"]).limit, 25)
        self.assertEqual(parser().parse_args(["resume-all", "session_test"]).session_id, "session_test")
        config = self.root / "config.toml"
        config.write_text('source_db="collector.db"\nresult_db="collector.db"\nstate_dir="state"\n')
        stdout, stderr = io.StringIO(), io.StringIO()
        logger = logging.getLogger("news_local")
        saved = (logger.handlers[:], logger.level, logger.propagate)
        try:
            with (patch("news_local.cli.DifyClient", return_value=self.client),
                  patch.dict("os.environ", {"DIFY_API_KEY": "test-secret"}),
                  contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr)):
                main(["--config", str(config), "run-all", "--log-level", "key"])
            report = json.loads(stdout.getvalue())
            self.assertEqual(report["status"], "SUCCESS", report)
            self.assertIn("累计进度", stderr.getvalue())
            self.assertIn("+08:00", stderr.getvalue())
            self.assertNotIn("test-secret", stderr.getvalue())
        finally:
            logger.handlers, logger.level, logger.propagate = saved
