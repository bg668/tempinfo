import io
import json
import sqlite3
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from helpers import FakeDify, collector_db

from news_local.collector import Collector
from news_local.config import Settings
from news_local.contracts import validate_bundle
from news_local.dify_client import sse_events
from news_local.errors import ConflictError, ContractError, NewsError
from news_local.planner import select_batch
from news_local.repository import Repository
from news_local.review import review_changes
from news_local.service import Runner
from news_local.state import RunStore
from news_local.timeutils import normalize_time


class SystemCase(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source = self.root / "collector.db"
        collector_db(self.source)
        self.settings = Settings(self.source, self.source, self.root / "state", api_key="test-key")
        self.collector, self.repository = Collector(self.source), Repository(self.source)
        self.repository.initialize()
        self.client, self.store = FakeDify(), RunStore(self.settings.state_dir)
        self.runner = Runner(
            self.settings, self.collector, self.repository, self.client, self.store
        )

    def successful_run(self):
        report = self.runner.run()
        self.assertEqual(report["status"], "SUCCESS", report)
        run = self.store.load(report["run_id"])
        raw = json.loads((self.store.directory(report["run_id"]) / "result.json").read_text())
        return report, run, raw

    def test_time_naive_and_utc_same_instant(self):
        self.assertEqual(
            normalize_time("2026-08-17T13:28:19.472141"),
            normalize_time("2026-08-17T05:28:19.472141+00:00"),
        )
        self.assertTrue(normalize_time("2026-08-07T19:53:42").startswith("2026-08-07T19:53:42"))
        with self.assertRaises(ValueError):
            normalize_time("2026-08-07")

    def test_source_id_uses_parent_not_content_row_id(self):
        plan = self.runner.preview()
        self.assertEqual({a["source_id"] for a in plan["articles"]}, set(range(1, 9)))

    def test_first_run_and_success_drop_uncertain_are_skipped(self):
        report, _, _ = self.successful_run()
        self.assertGreater(report["decisions"]["DROP"], 0)
        self.assertGreater(report["decisions"]["UNCERTAIN"], 0)
        again = self.runner.run()
        self.assertEqual(again["status"], "NO_WORK")
        self.assertEqual(self.client.posts, 1)

    def test_exclude_before_limit(self):
        settings = replace(self.settings, batch_size=3)
        runner = Runner(settings, self.collector, self.repository, self.client, self.store)
        first = runner.run()
        selected = select_batch(self.collector, self.repository, settings)
        self.assertEqual(len(selected.articles), 3)
        self.assertEqual(selected.query["excluded_completed_count"], 3)
        self.assertEqual(first["query"]["selected_count"], 3)

    def test_content_change_reenters_queue(self):
        self.successful_run()
        with sqlite3.connect(self.source) as db:
            db.execute(
                "UPDATE article_contents SET content=content||'新增调查结果。' WHERE article_id=1"
            )
        self.assertEqual([a["source_id"] for a in self.runner.preview()["articles"]], [1])

    def test_digest_business_failure_is_terminal_but_damaged_success_is_not(self):
        self.successful_run()
        with sqlite3.connect(self.source) as db:
            db.execute(
                "UPDATE processing_items SET process_status='FAILED' "
                "WHERE source_article_id=7 AND item_key='item_002'"
            )
        # A persisted business failure is terminal; do not poison-loop it.
        self.assertEqual([a["source_id"] for a in self.runner.preview()["articles"]], [])
        with sqlite3.connect(self.source) as db:
            db.execute("DELETE FROM processing_items WHERE source_article_id=7 AND item_kind='digest_child'")
            db.execute(
                "UPDATE processing_items SET process_status='SUCCESS' "
                "WHERE source_article_id=7 AND item_kind='digest_parent'"
            )
        # A successful digest parent without any children is structurally incomplete.
        self.assertEqual([a["source_id"] for a in self.runner.preview()["articles"]], [7])

    def test_duplicate_ingest_preserves_review_feedback_and_json_null(self):
        report, _, _ = self.successful_run()
        row = self.repository.candidates()["items"][0]
        reviewed = self.repository.review(
            row["candidate_record_id"], "starred", row["updated_at"]
        )
        feedback = self.repository.create_feedback(
            "feedback-1", "candidate", row["candidate_record_id"], "  保留这条候选  "
        )
        result = self.runner.reingest(report["run_id"])
        self.assertEqual(result["candidates_inserted"], 0)
        kept = self.repository.candidate_detail(row["candidate_record_id"])["candidate"]
        self.assertEqual(kept["review_status"], "starred")
        self.assertEqual(kept["reviewer_id"], "root")
        self.assertEqual(kept["reviewed_at"], reviewed["reviewed_at"])
        self.assertEqual(
            self.repository.feedback_for_target("candidate", row["candidate_record_id"])["items"][0],
            feedback,
        )
        self.assertIsNone(kept["ioc_json"])
        self.assertEqual(kept["excluded_iocs_json"], [])
        self.assertTrue(kept["created_at"].endswith("+08:00"))

    def test_review_optimistic_conflict_and_same_status_idempotency(self):
        self.successful_run()
        row = self.repository.candidates()["items"][0]
        starred = self.repository.review(row["candidate_record_id"], "starred", row["updated_at"])
        repeated = self.repository.review(row["candidate_record_id"], "starred", row["updated_at"])
        self.assertEqual(repeated["updated_at"], starred["updated_at"])
        self.assertEqual(repeated["reviewed_at"], starred["reviewed_at"])
        self.assertEqual(repeated["reviewer_id"], "root")
        with self.assertRaises(ConflictError):
            self.repository.review(row["candidate_record_id"], "ignored", row["updated_at"])


    def test_feedback_candidate_and_processing_item_are_exact_and_appendable(self):
        report, _, _ = self.successful_run()
        candidate = self.repository.candidates()["items"][0]
        item = self.repository.processing(report["run_id"])["items"][0]
        first = self.repository.create_feedback(
            "feedback-candidate-1", "candidate", candidate["candidate_record_id"], "  候选反馈  "
        )
        second = self.repository.create_feedback(
            "feedback-candidate-2", "candidate", candidate["candidate_record_id"], "第二条"
        )
        child = self.repository.create_feedback(
            "feedback-item-1", "processing_item", item["item_id"], "处理项反馈"
        )
        self.assertEqual(first["content"], "候选反馈")
        self.assertTrue(first["created_at"].endswith("+08:00"))
        target = self.repository.feedback_for_target("candidate", candidate["candidate_record_id"])
        self.assertEqual(target["total"], 2)
        self.assertEqual({v["feedback_id"] for v in target["items"]}, {first["feedback_id"], second["feedback_id"]})
        self.assertEqual(
            self.repository.feedback_for_target("processing_item", item["item_id"])["items"][0],
            child,
        )
        self.assertEqual(self.repository.feedback(limit=1)["total"], 3)
        self.assertEqual(len(self.repository.feedback(limit=1)["items"]), 1)

    def test_feedback_retry_is_idempotent_and_changed_payload_conflicts(self):
        self.successful_run()
        candidate = self.repository.candidates()["items"][0]
        args = ("feedback-retry", "candidate", candidate["candidate_record_id"], "同一内容")
        first = self.repository.create_feedback(*args)
        repeated = self.repository.create_feedback(*args)
        self.assertEqual(repeated, first)
        self.assertEqual(self.repository.feedback()["total"], 1)
        with self.assertRaises(ConflictError):
            self.repository.create_feedback(
                "feedback-retry", "candidate", candidate["candidate_record_id"], "不同内容"
            )

    def test_feedback_validation_rejects_dangling_blank_and_oversized(self):
        self.successful_run()
        candidate = self.repository.candidates()["items"][0]
        with self.assertRaises(NewsError):
            self.repository.create_feedback("x", "candidate", "missing", "text")
        with self.assertRaises(NewsError):
            self.repository.create_feedback("x", "unknown", candidate["candidate_record_id"], "text")
        with self.assertRaises(NewsError):
            self.repository.create_feedback("x", "candidate", candidate["candidate_record_id"], "   ")
        with self.assertRaises(NewsError):
            self.repository.create_feedback(
                "x", "candidate", candidate["candidate_record_id"], "a" * 5001
            )

    def test_wrong_batch_hash_score_and_missing_source_rejected(self):
        report, run, raw = self.successful_run()
        for mutation in (
            lambda b: b.update(run_id="run_" + "f" * 32),
            lambda b: b["processing_items"][0].update(input_hash="wrong"),
            lambda b: b["candidates"][0].update(total_score=1),
            lambda b: b["processing_items"].pop(),
        ):
            altered = json.loads(json.dumps(raw))
            mutation(altered)
            if len(altered["processing_items"]) == len(raw["processing_items"]) - 1:
                altered["processing_items"] = [
                    r for r in altered["processing_items"] if r["source_article_id"] != "1"
                ]
            with self.assertRaises(ContractError):
                validate_bundle(altered, report["run_id"], run["plan"]["articles"])

    def test_shared_candidates_allows_web_review_version_column(self):
        with sqlite3.connect(self.source) as db:
            db.execute("ALTER TABLE candidates ADD COLUMN review_version INTEGER")

        # Repeated initialization must tolerate Web-owned nullable extension columns.
        self.repository.initialize()
        self.repository.initialize()
        report, _, _ = self.successful_run()
        with sqlite3.connect(self.source) as db:
            row = db.execute(
                "SELECT review_version FROM candidates WHERE run_id=? LIMIT 1",
                (report["run_id"],),
            ).fetchone()
        self.assertIsNotNone(row)
        self.assertIsNone(row[0])

    def test_legacy_review_constraint_migration_preserves_web_extension(self):
        target_path = self.root / "legacy-web-extension.db"
        schema = Path(__file__).parents[1] / "src" / "news_local" / "schema.sql"
        text = schema.read_text(encoding="utf-8")
        start = text.index("CREATE TABLE IF NOT EXISTS candidates (")
        end = text.index("\n);", start) + len("\n);")
        candidate_sql = text[start:end].replace(
            "'pending','starred','ignored'",
            "'pending','accepted','rejected','deferred'",
        )
        candidate_sql = candidate_sql.replace(
            "    UNIQUE (run_id, candidate_id),",
            "    review_version INTEGER DEFAULT 0,\n    UNIQUE (run_id, candidate_id),",
            1,
        )
        with sqlite3.connect(target_path) as db:
            db.executescript(candidate_sql)

        target = Repository(target_path)
        target.initialize()
        with sqlite3.connect(target_path) as db:
            columns = {row[1] for row in db.execute("PRAGMA table_info(candidates)")}
            create_sql = db.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='candidates'"
            ).fetchone()[0]
        self.assertIn("review_version", columns)
        self.assertIn("'starred'", create_sql)
        self.assertNotIn("'accepted'", create_sql)

    def test_shared_table_rejects_unfillable_extra_column(self):
        target = Repository(self.root / "blocking-extra.db")
        target.initialize()
        with sqlite3.connect(target.path) as db:
            # SQLite permits this on an empty table, but later explicit-column INSERTs cannot fill it.
            db.execute("ALTER TABLE candidates ADD COLUMN web_required INTEGER NOT NULL")
        with self.assertRaises(NewsError):
            target.initialize()

    def test_transaction_rolls_back_both_tables(self):
        report, run, raw = self.successful_run()
        target = Repository(self.root / "separate.db")
        target.initialize()
        bundle = validate_bundle(raw, report["run_id"], run["plan"]["articles"])
        bundle["candidates"][0]["primary_item_id"] = "missing"
        with self.assertRaises(NewsError):
            target.ingest(bundle)
        with sqlite3.connect(target.path) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM processing_items").fetchone()[0], 0)
            self.assertEqual(db.execute("SELECT count(*) FROM candidates").fetchone()[0], 0)

    def test_disconnect_resume_never_posts_twice(self):
        self.client.pending = True
        report = self.runner.run()
        self.assertEqual(report["status"], "WAITING")
        with self.assertRaises(NewsError):
            self.runner.run()
        self.client.pending = False
        resumed = self.runner.resume(report["run_id"])
        self.assertEqual(resumed["status"], "SUCCESS", resumed)
        self.assertEqual(self.client.posts, 1)

    def test_db_failure_retries_only_local_ingest(self):
        original = self.repository.ingest
        self.repository.ingest = lambda bundle: (_ for _ in ()).throw(NewsError("数据库暂时不可写"))
        report = self.runner.run()
        self.assertEqual(report["status"], "NEEDS_RECOVERY")
        self.repository.ingest = original
        self.assertEqual(self.runner.resume(report["run_id"])["status"], "SUCCESS")
        self.assertEqual(self.client.posts, 1)

    def test_placeholder_failure_not_fake_drop(self):
        with sqlite3.connect(self.source) as db:
            db.execute(
                "UPDATE article_contents SET content='「点击可全屏观看」' WHERE article_id=1"
            )
        report = self.runner.run()
        self.assertEqual(report["status"], "PARTIAL", report)
        self.assertEqual(report["input_quality_error_count"], 1)
        rows = self.repository.processing(report["run_id"])["items"]
        invalid = next(r for r in rows if r["source_article_id"] == 1)
        self.assertEqual(invalid["process_status"], "FAILED")
        self.assertIsNone(invalid["decision"])
        self.assertIsNotNone(invalid["input_hash"])
        self.assertEqual(invalid["input_meta_json"]["hash_basis"], "raw_collector_record_v1")
        # Deterministic local failures are terminal for this exact source state.
        self.assertEqual(self.runner.preview()["articles"], [])
        self.assertEqual(self.runner.preview()["rejected"], [])
        with sqlite3.connect(self.source) as db:
            db.execute(
                "UPDATE article_contents SET content='正文已经补抓完成。' WHERE article_id=1"
            )
        self.assertEqual([a["source_id"] for a in self.runner.preview()["articles"]], [1])

    def test_csv_failure_does_not_claim_full_success(self):
        self.client.csv_failure = True
        report = self.runner.run()
        self.assertEqual(report["status"], "PARTIAL")
        self.assertEqual(report["database"]["status"], "SUCCESS")

    def test_csv_retry_does_not_rerun_model(self):
        self.client.csv_failure = True
        report = self.runner.run()
        self.client.csv_failure = False
        resumed = self.runner.resume(report["run_id"])
        self.assertEqual(resumed["status"], "SUCCESS", resumed)
        self.assertEqual(self.client.posts, 1)
        self.assertEqual(resumed["database"]["candidates_inserted"], 0)

    def test_corrupted_local_result_is_not_reingested(self):
        report, _, _ = self.successful_run()
        path = self.store.directory(report["run_id"]) / "bundle.validated.json"
        path.write_text(path.read_text() + " ")
        with self.assertRaises(NewsError):
            self.runner.reingest(report["run_id"])

    def test_run_listing_does_not_load_article_bodies(self):
        report, _, _ = self.successful_run()
        metadata = self.store.list()[0]
        self.assertNotIn("plan", metadata)
        self.assertNotIn("inputs", metadata)
        run = self.store.load(report["run_id"])
        self.assertIn("content", run["plan"]["articles"][0]["payload"])

    def test_corrupted_input_snapshot_blocks_resume(self):
        self.client.pending = True
        report = self.runner.run()
        path = self.store.directory(report["run_id"]) / "input.json"
        path.write_text(path.read_text() + " ")
        with self.assertRaises(NewsError):
            self.runner.resume(report["run_id"])

    def test_summary_write_failure_preserves_committed_database_status(self):
        from unittest.mock import patch

        from news_local.state import atomic_json

        def write(path, value):
            if path.name == "summary.json":
                raise OSError("synthetic summary failure")
            atomic_json(path, value)

        with patch("news_local.service.atomic_json", write):
            report = self.runner.run()
        self.assertEqual(report["status"], "NEEDS_RECOVERY")
        self.assertEqual(report["database"]["status"], "SUCCESS")
        self.assertEqual(self.runner.resume(report["run_id"])["status"], "SUCCESS")
        self.assertEqual(self.client.posts, 1)

    def test_capacity_error_does_not_post_or_shrink(self):
        runner = Runner(
            replace(self.settings, max_input_chars=10),
            self.collector,
            self.repository,
            self.client,
            self.store,
        )
        self.assertEqual(runner.run()["status"], "FAILED")
        self.assertEqual(self.client.posts, 0)

    def test_single_runner_lock(self):
        with self.store.lock():
            with self.assertRaises(NewsError):
                with self.store.lock():
                    pass

    def test_review_rejects_ai_fields_identity_override_and_legacy_states(self):
        for key in ("title", "total_score", "reviewer_id", "review_comment"):
            with self.assertRaises(ContractError):
                review_changes(
                    {"review_status": "starred", "expected_updated_at": "now", key: "fake"}
                )
        for status in ("accepted", "rejected", "deferred"):
            with self.assertRaises(ContractError):
                review_changes({"review_status": status, "expected_updated_at": "now"})

    def test_sse_comments_crlf_multiline(self):
        stream = io.BytesIO(
            b': heartbeat\r\ndata: {"event":\r\ndata: "ping"}\r\n\r\ndata: [DONE]\n\n'
        )
        events = list(sse_events(stream))
        self.assertEqual(json.loads(events[0])["event"], "ping")
        self.assertEqual(events[1], "[DONE]")

    def test_config_paths_are_relative_to_file(self):
        config = self.root / "config.toml"
        config.write_text('source_db="collector.db"\nresult_db="out.db"\nstate_dir="state"\n')
        settings = Settings.load(config)
        self.assertEqual(settings.source_db, self.source)

    def test_50_articles_same_batch(self):
        source = self.root / "fifty.db"
        collector_db(source, 60)
        settings = replace(self.settings, batch_size=50, source_db=source, result_db=source)
        runner = Runner(settings, Collector(source), Repository(source), self.client, self.store)
        result = runner.run()
        self.assertEqual(result["status"], "SUCCESS", result)
        self.assertEqual(result["submitted_count"], 50)
        self.assertEqual(self.client.posts, 1)
        self.assertEqual(result["completed_article_count"], 50)


if __name__ == "__main__":
    unittest.main()
