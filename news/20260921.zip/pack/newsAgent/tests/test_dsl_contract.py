"""The DSL builder is optional; these tests require its PyYAML development dependency."""

import hashlib
import json
import unittest
from pathlib import Path

from news_local.article_contract import canonical_json
from news_local.normalize import prepare_article

try:
    import yaml
except ImportError:
    yaml = None


@unittest.skipIf(yaml is None, "Install PyYAML to check DSL contracts")
class DslContractTests(unittest.TestCase):
    def test_shared_digest_routing_preserves_hash_and_explicit_configuration(self):
        from news_local.article_contract import parse_digest_keywords
        from news_local.config import Settings

        root = Path(__file__).resolve().parents[1]
        doc = yaml.safe_load(next((root / "dify").glob("00*.yml")).read_text())
        ns = {}
        exec(next(n['data']['code'] for n in doc['workflow']['graph']['nodes'] if n['id'] == '1100'), ns)
        row = {
            'article_id': 48285, 'title': '安全简讯（2026.08.27）', 'account': '示例媒体',
            'url': 'https://example.com/48285', 'published_at': '2026-08-27T18:00:00+08:00',
            'fetched_at': '2026-08-27T18:30:00+08:00', 'content': '1. 某公司披露攻击事件\n原文正文',
        }
        self.assertIn('安全简讯', Settings(None, None, None).digest_keywords)
        start = next(n['data'] for n in doc['workflow']['graph']['nodes'] if n['id'] == '1000')
        default = next(v['default'] for v in start['variables'] if v['variable'] == 'digest_keywords')
        self.assertEqual(default, Settings(None, None, None).digest_keywords)
        for configured, expected in [('', True), (default, True), ('日报\n安全简讯', True),
                                     ('日报,周报,快讯', False), ('自定义周刊', False)]:
            with self.subTest(configured=configured):
                keywords = parse_digest_keywords(configured)
                self.assertEqual(ns['parse_digest_keywords'](configured), keywords)
                article = prepare_article(row, 50000, keywords)
                self.assertEqual(article.digest, expected)
                out = ns['main'](json.dumps([article.payload]), digest_keywords=configured)
                record = json.loads(out['manifest_json'])['records'][0]
                self.assertEqual(record['route'], 'digest' if expected else 'normal')
                self.assertEqual(record['input_hash'], article.input_hash)

    def test_caller_batch_and_canonical_hash_match(self):
        root = Path(__file__).resolve().parents[1]
        doc = yaml.safe_load(next((root / "dify").glob("00*.yml")).read_text())
        node = next(n for n in doc["workflow"]["graph"]["nodes"] if n["id"] == "1100")
        namespace = {}
        exec(node["data"]["code"], namespace)
        article = prepare_article(
            {
                "article_id": 196,
                "title": "真实数据库映射测试",
                "account": "示例媒体",
                "url": "https://example.com/196",
                "published_at": "2026-08-07T19:53:42",
                "fetched_at": "2026-08-17T05:28:19.472141+00:00",
                "content": '第一行\n  保留缩进和引号"。',
            },
            50000,
            ("日报",),
        )
        run_id = "run_" + "a" * 32
        result = namespace["main"](json.dumps([article.payload], ensure_ascii=False), run_id=run_id)
        manifest = json.loads(result["manifest_json"])
        self.assertEqual(manifest["run_id"], run_id)
        self.assertEqual(manifest["records"][0]["input_hash"], article.input_hash)
        self.assertEqual(
            article.input_hash, hashlib.sha256(canonical_json(article.payload).encode()).hexdigest()
        )
        with self.assertRaises(ValueError):
            namespace["main"]("[]", run_id="bad-id")
        legacy = namespace["main"]("[]")
        self.assertRegex(json.loads(legacy["manifest_json"])["run_id"], r"^run_[a-f0-9]{32}$")

    def test_local_caller_inputs_match_current_main_without_verbose(self):
        from types import SimpleNamespace

        from news_local.config import Settings
        from news_local.service import Runner

        run = {
            "run_id": "run_" + "a" * 32,
            "grouping_mode": "singleton",
            "plan": {"articles": [{"payload": {"source_article_id": "a", "content": "正文"}}]},
        }
        caller = SimpleNamespace(settings=Settings(None, None, None))
        supplied = Runner._inputs(caller, run)
        self.assertEqual(json.loads(supplied["articles_json"])[0]["content"], "正文")
        root = Path(__file__).resolve().parents[1]
        doc = yaml.safe_load(next((root / "dify").glob("00*.yml")).read_text())
        start = next(n["data"] for n in doc["workflow"]["graph"]["nodes"] if n["id"] == "1000")
        self.assertEqual(set(supplied), {v["variable"] for v in start["variables"]})
        self.assertNotIn("verbose", supplied)

    def test_iteration_boundaries_tool_bindings_and_run_id_upstream(self):
        root = Path(__file__).resolve().parents[1]
        doc = yaml.safe_load(next((root / "dify").glob("00*.yml")).read_text())
        nodes = {n["id"]: n for n in doc["workflow"]["graph"]["nodes"]}
        for node in nodes.values():
            if node.get("parentId"):
                parent = nodes[node["parentId"]]
                self.assertLessEqual(
                    node["position"]["x"] + node.get("width", 242), parent["width"]
                )
                self.assertLessEqual(
                    node["position"]["y"] + node.get("height", 100), parent["height"]
                )
            if node["data"]["type"] == "tool":
                self.assertNotIn("PLACEHOLDER", node["data"]["provider_id"])
        variable = next(v for v in nodes["1100"]["data"]["variables"] if v["variable"] == "run_id")
        self.assertEqual(variable["value_selector"], ["1000", "run_id"])
