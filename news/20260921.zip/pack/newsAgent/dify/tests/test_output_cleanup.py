"""Keep persisted data complete while removing unused Dify output variables."""

import copy
import csv
import io
import json
import unittest

import test_regression as fixture
import test_storage as storage


class OutputCleanupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixture.WorkflowTests.setUpClass()

    def finish(self, prepared, normals):
        helper = storage.StorageTests()
        helper.f = fixture.WorkflowTests()
        return helper.finish(prepared, [], normals)

    def bundle(self, result):
        keys = ('processing_items_json', 'candidates_json', 'run_id', 'processing_version',
                'run_status', 'stats_json', 'errors_json', 'warnings_json')
        packaged = fixture.invoke('00', '6050', **{key: result[key] for key in keys})
        return json.loads(packaged['bundle_json'])

    def test_25_articles_preserve_50_errors_without_exposing_error_array(self):
        f = fixture.WorkflowTests()
        prototype = fixture.decode(f.incident())
        articles, normals = [], []
        for index in range(25):
            article = copy.deepcopy(f.articles[0])
            article['source_article_id'] = f'failure-{index:02d}'
            articles.append(article)
            result = copy.deepcopy(prototype)
            result.update(kind='error', article=article, errors=['fixture_extraction_failed'],
                          error_stage='incident')
            result['triage']['source_article_id'] = article['source_article_id']
            normals.append(json.dumps(result, ensure_ascii=False))
        prepared = fixture.invoke('00', '1100', articles_json=json.dumps(articles))
        self.assertEqual(len(prepared['normal_article_jsons']), 25)
        final = self.finish(prepared, normals)
        errors = json.loads(final['errors_json'])
        self.assertEqual(len(errors), 50)
        self.assertNotIn('errors', final)
        self.assertFalse(any(isinstance(value, list) for value in final.values()))
        bundle = self.bundle(final)
        self.assertEqual(bundle['errors'], errors)
        self.assertEqual(bundle['stats']['error_count'], 50)
        self.assertEqual(len(bundle['processing_items']), 25)
        self.assertTrue(all(row['errors_json'] and row['process_status'] == 'FAILED'
                            for row in bundle['processing_items']))

    def test_drop_uncertain_remain_in_tables_without_audit_or_verbose(self):
        f = fixture.WorkflowTests()
        articles, normals = [], []
        for decision, route in [('DROP', 'non_target'), ('UNCERTAIN', 'uncertain')]:
            article = copy.deepcopy(f.articles[0])
            article['source_article_id'] = decision
            articles.append(article)
            rendered = fixture.invoke('02', '150', article_json=json.dumps(article))
            triage = fixture.invoke('02', '300',
                raw=fixture.raw('triage_result', fixture.triage(decision, decision, route)),
                article_text=rendered['article_text'])
            self.assertFalse(triage['validation_error'])
            normals.append(fixture.invoke('02', '700', article_text=rendered['article_text'],
                article_json=rendered['article_json'], triage_json=triage['triage_json'],
                validation_error=triage['validation_error'])['result_json'])
        prepared = fixture.invoke('00', '1100', articles_json=json.dumps(articles))
        final = self.finish(prepared, normals)
        bundle = self.bundle(final)
        self.assertEqual([r['decision'] for r in bundle['processing_items']], ['DROP', 'UNCERTAIN'])
        self.assertTrue(all(r['reason'] and r['total_score'] is not None
                            for r in bundle['processing_items']))
        self.assertEqual(bundle['candidates'], [])
        self.assertEqual((bundle['stats']['drop_count'], bundle['stats']['uncertain_count']), (1, 1))
        exported = fixture.invoke('00', '6100', review_items_json=final['review_items_json'])
        self.assertEqual(list(csv.DictReader(io.StringIO(exported['csv_text'].lstrip('\ufeff')))), [])


if __name__ == '__main__':
    unittest.main()
