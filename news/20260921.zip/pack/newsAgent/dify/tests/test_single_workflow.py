"""Exercise real single-DSL wiring through branches, iteration, files and SQLite."""

import copy
import csv
import hashlib
import io
import json
import re
import sys
import tempfile
import unittest
from pathlib import Path

import yaml

import test_regression as fixture
from single_runtime import DSL, GraphRun
from validate_single import check_single

sys.path.insert(0, str(DSL.parents[1] / 'src'))
from news_local.article_contract import canonical_json, normalize_article
from news_local.contracts import validate_bundle
from news_local.repository import Repository
from news_local.reporting import summarize
from news_local.timeutils import now_text


class SingleWorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixture.WorkflowTests.setUpClass()

    def setUp(self):
        self.f = fixture.WorkflowTests()
        originals = {a['source_article_id']: a for a in self.f.articles}
        self.articles = [dict(originals[key], source_article_id=sid) for key, sid in
                         [('A-SEC-001', '101'), ('A-POL-001', '102'), ('A-DIG-001', '103')]]
        self.decisions = {}
        self.digest_draft = None
        self.incident_ids = ['101']

    def model(self, node_id, prompts):
        text = next(p['text'] for p in prompts if p['role'] == 'user')
        if node_id in ('2110', '3110', '3140', '3160'):
            self.assertIn('article:\n', text)
            sid = re.search(r'^  source_article_id: (.+)$', text, re.M).group(1)
        if node_id == '2110':
            draft = copy.deepcopy(self.digest_draft or self.f.digest_draft())
            draft['parent_article_id'] = sid
            return '<think>分析</think>\n' + fixture.raw('digest_result', draft)
        if node_id == '3110':
            if sid in self.decisions:
                decision, route = self.decisions[sid]
                value = fixture.triage(sid, decision, route)
            elif sid == '102':
                value = fixture.triage(sid, route='compliance_policy', category='compliance_policy', nature='policy')
            else:
                value = fixture.triage(sid)
            return fixture.raw('triage_result', value)
        if node_id == '3140':
            return fixture.raw('incident_result', self.f.incident_draft(sid))
        if node_id == '3160':
            value = self.f.policy_draft(); value['source_article_id'] = sid
            return fixture.raw('policy_result', value)
        if node_id == '4100':
            self.assertIn('event_match_input:\n', text)
            return fixture.raw('event_match_result', {'groups': {'group_001': {
                'canonical_title': '制造企业勒索事件', 'member_article_ids': self.incident_ids,
                'match_reason': '主体、时间、系统和影响一致'}}})
        if node_id == '5110':
            self.assertIn('event_candidate_input:\n', text)
            return fixture.raw('event_candidate', self.f.candidate_draft())
        raise AssertionError(node_id)

    def execute(self, directory, articles=None, mode='singleton', model=None, fail_nodes=()):
        articles = self.articles if articles is None else articles
        run = GraphRun(model or self.model, directory, fail_nodes)
        result = run.run({'articles_json': json.dumps(articles, ensure_ascii=False),
                          'digest_keywords': '', 'max_content_chars': 50000,
                          'grouping_mode': mode, 'run_id': 'run_' + 'a' * 32})
        self.assertEqual(result['export_status'], {'result_json': 'SUCCESS', 'review_csv': 'SUCCESS'})
        bundle = json.loads(next(p for p in run.files if p.suffix == '.json').read_text())
        csv_bytes = next(p for p in run.files if p.suffix == '.csv').read_bytes()
        self.assertTrue(csv_bytes.startswith(b'\xef\xbb\xbf'))
        csv_rows = list(csv.DictReader(io.StringIO(csv_bytes.decode('utf-8-sig'))))
        self.assertEqual(len(csv_rows), len(bundle['candidates']))
        return run, result, bundle

    def test_graph_scope_and_deployment_contract(self):
        report = check_single()
        self.assertEqual((report['nodes'], report['types']['llm'], report['types']['tool']), (39, 6, 2))
        doc = yaml.safe_load(DSL.read_text())
        self.assertEqual(len(list(DSL.parent.glob('*.yml'))), 1)
        nodes = {n['id']: n['data'] for n in doc['workflow']['graph']['nodes']}
        self.assertEqual({o['variable'] for o in nodes['7000']['outputs']},
                         {'run_id', 'run_status', 'stats', 'export_status', 'error_summary', 'result_json_file', 'review_csv_file'})
        text = next(p['text'] for p in nodes['2110']['prompt_template'] if p['role'] == 'system')
        ns = {}; exec(nodes['2120']['code'], ns)
        for name in ('ALLOWED_CATEGORIES', 'ALLOWED_NATURES'):
            self.assertTrue(all(value in text for value in ns[name]))
        self.assertNotIn('Article Triage允许值', text)

    def test_all_routes_files_sqlite_and_repeat_ingest(self):
        for sid, decision, route in [('104', 'DROP', 'non_target'), ('105', 'UNCERTAIN', 'uncertain')]:
            self.articles.append(dict(self.articles[0], source_article_id=sid))
            self.decisions[sid] = decision, route
        with tempfile.TemporaryDirectory() as folder:
            run, result, bundle = self.execute(folder)
            self.assertEqual(result['run_status'], 'SUCCESS')
            self.assertEqual(len(bundle['candidates']), 3)
            self.assertEqual(len(bundle['processing_items']), 7)
            expected = [{'source_id': int(a['source_article_id']),
                         'input_hash': hashlib.sha256(canonical_json(normalize_article(a, 50000)).encode()).hexdigest(),
                         'digest': a['source_article_id'] == '103'} for a in self.articles]
            validated = validate_bundle(bundle, bundle['run_id'], expected)
            repository = Repository(Path(folder) / 'results.sqlite')
            repository.initialize()
            saved = repository.ingest(validated)
            self.assertEqual(saved['processing_items_inserted'], 7)
            self.assertEqual(saved['candidates_inserted'], 3)
            self.assertEqual(repository.ingest(validated)['duplicates_skipped'], 10)
            with repository.connect() as db:
                self.assertTrue(all(r[0].endswith('+08:00') for r in db.execute('SELECT created_at FROM candidates')))
            self.assertEqual(run.calls.count('3140'), 1)
            self.assertEqual(run.calls.count('3160'), 1)
            self.assertEqual(run.calls.count('3110'), 4)

    def test_event_match_and_llm_failure_singleton_repair(self):
        self.articles = [self.articles[0], dict(self.articles[0], source_article_id='106')]
        self.incident_ids = ['101', '106']
        with tempfile.TemporaryDirectory() as folder:
            run, result, bundle = self.execute(folder, mode='event_match')
            self.assertEqual(result['run_status'], 'SUCCESS')
            self.assertEqual(len(bundle['candidates']), 1)
            self.assertIn('4100', run.calls)
        with tempfile.TemporaryDirectory() as folder:
            _, result, bundle = self.execute(folder, mode='event_match', fail_nodes={'4100'})
            self.assertEqual(result['run_status'], 'PARTIAL')
            self.assertEqual(len(bundle['candidates']), 2)
            self.assertTrue(bundle['errors'])

    def test_empty_input_exports_files_without_model_calls(self):
        with tempfile.TemporaryDirectory() as folder:
            run, result, bundle = self.execute(folder, articles=[])
            self.assertEqual(result['run_status'], 'SUCCESS')
            self.assertEqual(run.calls, [])
            self.assertEqual(bundle['processing_items'], [])

    def test_model_failures_preserve_error_rows_and_files(self):
        for node in ('3110', '3140', '5110'):
            with self.subTest(node=node), tempfile.TemporaryDirectory() as folder:
                _, result, bundle = self.execute(folder, articles=self.articles[:1], fail_nodes={node})
                self.assertEqual(result['run_status'], 'FAILED')
                self.assertEqual(bundle['candidates'], [])
                self.assertEqual(bundle['processing_items'][0]['process_status'], 'FAILED')
                self.assertEqual(bundle['processing_items'][0]['source_article_id'], '101')

    def test_iteration_code_failure_is_attributed_and_other_rows_continue(self):
        with tempfile.TemporaryDirectory() as folder:
            _, result, bundle = self.execute(folder, fail_nodes={'3150'})
            self.assertEqual(result['run_status'], 'PARTIAL')
            self.assertEqual(len(bundle['candidates']), 2)
            failed = next(r for r in bundle['processing_items'] if r['source_article_id'] == '101')
            self.assertEqual(failed['process_status'], 'FAILED')
            self.assertIn('iteration_item_execution_failed', str(bundle['errors']))

    def test_real_digest_invalid_children_do_not_erase_valid_keep(self):
        captured = json.loads((fixture.ROOT / 'tests/fixtures/digest_48285_regression.json').read_text())
        self.digest_draft = captured['draft']
        with tempfile.TemporaryDirectory() as folder:
            _, result, bundle = self.execute(folder, articles=[captured['article']])
            self.assertEqual(result['run_status'], 'PARTIAL')
            self.assertEqual(len(bundle['candidates']), 2)
            self.assertEqual({r['item_key'] for r in bundle['processing_items'] if r['candidate_record_id']},
                             {'item_001', 'item_003'})
            self.assertEqual(len(bundle['processing_items']), 7)
            self.assertEqual(sum(r['process_status'] == 'FAILED' for r in bundle['processing_items']), 5)
            self.assertTrue(all(r['source_text'] for r in bundle['processing_items'] if r['item_kind'] == 'digest_child'))
            self.assertEqual(result['stats']['digest_observed_keep_count'], 5)
            self.assertEqual(result['stats']['digest_keep_count'], 2)
            self.assertEqual(result['stats']['digest_partial_parent_count'], 1)
            a = captured['article']
            validated = validate_bundle(bundle, bundle['run_id'], [{'source_id': int(a['source_article_id']),
                'input_hash': hashlib.sha256(canonical_json(normalize_article(a, 50000)).encode()).hexdigest(), 'digest': True}])
            repository = Repository(Path(folder) / 'results.sqlite'); repository.initialize()
            saved = repository.ingest(validated)
            self.assertEqual(saved['candidates_inserted'], 2)
            expected_hash = validated['processing_items'][0]['input_hash']
            self.assertEqual(repository.processed_inputs(), {(48285, expected_hash)})
            summary = summarize({'run_id': bundle['run_id'], 'started_at': now_text(),
                'grouping_mode': 'singleton', 'plan': {'articles': [{'payload': a, 'digest': True}],
                'query': {}, 'rejected': []}}, validated, saved)
            self.assertEqual(summary['status'], 'PARTIAL')
            self.assertEqual(summary['candidate_count'], 2)

    def test_digest_coverage_failure_blocks_all_children(self):
        self.digest_draft = self.f.digest_draft()
        del self.digest_draft['items']['item_002']
        with tempfile.TemporaryDirectory() as folder:
            _, result, bundle = self.execute(folder, articles=self.articles[2:])
            self.assertEqual(result['run_status'], 'FAILED')
            self.assertEqual(bundle['candidates'], [])
            self.assertTrue(all(r['process_status'] == 'FAILED' for r in bundle['processing_items']))

    def test_real_25_inputs_reach_files_with_unavailable_extraction_explicitly_failed(self):
        articles = json.loads((fixture.ROOT / 'examples/articles_25_replay.json').read_text())
        triages = json.loads((fixture.ROOT / 'tests/fixtures/batch_25_triage.json').read_text())
        digest = json.loads((fixture.ROOT / 'tests/fixtures/digest_48285_regression.json').read_text())
        def captured_model(node_id, prompts):
            text = next(p['text'] for p in prompts if p['role'] == 'user')
            if node_id == '2110':
                return fixture.raw('digest_result', digest['draft'])
            if node_id == '3110':
                sid = re.search(r'^  source_article_id: (.+)$', text, re.M).group(1)
                return fixture.raw('triage_result', triages[sid])
            if node_id == '3140':
                raise RuntimeError('No original incident-extraction output was supplied; do not invent it.')
            raise AssertionError(('unexpected_model_call', node_id))
        with tempfile.TemporaryDirectory() as folder:
            run, result, bundle = self.execute(folder, articles=articles, model=captured_model)
            self.assertEqual(result['run_status'], 'PARTIAL')
            self.assertEqual(len(bundle['processing_items']), 31)
            self.assertEqual(len(bundle['candidates']), 2)
            self.assertEqual(result['stats']['normal_drop_count'], 23)
            self.assertEqual(result['stats']['normal_observed_keep_count'], 1)
            self.assertEqual(result['stats']['digest_observed_keep_count'], 5)
            self.assertEqual(run.calls.count('3140'), 1)
            self.assertNotIn('source_article_id_mismatch', str(bundle['errors']))
            self.assertNotIn('parent_article_id_mismatch', str(bundle['errors']))

    def test_40_digest_candidates_cross_only_string_boundaries(self):
        self.digest_draft = {'parent_article_id': '103', 'items': {}}
        body = []
        for index in range(1, 41):
            heading = f'{index}. 企业{index}披露数据泄露'
            content = f'企业{index}披露遭遇数据泄露，影响范围仍在调查。'
            body.append(heading + '\n' + content)
            triage = fixture.triage('103', category='data_breach'); triage.pop('source_article_id')
            self.digest_draft['items'][f'item_{index:03d}'] = dict(
                triage, source_heading=heading, title=f'企业{index}披露数据泄露', source_text=content, summary=content)
        article = dict(self.articles[2], content='\n'.join(body))
        with tempfile.TemporaryDirectory() as folder:
            run, result, bundle = self.execute(folder, articles=[article])
            self.assertEqual(result['run_status'], 'SUCCESS', bundle['errors'])
            self.assertEqual(len(bundle['candidates']), 40)
            self.assertIsInstance(run.values['4000']['digest_candidates_json'], str)


if __name__ == '__main__':
    unittest.main()
