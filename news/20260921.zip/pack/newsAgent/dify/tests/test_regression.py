"""Offline regression tests. All model outputs are fixtures, not live LLM runs."""
from pathlib import Path
import copy
from functools import lru_cache
import csv
import hashlib
import io
import json
import sys
import unittest
import yaml

ROOT = Path(__file__).resolve().parents[1]
RELEASE = ROOT / 'build/modules'
SAMPLE = ROOT / 'examples' / 'sample_articles.json'
if not SAMPLE.exists():
    SAMPLE = ROOT.parents[1] / 'upload' / 'ac24554f-538a-4d59-82fa-4cda1f557d30.json'


@lru_cache(maxsize=None)
def node_data(prefix, node):
    doc = yaml.safe_load(next(RELEASE.glob(prefix + '*.yml')).read_text())
    return next(n['data'] for n in doc['workflow']['graph']['nodes'] if n['id'] == node)


def runtime(prefix, node):
    code = node_data(prefix, node)['code']
    namespace = {}
    exec(compile(code, prefix + ':' + node, 'exec'), namespace)
    return namespace


_context = {}

def invoke(prefix, node, **kwargs):
    if (prefix, node) == ('00', '4000'):
        _context.update({key: kwargs[key] for key in ('digest_results', 'normal_results', 'manifest_json')})
    if (prefix, node) == ('00', '6000'):
        for key, value in _context.items():
            kwargs.setdefault(key, value)
    ns = runtime(prefix, node)
    if (prefix, node) in (('01', '300'), ('02', '510'), ('02', '610'), ('02', '700')) and 'article_json' not in kwargs:
        article = ns['parse_article_input'](kwargs['article_text'])
        article['content_chars'] = int(article.get('content_chars', len(article['content'])))
        article['content_truncated'] = article.get('content_truncated') == 'true'
        kwargs['article_json'] = json.dumps(article, ensure_ascii=False)
    result = ns['main'](**kwargs)
    declared = node_data(prefix, node)['outputs']
    assert set(result) == set(declared), (prefix, node, set(result), set(declared))
    return result


def decode(value):
    return json.loads(value['result_json'])


def tree(value, indent=0):
    lines = []
    for key, child in value.items():
        prefix = ' ' * indent + str(key) + ':'
        if isinstance(child, dict):
            lines.append(prefix)
            lines.extend(tree(child, indent + 2))
        elif isinstance(child, list):
            if child:
                lines.append(prefix)
                lines.extend(' ' * (indent + 2) + '- ' + str(x) for x in child)
            else:
                lines.append(prefix + ' []')
        else:
            lines.append(prefix + ' ' + str(child))
    return lines


def raw(root, value):
    return '\n'.join(tree({root: value}))


def triage(sid, decision='KEEP', route='security_event', category='ransomware', nature='real_world_event', scores=None):
    return {'source_article_id': sid, 'decision': decision, 'route': route, 'category': category,
            'content_nature': nature, 'scores': scores or dict(zip(('relevance', 'impact', 'freshness', 'evidence_quality', 'audience_value'), (5, 4, 5, 3, 5))),
            'reason': '正文明确报道目标事项，有直接安全运营或合规关注价值' if decision == 'KEEP' else '属于产品和活动宣传，不是目标安全资讯'}


class WorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.articles = json.loads(SAMPLE.read_text())
        cls.prepared = invoke('00', '1100', articles_json=json.dumps(cls.articles, ensure_ascii=False))
        cls.article_texts = {json.loads(value)['source_article_id']: invoke('01', '150', article_json=value)['article_text'] for key in ('digest_article_jsons', 'normal_article_jsons') for value in cls.prepared[key]}

    def digest_draft(self):
        first = triage('A-DIG-001', category='data_breach')
        second = triage('A-DIG-001', 'DROP', 'non_target', 'product', 'marketing', dict(zip(first['scores'], (0, 0, 2, 5, 0))))
        first.pop('source_article_id')
        second.pop('source_article_id')
        return {'parent_article_id': 'A-DIG-001', 'items': {
            'item_001': {'source_heading': '【事件一】', 'title': '某海外零售企业披露数据泄露，范围仍在调查',
                         'source_text': '某海外零售企业称遭数据泄露，调查仍在进行，泄露范围尚未确认。',
                         'summary': '某海外零售企业称遭数据泄露，调查仍在进行，泄露范围尚未确认。', **first},
            'item_002': {'source_heading': '【事件二】', 'title': '安全厂商发布新品和线上研讨会报名信息',
                         'source_text': '安全厂商发布某工具新品宣传与线上研讨会报名信息。',
                         'summary': '安全厂商发布产品和活动宣传。', **second}}}

    def digest(self, draft=None):
        return invoke('01', '300', raw=raw('digest_result', draft or self.digest_draft()), article_text=self.article_texts['A-DIG-001'])

    def incident_draft(self, sid='A-SEC-001'):
        return {'source_article_id': sid, 'event_time': '2026-08-29', 'title': '某制造企业遭勒索攻击导致业务中断',
                'source_url': 'https://example.com/security-1',
                'summary': '某制造企业遭勒索软件攻击，部分生产管理服务器被加密，部分业务中断。攻击者身份尚未确认，初始进入方式未披露。',
                'entities': {'victim': {'value': '某制造企业', 'certainty': 'reported'},
                             'attacker': {'value': 'unknown', 'certainty': 'unknown'},
                             'attack_vector_or_cause': 'unknown', 'affected_system': '生产管理服务器', 'impact': '部分业务中断'},
                'data_breach_scope': 'unknown', 'lesson': 'unknown',
                'ioc': {'ips': ['203.0.113.10'], 'domains': [], 'urls': [], 'hashes': [], 'file_paths': [], 'vulnerabilities': ['CVE-2026-12345']}}

    def incident(self, draft=None, text=None, tri=None):
        article_text = text or self.article_texts['A-SEC-001']
        t = invoke('02', '300', raw=raw('triage_result', tri or triage('A-SEC-001')), article_text=article_text)
        return invoke('02', '510', raw=raw('incident_result', draft or self.incident_draft()), article_text=article_text, triage_json=t['triage_json'])

    def policy_draft(self):
        return {'source_article_id': 'A-POL-001', 'policy_time': '2026-08-30', 'title': '监管机构发布数据安全管理要求',
                'source_url': 'https://example.com/policy-1', 'issuer': '监管机构', 'policy_name': 'unknown',
                'policy_status': 'officially_issued', 'effective_time': '2026-10-01', 'affected_entities': ['相关企业'],
                'requirements': ['完善重要数据识别', '完善访问控制', '完善事件报告机制'], 'key_changes': [],
                'impact': '相关企业需完善数据安全管理机制',
                'summary': '监管机构于2026年8月30日发布数据安全管理要求，自2026年10月1日起实施，要求相关企业完善重要数据识别、访问控制与事件报告机制。'}

    def policy(self, draft=None):
        text = self.article_texts['A-POL-001']
        t = invoke('02', '300', raw=raw('triage_result', triage('A-POL-001', route='compliance_policy', category='compliance_policy', nature='policy')), article_text=text)
        return invoke('02', '610', raw=raw('policy_result', draft or self.policy_draft()), article_text=text, triage_json=t['triage_json'])

    def candidate_draft(self):
        return {'event_time': '2026-08-29', 'title': '某制造企业遭勒索软件攻击致部分业务中断',
                'summary': '2026年8月29日，某制造企业披露遭勒索软件攻击，部分生产管理服务器被加密并导致部分业务中断。攻击者身份尚未确认，初始进入方式未披露，企业正在调查影响范围。',
                'victim': '某制造企业', 'attacker': 'unknown', 'attack_vector_or_cause': 'unknown',
                'affected_system': '生产管理服务器', 'impact': '部分业务中断', 'data_breach_scope': 'unknown', 'lesson': 'unknown'}

    def pipeline(self, digests=None, normals=None, candidate_draft=None):
        d = [self.digest()['result_json']] if digests is None else digests
        n = [self.incident()['result_json'], self.policy()['result_json']] if normals is None else normals
        collect = invoke('00', '4000', digest_results=d, normal_results=n, prepare_errors_json=self.prepared['prepare_errors_json'], manifest_json=self.prepared['manifest_json'])
        grouped = invoke('03', '500', incidents_json=collect['incidents_json'])
        groups = invoke('00', '4200', result_json=grouped['result_json'], incidents_json=collect['incidents_json'])
        events = [invoke('04', '400', raw=raw('event_candidate', candidate_draft or self.candidate_draft()), group_json=g)['result_json'] for g in groups['group_jsons']]
        final = invoke('00', '6000', digest_candidates_json=collect['digest_candidates_json'], policy_candidates_json=collect['policy_candidates_json'],
                       event_results=events, errors_json=collect['errors_json'],
                       event_match_errors_json=groups['event_match_errors_json'], stage_stats_json=collect['stage_stats_json'],
                       group_jsons=groups['group_jsons'], warnings_json=collect['warnings_json'])
        return final, collect, groups, events

    def test_sample_end_to_end(self):
        final, _, _, _ = self.pipeline()
        self.assertEqual(final['run_status'], 'SUCCESS', json.loads(final['errors_json']))
        self.assertEqual(len(json.loads(final['review_items_json'])), 3)
        stats = json.loads(final['stats_json'])
        for key, value in {'input_count': 3, 'digest_parent_count': 1, 'digest_item_count': 2, 'digest_keep_count': 1,
                           'digest_drop_count': 1, 'normal_article_count': 2, 'normal_incident_count': 1,
                           'normal_policy_count': 1, 'event_group_count': 1, 'candidate_count': 3, 'error_count': 0}.items():
            self.assertEqual(stats[key], value, key)
        self.assertTrue(stats['digest_coverage_verified'])
        self.assertEqual(stats['quality_status'], 'WARN')
        for item in json.loads(final['review_items_json']):
            self.assertTrue(item['candidate_id'])
            self.assertTrue(item['source_article_ids'])
            self.assertEqual(item['total_score'], sum(item['scores'].values()) * 4)
            self.assertTrue(item['reason'])
            self.assertTrue(item['source_preview'])
        event = next(x for x in json.loads(final['review_items_json']) if x.get('event_id'))
        self.assertEqual(event['ioc']['ips'], [])
        self.assertEqual(event['ioc']['vulnerabilities'], [])
        self.assertEqual(len(event['excluded_iocs']), 2)
        self.assertNotIn('尚无已证实', event['summary'])
        self.assertNotIn('【事件一】', json.loads(final['review_items_json'])[0]['title'])

    def test_digest_label_title_rejected(self):
        draft = self.digest_draft(); draft['items']['item_001']['title'] = '【事件一】'
        obj = decode(self.digest(draft)); self.assertEqual(obj['candidates'], [])
        self.assertIn('label_only_title', str(obj['errors']))

    def test_digest_missing_drop_is_error(self):
        draft = self.digest_draft(); del draft['items']['item_002']
        obj = decode(self.digest(draft)); self.assertIn('digest_item_coverage', str(obj['errors']))
        self.assertEqual(obj['candidates'], [])

    def test_digest_source_cannot_cross_sections(self):
        draft = self.digest_draft(); draft['items']['item_001']['source_text'] = draft['items']['item_002']['source_text']
        self.assertIn('source_text_must_cover_own_section', str(decode(self.digest(draft))['errors']))

    def test_digest_id_does_not_depend_on_title(self):
        first = decode(self.digest())['candidates'][0]
        draft = self.digest_draft(); draft['items']['item_001']['title'] = '某海外零售企业数据泄露事件仍在调查'
        second = decode(self.digest(draft))['candidates'][0]
        self.assertEqual(first['candidate_id'], second['candidate_id'])

    def test_digest_keeps_drop_in_processing_items(self):
        obj = decode(self.digest())
        self.assertEqual(len(obj['candidates']), 1); self.assertEqual(len(obj['items']), 2)
        final, _, _, _ = self.pipeline()
        self.assertEqual(json.loads(final['stats_json'])['candidate_count'], 3)

    def test_fractional_boolean_and_missing_scores_rejected(self):
        for value in (True, 2.5, '3.5', None):
            t = triage('A-SEC-001'); t['scores']['relevance'] = value
            parsed = invoke('02', '300', raw=raw('triage_result', t), article_text=self.article_texts['A-SEC-001'])
            self.assertTrue(parsed['validation_error'])
            self.assertNotIn('total_score', json.loads(parsed['triage_json']))

    def test_unknown_not_false_no_breach(self):
        draft = self.incident_draft(); draft['summary'] += '尚无已证实的数据泄露信息。'
        obj = decode(self.incident(draft)); self.assertEqual(obj['kind'], 'error')
        self.assertIn('unsupported_negative_breach', str(obj['errors']))
        draft = self.candidate_draft(); draft['summary'] += '未发生数据泄露。'
        final, _, _, _ = self.pipeline(candidate_draft=draft)
        self.assertEqual(final['run_status'], 'PARTIAL'); self.assertEqual(len(json.loads(final['review_items_json'])), 2)

    def test_explicit_negative_source_can_be_retold(self):
        ns = runtime('02', '510')
        self.assertEqual(ns['factual_errors']({'summary': '企业称未发生数据泄露。'}, '企业称未发生数据泄露。'), [])

    def test_unknown_field_cannot_be_upgraded(self):
        draft = self.candidate_draft(); draft['attacker'] = '某勒索团伙'
        final, _, _, _ = self.pipeline(candidate_draft=draft)
        self.assertIn('unknown_fact_upgraded:attacker', str(json.loads(final['errors_json'])))

    def test_formal_policy_title_not_invented(self):
        draft = self.policy_draft(); draft['summary'] = '监管机构发布《数据安全管理要求》。'
        obj = decode(self.policy(draft)); self.assertEqual(obj['kind'], 'error')
        self.assertIn('unsupported_formal_policy_title', str(obj['errors']))

    def test_example_iocs_audited_even_if_llm_omits_them(self):
        draft = self.incident_draft(); draft['ioc']['ips'] = []; draft['ioc']['vulnerabilities'] = []
        obj = decode(self.incident(draft)); self.assertEqual(obj['kind'], 'incident', obj['errors'])
        self.assertEqual(len(obj['excluded_iocs']), 2)

    def test_real_ioc_not_removed_by_example_elsewhere(self):
        ns = runtime('02', '510')
        data = {'ips': ['203.0.113.10', '198.51.100.20']}
        content = 'IOC示例：203.0.113.10。攻击者C2地址为198.51.100.20。'
        clean, excluded, errors = ns['example_ioc_filter'](data, content)
        self.assertEqual(clean['ips'], ['198.51.100.20']); self.assertEqual(len(excluded), 1); self.assertEqual(errors, [])
        clean, excluded, errors = ns['example_ioc_filter']({'ips': ['203.0.113.10']}, 'IOC示例：203.0.113.10。真实C2地址：203.0.113.10。')
        self.assertEqual(clean['ips'], ['203.0.113.10']); self.assertEqual(excluded, [])

    def test_ioc_example_block_and_token_boundaries(self):
        ns = runtime('02', '510')
        clean, excluded, errors = ns['example_ioc_filter']({'ips': ['203.0.113.10']}, 'IOC示例：\n  - 203.0.113.10\n正式事件仍在调查。')
        self.assertEqual(clean['ips'], []); self.assertEqual(len(excluded), 1)
        clean, excluded, errors = ns['example_ioc_filter']({'ips': ['203.0.113.1']}, '真实C2：203.0.113.10。')
        self.assertTrue(errors); self.assertEqual(clean['ips'], [])
        clean, excluded, errors = ns['example_ioc_filter']({'ips': ['198.51.100.20']}, '真实C2为198.51.100.20，示例仅供附录说明。')
        self.assertEqual(clean['ips'], ['198.51.100.20']); self.assertEqual(excluded, [])
        clean, excluded, errors = ns['example_ioc_filter']({'domains': ['sample.attacker.test']}, '攻击者使用域名sample.attacker.test。')
        self.assertEqual(clean['domains'], ['sample.attacker.test']); self.assertEqual(excluded, [])

    def test_independent_subflow_malformed_inputs_return_errors(self):
        for group in ('[]', 'null', 'garbage', '{"members":null}', '{"members":[42]}'):
            out = decode(invoke('04', '400', raw='bad tree', group_json=group))
            self.assertTrue(out['errors'], group)
            self.assertNotIn('review_item', out)
        out = decode(invoke('02', '510', raw='bad tree', article_text='bad article', article_json='{}', triage_json='[]'))
        self.assertEqual(out['kind'], 'error')

    def test_multi_source_scores_are_one_coherent_member(self):
        first = decode(self.incident())
        second = copy.deepcopy(first)
        second['article']['source_article_id'] = 'A-SEC-002'
        second['article']['url'] = 'https://example.com/security-2'
        second['facts']['source_article_id'] = 'A-SEC-002'
        second['facts']['source_url'] = 'https://example.com/security-2'
        second['triage']['source_article_id'] = 'A-SEC-002'
        first['triage']['scores'] = dict(zip(first['triage']['scores'], (5, 5, 1, 1, 1)))
        first['triage']['total_score'] = 52
        second['triage']['scores'] = dict(zip(second['triage']['scores'], (1, 1, 5, 5, 5)))
        second['triage']['total_score'] = 68
        ids = ['A-SEC-001', 'A-SEC-002']
        event_id = runtime('04', '400')['stable_event_id'](ids)
        group = {'event_id': event_id, 'member_article_ids': ids, 'members': [first, second]}
        out = decode(invoke('04', '400', raw=raw('event_candidate', self.candidate_draft()), group_json=json.dumps(group, ensure_ascii=False)))
        self.assertEqual(out['errors'], [])
        item = out['review_item']
        self.assertEqual(item['scores'], second['triage']['scores'])
        self.assertEqual(item['total_score'], 68)
        self.assertEqual(item['score_source_article_id'], 'A-SEC-002')
        self.assertEqual(len(item['source_details']), 2)
        self.assertEqual(len(item['source_urls']), 2)

    def test_digest_truncation_is_not_complete_success(self):
        article_text = self.article_texts['A-DIG-001'].replace('content_truncated: false', 'content_truncated: true')
        out = decode(invoke('01', '300', raw=raw('digest_result', self.digest_draft()), article_text=article_text))
        self.assertIn('digest_content_truncated', str(out['errors']))
        self.assertEqual(out['candidates'], [])

    def test_no_heading_coverage_is_explicitly_unverified(self):
        article_text = self.article_texts['A-DIG-001'].replace('【事件一】', '').replace('【事件二】', '')
        draft = self.digest_draft()
        for item in draft['items'].values():
            item['source_heading'] = 'unknown'
        out = decode(invoke('01', '300', raw=raw('digest_result', draft), article_text=article_text))
        self.assertEqual(out['errors'], [])
        self.assertFalse(out['stats']['coverage_verified'])
        self.assertTrue(out['warnings'])

    def test_empty_and_all_dropped_pipeline_still_exports_headers(self):
        for decision in (None, 'DROP', 'UNCERTAIN'):
            articles = [] if decision is None else [self.articles[0]]
            prepared = invoke('00', '1100', articles_json=json.dumps(articles, ensure_ascii=False))
            normal = []
            if decision:
                td = triage('A-SEC-001', decision, 'non_target' if decision == 'DROP' else 'uncertain', 'other', 'other')
                tr = invoke('02', '300', raw=raw('triage_result', td), article_text=invoke('02', '150', article_json=prepared['normal_article_jsons'][0])['article_text'])
                normal.append(invoke('02', '700', article_text=invoke('02', '150', article_json=prepared['normal_article_jsons'][0])['article_text'], triage_json=tr['triage_json'], validation_error=tr['validation_error'])['result_json'])
            collect = invoke('00', '4000', digest_results=[], normal_results=normal, prepare_errors_json=prepared['prepare_errors_json'], manifest_json=prepared['manifest_json'])
            grouped = invoke('03', '500', incidents_json=collect['incidents_json'])
            groups = invoke('00', '4200', result_json=grouped['result_json'], incidents_json=collect['incidents_json'])
            out = invoke('00', '6000', digest_candidates_json='[]', policy_candidates_json='[]', event_results=[],
                         errors_json=collect['errors_json'], event_match_errors_json=groups['event_match_errors_json'],
                         stage_stats_json=collect['stage_stats_json'], group_jsons=groups['group_jsons'], warnings_json=collect['warnings_json'])
            self.assertEqual(out['run_status'], 'SUCCESS', json.loads(out['errors_json']))
            expected_business = {None: 'empty_input', 'DROP': 'all_dropped', 'UNCERTAIN': 'uncertain_only_or_dropped'}[decision]
            self.assertEqual(json.loads(out['stats_json'])['business_result'], expected_business)
            self.assertEqual(json.loads(out['stats_json'])['candidate_count'], 0)
            self.assertEqual(len(list(csv.DictReader(io.StringIO(invoke('00', '6100', review_items_json=out['review_items_json'])['csv_text'].lstrip('\ufeff'))))), 0)
            if decision == 'UNCERTAIN':
                self.assertEqual(json.loads(out['stats_json'])['quality_status'], 'WARN')

    def test_missing_event_result_is_partial_and_csv_survives(self):
        _, collected, groups, _ = self.pipeline()
        out = invoke('00', '6000', digest_candidates_json=collected['digest_candidates_json'], policy_candidates_json=collected['policy_candidates_json'],
                     event_results=[], errors_json=collected['errors_json'],
                     event_match_errors_json=groups['event_match_errors_json'], stage_stats_json=collected['stage_stats_json'],
                     group_jsons=groups['group_jsons'], warnings_json=collected['warnings_json'])
        self.assertEqual(out['run_status'], 'PARTIAL')
        self.assertIn('missing_child_result', str(json.loads(out['errors_json'])))
        self.assertEqual(len(list(csv.DictReader(io.StringIO(invoke('00', '6100', review_items_json=out['review_items_json'])['csv_text'].lstrip('\ufeff'))))), 2)

    def test_missing_child_and_bad_json_not_silent_empty(self):
        for digests in ([], ['bad json'], ['{}'], ['null'], [None]):
            final, _, _, _ = self.pipeline(digests=digests)
            self.assertEqual(final['run_status'], 'PARTIAL')
            self.assertTrue(json.loads(final['errors_json']))

    def test_missing_groups_detected(self):
        _, collected, _, _ = self.pipeline()
        result = invoke('00', '4200', result_json='{"groups":[],"errors":[]}', incidents_json=collected['incidents_json'])
        self.assertIn('event_group_missing_incidents', result['event_match_errors_json'])
        result = invoke('00', '4200', result_json='garbage', incidents_json=collected['incidents_json'])
        self.assertTrue(json.loads(result['event_match_errors_json']))

    def test_empty_and_invalid_input_distinguished(self):
        for value, error in (('[]', False), ('{}', True), ('null', True), ('invalid', True)):
            result = invoke('00', '1100', articles_json=value)
            self.assertEqual(bool(json.loads(result['prepare_errors_json'])), error)
        result = invoke('00', '1100', articles_json=json.dumps({'articles': self.articles, 'collector_batch': 'batch-1'}, ensure_ascii=False))
        self.assertEqual(json.loads(result['manifest_json'])['input_count'], 3)
        self.assertEqual(json.loads(result['prepare_errors_json']), [])

    def test_duplicate_source_input_rejected(self):
        result = invoke('00', '1100', articles_json=json.dumps([self.articles[0], self.articles[0]]))
        self.assertEqual(len(result['normal_article_jsons']), 1)
        self.assertIn('duplicate_source_article_id', result['prepare_errors_json'])

    def test_csv_roundtrip_and_file_settings(self):
        final, _, _, _ = self.pipeline()
        result = invoke('00', '6100', review_items_json=final['review_items_json'])
        content = result['csv_text']; rows = list(csv.DictReader(io.StringIO(content.lstrip('\ufeff'))))
        self.assertEqual(content.count('\ufeff'), 1); self.assertEqual(len(rows), 3)
        self.assertEqual(len(rows[0]), 34)
        self.assertTrue(all(row['总分'] and row['候选ID'] and row['来源文章ID'] for row in rows))
        self.assertEqual(content.encode('utf-8')[:3], b'\xef\xbb\xbf')
        empty = invoke('00', '6100', review_items_json='[]')
        self.assertIn('是否采用', empty['csv_text'])
        self.assertEqual(len(list(csv.reader(io.StringIO(empty['csv_text'])))), 1)

    def test_csv_formula_and_delimiter_safety(self):
        ns = runtime('00', '6100')
        for payload in ('=1+1', '+SUM(A1)', '-2+3', '@SUM(A1)', '\t=1', '\ufeff=1', '\u200b=1', '＝1'):
            self.assertTrue(ns['safe_cell'](payload).startswith("'"), repr(payload))
        final, _, _, _ = self.pipeline(); items = json.loads(final['review_items_json'])
        items[0]['title'] = '逗号,引号"和\n换行'; items[0]['summary'] = '=HYPERLINK("bad")'
        out = invoke('00', '6100', review_items_json=json.dumps(items, ensure_ascii=False))
        rows = list(csv.DictReader(io.StringIO(out['csv_text'].lstrip('\ufeff'))))
        self.assertEqual(rows[0]['标题'], '逗号,引号"和 换行')
        self.assertTrue(rows[0]['概述'].startswith("'="))


if __name__ == '__main__':
    unittest.main(verbosity=2)
