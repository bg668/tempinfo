"""Static graph/contract checks against the exact supplied working DSLs."""
from pathlib import Path
import ast
import copy
import hashlib
import json
import re
import yaml

ROOT = Path(__file__).resolve().parents[1]
RELEASE = ROOT / 'build/modules'
BASELINE = ROOT / 'input' if (ROOT / 'input').exists() else ROOT / 'source/input'


def check_all():
    reports = []
    for path in sorted(RELEASE.glob('*.yml')):
        doc = yaml.safe_load(path.read_text())
        graph = doc['workflow']['graph']
        nodes = {n['id']: n for n in graph['nodes']}
        assert len(nodes) == len(graph['nodes']), 'duplicate_node_id'
        forward = {node_id: set() for node_id in nodes}
        for edge in graph['edges']:
            assert edge['source'] in nodes and edge['target'] in nodes
            forward[edge['source']].add(edge['target'])
        for node in nodes.values():
            if node.get('parentId'):
                assert node['parentId'] in nodes
                parent = nodes[node['parentId']]
                assert parent['data']['type'] in ('iteration', 'loop')
                # ReactFlow stores position relative to parent, plus absolute canvas position.
                absolute = node.get('positionAbsolute', node['position'])
                parent_absolute = parent.get('positionAbsolute', parent['position'])
                local_x = absolute['x'] - parent_absolute['x']
                local_y = absolute['y'] - parent_absolute['y']
                assert node['position'] == {'x': local_x, 'y': local_y}
                assert local_x >= 0 and local_y >= 0
                assert local_x + node['width'] <= parent['width']
                assert local_y + node['height'] <= parent['height']
                forward[node['parentId']].add(node['id'])
        def upstream(source, target):
            seen, todo = set(), [source]
            while todo:
                node = todo.pop()
                if node == target:
                    return True
                if node not in seen:
                    seen.add(node); todo.extend(forward[node])
            return False
        count, llms, code_nodes = 0, 0, 0
        consumed = set()
        for node_id, node in nodes.items():
            data = node['data']
            assert data['type'] not in ('agent', 'agent-v2')
            if data['type'] == 'code':
                code_nodes += 1
                parsed = ast.parse(data['code'])
                mains = [n for n in parsed.body if isinstance(n, ast.FunctionDef) and n.name == 'main']
                assert mains, node_id
                args = {a.arg for a in mains[-1].args.args}
                assert args == {v['variable'] for v in data['variables']}, (path.name, node_id, args)
            selectors = []
            for variable in data.get('variables', []):
                if isinstance(variable, dict) and 'value_selector' in variable:
                    selectors.append(variable['value_selector'])
                elif isinstance(variable, list):
                    selectors.append(variable)
            if data['type'] == 'end':
                selectors.extend(o['value_selector'] for o in data['outputs'])
            if data['type'] == 'iteration':
                selectors.append(data['iterator_selector'])
                consumed.add(tuple(data['output_selector'][:2]))
                child = nodes[data['output_selector'][0]]
                if child['data']['type'] == 'code':
                    assert data['output_selector'][1] in child['data']['outputs']
                else:
                    assert data['output_selector'][1] in {'text', 'json', 'files'}
                assert child.get('parentId') == node_id
            if data['type'] == 'if-else':
                for case in data.get('cases', []):
                    selectors.extend(c['variable_selector'] for c in case.get('conditions', []))
            if data['type'] == 'tool':
                for parameter in data.get('tool_parameters', {}).values():
                    if parameter['type'] == 'variable':
                        selectors.append(parameter['value'])
                    elif parameter['type'] == 'mixed' and isinstance(parameter.get('value'), str):
                        selectors.extend([s.split('.') for s in re.findall(r'\{\{#([^#]+)#\}\}', parameter['value'])])
            if data['type'] == 'llm':
                llms += 1
                for prompt in data['prompt_template']:
                    refs = [s.split('.') for s in re.findall(r'\{\{#([^#]+)#\}\}', prompt['text'])]
                    assert not any(any('_json' in field for field in ref) for ref in refs), 'LLM_direct_JSON'
                    selectors.extend(refs)
                assert '<' in data['prompt_template'][0]['text'] and '例如' in data['prompt_template'][0]['text']
            for selector in selectors:
                source, output_name = selector[:2]
                consumed.add((source, output_name))
                if source in ('sys', 'env'):
                    continue
                assert source in nodes, (path.name, node_id, selector)
                assert upstream(source, node_id), (path.name, node_id, 'non_upstream', selector)
                source_data = nodes[source]['data']
                if source_data['type'] == 'code':
                    assert output_name in source_data['outputs'], (node_id, selector)
                elif source_data['type'] == 'tool':
                    allowed = {'text', 'json', 'files'}
                    if source_data.get('error_strategy') in ('default-value', 'fail-branch'):
                        allowed.update({'error_message', 'error_type'})
                    assert output_name in allowed, (node_id, 'unverified_tool_custom_output', selector)
                elif source_data['type'] == 'start':
                    assert output_name in {v['variable'] for v in source_data['variables']}
                count += 1
        for node_id, node in nodes.items():
            if node['data']['type'] == 'code':
                for output in node['data']['outputs']:
                    assert (node_id, output) in consumed, (path.name, node_id, 'unused_output', output)
        previous = json.loads((ROOT / 'tests/fixtures/module_graphs.json').read_text())[path.name]
        current = copy.deepcopy(doc)
        for node in current['workflow']['graph']['nodes']:
            if node['data']['type'] == 'code':
                parsed = ast.parse(node['data']['code'])
                functions = [n.name for n in parsed.body if isinstance(n, ast.FunctionDef)]
                assert len(functions) == len(set(functions)), 'duplicate_function'
                assert functions.count('main') == 1, 'multiple_main'
                assert not re.search(r'_(?:legacy|v\d+)(?:_result)?_main', node['data']['code']), 'historical_wrapper'
                assert not any(isinstance(n, ast.ImportFrom) and n.module == 'common' for n in parsed.body), 'runtime_local_import'
                node['data']['code'] = '__CODE__'
        assert current == previous, 'unexpected_graph_config_or_contract_change'
        reports.append({'file': path.name, 'nodes': len(nodes), 'edges': len(graph['edges']), 'code_nodes': code_nodes,
                        'llm_nodes': llms, 'checked_selectors': count,
                        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    main = yaml.safe_load(next(RELEASE.glob('00*.yml')).read_text())
    nodes = {n['id']: n['data'] for n in main['workflow']['graph']['nodes']}
    assert nodes['6200']['tool_name'] == 'save_as_file'
    assert nodes['6200']['tool_parameters']['content'] == {'type': 'variable', 'value': ['6100', 'csv_text']}
    assert nodes['6200']['tool_parameters']['encoding']['value'] == 'utf-8'
    assert nodes['6200']['tool_parameters']['mime_type']['value'] == 'text/csv'
    assert next(o for o in nodes['7000']['outputs'] if o['variable'] == 'review_csv_file')['value_selector'] == ['6200', 'files']
    assert {o['variable'] for o in nodes['7000']['outputs']} == {'run_id','run_status','stats','export_status','error_summary','result_json_file','review_csv_file'}
    assert nodes['6060']['tool_parameters']['mime_type']['value'] == 'application/json'
    assert nodes['6060']['plugin_unique_identifier'] == nodes['6200']['plugin_unique_identifier']
    for node_id in ('2110', '3110'):
        assert 'article_text' not in nodes[node_id]['tool_parameters']
        assert 'article_json' in nodes[node_id]['tool_parameters']
        assert {p['name'] for p in nodes[node_id]['paramSchemas']} == set(nodes[node_id]['tool_parameters'])
    for tool, adapter in [('2110', '2120'), ('3110', '3120'), ('4100', '4120'), ('5110', '5120')]:
        assert nodes[tool]['default_value'] == [{'key': 'text', 'type': 'string', 'value': ''}]
        refs = {v['variable']: v['value_selector'] for v in nodes[adapter]['variables']}
        assert refs['tool_text'] == [tool, 'text']
        assert refs['error_message'] == [tool, 'error_message']
        assert refs['error_type'] == [tool, 'error_type']
    for prefix in ('01','02'):
        doc = yaml.safe_load(next(RELEASE.glob(prefix+'*.yml')).read_text())
        ns = {n['id']: n['data'] for n in doc['workflow']['graph']['nodes']}
        assert any(v['variable']=='article_json' for v in ns['100']['variables'])
        assert not any(v['variable']=='article_text' for v in ns['100']['variables'])
    return reports


if __name__ == '__main__':
    print(json.dumps(check_all(), ensure_ascii=False, indent=2))
