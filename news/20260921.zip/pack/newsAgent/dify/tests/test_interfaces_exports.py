import copy
import hashlib
import json
import unittest
import subprocess
import sys
import tempfile
import test_regression as fixture
BASELINE = fixture.ROOT / "tests/fixtures/v3_interface.json"


class InterfaceExportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixture.WorkflowTests.setUpClass()
        cls.f = fixture.WorkflowTests()

    def bundle(self, result):
        keys = ('processing_items_json', 'candidates_json', 'run_id', 'processing_version', 'run_status', 'stats_json', 'errors_json', 'warnings_json')
        return fixture.invoke('00', '6050', **{k: result[k] for k in keys})

    def test_json_interfaces_render_identical_text(self):
        legacy = BASELINE
        import yaml
        old = yaml.safe_load(legacy.read_text())
        ns = {}
        exec(next(n['data']['code'] for n in old['workflow']['graph']['nodes'] if n['id'] == '1100'), ns)
        prior = ns['main'](json.dumps(self.f.articles))
        expected = prior['digest_article_texts'] + prior['normal_article_texts']
        current = self.f.prepared['digest_article_jsons'] + self.f.prepared['normal_article_jsons']
        for prefix in ('01', '02'):
            self.assertEqual([fixture.invoke(prefix, '150', article_json=s)['article_text'] for s in current], expected)

    def test_aliases_metadata_and_body_preserved(self):
        article = {'id': 'x', 'publisher': '媒体甲', 'title': '普通新闻', 'link': 'https://example.com/a',
                   'body_text': '第一行："引号"\n  缩进正文\\\n末行', 'source_version': 'v8'}
        prepared = fixture.invoke('00', '1100', articles_json=json.dumps([article]))
        raw = prepared['normal_article_jsons'][0]
        for prefix in ('01', '02'):
            out = fixture.invoke(prefix, '150', article_json=raw)
            obj = json.loads(out['article_json'])
            self.assertEqual(obj['content'], article['body_text'])
            self.assertEqual(obj['account'], '媒体甲')
            self.assertEqual(obj['source_version'], 'v8')
            self.assertNotIn('source_version:', out['article_text'])
        record = json.loads(prepared['manifest_json'])['records'][0]
        self.assertEqual(record['input_hash'], hashlib.sha256(raw.encode()).hexdigest())
        self.assertEqual(record['input_meta_json']['hash_basis'], 'canonical_article_json_v1')

    def test_input_validation_precedes_llm(self):
        bad = ['invalid', '[]', '{}', json.dumps({**self.f.articles[0], 'title': 'a\ncontent:'}),
               json.dumps({**self.f.articles[0], 'content_truncated': 'false'})]
        for prefix in ('01', '02'):
            for value in bad:
                with self.subTest(prefix=prefix, value=value), self.assertRaises((ValueError, TypeError)):
                    fixture.invoke(prefix, '150', article_json=value)

    def test_wrapper_keeps_source_metadata_without_model_echo(self):
        a = copy.deepcopy(self.f.articles[0]); a['source_version'] = 'revision-17'
        rendered = fixture.invoke('02', '150', article_json=json.dumps(a))
        tr = fixture.invoke('02', '300', raw=fixture.raw('triage_result', fixture.triage('A-SEC-001')), article_text=rendered['article_text'])
        out = fixture.invoke('02', '510', raw=fixture.raw('incident_result', self.f.incident_draft()),
            article_text=rendered['article_text'], article_json=rendered['article_json'], triage_json=tr['triage_json'])
        self.assertEqual(fixture.decode(out)['article']['source_version'], 'revision-17')

    def test_bundle_contains_complete_tables_and_feedback(self):
        result = self.f.pipeline()[0]
        packaged = self.bundle(result)
        bundle = json.loads(packaged['bundle_json'])
        self.assertEqual(bundle['processing_items'], json.loads(result['processing_items_json']))
        self.assertEqual(bundle['candidates'], json.loads(result['candidates_json']))
        self.assertEqual((len(bundle['processing_items']), len(bundle['candidates'])), (5, 3))
        self.assertEqual(bundle['stats']['drop_count'], 1)
        self.assertEqual(bundle['stats']['keep_count'], 3)
        self.assertEqual(bundle['stats']['uncertain_count'], 0)
        self.assertTrue(all(c['review_status'] == 'pending' and c['review_comment'] is None for c in bundle['candidates']))
        self.assertIn(result['run_id'], packaged['json_filename'])
        self.assertIn(result['run_id'], packaged['csv_filename'])

    def test_bundle_rejects_mixed_batch(self):
        result = self.f.pipeline()[0]
        rows = json.loads(result['processing_items_json']); rows[0]['run_id'] = 'wrong'
        result['processing_items_json'] = json.dumps(rows)
        with self.assertRaisesRegex(ValueError, 'run_id_mismatch'):
            self.bundle(result)

    def test_status_reports_file_presence_and_business_failure(self):
        result = self.f.pipeline()[0]; packaged = self.bundle(result)
        args = {'run_status': 'PARTIAL', 'stats_json': packaged['stats_json'],
                'errors_json': '[{"code":"model_parse_error"}]',
                'json_files': [{'filename': packaged['json_filename']}], 'csv_files': [{'filename': packaged['csv_filename']}]}
        out = fixture.invoke('00', '6500', **args)
        self.assertEqual(out['run_status'], 'PARTIAL')
        self.assertEqual(out['export_status'], {'result_json': 'SUCCESS', 'review_csv': 'SUCCESS'})
        args['json_files'] = []; args['run_status'] = 'SUCCESS'
        out = fixture.invoke('00', '6500', **args)
        self.assertEqual(out['run_status'], 'FAILED')
        self.assertEqual(out['export_status']['result_json'], 'FAILED')
        self.assertNotIn('processing_items', out)
        self.assertIn('result_json_export_empty', out['error_summary'])

    def test_empty_bundle_and_uncertain_row_not_lost(self):
        result = self.f.pipeline()[0]
        result.update({'processing_items_json': '[]', 'candidates_json': '[]', 'run_status': 'SUCCESS', 'errors_json': '[]'})
        bundle = json.loads(self.bundle(result)['bundle_json'])
        self.assertEqual(bundle['processing_items'], [])
        self.assertEqual(bundle['candidates'], [])
        row = json.loads(self.f.pipeline()[0]['processing_items_json'])[0]
        row.update({'run_id': result['run_id'], 'item_kind': 'normal', 'decision': 'UNCERTAIN', 'candidate_record_id': None})
        result['processing_items_json'] = json.dumps([row])
        bundle = json.loads(self.bundle(result)['bundle_json'])
        self.assertEqual(bundle['stats']['uncertain_count'], 1)
        self.assertEqual(bundle['processing_items'][0]['decision'], 'UNCERTAIN')

    def test_binder_rejects_removed_verbose_parameter(self):
        import yaml
        main = next(fixture.RELEASE.glob('00*.yml'))
        document = yaml.safe_load(main.read_text())
        tool = next(n['data'] for n in document['workflow']['graph']['nodes'] if n['id'] == '2110')
        tool['paramSchemas'].append({'name': 'verbose', 'required': False})
        with tempfile.TemporaryDirectory() as folder:
            from pathlib import Path
            stale = Path(folder) / 'stale.yml'
            stale.write_text(yaml.safe_dump(document, allow_unicode=True))
            result = subprocess.run([sys.executable, str(fixture.ROOT / 'tools/bind_main_workflow.py'),
                '--template', str(main), '--tool-dsl', str(stale), '--output', str(Path(folder) / 'out.yml')],
                capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('多余 verbose', result.stderr)
            self.assertFalse((Path(folder) / 'out.yml').exists())

    def test_binder_rejects_old_input_contract(self):
        import yaml
        main = next(fixture.RELEASE.glob('00*.yml'))
        baseline = BASELINE
        script = fixture.ROOT / 'tools/bind_main_workflow.py'
        with tempfile.TemporaryDirectory() as folder:
            target = str(__import__('pathlib').Path(folder) / 'bound.yml')
            command = [sys.executable, str(script), '--template', str(main), '--output', target, '--tool-dsl']
            old = subprocess.run(command + [str(baseline)], capture_output=True, text=True)
            self.assertNotEqual(old.returncode, 0)
            self.assertIn('article_json', old.stderr)
            updated = subprocess.run(command + [str(main)], capture_output=True, text=True)
            self.assertEqual(updated.returncode, 0, updated.stderr)
            before = yaml.safe_load(main.read_text())
            after = yaml.safe_load(__import__('pathlib').Path(target).read_text())
            self.assertEqual(before, after)


if __name__ == '__main__':
    unittest.main()
