"""Workspace rebinding must preserve routing and use the actual registered name."""

import copy
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
MAIN = next((ROOT / "build/modules").glob("00*.yml"))
BINDER = ROOT / "tools/bind_main_workflow.py"


class ToolBindingTests(unittest.TestCase):
    def setUp(self):
        self.template = yaml.safe_load(MAIN.read_text(encoding="utf-8"))
        self.source = copy.deepcopy(self.template)

    def run_binder(self, folder, *extra):
        template, source, output = [Path(folder) / name for name in ("main.yml", "tools.yml", "out.yml")]
        for path, document in ((template, self.template), (source, self.source)):
            path.write_text(yaml.safe_dump(document, allow_unicode=True), encoding="utf-8")
        result = subprocess.run(
            [sys.executable, str(BINDER), "--template", str(template), "--tool-dsl", str(source),
             "--output", str(output), *extra],
            capture_output=True, text=True,
        )
        return result, output

    def test_renamed_match_tool_preserves_inputs_errors_and_graph(self):
        source_nodes = {node["id"]: node for node in self.source["workflow"]["graph"]["nodes"]}
        data = source_nodes["4100"]["data"]
        data["tool_name"] = "new_match_name"
        data["provider_id"] = "11111111-2222-4333-8444-555555555555"
        data["tool_parameters"] = {
            "incidents_json": {"type": "mixed", "value": ""},
            "grouping_mode": {"type": "constant", "value": "singleton"},
        }
        with tempfile.TemporaryDirectory() as folder:
            result, path = self.run_binder(folder, "--tool-alias", "news_event_match=new_match_name")
            self.assertEqual(result.returncode, 0, result.stderr)
            actual = yaml.safe_load(path.read_text(encoding="utf-8"))
        expected = copy.deepcopy(self.template)
        target = next(node["data"] for node in expected["workflow"]["graph"]["nodes"] if node["id"] == "4100")
        target["tool_name"] = data["tool_name"]
        target["provider_id"] = data["provider_id"]
        self.assertEqual(actual, expected)

    def test_same_name_with_different_providers_is_rejected(self):
        nodes = self.source["workflow"]["graph"]["nodes"]
        duplicate = copy.deepcopy(next(node for node in nodes if node["id"] == "3110"))
        duplicate["id"] = "duplicate-tool"
        duplicate["data"]["provider_id"] = "11111111-2222-4333-8444-555555555555"
        nodes.append(duplicate)
        with tempfile.TemporaryDirectory() as folder:
            result, path = self.run_binder(folder)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("对应多个不同工具", result.stderr)
            self.assertFalse(path.exists())

    def test_two_roles_cannot_share_one_tool(self):
        with tempfile.TemporaryDirectory() as folder:
            result, path = self.run_binder(folder, "--tool-alias", "news_digest_process=news_article_process")
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("四个业务角色不能绑定到同一个工具", result.stderr)
            self.assertFalse(path.exists())


if __name__ == "__main__":
    unittest.main()
