"""Compare exported business artifacts with v1.2; failure diagnostics intentionally change.

python dify/tests/compare_release.py --baseline <v1.2/dify> --report comparison.json
"""
import argparse
import json
from pathlib import Path
from unittest.mock import patch
import uuid
import yaml
import subprocess
import sys

import test_regression as fixture
import test_storage as storage


def normalize(value):
    if isinstance(value, dict):
        return {k: '__VERSION__' if k == 'processing_version' else normalize(v) for k, v in value.items()}
    if isinstance(value, list):
        return [normalize(v) for v in value]
    if isinstance(value, str) and value.startswith(('{', '[')):
        try:
            return normalize(json.loads(value))
        except ValueError:
            pass
    return value


def artifacts(scenario):
    fixture.WorkflowTests.setUpClass()
    f = fixture.WorkflowTests()
    if scenario == 'sample':
        final = f.pipeline()[0]
    else:
        articles = [] if scenario == 'empty' else [f.articles[0]]
        prepared = fixture.invoke('00', '1100', articles_json=json.dumps(articles))
        normals = []
        if articles:
            rendered = fixture.invoke('02', '150', article_json=prepared['normal_article_jsons'][0])
            decision = scenario.upper()
            td = fixture.triage('A-SEC-001', decision, 'non_target' if decision == 'DROP' else 'uncertain')
            triage = fixture.invoke('02', '300', article_text=rendered['article_text'],
                                    raw=fixture.raw('triage_result', td))
            normals.append(fixture.invoke('02', '700', article_text=rendered['article_text'],
                article_json=rendered['article_json'], triage_json=triage['triage_json'],
                validation_error=triage['validation_error'])['result_json'])
        helper = storage.StorageTests()
        helper.f = f
        final = helper.finish(prepared, [], normals)
    fields = ('processing_items_json', 'candidates_json', 'run_id', 'processing_version',
              'run_status', 'stats_json', 'errors_json', 'warnings_json')
    packaged = fixture.invoke('00', '6050', **{k: final[k] for k in fields})
    csv = fixture.invoke('00', '6100', review_items_json=final['review_items_json'])
    return normalize({'bundle': packaged['bundle_json'], 'csv': csv['csv_text'], 'status': final['run_status']})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    # Run the baseline's own harness so its historical node interfaces stay intact.
    script = (
        'import json,sys,uuid; from unittest.mock import patch; '
        'sys.path.insert(0,sys.argv[1]); import compare_release as c; '
        'p=patch("uuid.uuid4",return_value=uuid.UUID("a"*32)); p.start(); '
        'print(json.dumps({s:c.artifacts(s) for s in ("sample","drop","uncertain","empty")}))'
    )
    baseline = subprocess.run([sys.executable, '-c', script, str(args.baseline / 'tests')],
                              check=True, capture_output=True, text=True)
    prior = json.loads(baseline.stdout)
    results = []
    for scenario in ('sample', 'drop', 'uncertain', 'empty'):
        with patch('uuid.uuid4', return_value=uuid.UUID('a' * 32)):
            current = artifacts(scenario)
        previous = prior[scenario]
        added_stats = sorted(set(current['bundle']['stats']) - set(previous['bundle']['stats']))
        for key in added_stats:
            del current['bundle']['stats'][key]
        results.append({'scenario': scenario, 'equal': previous == current, 'added_stats': added_stats})
    report = {'passed': all(r['equal'] for r in results), 'scenarios': results,
              'compared_artifacts': ['complete_JSON_bundle', 'CSV_text', 'business_status'],
              'normalization': ['processing_version', 'controlled_run_uuid', 'explicit_additive_stats'],
              'failure_semantics': 'digest_item_isolation_intentionally_changes_failure_cases; covered_by_single_workflow_tests'}
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report['passed'] else 1)


if __name__ == '__main__':
    main()
