import json
import unittest
import test_regression as fixture

TARGETS = [('01', '300'), ('02', '300'), ('02', '510'), ('02', '610'), ('03', '410'), ('04', '400')]


class ReasoningFilterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixture.WorkflowTests.setUpClass()
        cls.f = fixture.WorkflowTests()

    def test_six_parsers_accept_leading_reasoning_and_keep_indentation(self):
        body = 'result:\n  title: 正文\n  child:\n    value: 缩进保留'
        for prefix, nid in TARGETS:
            parse = fixture.runtime(prefix, nid)['parse_contract']
            for leading in ('<think>思考\n第二行</think>', '\ufeff \n<think>x</think>\n', '<think>a</think><think>b</think>'):
                with self.subTest(node=(prefix, nid), leading=leading):
                    self.assertEqual(parse(leading + body, 'result'), parse(body, 'result'))
                    self.assertEqual(parse(leading + '```text\n' + body + '\n```', 'result'), parse(body, 'result'))

    def test_all_cleaners_preserve_literal_tags_in_answer(self):
        body = 'result:\n  content: 原文示例 <think>字面内容</think>'
        for prefix, nid in TARGETS:
            clean = fixture.runtime(prefix, nid)['clean_model_output']
            self.assertEqual(clean(body), body)
            self.assertEqual(clean('<think>分析</think>' + body), body)

    def test_incomplete_and_empty_outputs_are_errors(self):
        for prefix, nid in TARGETS:
            parse = fixture.runtime(prefix, nid)['parse_contract']
            for value, error in [('<think>未结束', 'model_reasoning_unclosed'), ('<think>只有思考</think>', 'model_answer_empty'), ('', 'model_answer_empty')]:
                with self.subTest(node=(prefix, nid), value=value), self.assertRaisesRegex(ValueError, error):
                    parse(value, 'result')

    def test_main_aggregation_preserves_source_tags(self):
        digest = fixture.decode(self.f.digest())
        literal = '原文含有 <think>这不是模型前缀</think>'
        digest['article']['content'] = literal
        digest['items'][0]['source_details'][0]['evidence_text'] = literal
        digest['candidates'][0]['source_details'][0]['evidence_text'] = literal
        result = fixture.invoke('00', '4000', digest_results=[json.dumps(digest, ensure_ascii=False)],
            normal_results=[self.f.incident()['result_json'], self.f.policy()['result_json']],
            prepare_errors_json=self.f.prepared['prepare_errors_json'], manifest_json=self.f.prepared['manifest_json'])
        self.assertEqual(json.loads(result['digest_candidates_json'])[0]['source_details'][0]['evidence_text'], literal)

    def test_full_pipeline_with_reasoning_on_all_model_answers(self):
        original = fixture.raw
        expected = self.f.pipeline()[0]
        try:
            fixture.raw = lambda root, value: '<think>本地模型推理\n保留正式答案</think>\n' + original(root, value)
            actual = self.f.pipeline()[0]
        finally:
            fixture.raw = original
        self.assertEqual(actual['processing_items_json'], expected['processing_items_json'])
        self.assertEqual(actual['candidates_json'], expected['candidates_json'])
        self.assertEqual(actual['run_status'], 'SUCCESS')

    def test_reasoning_only_is_not_a_business_drop(self):
        triage = fixture.invoke('02', '300', raw='<think>还在推理', article_text=self.f.article_texts['A-SEC-001'])
        result = fixture.decode(fixture.invoke('02', '700', article_text=self.f.article_texts['A-SEC-001'],
            triage_json=triage['triage_json'], validation_error=triage['validation_error']))
        self.assertTrue(result['errors'])
        self.assertIn('model_reasoning_unclosed', str(result['errors']))


if __name__ == '__main__':
    unittest.main()
