import copy
import csv
import io
import json
import unittest
import test_regression as fixture

PROCESSING_FIELDS = set('item_id run_id source_article_id candidate_record_id item_kind item_key title summary source_heading source_text process_status decision route category content_nature relevance impact freshness evidence_quality audience_value total_score reason facts_json ioc_json excluded_iocs_json quality_warnings_json errors_json input_hash input_meta_json processing_version created_at'.split())
CANDIDATE_FIELDS = set('candidate_record_id candidate_id run_id candidate_type primary_item_id title summary facts_json relevance impact freshness evidence_quality audience_value total_score reason score_strategy score_source_item_id match_reason ioc_json excluded_iocs_json quality_warnings_json review_status review_reason_code review_comment reviewed_title reviewed_summary review_corrections_json reviewer_id reviewed_at created_at updated_at'.split())

class StorageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixture.WorkflowTests.setUpClass()

    def setUp(self):
        self.f = fixture.WorkflowTests()

    def rows(self, out):
        return json.loads(out['processing_items_json']), json.loads(out['candidates_json'])

    def finish(self, prepared, digests, normals, grouping=None, events=None):
        call = fixture.invoke
        c = call('00', '4000', digest_results=digests, normal_results=normals, prepare_errors_json=prepared['prepare_errors_json'], manifest_json=prepared['manifest_json'])
        grouping = grouping if grouping is not None else call('03', '500', incidents_json=c['incidents_json'])['result_json']
        g = call('00', '4200', result_json=grouping, incidents_json=c['incidents_json'])
        if events is None:
            events = [call('04', '400', raw=fixture.raw('event_candidate', self.f.candidate_draft()), group_json=s)['result_json'] for s in g['group_jsons']]
        return call('00', '6000', digest_candidates_json=c['digest_candidates_json'], policy_candidates_json=c['policy_candidates_json'], event_results=events, errors_json=c['errors_json'], event_match_errors_json=g['event_match_errors_json'], stage_stats_json=c['stage_stats_json'], group_jsons=g['group_jsons'], warnings_json=c['warnings_json'])

    def test_exact_schema_relationships_and_full_facts(self):
        out, _, _, _ = self.f.pipeline()
        rows, candidates = self.rows(out)
        self.assertEqual((len(rows), len(candidates)), (5, 3))
        self.assertEqual({r['run_id'] for r in rows + candidates}, {out['run_id']})
        by_id = {r['item_id']: r for r in rows}
        for r in rows:
            self.assertEqual(set(r), PROCESSING_FIELDS)
            self.assertEqual(r['process_status'], 'SUCCESS')
            self.assertIsNone(r['created_at'])
        for c in candidates:
            self.assertEqual(set(c), CANDIDATE_FIELDS)
            members = [r for r in rows if r['candidate_record_id'] == c['candidate_record_id']]
            self.assertTrue(members)
            self.assertIn(c['primary_item_id'], [m['item_id'] for m in members])
            self.assertIn(c['score_source_item_id'], [m['item_id'] for m in members])
            self.assertEqual(c['review_status'], 'pending')
            self.assertIsNone(c['reviewer_id'])
            for k in fixture.runtime('00', '6000')['SCORE_COLUMNS']:
                self.assertEqual(c[k], by_id[c['score_source_item_id']][k])
        incident = next(r for r in rows if r['source_article_id'] == 'A-SEC-001')
        event = next(c for c in candidates if c['candidate_id'].startswith('event_'))
        self.assertEqual(incident['facts_json']['entities']['victim']['value'], '某制造企业')
        self.assertEqual(event['facts_json']['attacker'], 'unknown')
        self.assertTrue(all(x['item_id'] == incident['item_id'] for x in event['excluded_iocs_json']))
        drop = next(r for r in rows if r['decision'] == 'DROP')
        self.assertTrue(drop['summary'])
        self.assertIsNone(drop['candidate_record_id'])
        parent = next(r for r in rows if r['item_kind'] == 'digest_parent')
        self.assertIsNone(parent['decision'])
        self.assertIsNone(parent['total_score'])

    def test_ioc_not_run_is_distinct_from_no_findings(self):
        rows, candidates = self.rows(self.f.pipeline()[0])
        self.assertIsNone(next(r for r in rows if r['source_article_id'] == 'A-POL-001')['ioc_json'])
        self.assertIsNone(next(c for c in candidates if c['candidate_type'] == 'compliance_policy')['ioc_json'])
        self.assertEqual(next(r for r in rows if r['source_article_id'] == 'A-SEC-001')['ioc_json']['ips'], [])

    def test_runtime_extract_failure_preserves_keep_and_scores(self):
        text = self.f.article_texts['A-SEC-001']
        tr = fixture.invoke('02', '300', raw=fixture.raw('triage_result', fixture.triage('A-SEC-001')), article_text=text)
        failed = fixture.invoke('02', '510', raw='__NODE_EXECUTION_FAILED__', article_text=text, triage_json=tr['triage_json'])['result_json']
        out = self.finish(self.f.prepared, [self.f.digest()['result_json']], [failed, self.f.policy()['result_json']])
        rows, candidates = self.rows(out)
        r = next(r for r in rows if r['source_article_id'] == 'A-SEC-001')
        self.assertEqual((r['decision'], r['process_status']), ('KEEP', 'FAILED'))
        self.assertEqual(r['total_score'], 88)
        self.assertIsNone(r['facts_json'])
        self.assertEqual(len(candidates), 2)

    def test_runtime_triage_failure_is_not_uncertain(self):
        text = self.f.article_texts['A-SEC-001']
        tr = fixture.invoke('02', '300', raw='__NODE_EXECUTION_FAILED__', article_text=text)
        failed = fixture.invoke('02', '700', article_text=text, triage_json=tr['triage_json'], validation_error=tr['validation_error'])['result_json']
        rows, _ = self.rows(self.finish(self.f.prepared, [self.f.digest()['result_json']], [failed, self.f.policy()['result_json']]))
        r = next(r for r in rows if r['source_article_id'] == 'A-SEC-001')
        self.assertEqual(r['process_status'], 'FAILED')
        self.assertIsNone(r['decision'])
        self.assertIsNone(r['total_score'])

    def test_parent_failure_retains_children_without_candidates(self):
        draft = self.f.digest_draft()
        draft['parent_article_id'] = 'wrong-parent'
        rows, candidates = self.rows(self.f.pipeline(digests=[self.f.digest(draft)['result_json']])[0])
        digests = [r for r in rows if r['source_article_id'] == 'A-DIG-001']
        self.assertEqual(len(digests), 3)
        self.assertTrue(all(r['process_status'] == 'FAILED' for r in digests))
        self.assertEqual(len(candidates), 2)

    def test_group_tool_failure_preserves_processed_facts(self):
        grouping = json.dumps({'groups': [], 'errors': ['workflow_tool_execution_failed:event_match'], 'degraded': True})
        out = self.finish(self.f.prepared, [self.f.digest()['result_json']], [self.f.incident()['result_json'], self.f.policy()['result_json']], grouping=grouping)
        rows, candidates = self.rows(out)
        r = next(r for r in rows if r['source_article_id'] == 'A-SEC-001')
        self.assertEqual(r['process_status'], 'FAILED')
        self.assertIsNotNone(r['facts_json'])
        self.assertEqual(len(candidates), 2)
        self.assertEqual(len(list(csv.DictReader(io.StringIO(fixture.invoke('00', '6100', review_items_json=out['review_items_json'])['csv_text'].lstrip('\ufeff'))))), 2)

    def test_missing_all_tool_results_still_returns_source_records(self):
        out = self.finish(self.f.prepared, [None], [None, None])
        rows, candidates = self.rows(out)
        self.assertEqual(len(rows), 3)
        self.assertEqual(candidates, [])
        self.assertTrue(all(r['process_status'] == 'FAILED' for r in rows))
        self.assertEqual(out['run_status'], 'FAILED')
        self.assertEqual(len(list(csv.DictReader(io.StringIO(fixture.invoke('00', '6100', review_items_json=out['review_items_json'])['csv_text'].lstrip('\ufeff'))))), 0)

    def test_old_subflow_contract_cannot_silently_populate_tables(self):
        digest = fixture.decode(self.f.digest())
        digest.pop('storage_contract_version')
        out = self.f.pipeline(digests=[json.dumps(digest)])[0]
        self.assertEqual(len(self.rows(out)[1]), 2)
        self.assertIn('storage_contract_version_mismatch', out['errors_json'])

    def test_batch_ids_hash_and_input_metadata(self):
        call = lambda data: json.loads(fixture.invoke('00', '1100', articles_json=json.dumps(data))['manifest_json'])
        a, b = call(self.f.articles), call(self.f.articles)
        self.assertNotEqual(a['run_id'], b['run_id'])
        self.assertEqual([x['input_hash'] for x in a['records']], [x['input_hash'] for x in b['records']])
        changed = copy.deepcopy(self.f.articles)
        changed[0]['title'] += '最新披露'
        self.assertNotEqual(a['records'][0]['input_hash'], call(changed)['records'][0]['input_hash'])
        for source, record in zip(self.f.articles, a['records']):
            self.assertEqual(record['input_meta_json']['input_content_chars'], len(source['content'].strip()))
        long_article = copy.deepcopy(self.f.articles[0])
        long_article['content'] = '正文' * 650
        clipped = fixture.invoke('00', '1100', articles_json=json.dumps([long_article]), max_content_chars=1000)
        meta = json.loads(clipped['manifest_json'])['records'][0]['input_meta_json']
        self.assertEqual((meta['original_content_chars'], meta['input_content_chars'], meta['content_truncated']), (1300, 1000, True))

    def test_multisource_group_links_both_rows_and_score_source(self):
        source = copy.deepcopy(self.f.articles[0])
        source['source_article_id'] = 'A-SEC-002'
        source['url'] = 'https://example.com/security-2'
        prepared = fixture.invoke('00', '1100', articles_json=json.dumps([self.f.articles[0], source]))
        first = fixture.decode(self.f.incident())
        second = copy.deepcopy(first)
        for container in ('article', 'facts', 'triage'):
            second[container]['source_article_id'] = 'A-SEC-002'
        second['article']['url'] = source['url']
        second['facts']['source_url'] = source['url']
        second['triage']['scores'] = {k: 5 for k in second['triage']['scores']}
        second['triage']['total_score'] = 100
        ids = ['A-SEC-001', 'A-SEC-002']
        gid = fixture.runtime('04', '400')['stable_event_id'](ids)
        group = {'event_id': gid, 'member_article_ids': ids, 'members': [first, second], 'canonical_title': '同一事件', 'match_reason': '主体、时间和受影响系统一致'}
        out = self.finish(prepared, [], [json.dumps(first), json.dumps(second)], grouping=json.dumps({'groups': [group], 'errors': []}))
        rows, candidates = self.rows(out)
        self.assertEqual(out['run_status'], 'SUCCESS', out['errors_json'])
        self.assertEqual((len(rows), len(candidates)), (2, 1))
        c = candidates[0]
        self.assertEqual(c['total_score'], 100)
        self.assertEqual(c['score_source_item_id'], rows[1]['item_id'])
        self.assertEqual(c['primary_item_id'], rows[0]['item_id'])
        self.assertEqual(c['match_reason'], group['match_reason'])
        self.assertEqual({r['candidate_record_id'] for r in rows}, {c['candidate_record_id']})
        self.assertEqual(len(c['excluded_iocs_json']), 4)

    def test_csv_contains_ids_and_media_but_not_drop(self):
        out = self.f.pipeline()[0]
        exported = fixture.invoke('00', '6100', review_items_json=out['review_items_json'])
        rows = list(csv.DictReader(io.StringIO(exported['csv_text'].lstrip('\ufeff'))))
        self.assertTrue(all(r['候选记录ID'] and r['批次ID'] and r['来源处理记录ID'] for r in rows))
        self.assertTrue(all(r['来源账号/媒体'] for r in rows))
        self.assertIn('原文预览', rows[0])
        self.assertNotIn('原文证据摘录', rows[0])
        self.assertFalse(any('新品' in r['标题'] for r in rows))

if __name__ == '__main__':
    unittest.main(verbosity=2)
