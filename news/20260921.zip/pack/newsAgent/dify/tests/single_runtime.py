"""Offline graph executor: real Code nodes/selectors, deterministic model/file doubles.

This validates the delivered graph's data flow; it is not a Dify server emulator.
"""

import copy
import re
from pathlib import Path

import yaml

DSL = Path(__file__).resolve().parents[1] / '00_安全资讯处理_单工作流.yml'
REFERENCE = re.compile(r'\{\{#([^#]+)#\}\}')


def resolve(values, selector):
    value = values[selector[0]]
    for key in selector[1:]:
        value = value[key]
    return value


def validate_outputs(data, result):
    assert set(result) == set(data['outputs']), (data['title'], set(result), set(data['outputs']))
    for key, declaration in data['outputs'].items():
        value, kind = result[key], declaration['type']
        if kind.startswith('array['):
            assert isinstance(value, list) and len(value) <= 30, (key, 'array_limit', len(value))
        elif kind == 'string':
            assert isinstance(value, str), (key, type(value))
        elif kind == 'object':
            assert isinstance(value, dict), (key, type(value))
        elif kind == 'number':
            assert type(value) in (int, float), (key, type(value))


class GraphRun:
    def __init__(self, model, file_directory, fail_nodes=()):
        graph = yaml.safe_load(DSL.read_text(encoding='utf-8'))['workflow']['graph']
        self.nodes = {node['id']: node for node in graph['nodes']}
        self.edges = graph['edges']
        self.model = model
        self.directory = Path(file_directory)
        self.fail_nodes = set(fail_nodes)
        self.calls, self.files, self.trace, self.values = [], [], [], {}

    def run(self, inputs):
        values = self.scope(None, {'1000': copy.deepcopy(inputs)})
        self.values = values
        return values['7000']

    def scope(self, parent, initial):
        values = dict(initial)
        pending = {k for k, n in self.nodes.items() if n.get('parentId') == parent}
        status, handles = {}, {}
        while pending:
            advanced = False
            for node_id in sorted(pending):
                incoming = [e for e in self.edges if e['target'] == node_id
                            and self.nodes[e['source']].get('parentId') == parent]
                if not all(e['source'] in status for e in incoming):
                    continue
                active = not incoming or any(status[e['source']] and
                         (e['sourceHandle'] == 'source' or handles.get(e['source']) == e['sourceHandle'])
                         for e in incoming)
                status[node_id] = active
                if active:
                    result, handle = self.evaluate(node_id, values)
                    values[node_id] = result
                    handles[node_id] = handle
                    self.trace.append((node_id, copy.deepcopy(result)))
                pending.remove(node_id)
                advanced = True
            if not advanced:
                raise AssertionError(('cycle_or_unsatisfied_dependency', parent, pending))
        return values

    def evaluate(self, node_id, values):
        data = self.nodes[node_id]['data']
        kind = data['type']
        if node_id in self.fail_nodes and kind != 'llm':
            raise RuntimeError('synthetic_code_failure:' + node_id)
        if kind in ('start', 'iteration-start'):
            return values.get(node_id, {}), 'source'
        if kind == 'code':
            namespace = {}
            exec(compile(data['code'], node_id, 'exec'), namespace)
            arguments = {v['variable']: resolve(values, v['value_selector']) for v in data['variables']}
            result = namespace['main'](**arguments)
            validate_outputs(data, result)
            return result, 'source'
        if kind == 'if-else':
            for case in data['cases']:
                checks = []
                for condition in case['conditions']:
                    assert condition['comparison_operator'] == 'is'
                    checks.append(resolve(values, condition['variable_selector']) == condition['value'])
                if (all(checks) if case['logical_operator'] == 'and' else any(checks)):
                    return {}, case['case_id']
            return {}, 'false'
        if kind == 'variable-aggregator':
            available = [resolve(values, s) for s in data['variables'] if s[0] in values]
            assert len(available) == 1, (node_id, 'branches_not_exclusive', len(available))
            return {'output': available[0]}, 'source'
        if kind == 'iteration':
            outputs = []
            for index, item in enumerate(resolve(values, data['iterator_selector'])):
                context = dict(values, **{node_id: {'item': item, 'index': index}})
                try:
                    inner = self.scope(node_id, context)
                    outputs.append(resolve(inner, data['output_selector']))
                except RuntimeError:
                    assert data['error_handle_mode'] == 'continue-on-error'
                    outputs.append(None)
            return {'output': outputs}, 'source'
        if kind == 'llm':
            prompts = [{**p, 'text': REFERENCE.sub(
                lambda m: str(resolve(values, m.group(1).split('.'))), p['text'])}
                for p in data['prompt_template']]
            self.calls.append(node_id)
            try:
                if node_id in self.fail_nodes:
                    raise RuntimeError('synthetic_model_failure:' + node_id)
                text = self.model(node_id, prompts)
                return {'text': text}, 'source'
            except RuntimeError as exc:
                assert data['error_strategy'] == 'default-value'
                return {**{v['key']: v['value'] for v in data['default_value']},
                        'error_message': str(exc), 'error_type': type(exc).__name__}, 'source'
        if kind == 'tool':
            assert data['tool_name'] == 'save_as_file' and data['provider_type'] == 'builtin'
            arguments = {}
            for key, parameter in data['tool_parameters'].items():
                if parameter['type'] == 'variable':
                    arguments[key] = resolve(values, parameter['value'])
                else:
                    arguments[key] = REFERENCE.sub(lambda m: str(resolve(values, m.group(1).split('.'))),
                                                     str(parameter.get('value') or ''))
            path = self.directory / arguments['filename']
            path.write_text(arguments['content'], encoding=arguments.get('encoding') or 'utf-8', newline='')
            self.files.append(path)
            return {'files': [{'filename': path.name}], 'text': '', 'json': []}, 'source'
        if kind == 'end':
            return {v['variable']: resolve(values, v['value_selector']) for v in data['outputs']}, 'source'
        raise AssertionError(('unsupported_node_type', node_id, kind))
