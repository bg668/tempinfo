"""Validate the single workflow's actual graph, selectors, scopes and container bounds."""

import ast
from collections import Counter
import hashlib
import inspect
import json
import re

import yaml

from single_runtime import DSL


def selectors(data):
    result = []
    for variable in data.get('variables', []):
        if isinstance(variable, list):
            result.append(variable)
        elif 'value_selector' in variable:
            result.append(variable['value_selector'])
    for case in data.get('cases', []):
        result.extend(c['variable_selector'] for c in case['conditions'])
    if data['type'] == 'iteration':
        result.append(data['iterator_selector'])
    if data['type'] == 'end':
        result.extend(o['value_selector'] for o in data['outputs'])
    for parameter in data.get('tool_parameters', {}).values():
        if parameter['type'] == 'variable':
            result.append(parameter['value'])
        elif isinstance(parameter.get('value'), str):
            result.extend(s.split('.') for s in re.findall(r'\{\{#([^#]+)#\}\}', parameter['value']))
    for prompt in data.get('prompt_template', []):
        refs = [s.split('.') for s in re.findall(r'\{\{#([^#]+)#\}\}', prompt['text'])]
        assert not any('_json' in field for ref in refs for field in ref), 'LLM_direct_JSON'
        result.extend(refs)
    return result


def check_single():
    document = yaml.safe_load(DSL.read_text(encoding='utf-8'))
    graph = document['workflow']['graph']
    nodes = {n['id']: n for n in graph['nodes']}
    assert len(nodes) == len(graph['nodes'])
    assert len({e['id'] for e in graph['edges']}) == len(graph['edges'])
    forward = {k: set() for k in nodes}
    for edge in graph['edges']:
        source, target = nodes[edge['source']], nodes[edge['target']]
        assert source.get('parentId') == target.get('parentId'), 'cross_iteration_edge'
        assert edge['data']['sourceType'] == source['data']['type']
        assert edge['data']['targetType'] == target['data']['type']
        assert edge['data']['isInIteration'] == bool(source.get('parentId'))
        forward[edge['source']].add(edge['target'])
    for node in nodes.values():
        if node.get('parentId'):
            parent = nodes[node['parentId']]
            assert parent['data']['type'] == 'iteration'
            assert node['data']['isInIteration']
            for axis, size in (('x', 'width'), ('y', 'height')):
                assert node['positionAbsolute'][axis] == parent['position'][axis] + node['position'][axis]
                assert node['position'][axis] >= 0
                assert node['position'][axis] + node[size] + 32 <= parent[size]
            forward[parent['id']].add(node['id'])
    visiting, done = set(), set()
    def visit(node_id):
        assert node_id not in visiting, 'cycle'
        if node_id in done:
            return
        visiting.add(node_id)
        for child in forward[node_id]:
            visit(child)
        visiting.remove(node_id)
        done.add(node_id)
    visit('1000')
    assert done == set(nodes), 'unreachable_node'
    def upstream(source, target):
        todo, seen = [source], set()
        while todo:
            current = todo.pop()
            if current == target:
                return True
            if current not in seen:
                seen.add(current)
                todo.extend(forward[current])
        return False
    outputs, consumed = {}, set()
    for key, node in nodes.items():
        data, kind = node['data'], node['data']['type']
        assert kind not in ('agent', 'agent-v2')
        if kind == 'code':
            parsed = ast.parse(data['code'])
            functions = [n.name for n in parsed.body if isinstance(n, ast.FunctionDef)]
            assert len(functions) == len(set(functions)) and functions.count('main') == 1
            assert not any(isinstance(n, ast.ImportFrom) and n.module == 'common' for n in parsed.body)
            assert not re.search(r'_(?:legacy|v\d+)(?:_result)?_main', data['code'])
            namespace = {}; exec(compile(parsed, key, 'exec'), namespace)
            assert set(inspect.signature(namespace['main']).parameters) == {v['variable'] for v in data['variables']}
            outputs[key] = set(data['outputs'])
        elif kind == 'start':
            outputs[key] = {v['variable'] for v in data['variables']}
        elif kind in ('variable-aggregator', 'iteration'):
            outputs[key] = {'output', 'item', 'index'} if kind == 'iteration' else {'output'}
        elif kind in ('llm', 'tool'):
            outputs[key] = {'text', 'json', 'files', 'error_message', 'error_type'}
            if kind == 'tool':
                assert data['provider_type'] == 'builtin' and data['tool_name'] == 'save_as_file'
            else:
                assert data['error_strategy'] == 'default-value'
                assert '<' in data['prompt_template'][0]['text'] and '例如' in data['prompt_template'][0]['text']
    reference_count = 0
    for key, node in nodes.items():
        data = node['data']
        for selector in selectors(data):
            source, output = selector[:2]
            assert output in outputs[source], (key, selector, 'unknown_output')
            assert upstream(source, key), (key, selector, 'not_upstream')
            owner = nodes[source].get('parentId')
            assert not owner or owner == node.get('parentId'), (key, selector, 'escaped_iteration_variable')
            consumed.add((source, output)); reference_count += 1
        if data['type'] == 'iteration':
            selector = data['output_selector']
            assert nodes[selector[0]].get('parentId') == key
            assert selector[1] in outputs[selector[0]]
            assert nodes[data['start_node_id']].get('parentId') == key
            consumed.add(tuple(selector))
    for key, node in nodes.items():
        if node['data']['type'] == 'code':
            assert all((key, field) in consumed for field in outputs[key]), (key, 'unused_output')
    # Nodes sharing a canvas scope must not overlap.
    rectangles = list(nodes.values())
    for i, first in enumerate(rectangles):
        for second in rectangles[i + 1:]:
            if first.get('parentId') != second.get('parentId'):
                continue
            a, b = first['position'], second['position']
            assert (a['x'] + first['width'] <= b['x'] or b['x'] + second['width'] <= a['x']
                    or a['y'] + first['height'] <= b['y'] or b['y'] + second['height'] <= a['y']), (first['id'], second['id'], 'overlap')
    return {'file': DSL.name, 'nodes': len(nodes), 'edges': len(graph['edges']),
            'types': dict(Counter(n['data']['type'] for n in nodes.values())),
            'checked_selectors': reference_count, 'sha256': hashlib.sha256(DSL.read_bytes()).hexdigest(),
            'iterations': {k: {'width': n['width'], 'height': n['height']} for k, n in nodes.items() if n['data']['type'] == 'iteration'}}


if __name__ == '__main__':
    print(json.dumps(check_single(), ensure_ascii=False, indent=2))
