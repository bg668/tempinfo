"""Numeric database identifiers must survive every model boundary as text."""

import copy
import csv
import io
import json
import unittest

import test_regression as fixture


class NumericIdTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixture.WorkflowTests.setUpClass()

    def setUp(self):
        self.f = fixture.WorkflowTests()

    def render(self, article):
        return fixture.invoke('02', '150', article_json=json.dumps(article, ensure_ascii=False))

    def test_identity_scalars_and_lists_keep_leading_zeroes_in_all_parsers(self):
        text = ('result:\n  source_article_id: "00048083"\n  parent_article_id: 00048285\n'
                '  member_article_ids:\n    - 0007\n    - 7\n  scores:\n    relevance: 5')
        for prefix, node in [('01', '300'), ('02', '300'), ('02', '510'), ('02', '610'),
                             ('03', '410'), ('04', '400')]:
            with self.subTest(parser=(prefix, node)):
                result = fixture.runtime(prefix, node)['parse_contract'](text, 'result')
                self.assertEqual(result['source_article_id'], '00048083')
                self.assertEqual(result['parent_article_id'], '00048285')
                self.assertEqual(result['member_article_ids'], ['0007', '7'])
                self.assertIs(type(result['scores']['relevance']), int)

    def test_real_25_triage_payloads_pass_and_drop_is_not_uncertain(self):
        cases = json.loads((fixture.ROOT / 'tests/fixtures/real_triage_regressions.json').read_text())['cases']
        counts = {'KEEP': 0, 'DROP': 0}
        for case in cases:
            article = dict(self.f.articles[0], source_article_id=case['source_article_id'], title=case['title'])
            rendered = self.render(article)
            result = fixture.invoke('02', '300', raw=fixture.raw('triage_result', case['triage']),
                                    article_text=rendered['article_text'])
            self.assertEqual(result['validation_error'], '', case['source_article_id'])
            triage = json.loads(result['triage_json'])
            self.assertEqual(triage['source_article_id'], case['source_article_id'])
            self.assertEqual(result['decision'], case['triage']['decision'])
            self.assertEqual(triage['total_score'], sum(case['triage']['scores'].values()) * 4)
            counts[result['decision']] += 1
            if result['decision'] == 'DROP':
                wrapped = fixture.decode(fixture.invoke('02', '700',
                    article_text=rendered['article_text'], article_json=rendered['article_json'],
                    triage_json=result['triage_json'], validation_error=result['validation_error']))
                self.assertEqual(wrapped['kind'], 'nonkeep')
                self.assertEqual(wrapped['errors'], [])
                if case['source_article_id'] == '48083':
                    self.assertEqual(triage['total_score'], 48)
        self.assertEqual(counts, {'KEEP': 2, 'DROP': 23})

    def test_parse_failure_stays_one_error_through_nonkeep_wrapper(self):
        rendered = self.render(dict(self.f.articles[0], source_article_id='48083'))
        for raw, expected in [('以下是结果\ntriage_result:', 'parse:line 1: expected key: value'),
                              ('<think>未闭合', 'parse:model_reasoning_unclosed')]:
            result = fixture.invoke('02', '300', raw=raw, article_text=rendered['article_text'])
            self.assertEqual(result['validation_error'], expected)
            self.assertEqual(json.loads(result['triage_json']), {'_validation_error': expected})
            wrapped = fixture.decode(fixture.invoke('02', '700',
                article_text=rendered['article_text'], article_json=rendered['article_json'],
                triage_json=result['triage_json'], validation_error=result['validation_error']))
            self.assertEqual(wrapped['kind'], 'error')
            self.assertEqual(wrapped['errors'], [expected])
            self.assertEqual(wrapped['article']['source_article_id'], '48083')

    def test_wrong_identity_is_still_rejected(self):
        rendered = self.render(dict(self.f.articles[0], source_article_id='00048083'))
        result = fixture.invoke('02', '300', raw=fixture.raw('triage_result', fixture.triage('48083')),
                                article_text=rendered['article_text'])
        self.assertEqual(result['validation_error'], 'source_article_id_mismatch')
        self.assertEqual(json.loads(result['triage_json'])['source_article_id'], '48083')

    def test_numeric_ids_reach_complete_tables_and_nonempty_csv(self):
        mapping = {'A-SEC-001': '48490', 'A-POL-001': '00048083', 'A-DIG-001': '00048285'}
        articles = {a['source_article_id']: dict(a, source_article_id=mapping[a['source_article_id']])
                    for a in self.f.articles}
        articles['A-DIG-001']['title'] = '安全简讯（2026.08.27）'
        self.f.prepared = fixture.invoke('00', '1100', articles_json=json.dumps(list(articles.values())))
        rendered = {key: self.render(article)['article_text'] for key, article in articles.items()}
        digest = self.f.digest_draft()
        digest['parent_article_id'] = mapping['A-DIG-001']
        d = fixture.invoke('01', '300', raw=fixture.raw('digest_result', digest),
                           article_text=rendered['A-DIG-001'])
        normals = []
        for key, node, root, draft, triage in [
            ('A-SEC-001', '510', 'incident_result', self.f.incident_draft(), fixture.triage(mapping['A-SEC-001'])),
            ('A-POL-001', '610', 'policy_result', self.f.policy_draft(), fixture.triage(mapping['A-POL-001'],
                route='compliance_policy', category='compliance_policy', nature='policy')),
        ]:
            t = fixture.invoke('02', '300', raw=fixture.raw('triage_result', triage), article_text=rendered[key])
            self.assertEqual(t['validation_error'], '')
            draft['source_article_id'] = mapping[key]
            out = fixture.invoke('02', node, raw='<think>分析</think>\n' + fixture.raw(root, draft),
                                 article_text=rendered[key], triage_json=t['triage_json'])
            self.assertEqual(fixture.decode(out)['errors'], [])
            normals.append(out['result_json'])
        final, _, _, _ = self.f.pipeline(digests=[d['result_json']], normals=normals)
        self.assertEqual(final['run_status'], 'SUCCESS', final['errors_json'])
        records = json.loads(final['processing_items_json'])
        self.assertEqual({r['source_article_id'] for r in records}, set(mapping.values()))
        candidates = json.loads(final['candidates_json'])
        self.assertEqual(len(candidates), 3)
        item_ids = {r['item_id'] for r in records}
        self.assertTrue(all(c['primary_item_id'] in item_ids for c in candidates))
        csv_text = fixture.invoke('00', '6100', review_items_json=final['review_items_json'])['csv_text']
        self.assertEqual(len(list(csv.DictReader(io.StringIO(csv_text.lstrip('\ufeff'))))), 3)

    def test_match_distinguishes_zero_padded_ids(self):
        incident = fixture.decode(self.f.incident())
        members = []
        for sid in ('0007', '7'):
            member = copy.deepcopy(incident)
            for key in ('article', 'facts', 'triage'):
                member[key]['source_article_id'] = sid
            members.append(member)
        draft = {'groups': {'group_001': {'canonical_title': '同一事件',
                  'member_article_ids': ['0007', '7'], 'match_reason': '主体与事件事实一致'}}}
        result = fixture.decode(fixture.invoke('03', '410', raw=fixture.raw('event_match_result', draft),
                                               incidents_json=json.dumps(members)))
        self.assertEqual(result['errors'], [])
        self.assertFalse(result['degraded'])
        self.assertEqual(result['groups'][0]['member_article_ids'], ['0007', '7'])


if __name__ == '__main__':
    unittest.main()
