"""Exercise actual WorkflowTool text envelopes, including missing custom outputs."""

import copy
import json
import unittest

import test_regression as fixture
import test_storage as storage


class WorkflowToolTransportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixture.WorkflowTests.setUpClass()

    def adapt(self, node, outputs, source, message=None, error_type=None):
        # Dify WorkflowTool._invoke returns json.dumps(End outputs) in standard text.
        return fixture.invoke('00', node, tool_text=json.dumps(outputs, ensure_ascii=False),
                              error_message=message, error_type=error_type,
                              source_json=json.dumps(source, ensure_ascii=False))

    def finish(self, prepared, normals, digests=None, grouping=None, events=None):
        helper = storage.StorageTests()
        helper.f = fixture.WorkflowTests()
        return helper.finish(prepared, digests or [], normals, grouping=grouping, events=events)

    def test_all_four_standard_text_adapters_preserve_end_outputs(self):
        f = fixture.WorkflowTests()
        incident, digest, policy = f.incident(), f.digest(), f.policy()
        group_output = fixture.invoke('03', '500', incidents_json=json.dumps([fixture.decode(incident)]))
        group = fixture.decode(group_output)['groups'][0]
        candidate = fixture.invoke('04', '400', group_json=json.dumps(group),
                                   raw=fixture.raw('event_candidate', f.candidate_draft()))
        cases = [('2120', digest, f.articles[2]), ('3120', incident, f.articles[0]),
                 ('3120', policy, f.articles[1]), ('4120', group_output, [fixture.decode(incident)]),
                 ('5120', candidate, group)]
        for node, end_outputs, source in cases:
            with self.subTest(node=node):
                self.assertEqual(fixture.decode(self.adapt(node, end_outputs, source)),
                                 fixture.decode(end_outputs))
        fixed = self.finish(f.prepared,
            [self.adapt('3120', incident, f.articles[0])['result_json'],
             self.adapt('3120', policy, f.articles[1])['result_json']],
            [self.adapt('2120', digest, f.articles[2])['result_json']],
            self.adapt('4120', group_output, [])['result_json'],
            [self.adapt('5120', candidate, group)['result_json']])
        baseline = f.pipeline()[0]
        # Run IDs/processing_version come from the same prepared manifest.
        for field in ('processing_items_json', 'candidates_json', 'review_items_json', 'stats_json', 'errors_json'):
            self.assertEqual(json.loads(fixed[field]), json.loads(baseline[field]), field)

    def test_25_tool_failures_keep_actual_cause_and_source_without_cascade(self):
        f = fixture.WorkflowTests()
        articles, outputs = [], []
        for index in range(25):
            article = copy.deepcopy(f.articles[0])
            article['source_article_id'] = str(10000 + index)
            articles.append(article)
            outputs.append(self.adapt('3120', {}, article,
                'fixture: provider rejected model configuration', 'ToolInvokeError')['result_json'])
        prepared = fixture.invoke('00', '1100', articles_json=json.dumps(articles))
        final = self.finish(prepared, outputs)
        rows, errors = json.loads(final['processing_items_json']), json.loads(final['errors_json'])
        self.assertEqual(len(rows), 25)
        self.assertEqual(len(errors), 25)
        self.assertEqual(json.loads(final['stats_json'])['normal_error_count'], 25)
        self.assertEqual({e['code'] for e in errors}, {'workflow_tool_execution_failed'})
        self.assertEqual({e['source_article_id'] for e in errors}, {a['source_article_id'] for a in articles})
        for row in rows:
            self.assertEqual(row['process_status'], 'FAILED')
            self.assertIsNone(row['decision'])
            self.assertEqual(len(row['errors_json']), 1)
            self.assertEqual(row['errors_json'][0]['node_id'], '3110')
            self.assertEqual(row['errors_json'][0]['error_type'], 'ToolInvokeError')
            self.assertIn('provider rejected', row['errors_json'][0]['message'])

    def test_group_tool_failure_preserves_error_without_none_json_message(self):
        adapted = self.adapt('4120', {}, [], 'fixture: workflow not published', 'ToolInvokeError')
        result = fixture.invoke('00', '4200', result_json=adapted['result_json'], incidents_json='[]')
        errors = json.loads(result['event_match_errors_json'])
        self.assertEqual(len(errors), 1)
        self.assertEqual(errors[0]['message'], 'fixture: workflow not published')
        self.assertEqual(errors[0]['node_id'], '4100')
        self.assertEqual(result['group_jsons'], [])

    def test_missing_end_output_is_contract_error_not_execution_error(self):
        for value in ('', 'not json', '{}', 'null', '{"result_json":null}', '{"result_json":"[]"}'):
            result = fixture.decode(fixture.invoke('00', '3120', tool_text=value,
                error_message=None, error_type=None, source_json='{"source_article_id":"A"}'))
            self.assertEqual(result['errors'][0]['code'], 'workflow_tool_output_invalid')
            self.assertEqual(result['article']['source_article_id'], 'A')
            self.assertNotIn('triage', result)

    def test_digest_and_candidate_failures_keep_context_and_original_error(self):
        for node, source, id_field in [('2120', {'source_article_id': 'D1'}, 'parent_article_id'),
                                      ('5120', {'event_id': 'E1'}, 'event_id')]:
            result = fixture.decode(self.adapt(node, {}, source, 'fixture: timeout', 'TimeoutError'))
            self.assertEqual(result[id_field], next(iter(source.values())))
            self.assertEqual(result['errors'][0]['message'], 'fixture: timeout')


if __name__ == '__main__':
    unittest.main()
