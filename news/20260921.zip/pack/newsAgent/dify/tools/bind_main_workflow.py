#!/usr/bin/env python3
"""Bind workspace-local Workflow Tools without changing the caller's contract."""

import argparse
import json
from pathlib import Path

import yaml

ROLES = {
    "2110": "news_digest_process",
    "3110": "news_article_process",
    "4100": "news_event_match",
    "5110": "news_event_candidate",
}
EXPECTED = set(ROLES.values())
COPY_FIELDS = (
    "provider_id",
    "provider_type",
    "provider_name",
    "provider_show_name",
    "tool_name",
    "tool_label",
    "version",
    "tool_node_version",
    "tool_description",
    "is_team_authorization",
    "paramSchemas",
    "params",
    "plugin_id",
    "provider_icon",
    "provider_icon_dark",
    "plugin_unique_identifier",
)


def from_dsl(path, accepted_names=None):
    """Resolve explicit tool identities; never infer a role from similar inputs."""
    document = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    accepted_names = accepted_names or {role: {role} for role in EXPECTED}
    bindings = {}
    for node in document.get("workflow", {}).get("graph", {}).get("nodes", []):
        data = node.get("data") or {}
        if data.get("type") == "tool" and data.get("provider_type") == "workflow":
            for role, names in accepted_names.items():
                if data.get("tool_name") not in names:
                    continue
                binding = {k: data[k] for k in COPY_FIELDS if k in data}
                if role in bindings and bindings[role] != binding:
                    raise ValueError(role + " 对应多个不同工具；请只保留目标工具或指定 --tool-alias")
                bindings[role] = binding
    return bindings


def bind_tool(data, binding):
    name = data["tool_name"]
    if not binding.get("provider_id") or not binding.get("tool_name"):
        raise ValueError(name + " 缺少 provider_id 或实际 tool_name")
    if binding.get("provider_type") != "workflow":
        raise ValueError(name + " 必须绑定 Workflow Tool")
    parameters = data.get("tool_parameters") or {}
    schemas = binding.get("paramSchemas")
    if not isinstance(schemas, list):
        raise ValueError(name + " 缺少真实参数定义；请发布新子流程并导出包含四个工具的临时 DSL")
    names = {p.get("name") for p in schemas}
    missing = set(parameters) - names
    # Even an optional obsolete parameter means the exported tool contract is stale.
    extra = names - set(parameters)
    if missing or extra:
        details = []
        if missing:
            details.append("缺少 " + ",".join(sorted(missing)))
        if extra:
            details.append("多余 " + ",".join(sorted(extra)))
        raise ValueError(
            name + " 工具接口过期，" + "；".join(details) + "；请更新子流程和工具定义后重新导出"
        )
    for key in COPY_FIELDS:
        if key in binding:
            data[key] = binding[key]
        else:
            data.pop(key, None)
    data["provider_type"] = "workflow"
    data["tool_parameters"] = parameters
    data["params"] = {key: data.get("params", {}).get(key, "") for key in parameters}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--template", required=True)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--tool-dsl")
    source.add_argument("--bindings-json")
    parser.add_argument("--output", required=True)
    parser.add_argument(
        "--tool-alias",
        action="append",
        default=[],
        metavar="ROLE=TOOL_NAME",
        help="明确指定业务角色对应的实际调用名，例如 news_event_match=03work",
    )
    args = parser.parse_args()
    document = yaml.safe_load(Path(args.template).read_text(encoding="utf-8"))
    targets = {
        ROLES[node["id"]]: node["data"]
        for node in document["workflow"]["graph"]["nodes"]
        if node["id"] in ROLES and node.get("data", {}).get("type") == "tool"
    }
    if set(targets) != EXPECTED:
        raise SystemExit("主控缺少固定调用节点 2110 / 3110 / 4100 / 5110")
    accepted_names = {role: {role, data["tool_name"]} for role, data in targets.items()}
    aliases = {}
    for value in args.tool_alias:
        role, separator, name = value.partition("=")
        if not separator or role not in EXPECTED or not name or role in aliases:
            raise SystemExit("无效或重复的 --tool-alias: " + value)
        aliases[role] = name
        accepted_names[role] = {name}
    if args.bindings_json and aliases:
        raise SystemExit("--tool-alias 仅用于 --tool-dsl；bindings JSON 直接按业务角色填写")
    try:
        bindings = (
            from_dsl(args.tool_dsl, accepted_names)
            if args.tool_dsl
            else json.loads(Path(args.bindings_json).read_text(encoding="utf-8"))
        )
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc
    missing = EXPECTED - set(bindings)
    if missing:
        raise SystemExit("缺少 Workflow Tool: " + ",".join(sorted(missing)))
    identities = {
        (bindings[role].get("provider_id"), bindings[role].get("tool_name"))
        for role in EXPECTED
    }
    if len(identities) != 4:
        raise SystemExit("四个业务角色不能绑定到同一个工具")
    for role, data in targets.items():
        try:
            bind_tool(data, bindings[role])
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
    text = yaml.safe_dump(document, allow_unicode=True, sort_keys=False, width=120)
    if any(
        "__" + role + "_PROVIDER_ID__" in text
        for role in ("DIGEST", "ARTICLE", "MATCH", "CANDIDATE")
    ):
        raise SystemExit("仍有未替换 provider placeholder")
    Path(args.output).write_text(text, encoding="utf-8")
    print("已生成", args.output)


if __name__ == "__main__":
    main()
