"""公共业务函数。只使用 Python 标准库；由构建脚本按节点实际依赖嵌入 DSL。"""

import hashlib
import ipaddress
import json
import re
from urllib.parse import urlsplit

ALLOWED_CATEGORIES = {
    'security_incident',
    'threat_activity',
    'vulnerability',
    'data_breach',
    'ransomware',
    'compliance_policy',
    'research',
    'product',
    'other',
}
ALLOWED_NATURES = {
    'real_world_event',
    'policy',
    'ctf_or_simulation',
    'research_or_tutorial',
    'marketing',
    'recruitment',
    'conference_or_training',
    'procurement',
    'other',
}
CONTRACT_VERSION = 'news-review-v2'
EXAMPLE_MARKER = re.compile(
    '(?<!非)(?<!不是)(?:IOC\\s*)?(?:示例|样例|举例|教学演示|演示数据|测试数据|占位(?:符|值)?)|(?<![A-Za-z0-9_./-])(?:example|sample|demo|placeholder)(?![A-Za-z0-9_./-])',
    re.I,
)
IOC_KEYS = ('ips', 'domains', 'urls', 'hashes', 'file_paths', 'vulnerabilities')
NEGATIVE_BREACH = re.compile(
    '(?:尚无|暂无|没有|并无|不存在|未发现|尚未发现|未发生|没有发生|并未发生|不涉及|未涉及|并未涉及|未造成|未导致|排除)[^。；;\\n]{0,22}(?:数据|信息)[^。；;\\n]{0,8}(?:泄露|外泄|被窃|被盗)|(?:数据|信息)[^。；;\\n]{0,8}(?:未泄露|未外泄)|no\\s+(?:confirmed\\s+|evidence\\s+of\\s+)?data\\s+(?:breach|leak)',
    re.I,
)
SCORE_KEYS = ('relevance', 'impact', 'freshness', 'evidence_quality', 'audience_value')
DIGEST_COVERAGE_ERRORS = {
    'source_text_not_grounded', 'duplicate_source_text', 'item_order_mismatch',
    'source_heading_mismatch', 'source_text_must_cover_own_section',
    'source_heading_not_grounded',
}
_DOMAIN_RE = re.compile(
    '(?<![@A-Za-z0-9_.-])(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\\.)+[A-Za-z]{2,63}(?![A-Za-z0-9_.-])'
)
_HASH_RE = re.compile('(?<![0-9A-Fa-f])(?:[0-9A-Fa-f]{64}|[0-9A-Fa-f]{40}|[0-9A-Fa-f]{32})(?![0-9A-Fa-f])')
_IPV4_RE = re.compile('(?<![A-Za-z0-9_.])(?:\\d{1,3}\\.){3}\\d{1,3}(?![A-Za-z0-9_.])')
_URL_RE = re.compile('https?://[^\\s<>"\\\'，。；、]+', re.I)
_VULN_RE = re.compile(
    '(?<![A-Za-z0-9-])(?:CVE-\\d{4}-\\d{4,}|CNVD-\\d{4}-\\d+|CNNVD-\\d{6}-\\d+)(?![A-Za-z0-9-])', re.I
)
_WINDOWS_PATH_RE = re.compile('(?<!\\w)[A-Za-z]:\\\\(?:[^\\s<>:"|?*]+\\\\)*[^\\s<>:"|?*]+')


def _clean_scalar(value):
    value = str(value).strip()
    if len(value) >= 2 and value[0] == value[-1] and (value[0] in {'"', "'"}):
        return value[1:-1]
    return value


def _parse_block(tokens, index, indent, field=''):
    if index >= len(tokens):
        raise ValueError('unexpected end')
    if tokens[index][1] != indent:
        raise ValueError(f'line {tokens[index][0]}: invalid indentation jump')
    if tokens[index][2].startswith('-'):
        result = []
        while index < len(tokens) and tokens[index][1] == indent:
            lineno, _, text = tokens[index]
            if not text.startswith('- '):
                raise ValueError(f'line {lineno}: list items must use - value')
            val = text[2:].strip()
            if not val:
                raise ValueError(f'line {lineno}: nested list items unsupported')
            result.append(_parse_scalar(val, field))
            index += 1
        return (result, index)
    result = {}
    while index < len(tokens) and tokens[index][1] == indent:
        lineno, _, text = tokens[index]
        if text.startswith('-'):
            raise ValueError(f'line {lineno}: mixed mapping/list block')
        if ':' not in text:
            raise ValueError(f'line {lineno}: expected key: value')
        key, val = text.split(':', 1)
        key = key.strip()
        val = val.strip()
        if not key:
            raise ValueError(f'line {lineno}: empty key')
        if key in result:
            raise ValueError(f'line {lineno}: duplicate key {key}')
        index += 1
        if val:
            result[key] = _parse_scalar(val, key)
            continue
        if index >= len(tokens) or tokens[index][1] <= indent:
            raise ValueError(f'line {lineno}: empty mapping requires child; use [] for empty list')
        if tokens[index][1] != indent + 2:
            raise ValueError(f'line {tokens[index][0]}: invalid indentation jump')
        child, index = _parse_block(tokens, index, indent + 2, key)
        result[key] = child
    if index < len(tokens) and tokens[index][1] > indent:
        raise ValueError(f'line {tokens[index][0]}: invalid indentation jump')
    return (result, index)


def _parse_scalar(value, field=''):
    value = _clean_scalar(value)
    if value == '[]':
        return []
    # Identifiers are opaque text, including leading zeroes and list members.
    if field.endswith(('_id', '_ids')):
        return value
    if value.isdigit() or (value.startswith('-') and value[1:].isdigit()):
        return int(value)
    return value


def _strip_code_fence(text):
    value = str(text or '').strip()
    if value.startswith('```') and value.endswith('```'):
        lines = value.splitlines()
        if len(lines) >= 3:
            return '\n'.join(lines[1:-1]).strip()
    return value


def _tokenize(text):
    out = []
    for lineno, raw in enumerate(str(text).splitlines(), 1):
        if not raw.strip():
            continue
        prefix = raw[: len(raw) - len(raw.lstrip())]
        if '\t' in prefix:
            raise ValueError(f'line {lineno}: tabs are not allowed')
        indent = len(raw) - len(raw.lstrip(' '))
        if indent % 2:
            raise ValueError(f'line {lineno}: indentation must be multiples of two spaces')
        out.append((lineno, indent, raw.strip()))
    return out


def _unique(values):
    out = []
    seen = set()
    for val in values:
        val = str(val).strip().rstrip('.,;:!?)】）]')
        key = val.casefold()
        if val and key not in seen:
            seen.add(key)
            out.append(val)
    return out


def canonical_json(article):
    return json.dumps(
        article, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    )


def parse_digest_keywords(value):
    """Shared routing configuration; explicit user keywords replace the defaults."""
    words = (word.strip() for word in re.split(r"[,，;；\n]+", value or ""))
    return tuple(dict.fromkeys(word for word in words if word)) or (
        "日报", "周报", "快讯", "安全简讯"
    )


def clean_model_output(text):
    """Remove only complete leading reasoning blocks; preserve answer contents."""
    text = str(text or '').lstrip('\ufeff \t\r\n')
    while text.startswith('<think>'):
        end = text.find('</think>', len('<think>'))
        if end < 0:
            raise ValueError('model_reasoning_unclosed')
        text = text[end + len('</think>') :].lstrip('\ufeff \t\r\n')
    if not text:
        raise ValueError('model_answer_empty')
    return text


def enrich_review(review, candidate_id, article, triage, excerpt=None):
    detail = source_detail(article, triage, excerpt)
    review.update(
        {
            'candidate_id': candidate_id,
            'source_article_ids': [detail['source_article_id']],
            'source_urls': [detail['source_url']],
            'decision': triage.get('decision', 'KEEP'),
            'category': triage.get('category', ''),
            'content_nature': triage.get('content_nature', ''),
            'scores': detail['scores'],
            'total_score': detail['total_score'],
            'reason': detail['reason'],
            'score_source_article_id': detail['source_article_id'],
            'score_strategy': 'single_article',
            'evidence_text': detail['evidence_text'],
            'source_details': [detail],
            'quality_warnings': [],
            'excluded_iocs': [],
        }
    )
    if str(article.get('content_truncated')).lower() == 'true':
        review['quality_warnings'].append('input_content_truncated')
    return review


def example_ioc_filter(ioc, content):
    """Exclude values only when all occurrences lie in an explicitly example-marked clause.

    An example heading ending in a colon also governs its following indented/list lines.
    An IOC repeated in a genuine incident clause remains eligible.
    """
    clauses = []
    example_block = False
    for line in str(content or '').splitlines():
        if not line.strip():
            example_block = False
            continue
        is_list_line = bool(re.match('^\\s*(?:[-*•]\\s|(?:\\d+[.)、])\\s)', line))
        is_indented = line.startswith((' ', '\t'))
        if not is_list_line and (not is_indented):
            example_block = False
        line_marked = bool(EXAMPLE_MARKER.search(line))
        for clause in re.split('[。；;\\n!?！？]', line):
            if clause.strip():
                marker = EXAMPLE_MARKER.search(clause)
                clauses.append((clause, marker.start() if marker else None, example_block))
        if line_marked and line.rstrip().endswith(('：', ':')):
            example_block = True
    clean = {key: [] for key in IOC_KEYS}
    excluded = []
    errors = []
    for key in IOC_KEYS:
        values = ioc.get(key, [])
        if not isinstance(values, list):
            errors.append('ioc_not_list:' + key)
            continue
        for value in values:
            if not isinstance(value, str) or not value.strip():
                errors.append('invalid_ioc_value:' + key)
                continue
            occurrences = []
            token = re.escape(value)
            if key in ('ips', 'domains', 'hashes', 'vulnerabilities'):
                token = '(?<![A-Za-z0-9_.-])' + token + '(?![A-Za-z0-9_.-])'
            for clause, marker_position, inherited in clauses:
                for match in re.finditer(token, clause):
                    occurrences.append(
                        (
                            clause,
                            inherited or (marker_position is not None and marker_position <= match.start()),
                        )
                    )
            if not occurrences:
                errors.append('ioc_not_grounded:' + key + '=' + value)
            elif all((marked for _, marked in occurrences)):
                excluded.append(
                    {
                        'type': key,
                        'value': value,
                        'reason': 'explicit_example_context',
                        'evidence_text': occurrences[0][0].strip(),
                    }
                )
            elif value not in clean[key]:
                clean[key].append(value)
    return (clean, excluded, errors)


def factual_errors(draft, source):
    """Narrow, explainable guards; not a general semantic entailment checker."""
    errors = []
    for key in ('title', 'summary', 'impact', 'data_breach_scope', 'lesson'):
        value = draft.get(key, '')
        if not isinstance(value, str):
            continue
        if NEGATIVE_BREACH.search(value) and (not NEGATIVE_BREACH.search(source)):
            errors.append('unsupported_negative_breach:' + key)
        for name in re.findall('《([^》]+)》', value):
            if '《' + name + '》' not in source:
                errors.append('unsupported_formal_policy_title:' + key)
    return list(dict.fromkeys(errors))


def ioc_report(ioc):
    return {
        'ip_count': len(ioc.get('ips') or []),
        'domain_count': len(ioc.get('domains') or []),
        'url_count': len(ioc.get('urls') or []),
        'hash_count': len(ioc.get('hashes') or []),
        'file_path_count': len(ioc.get('file_paths') or []),
        'vulnerability_count': len(ioc.get('vulnerabilities') or []),
        **{
            k: list(ioc.get(k) or [])
            for k in ('ips', 'domains', 'urls', 'hashes', 'file_paths', 'vulnerabilities')
        },
    }


def is_label_title(title):
    value = str(title or '').strip()
    if not value or value.casefold() in {'unknown', 'null', 'none'}:
        return True
    value = re.sub('^[【\\[（(\\s#]+|[】\\]）)\\s]+$', '', value)
    return bool(
        re.fullmatch(
            '(?:(?:事件|新闻|资讯|快讯|条目|案例|要闻)\\s*)?(?:第\\s*)?[一二三四五六七八九十百零〇\\d]+(?:\\s*[条项章节])?[.、:：]?',
            value,
        )
    )


def literal_iocs(text):
    ips = []
    for m in _IPV4_RE.finditer(text or ''):
        try:
            ipaddress.ip_address(m.group(0))
            ips.append(m.group(0))
        except ValueError:
            pass
    urls = _unique([m.group(0) for m in _URL_RE.finditer(text or '')])
    domains = [m.group(0) for m in _DOMAIN_RE.finditer(text or '')]
    for u in urls:
        host = urlsplit(u).hostname
        if host:
            try:
                ipaddress.ip_address(host)
            except ValueError:
                domains.append(host)
    return {
        'ips': _unique(ips),
        'domains': _unique(domains),
        'urls': urls,
        'hashes': _unique([m.group(0) for m in _HASH_RE.finditer(text or '')]),
        'file_paths': _unique([m.group(0) for m in _WINDOWS_PATH_RE.finditer(text or '')]),
        'vulnerabilities': _unique([m.group(0) for m in _VULN_RE.finditer(text or '')]),
    }


def norm_text(value):
    return re.sub('\\s+', '', str(value or ''))


def parse_article_input(text):
    lines = str(text or '').splitlines()
    out = {}
    content = []
    in_content = False
    if not lines or lines[0].strip() != 'article:':
        raise ValueError('article root missing')
    for raw in lines[1:]:
        if raw.startswith('  ') and (not raw.startswith('    ')):
            s = raw[2:]
            if s == 'content:':
                in_content = True
                continue
            in_content = False
            if ':' in s:
                k, val = s.split(':', 1)
                out[k.strip()] = val.strip()
        elif in_content and raw.startswith('    '):
            content.append(raw[4:])
    out['content'] = '\n'.join(content).rstrip()
    return out


def parse_contract(text, root):
    parsed = parse_tree(text)
    if set(parsed) != {root}:
        raise ValueError(f'top level must contain only {root}')
    payload = parsed[root]
    if not isinstance(payload, dict):
        raise ValueError(root + ' must be mapping')
    return payload


def parse_tree(text):
    text = _strip_code_fence(clean_model_output(text))
    if not text:
        raise ValueError('empty output')
    tokens = _tokenize(text)
    if not tokens or tokens[0][1] != 0:
        raise ValueError('top level must start at indentation 0')
    parsed, index = _parse_block(tokens, 0, 0)
    if index != len(tokens):
        raise ValueError(f'line {tokens[index][0]}: remaining content')
    if not isinstance(parsed, dict):
        raise ValueError('top level must be mapping')
    return parsed


def render_lines(value, indent=0):
    p = ' ' * indent
    if isinstance(value, dict):
        lines = []
        for k, ch in value.items():
            if isinstance(ch, (dict, list)):
                if isinstance(ch, list) and (not ch):
                    lines.append(f'{p}{k}: []')
                else:
                    lines.append(f'{p}{k}:')
                    lines.extend(render_lines(ch, indent + 2))
            else:
                lines.append(f"{p}{k}: {('unknown' if ch is None else ch)}")
        return lines
    if isinstance(value, list):
        return [f'{p}- {x}' for x in value]
    return [f'{p}{value}']


def source_detail(article, triage, excerpt=None):
    body = str(article.get('content') or '') if excerpt is None else str(excerpt)
    return {
        'source_article_id': str(article.get('source_article_id') or ''),
        'source_url': str(article.get('url') or ''),
        'original_title': str(article.get('title') or ''),
        'published_at': str(article.get('published_at') or 'unknown'),
        'evidence_text': body[:2000],
        'evidence_truncated': len(body) > 2000,
        'scores': dict(triage.get('scores') or {}),
        'total_score': triage.get('total_score'),
        'reason': str(triage.get('reason') or ''),
    }


def stable_event_id(ids):
    return 'event_' + hashlib.sha256('|'.join(sorted(ids)).encode('utf-8')).hexdigest()[:16]


def unique_objects(rows):
    seen = set()
    out = []
    for row in rows:
        key = json.dumps(row, ensure_ascii=False, sort_keys=True)
        if key not in seen:
            seen.add(key)
            out.append(row)
    return out


def digest_parent_errors(result):
    """Older envelopes have no error scope, so conservatively block their whole parent."""
    scoped = result.get('parent_errors')
    return scoped if isinstance(scoped, list) else result.get('errors') or []


def model_failure_result():
    """A failed model call has no business payload to parse or validate."""
    return {'contract_version': CONTRACT_VERSION, 'kind': 'error',
            'errors': ['llm_execution_failed'], '_error': 'llm_execution_failed'}


def validate_triage_payload(obj, enforce_non_target_nature=True):
    errors = []
    required = {'source_article_id', 'decision', 'route', 'category', 'content_nature', 'scores', 'reason'}
    if set(obj) != required:
        errors.append('fields_mismatch')
    decision = str(obj.get('decision', ''))
    route = str(obj.get('route', ''))
    category = str(obj.get('category', ''))
    nature = str(obj.get('content_nature', ''))
    if decision not in {'KEEP', 'DROP', 'UNCERTAIN'}:
        errors.append('invalid_decision')
    if route not in {'security_event', 'compliance_policy', 'non_target', 'uncertain'}:
        errors.append('invalid_route')
    if category not in ALLOWED_CATEGORIES:
        errors.append('invalid_category')
    if nature not in ALLOWED_NATURES:
        errors.append('invalid_content_nature')
    if decision == 'KEEP' and route not in {'security_event', 'compliance_policy'}:
        errors.append('KEEP_route')
    if decision == 'DROP' and route != 'non_target':
        errors.append('DROP_route')
    if decision == 'UNCERTAIN' and route != 'uncertain':
        errors.append('UNCERTAIN_route')
    if route == 'compliance_policy' and (category != 'compliance_policy' or nature != 'policy'):
        errors.append('policy_consistency')
    if route == 'security_event' and category not in {
        'security_incident',
        'threat_activity',
        'vulnerability',
        'data_breach',
        'ransomware',
    }:
        errors.append('event_category')
    if (
        enforce_non_target_nature
        and decision == 'KEEP'
        and (
            nature
            in {
                'ctf_or_simulation',
                'research_or_tutorial',
                'marketing',
                'recruitment',
                'conference_or_training',
                'procurement',
            }
        )
    ):
        errors.append('non_target_nature_cannot_keep')
    scores = obj.get('scores')
    if not isinstance(scores, dict) or set(scores) != set(SCORE_KEYS):
        errors.append('scores_fields')
    clean = {}
    for k in SCORE_KEYS:
        try:
            val = int((scores or {}).get(k))
        except Exception:
            val = -1
        if not 0 <= val <= 5:
            errors.append('score_' + k)
            val = max(0, min(5, val if val >= 0 else 0))
        clean[k] = val
    total = round(sum(clean.values()) / 5.0 * 20.0, 2)
    obj = dict(obj)
    obj['scores'] = clean
    obj['total_score'] = total
    return (obj, errors)


def adapt_workflow_tool(tool_text, error_message, error_type, source_json, stage, node_id):
    """Unwrap WorkflowTool's standard text; retain original transport errors and identity."""
    code = 'workflow_tool_execution_failed'
    message = str(error_message or '')
    if not message and not error_type:
        try:
            outputs = json.loads(tool_text)
            if not isinstance(outputs, dict) or not isinstance(outputs.get('result_json'), str):
                raise ValueError('missing_result_json_in_tool_text:check_child_End_and_published_tool')
            payload = json.loads(outputs['result_json'])
            if not isinstance(payload, dict):
                raise ValueError('child_result_not_object')
            return payload
        except (TypeError, ValueError) as exc:
            code = 'workflow_tool_output_invalid'
            message = str(exc)
    if not message:
        message = str(error_type) + ': Dify did not provide error_message'
    error = {'stage': stage, 'code': code, 'message': message,
             'node_id': node_id, 'error_type': str(error_type or '')}
    payload = {'kind': 'error', 'contract_version': CONTRACT_VERSION,
               'storage_contract_version': 'news-storage-v1', 'error_stage': stage,
               'errors': [error]}
    try:
        source = json.loads(source_json)
    except (TypeError, ValueError):
        source = {}
    if stage in ('digest', 'normal'):
        article = source if isinstance(source, dict) else {}
        payload['article'] = article
        error['source_article_id'] = article.get('source_article_id', '')
        if stage == 'digest':
            payload.update(parent_article_id=article.get('source_article_id', ''), items=[], candidates=[])
    elif stage == 'candidate':
        payload['event_id'] = source.get('event_id', '') if isinstance(source, dict) else ''
        error['event_id'] = payload['event_id']
    else:
        payload.update(groups=[], degraded=True)
    return payload
