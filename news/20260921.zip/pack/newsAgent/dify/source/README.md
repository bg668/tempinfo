# 单工作流源码

维护 `common.py` 中的公共解析和规则、`nodes/` 中的业务函数，模板只定义各业务模块内部的节点参数。`prompt_contracts.py` 将允许枚举同步到快讯提示词，`build.py` 仅内嵌每个节点实际依赖的函数。`single_workflow.py` 完成节点编号、选择器、遍历归属和画布布局映射。

在项目根目录运行 `python tools/build_dsl.py`，最终部署文件为 `dify/00_安全资讯处理_单工作流.yml`。`dify/build/modules/` 仅是编译中间产物和回归输入，不需要在 Dify 创建多个应用。源码按业务模块组织，发布时使用一张图。

维护两层回归：模块校验保留已有业务规则和数据契约；单图回归直接运行交付 DSL 的 Code、选择器、分支、遍历及输出，使用模型和文件工具替身。每个 Code 节点仅一个 main，不引用服务器上的 common.py。完整测试为 `python tools/run_tests.py`。
