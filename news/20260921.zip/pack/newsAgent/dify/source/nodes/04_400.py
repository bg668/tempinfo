"""节点 04_400 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import json
import re
from common import (
    CONTRACT_VERSION,
    SCORE_KEYS,
    example_ioc_filter,
    factual_errors,
    ioc_report,
    is_label_title,
    model_failure_result,
    parse_contract,
    source_detail,
    stable_event_id,
    unique_objects,
)


def merge_iocs(rows):
    buckets = {k: {} for k in ('ips', 'domains', 'urls', 'hashes', 'file_paths', 'vulnerabilities')}
    for r in rows:
        f = r.get('facts') or {}
        i = (
            f.get('ioc')
            if isinstance(f.get('ioc'), dict)
            else r.get('ioc') if isinstance(r.get('ioc'), dict) else {}
        )
        for k in buckets:
            for val in i.get(k, []) or []:
                buckets[k].setdefault(str(val).casefold(), str(val))
    return {k: list(v.values()) for k, v in buckets.items()}


def text_value(value):
    return isinstance(value, str) and bool(value.strip()) and (not re.search('<[^>]+>', value))


def score_errors(triage):
    errors = []
    scores = triage.get('scores')
    if not isinstance(scores, dict) or set(scores) != set(SCORE_KEYS):
        return ['scores_fields']
    for key in SCORE_KEYS:
        if type(scores[key]) is not int or not 0 <= scores[key] <= 5:
            errors.append('score_integer_0_5:' + key)
    if not text_value(triage.get('reason')):
        errors.append('missing_reason')
    if 'total_score' in triage and (not errors) and (triage['total_score'] != sum(scores.values()) * 4):
        errors.append('total_score_mismatch')
    return errors


def parse_candidate_fields(raw: str, group_json: str) -> dict:
    """解析候选树文本并补充来源字段；返回对象，不进行结果序列化。"""
    errors = []
    try:
        group = json.loads(group_json or '{}')
    except Exception as e:
        group = {}
        errors.append('group_json:' + str(e))
    try:
        draft = parse_contract(raw, 'event_candidate')
    except Exception as e:
        draft = {}
        errors.append('candidate_tree:' + str(e))
    req = {
        'event_time',
        'title',
        'summary',
        'victim',
        'attacker',
        'attack_vector_or_cause',
        'affected_system',
        'impact',
        'data_breach_scope',
        'lesson',
    }
    if set(draft) != req:
        errors.append('fields_mismatch')
    for k in req:
        if not str(draft.get(k, '')).strip():
            errors.append('empty_' + k)
    if not str(group.get('event_id', '')).strip():
        errors.append('missing_event_id')
    members = [r for r in group.get('members') or [] if isinstance(r, dict)]
    ids = []
    urls = []
    if not members:
        errors.append('missing_members')
    for r in members:
        f = r.get('facts') or {}
        a = r.get('article') or {}
        sid = str(f.get('source_article_id') or a.get('source_article_id') or '')
        if sid and sid not in ids:
            ids.append(sid)
        u = str(f.get('source_url') or a.get('url') or '')
        if u and u not in urls:
            urls.append(u)
    ioc = merge_iocs(members)
    result = {
        'event_id': group.get('event_id', ''),
        'event_time': str(draft.get('event_time', 'unknown')),
        'title': str(draft.get('title') or group.get('canonical_title') or ''),
        'source_article_ids': ids,
        'source_urls': urls,
        'summary': str(draft.get('summary', '')),
        'victim': str(draft.get('victim', 'unknown')),
        'attacker': str(draft.get('attacker', 'unknown')),
        'attack_vector_or_cause': str(draft.get('attack_vector_or_cause', 'unknown')),
        'affected_system': str(draft.get('affected_system', 'unknown')),
        'impact': str(draft.get('impact', 'unknown')),
        'data_breach_scope': str(draft.get('data_breach_scope', 'unknown')),
        'lesson': str(draft.get('lesson', 'unknown')),
        'ioc': ioc_report(ioc),
    }
    primary = (members[0].get('article') if members else {}) or {}
    review = {
        'published_at': primary.get('published_at') or result['event_time'] or 'unknown',
        'title': result['title'],
        'original_title': primary.get('title') or result['title'],
        'summary': result['summary'],
        'source_url': primary.get('url') or (urls[0] if urls else ''),
        'type': 'security_event',
        'ioc': result['ioc'],
    }
    payload = {'candidate': result, 'errors': errors}
    if not errors:
        payload['review_item'] = review
    return payload


def validate_candidate(raw: str, group_json: str) -> dict:
    """校验事件成员、事实与评分来源，再生成候选审核项。"""
    try:
        payload = parse_candidate_fields(raw, group_json)
        if not isinstance(payload, dict):
            raise ValueError('legacy_result_not_object')
        for key in ('article', 'facts', 'triage', 'candidate'):
            if key in payload and (not isinstance(payload[key], dict)):
                raise ValueError('legacy_' + key + '_not_object')
    except Exception as exc:
        payload = {
            'article': {},
            'facts': {},
            'triage': {},
            'candidate': {},
            'errors': ['legacy_validation:' + str(exc)],
            '_error': 'legacy_validation:' + str(exc),
        }
    errors = list(payload.get('errors') or [])
    try:
        group = json.loads(group_json)
        if not isinstance(group, dict):
            raise ValueError('not_object')
    except Exception as exc:
        group = {}
        errors.append('group_json:' + str(exc))
    raw_members = group.get('members')
    if not isinstance(raw_members, list):
        errors.append('members_not_list')
        raw_members = []
    members = [row for row in raw_members if isinstance(row, dict)]
    if len(members) != len(raw_members):
        errors.append('member_not_object')
    draft = payload.get('candidate') or {}
    try:
        original_draft = parse_contract(raw, 'event_candidate')
    except Exception:
        original_draft = {}
    for key in (
        'event_time',
        'title',
        'summary',
        'victim',
        'attacker',
        'attack_vector_or_cause',
        'affected_system',
        'impact',
        'data_breach_scope',
        'lesson',
    ):
        if not text_value(original_draft.get(key)):
            errors.append('invalid_text:' + key)
    source = '\n'.join((str((r.get('article') or {}).get('content') or '') for r in members))
    errors.extend(factual_errors(draft, source))
    if is_label_title(draft.get('title')):
        errors.append('label_only_title')
    paths = {
        'victim': ('entities', 'victim', 'value'),
        'attacker': ('entities', 'attacker', 'value'),
        'attack_vector_or_cause': ('entities', 'attack_vector_or_cause'),
        'affected_system': ('entities', 'affected_system'),
        'impact': ('entities', 'impact'),
        'data_breach_scope': ('data_breach_scope',),
        'event_time': ('event_time',),
    }
    for field, path in paths.items():
        values = []
        for member in members:
            value = member.get('facts') or {}
            for key in path:
                value = value.get(key, 'unknown') if isinstance(value, dict) else 'unknown'
            values.append(str(value).strip().casefold())
        if (
            values
            and all((value in ('', 'unknown') for value in values))
            and (str(draft.get(field) or '').casefold() != 'unknown')
        ):
            errors.append('unknown_fact_upgraded:' + field)
    details, excluded, warnings, validated_members = ([], [], [], [])
    for member in members:
        if member.get('contract_version') != CONTRACT_VERSION:
            errors.append('incident_contract_version_mismatch:republish_workflow_02')
        article, triage = (member.get('article') or {}, member.get('triage') or {})
        errors.extend(score_errors(triage))
        details.append(source_detail(article, triage))
        clean, dropped, more = example_ioc_filter(
            (member.get('facts') or {}).get('ioc') or {}, str(article.get('content') or '')
        )
        errors.extend(more)
        excluded.extend(member.get('excluded_iocs') or [])
        excluded.extend(dropped)
        warnings.extend(member.get('quality_warnings') or [])
        validated_members.append({**member, 'facts': {**(member.get('facts') or {}), 'ioc': clean}})
    ids = [detail['source_article_id'] for detail in details]
    if len(set(ids)) != len(ids) or not all(ids):
        errors.append('duplicate_or_missing_source_id')
    if set(ids) != set(group.get('member_article_ids') or []):
        errors.append('group_membership_mismatch')
    if ids and group.get('event_id') != stable_event_id(ids):
        errors.append('event_id_mismatch')
    draft['ioc'] = ioc_report(merge_iocs(validated_members))
    excluded = unique_objects(excluded)
    if excluded:
        warnings.append('example_iocs_excluded')
    payload.update(
        {
            'contract_version': CONTRACT_VERSION,
            'kind': 'error' if errors else 'event_candidate',
            'event_id': group.get('event_id') or '',
            'errors': list(dict.fromkeys(errors)),
            'quality_warnings': list(dict.fromkeys(warnings)),
        }
    )
    if errors:
        payload.pop('review_item', None)
    else:
        best = sorted(details, key=lambda d: (-d['total_score'], d['source_article_id']))[0]
        review = payload['review_item']
        review.update(
            {
                'candidate_id': group['event_id'],
                'event_id': group['event_id'],
                'decision': 'KEEP',
                'source_article_ids': ids,
                'source_urls': list(dict.fromkeys((d['source_url'] for d in details))),
                'scores': best['scores'],
                'total_score': best['total_score'],
                'reason': best['reason'],
                'score_source_article_id': best['source_article_id'],
                'score_strategy': 'highest_total_member_then_source_id',
                'source_details': details,
                'evidence_text': '\n'.join(
                    (d['source_article_id'] + ': ' + d['evidence_text'] for d in details)
                ),
                'quality_warnings': payload['quality_warnings'],
                'excluded_iocs': excluded,
                'ioc': draft['ioc'],
            }
        )
    return payload


def main(raw: str, group_json: str) -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    try:
        payload = (model_failure_result() if raw == '__NODE_EXECUTION_FAILED__'
                   else validate_candidate(raw, group_json))
    except Exception as exc:
        payload = {
            'kind': 'error',
            'errors': ['child_code_exception:' + str(exc)],
            'contract_version': CONTRACT_VERSION,
        }
    try:
        payload['event_id'] = json.loads(group_json).get('event_id', '')
    except Exception:
        payload['event_id'] = ''
    payload['storage_contract_version'] = 'news-storage-v1'
    payload['error_stage'] = 'candidate'
    return {
        'result_json': json.dumps(payload, ensure_ascii=False),
    }
