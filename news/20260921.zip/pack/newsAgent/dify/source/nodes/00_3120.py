"""适配工作流工具返回，保留真实异常及输入身份。"""

import json
from common import adapt_workflow_tool


def main(tool_text: str, error_message: str, error_type: str, source_json: str) -> dict:
    payload = adapt_workflow_tool(tool_text, error_message, error_type, source_json, 'normal', '3110')
    return {'result_json': json.dumps(payload, ensure_ascii=False)}
