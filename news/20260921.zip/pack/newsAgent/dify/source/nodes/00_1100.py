"""节点 00_1100 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import hashlib
import json
import re
from common import canonical_json, parse_digest_keywords
import uuid

PROCESSING_VERSION = '__PROCESSING_VERSION__'


def text_value(value):
    if value is None:
        return ""
    if not isinstance(value, (str, int, float)) or isinstance(value, bool):
        raise ValueError("invalid_scalar_type")
    return str(value).strip()


def normalize_article(row, max_chars=100000):
    if not isinstance(row, dict):
        raise ValueError("article_not_object")
    aliases = {
        "source_article_id": ("source_article_id", "stable_article_id", "article_id", "id"),
        "account": ("account", "publisher", "author"),
        "title": ("title",),
        "url": ("url", "source_url", "link"),
        "published_at": ("published_at", "publish_time", "pub_date"),
        "content": ("content", "body_text", "article_text"),
    }
    out = {
        key: text_value(next((row.get(k) for k in keys if row.get(k)), None))
        for key, keys in aliases.items()
    }
    if not all((out[k] for k in ("source_article_id", "title", "url", "content"))):
        raise ValueError("missing_required_field")
    if any(("\n" in v or "\r" in v for k, v in out.items() if k != "content")):
        raise ValueError("multiline_metadata")
    original_chars = row.get("content_chars", len(out["content"]))
    truncated = row.get("content_truncated", False)
    if type(original_chars) is not int or original_chars < len(out["content"]):
        raise ValueError("invalid_content_chars")
    if type(truncated) is not bool or (original_chars > len(out["content"]) and (not truncated)):
        raise ValueError("invalid_content_truncated")
    out["content_chars"] = original_chars
    out["content_truncated"] = truncated or len(out["content"]) > max_chars
    out["content"] = out["content"][:max_chars]
    out["source_version"] = row.get("source_version")
    return out


def main(articles_json: str, digest_keywords: str = '', max_content_chars: int = 50000, run_id: str = '') -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    if run_id and not re.fullmatch(r'run_[a-f0-9]{32}', run_id):
        raise ValueError('invalid_run_id')
    errors, digest, normal, articles, records = ([], [], [], [], [])
    try:
        rows = json.loads(articles_json)
        if isinstance(rows, dict):
            rows = rows.get('articles')
        if not isinstance(rows, list):
            raise ValueError('expected_article_array_or_articles_object')
    except Exception as exc:
        rows = []
        errors.append({'stage': 'prepare', 'error': 'input_json:' + str(exc)})
    keywords = parse_digest_keywords(digest_keywords)
    try:
        limit = max(1000, min(int(max_content_chars or 50000), 100000))
    except Exception:
        limit = 50000
    seen = set()
    for index, row in enumerate(rows):
        raw = row if isinstance(row, dict) else {}

        def safe(*keys):
            try:
                return text_value(next((raw.get(k) for k in keys if raw.get(k)), None))
            except ValueError:
                return ''

        sid = safe('source_article_id', 'stable_article_id', 'article_id', 'id')
        record = {
            'index': index,
            'source_article_id': sid or None,
            'route': None,
            'accepted': False,
            'prepare_error': None,
            'input_hash': None,
            'input_meta_json': {},
            'account': safe('account', 'publisher', 'author'),
            'original_title': safe('title'),
            'source_url': safe('url', 'source_url', 'link'),
            'published_at': safe('published_at', 'publish_time', 'pub_date'),
        }
        try:
            article = normalize_article(row, limit)
            if sid in seen:
                raise ValueError('duplicate_source_article_id')
            serialized = canonical_json(article)
            if len(serialized) > 200000:
                raise ValueError('article_json_too_large')
            seen.add(sid)
            route = 'digest' if any((word in article['title'] for word in keywords)) else 'normal'
            (digest if route == 'digest' else normal).append(serialized)
            articles.append(
                {'source_article_id': sid, 'route': route, 'content_truncated': article['content_truncated']}
            )
            record.update(
                {
                    'accepted': True,
                    'route': route,
                    'input_hash': hashlib.sha256(serialized.encode('utf-8')).hexdigest(),
                    'input_meta_json': {
                        'original_content_chars': article['content_chars'],
                        'input_content_chars': len(article['content']),
                        'content_truncated': article['content_truncated'],
                        'source_version': article['source_version'],
                        'hash_basis': 'canonical_article_json_v1',
                    },
                }
            )
        except Exception as exc:
            error = {'stage': 'prepare', 'index': index, 'source_article_id': sid, 'error': str(exc)}
            errors.append(error)
            record['prepare_error'] = error
        records.append(record)
    if not rows and errors:
        records.append(
            {
                'index': 0,
                'source_article_id': None,
                'route': None,
                'accepted': False,
                'prepare_error': errors[0],
                'input_hash': None,
                'input_meta_json': {},
            }
        )
    manifest = {
        'input_count': len(rows),
        'articles': articles,
        'records': records,
        'run_id': run_id or ('run_' + uuid.uuid4().hex),
        'processing_version': PROCESSING_VERSION,
    }
    return {
        'digest_article_jsons': digest,
        'normal_article_jsons': normal,
        'prepare_errors_json': json.dumps(errors, ensure_ascii=False),
        'manifest_json': json.dumps(manifest, ensure_ascii=False),
    }
