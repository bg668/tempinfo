"""节点 02_700 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import json
import re
from common import CONTRACT_VERSION, SCORE_KEYS, parse_article_input


def text_value(value):
    return isinstance(value, str) and bool(value.strip()) and (not re.search('<[^>]+>', value))


def score_errors(triage):
    errors = []
    scores = triage.get('scores')
    if not isinstance(scores, dict) or set(scores) != set(SCORE_KEYS):
        return ['scores_fields']
    for key in SCORE_KEYS:
        if type(scores[key]) is not int or not 0 <= scores[key] <= 5:
            errors.append('score_integer_0_5:' + key)
    if not text_value(triage.get('reason')):
        errors.append('missing_reason')
    if 'total_score' in triage and (not errors) and (triage['total_score'] != sum(scores.values()) * 4):
        errors.append('total_score_mismatch')
    return errors


def error_envelope(kind, article, errors, **extra):
    return {
        'contract_version': CONTRACT_VERSION,
        'kind': kind,
        'article': article,
        'errors': list(dict.fromkeys(errors)),
        '_error': ';'.join(dict.fromkeys(errors)),
        **extra,
    }


def classify_nonkeep(article_text: str, triage_json: str, validation_error: str) -> dict:
    """整理 DROP/UNCERTAIN 或失败记录，供最终资讯处理表保存。"""
    errors = [validation_error] if validation_error else []
    article, triage = ({}, {})
    try:
        article = parse_article_input(article_text)
        triage = json.loads(triage_json)
        if not errors:
            errors.extend(score_errors(triage))
    except Exception as exc:
        errors.append('parse:' + str(exc))
    if triage.get('decision') not in ('DROP', 'UNCERTAIN') and (not errors):
        errors.append('nonkeep_decision_mismatch')
    return error_envelope('error' if errors else 'nonkeep', article, errors, triage=triage)


def main(article_text: str, triage_json: str, validation_error: str, article_json: str = '') -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    try:
        payload = classify_nonkeep(article_text, triage_json, validation_error)
    except Exception as exc:
        payload = {
            'kind': 'error',
            'errors': ['child_code_exception:' + str(exc)],
            'contract_version': CONTRACT_VERSION,
        }
    try:
        if not payload.get('triage'):
            payload['triage'] = json.loads(triage_json)
    except Exception:
        payload['triage'] = {}
    payload['storage_contract_version'] = 'news-storage-v1'
    payload['error_stage'] = 'triage'
    payload['article'] = json.loads(article_json)
    return {'result_json': json.dumps(payload, ensure_ascii=False)}
