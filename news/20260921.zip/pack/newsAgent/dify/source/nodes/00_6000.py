"""节点 00_6000 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import hashlib
import json
import re
from common import CONTRACT_VERSION, SCORE_KEYS, digest_parent_errors, is_label_title, unique_objects
import copy

STORAGE_VERSION = 'news-storage-v1'
SCORE_COLUMNS = ('relevance', 'impact', 'freshness', 'evidence_quality', 'audience_value')
IOC_COLUMNS = ('ips', 'domains', 'urls', 'hashes', 'file_paths', 'vulnerabilities')


def text_value(value):
    return isinstance(value, str) and bool(value.strip()) and (not re.search('<[^>]+>', value))


def score_errors(triage):
    errors = []
    scores = triage.get('scores')
    if not isinstance(scores, dict) or set(scores) != set(SCORE_KEYS):
        return ['scores_fields']
    for key in SCORE_KEYS:
        if type(scores[key]) is not int or not 0 <= scores[key] <= 5:
            errors.append('score_integer_0_5:' + key)
    if not text_value(triage.get('reason')):
        errors.append('missing_reason')
    if 'total_score' in triage and (not errors) and (triage['total_score'] != sum(scores.values()) * 4):
        errors.append('total_score_mismatch')
    return errors


def load_object(raw):
    try:
        value = json.loads(raw) if isinstance(raw, str) else raw
        return value if isinstance(value, dict) else {}
    except (TypeError, ValueError):
        return {}


def stable_record(prefix, *parts):
    value = json.dumps(parts, ensure_ascii=False, separators=(',', ':'))
    return prefix + hashlib.sha256(value.encode('utf-8')).hexdigest()[:32]


def issue(stage, code, message=None, **context):
    return {'stage': stage, 'code': code, 'message': str(message or code), **context}


def issues(values, stage):
    result = []
    if values and (not isinstance(values, list)):
        values = [values]
    for value in values or []:
        if isinstance(value, dict):
            result.append(
                issue(
                    value.get('stage') or stage,
                    value.get('code') or str(value.get('error') or 'validation_failed').split(':')[0],
                    value.get('message') or value.get('error') or value,
                    **{k: v for k, v in value.items() if k not in ('stage', 'code', 'message', 'error')}
                )
            )
        else:
            text = str(value)
            result.append(issue(stage, text.split(':', 1)[0], text))
    return result


def clean_facts(value):
    return {k: v for k, v in value.items() if not k.startswith('_')} if isinstance(value, dict) else None


def clean_ioc(value):
    if not isinstance(value, dict):
        return None
    return {key: list(dict.fromkeys(value.get(key) or [])) for key in IOC_COLUMNS}


def fill_triage(record, triage):
    decision, route = (triage.get('decision'), triage.get('route'))
    valid_route = (
        decision == 'KEEP'
        and route in ('security_event', 'compliance_policy')
        or (decision, route) in (('DROP', 'non_target'), ('UNCERTAIN', 'uncertain'))
    )
    if not valid_route or triage.get('_validation_error') or score_errors(triage):
        return False
    for name in ('decision', 'route', 'category', 'content_nature', 'reason'):
        record[name] = triage.get(name)
    record.update(triage['scores'])
    record['total_score'] = sum((record[k] for k in SCORE_COLUMNS)) * 4
    return True


def base_record(manifest, source, kind, key):
    return {
        'item_id': stable_record('item_', manifest['run_id'], source.get('source_article_id'), key),
        'run_id': manifest['run_id'],
        'source_article_id': source.get('source_article_id'),
        'candidate_record_id': None,
        'item_kind': kind,
        'item_key': key,
        'title': None,
        'summary': None,
        'source_heading': None,
        'source_text': None,
        'process_status': 'SUCCESS',
        'decision': None,
        'route': None,
        'category': None,
        'content_nature': None,
        **{k: None for k in SCORE_COLUMNS},
        'total_score': None,
        'reason': None,
        'facts_json': None,
        'ioc_json': None,
        'excluded_iocs_json': [],
        'quality_warnings_json': [],
        'errors_json': [],
        'input_hash': source.get('input_hash'),
        'input_meta_json': source.get('input_meta_json') or {},
        'processing_version': manifest['processing_version'],
        'created_at': None,
    }


def build_tables(result, manifest, digest_results, normal_results, event_results, group_jsons):
    """生成资讯处理表和候选表，并校验两表关联及评分来源。"""
    records, by_article, by_digest_candidate = ([], {}, {})
    sources = {r['source_article_id']: r for r in manifest['records'] if r.get('accepted')}
    raw_by_route = {
        'digest': [load_object(x) for x in digest_results or []],
        'normal': [load_object(x) for x in normal_results or []],
    }
    cursors = {'digest': 0, 'normal': 0}
    for source in manifest['records']:
        sid, route = (source.get('source_article_id'), source.get('route'))
        if not source.get('accepted'):
            row = base_record(manifest, source, 'normal', 'invalid_%04d' % source['index'])
            row['process_status'] = 'FAILED'
            row['errors_json'] = issues([source.get('prepare_error') or 'input_rejected'], 'prepare')
            records.append(row)
            continue
        ordinal = cursors[route]
        cursors[route] += 1
        raw = raw_by_route[route][ordinal] if ordinal < len(raw_by_route[route]) else {}
        stage = 'digest' if route == 'digest' else 'normal'
        returned_id = (
            raw.get('parent_article_id')
            if route == 'digest'
            else (raw.get('article') or {}).get('source_article_id')
        )
        errs = issues(raw.get('errors'), raw.get('error_stage') or stage)
        if not raw:
            errs.append(issue(stage, 'missing_child_result'))
        elif str(returned_id or '') != str(sid):
            errs.append(issue(stage, 'source_article_id_mismatch'))
        elif raw.get('storage_contract_version') != STORAGE_VERSION:
            errs.append(issue(stage, 'storage_contract_version_mismatch', '请检查当前工作流的数据契约版本'))
        if raw.get('kind') == 'error' and (not errs):
            errs.append(issue(stage, 'child_failed', raw.get('_error')))
        if str(returned_id or '') != str(sid):
            raw = {}
        if route == 'normal':
            row = base_record(manifest, source, 'normal', 'article')
            triage = raw.get('triage') or {}
            if not fill_triage(row, triage) and (not errs):
                errs.append(issue('triage', 'invalid_triage'))
            expected_kind = {
                'security_event': 'incident',
                'compliance_policy': 'policy',
                'non_target': 'nonkeep',
                'uncertain': 'nonkeep',
            }.get(row['route'])
            if raw.get('kind') != expected_kind and (not errs):
                errs.append(issue('normal', 'result_kind_mismatch'))
            facts = raw.get('facts') or {}
            if raw.get('kind') in ('incident', 'policy') and (not errs):
                row.update(
                    {
                        'title': facts.get('title'),
                        'summary': facts.get('summary'),
                        'facts_json': clean_facts(facts),
                    }
                )
                if raw['kind'] == 'incident':
                    row['ioc_json'] = clean_ioc(facts.get('ioc'))
            row['excluded_iocs_json'] = raw.get('excluded_iocs') or []
            row['quality_warnings_json'] = list(raw.get('quality_warnings') or [])
            row['errors_json'] = errs
            if errs:
                row['process_status'] = 'FAILED'
            if source['input_meta_json'].get('content_truncated'):
                row['quality_warnings_json'].append('input_content_truncated')
            row['quality_warnings_json'] = unique_objects(row['quality_warnings_json'])
            records.append(row)
            by_article[sid] = row
        else:
            parent_blocked = bool(digest_parent_errors(raw)) or (
                raw.get('kind') != 'digest'
                or not isinstance(raw.get('items'), list) or not raw.get('items')
                or str(returned_id or '') != str(sid)
                or raw.get('storage_contract_version') != STORAGE_VERSION
            )
            if (
                raw.get('kind') != 'digest'
                or not isinstance(raw.get('items'), list)
                or (not raw.get('items'))
            ) and (not errs):
                errs.append(issue('digest', 'digest_items_missing'))
            parent = base_record(manifest, source, 'digest_parent', 'parent')
            parent['errors_json'] = errs
            parent['quality_warnings_json'] = raw.get('warnings') or []
            if errs:
                parent['process_status'] = 'FAILED'
            records.append(parent)
            children = raw.get('items') or []
            if not isinstance(children, list):
                children = []
            keys = set()
            for index, child in enumerate(children, 1):
                if not isinstance(child, dict):
                    continue
                key = child.get('item_key') or 'invalid_child_%04d' % index
                if key in keys:
                    key = 'invalid_duplicate_%04d' % index
                keys.add(key)
                row = base_record(manifest, source, 'digest_child', key)
                valid_triage = fill_triage(row, child)
                local_errors = issues(child.get('validation_errors'), 'digest_validate')
                if not valid_triage:
                    local_errors.append(issue('digest_triage', 'invalid_triage'))
                if not parent_blocked:
                    row['source_heading'] = child.get('source_heading')
                    row['source_text'] = child.get('source_text')
                if not local_errors:
                    for field in ('title', 'summary', 'source_heading', 'source_text'):
                        row[field] = child.get(field)
                    row['ioc_json'] = clean_ioc(child.get('ioc'))
                row['excluded_iocs_json'] = child.get('excluded_iocs') or []
                row['quality_warnings_json'] = child.get('quality_warnings') or []
                row['errors_json'] = local_errors + (
                    [issue('digest', 'parent_validation_failed', '父快讯校验失败，本子项不发布候选')]
                    if parent_blocked
                    else []
                )
                if row['errors_json']:
                    row['process_status'] = 'FAILED'
                records.append(row)
                if child.get('candidate_id'):
                    by_digest_candidate[child['candidate_id']] = row
    groups = {g['event_id']: g for g in (load_object(x) for x in group_jsons) if g.get('event_id')}
    events = {e['event_id']: e for e in (load_object(x) for x in event_results or []) if e.get('event_id')}
    candidates, kept_reviews, projection_errors = ([], [], [])
    for review in result['review_items']:
        review = copy.deepcopy(review)
        cid = review['candidate_id']
        if review.get('child_id'):
            members = [by_digest_candidate.get(cid)]
        else:
            members = [by_article.get(sid) for sid in review['source_article_ids']]
        if not members or any(
            (not m or m['process_status'] != 'SUCCESS' or m['decision'] != 'KEEP' for m in members)
        ):
            projection_errors.append(issue('storage', 'candidate_source_invalid', candidate_id=cid))
            continue
        event = events.get(cid)
        if review.get('event_id') and (not event or event.get('storage_contract_version') != STORAGE_VERSION):
            projection_errors.append(
                issue('storage', 'candidate_storage_contract_mismatch', candidate_id=cid)
            )
            continue
        crid = stable_record('candidate_', manifest['run_id'], cid)
        if any((m['candidate_record_id'] for m in members)):
            projection_errors.append(
                issue('storage', 'processing_item_in_multiple_candidates', candidate_id=cid)
            )
            continue
        score_source = next(
            (m for m in members if m['source_article_id'] == review.get('score_source_article_id')), None
        )
        if score_source is None or any((score_source[k] != review['scores'][k] for k in SCORE_COLUMNS)):
            projection_errors.append(issue('storage', 'score_provenance_mismatch', candidate_id=cid))
            continue
        excluded, warnings = ([], [])
        for member in members:
            excluded.extend(
                ({**value, 'item_id': member['item_id']} for value in member['excluded_iocs_json'])
            )
            warnings.extend(
                (
                    {'item_id': member['item_id'], 'warning': value}
                    for value in member['quality_warnings_json']
                )
            )
        warnings.extend(
            (
                {'warning': value}
                for value in review.get('quality_warnings') or []
                if not any((w['warning'] == value for w in warnings))
            )
        )
        ioc = None
        if any((m['ioc_json'] is not None for m in members)):
            ioc = {
                key: list(dict.fromkeys((v for m in members for v in (m['ioc_json'] or {}).get(key, []))))
                for key in IOC_COLUMNS
            }
        facts = (
            clean_facts(event.get('candidate'))
            if event
            else clean_facts(review.get('policy_facts')) if review.get('policy_id') else None
        )
        candidate = {
            'candidate_record_id': crid,
            'candidate_id': cid,
            'run_id': manifest['run_id'],
            'candidate_type': review['type'],
            'primary_item_id': members[0]['item_id'],
            'title': review['title'],
            'summary': review['summary'],
            'facts_json': facts,
            **review['scores'],
            'total_score': review['total_score'],
            'reason': review['reason'],
            'score_strategy': review['score_strategy'],
            'score_source_item_id': score_source['item_id'],
            'match_reason': groups.get(cid, {}).get('match_reason') if len(members) > 1 else None,
            'ioc_json': ioc,
            'excluded_iocs_json': unique_objects(excluded),
            'quality_warnings_json': unique_objects(warnings),
            'review_status': 'pending',
            'review_reason_code': None,
            'review_comment': None,
            'reviewed_title': None,
            'reviewed_summary': None,
            'review_corrections_json': None,
            'reviewer_id': None,
            'reviewed_at': None,
            'created_at': None,
            'updated_at': None,
        }
        for member in members:
            member['candidate_record_id'] = crid
        candidates.append(candidate)
        review.update(
            {
                'candidate_record_id': crid,
                'run_id': manifest['run_id'],
                'source_item_ids': [m['item_id'] for m in members],
                'primary_item_id': candidate['primary_item_id'],
                'score_source_item_id': candidate['score_source_item_id'],
                'review_status': 'pending',
                'ioc': ioc,
                'source_accounts': list(
                    dict.fromkeys((sources[m['source_article_id']].get('account', '') for m in members))
                ),
                'excluded_iocs': candidate['excluded_iocs_json'],
            }
        )
        review['source_preview'] = review.pop('evidence_text', '')
        review['published_at'] = sources[members[0]['source_article_id']].get('published_at') or ''
        kept_reviews.append(review)
    group_by_source = {
        sid: gid for gid, group in groups.items() for sid in group.get('member_article_ids', [])
    }
    for row in records:
        if (
            row['item_kind'] != 'digest_parent'
            and row['decision'] == 'KEEP'
            and (row['process_status'] == 'SUCCESS')
            and (not row['candidate_record_id'])
        ):
            row['process_status'] = 'FAILED'
            gid = group_by_source.get(row['source_article_id'])
            row['errors_json'].append(
                issue('candidate' if gid else 'finalize', 'candidate_not_generated', event_id=gid)
            )
            if gid:
                row['errors_json'].extend(issues((events.get(gid) or {}).get('errors'), 'candidate'))
            elif result.get('errors'):
                row['errors_json'].extend(issues(result['errors'], 'finalize'))
    return (records, candidates, kept_reviews, projection_errors)


def collect_review_items(
    digest_candidates: list,
    policy_candidates: list,
    event_results: list,
    errors_json: str,
    event_match_errors_json: str,
    stage_stats_json: str,
    group_jsons: list,
    warnings_json: str,
) -> dict:
    """核对候选身份、来源和评分，汇总审核项、错误及统计。"""
    items = list(digest_candidates or []) + list(policy_candidates or [])
    errors = json.loads(errors_json)
    errors.extend(issues(json.loads(event_match_errors_json), 'event_match'))
    warnings = json.loads(warnings_json)
    stats = json.loads(stage_stats_json)
    expected_groups = {json.loads(g)['event_id'] for g in group_jsons}
    received_groups, successful_groups = (set(), set())
    for index, raw in enumerate(event_results or []):
        try:
            obj = json.loads(raw)
            if not isinstance(obj, dict) or obj.get('contract_version') != CONTRACT_VERSION:
                raise ValueError('contract_version_mismatch:candidate')
            event_id = obj.get('event_id')
            if event_id not in expected_groups or event_id in received_groups:
                raise ValueError('unexpected_or_duplicate_event_result')
            received_groups.add(event_id)
            if not isinstance(obj.get('errors'), list):
                raise ValueError('errors_not_list')
            if obj['errors']:
                errors.extend(issues(obj['errors'], 'candidate'))
                continue
            review = obj.get('review_item')
            if not isinstance(review, dict) or review.get('candidate_id') != event_id:
                raise ValueError('missing_or_mismatched_event_review_item')
            items.append(review)
            successful_groups.add(event_id)
        except Exception as exc:
            errors.append({'stage': 'candidate', 'index': index, 'error': str(exc)})
    for event_id in sorted(expected_groups - received_groups):
        errors.append({'stage': 'candidate', 'event_id': event_id, 'error': 'missing_child_result'})
    valid, seen = ([], set())
    for item in items:
        try:
            if not isinstance(item, dict):
                raise ValueError('review_item_not_object')
            cid = item.get('candidate_id')
            if not cid or cid in seen:
                raise ValueError('missing_or_duplicate_candidate_id')
            seen.add(cid)
            if item.get('decision') != 'KEEP' or item.get('type') not in (
                'security_event',
                'compliance_policy',
            ):
                raise ValueError('nonkeep_in_review_list')
            if score_errors(item) or item.get('total_score') != sum(item['scores'].values()) * 4:
                raise ValueError('invalid_review_score')
            for key in ('source_article_ids', 'source_urls', 'source_details'):
                if not isinstance(item.get(key), list) or not item[key]:
                    raise ValueError('missing_provenance:' + key)
            if not text_value(item.get('title')) or is_label_title(item['title']):
                raise ValueError('invalid_review_title')
            valid.append(item)
            warnings.extend(
                (
                    {'stage': 'review', 'candidate_id': cid, 'warning': w}
                    for w in item.get('quality_warnings', [])
                )
            )
        except Exception as exc:
            errors.append(
                {
                    'stage': 'finalize',
                    'candidate_id': item.get('candidate_id', '') if isinstance(item, dict) else '',
                    'error': str(exc),
                }
            )
    from datetime import datetime, timezone

    def timestamp(item):
        try:
            value = datetime.fromisoformat(str(item.get('published_at') or '').replace('Z', '+00:00'))
            return (value if value.tzinfo else value.replace(tzinfo=timezone.utc)).timestamp()
        except Exception:
            return float('-inf')

    valid.sort(key=lambda item: (-timestamp(item), item['candidate_id']))
    errors, warnings = (unique_objects(errors), unique_objects(warnings))
    status = 'SUCCESS' if not errors else 'PARTIAL' if valid else 'FAILED'
    uncertain_count = stats['normal_uncertain_count'] + stats['digest_uncertain_count']
    business = (
        'candidates'
        if valid
        else (
            'abnormal_empty'
            if errors
            else (
                'uncertain_only_or_dropped'
                if uncertain_count
                else 'empty_input' if not stats['input_count'] else 'all_dropped'
            )
        )
    )
    stats.update(
        {
            'event_group_count': len(expected_groups),
            'event_candidate_count': sum((x.get('event_id') in successful_groups for x in valid)),
            'digest_candidate_count': sum((bool(x.get('child_id')) for x in valid)),
            'policy_candidate_count': sum((bool(x.get('policy_id')) for x in valid)),
            'candidate_count': len(valid),
            'error_count': len(errors),
            'warning_count': len(warnings),
            'business_result': business,
            'quality_status': 'ERROR' if errors else 'WARN' if warnings else 'PASS',
            'quality_scope': 'structural_coverage_and_targeted_rules_not_full_fact_verification',
            'digest_coverage_verified': stats['digest_coverage_verified_count']
            == stats['digest_parent_count'],
        }
    )
    return {
        'warnings_json': json.dumps(warnings, ensure_ascii=False),
        'review_items': valid,
        'stats': stats,
        'errors': errors,
    }


def merge_tool_errors(errors):
    """The same tool exception can reach batch and row paths; keep one with all item links."""
    merged, seen = [], {}
    for error in errors:
        if error.get('code') not in ('workflow_tool_execution_failed', 'workflow_tool_output_invalid') or not error.get('node_id'):
            merged.append(error)
            continue
        key = tuple(str(error.get(k) or '') for k in
                    ('stage', 'code', 'message', 'node_id', 'error_type', 'source_article_id', 'event_id'))
        if key not in seen:
            target = dict(error)
            seen[key] = target
            merged.append(target)
        else:
            target = seen[key]
            for name, value in error.items():
                if name not in target:
                    target[name] = value
                elif name == 'item_id' and target[name] != value:
                    target['item_ids'] = list(dict.fromkeys(target.get('item_ids', [target[name]]) + [value]))
    return unique_objects(merged)


def main(
    digest_candidates_json: str,
    policy_candidates_json: str,
    event_results: list,
    errors_json: str,
    event_match_errors_json: str,
    stage_stats_json: str,
    group_jsons: list,
    warnings_json: str,
    digest_results: list,
    normal_results: list,
    manifest_json: str,
) -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    result = collect_review_items(
        json.loads(digest_candidates_json),
        json.loads(policy_candidates_json),
        event_results,
        errors_json,
        event_match_errors_json,
        stage_stats_json,
        group_jsons,
        warnings_json,
    )
    manifest = json.loads(manifest_json)
    rows, candidates, reviews, extra_errors = build_tables(
        result, manifest, digest_results, normal_results, event_results, group_jsons
    )
    errors = issues(result['errors'], 'finalize') + extra_errors
    for row in rows:
        errors.extend(({**e, 'item_id': row['item_id']} for e in row['errors_json']))
    errors = merge_tool_errors(errors)
    status = 'SUCCESS' if not errors else 'PARTIAL' if candidates else 'FAILED'
    stats = result['stats']
    stats.update(
        {
            'candidate_count': len(candidates),
            'error_count': len(errors),
            'processing_item_count': len(rows),
            'processing_leaf_count': sum((r['item_kind'] != 'digest_parent' for r in rows)),
            'processing_failed_count': sum((r['process_status'] == 'FAILED' for r in rows)),
            'event_candidate_count': sum((bool(r.get('event_id')) for r in reviews)),
            'policy_candidate_count': sum((bool(r.get('policy_id')) for r in reviews)),
            'digest_candidate_count': sum((bool(r.get('child_id')) for r in reviews)),
        }
    )
    if errors:
        stats['quality_status'] = 'ERROR'
    if not candidates and errors:
        stats['business_result'] = 'abnormal_empty'
    return {
        'run_id': manifest['run_id'],
        'processing_version': manifest['processing_version'],
        'processing_items_json': json.dumps(rows, ensure_ascii=False),
        'candidates_json': json.dumps(candidates, ensure_ascii=False),
        'review_items_json': json.dumps(reviews, ensure_ascii=False),
        'run_status': status,
        'errors_json': json.dumps(errors, ensure_ascii=False),
        'stats_json': json.dumps(stats, ensure_ascii=False),
        'warnings_json': result['warnings_json'],
    }
