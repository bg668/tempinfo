"""节点 02_510 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import json
import re
from common import (
    CONTRACT_VERSION,
    IOC_KEYS,
    SCORE_KEYS,
    _unique,
    example_ioc_filter,
    factual_errors,
    is_label_title,
    literal_iocs,
    model_failure_result,
    parse_article_input,
    parse_contract,
    unique_objects,
)

CERT = {'confirmed', 'reported', 'suspected', 'unknown'}


def text_value(value):
    return isinstance(value, str) and bool(value.strip()) and (not re.search('<[^>]+>', value))


def score_errors(triage):
    errors = []
    scores = triage.get('scores')
    if not isinstance(scores, dict) or set(scores) != set(SCORE_KEYS):
        return ['scores_fields']
    for key in SCORE_KEYS:
        if type(scores[key]) is not int or not 0 <= scores[key] <= 5:
            errors.append('score_integer_0_5:' + key)
    if not text_value(triage.get('reason')):
        errors.append('missing_reason')
    if 'total_score' in triage and (not errors) and (triage['total_score'] != sum(scores.values()) * 4):
        errors.append('total_score_mismatch')
    return errors


def ioc_exclusions_in_source(content):
    _, excluded, _ = example_ioc_filter(literal_iocs(content), content)
    return excluded


def parse_incident_fields(raw: str, article_text: str, triage_json: str) -> dict:
    """解析事件树文本并校验基础字段；返回对象，不进行结果序列化。"""
    errors = []
    try:
        article = parse_article_input(article_text)
    except Exception as e:
        article = {}
        errors.append('article_tree:' + str(e))
    try:
        obj = parse_contract(raw, 'incident_result')
    except Exception as e:
        obj = {}
        errors.append('incident_tree:' + str(e))
    required = {
        'source_article_id',
        'event_time',
        'title',
        'source_url',
        'summary',
        'entities',
        'data_breach_scope',
        'lesson',
        'ioc',
    }
    if set(obj) != required:
        errors.append('fields_mismatch')
    if str(obj.get('source_article_id', '')) != str(article.get('source_article_id', '')):
        errors.append('source_article_id_mismatch')
    if str(obj.get('source_url', '')) != str(article.get('url', '')):
        errors.append('source_url_mismatch')
    ent = obj.get('entities') if isinstance(obj.get('entities'), dict) else {}
    ioc = obj.get('ioc') if isinstance(obj.get('ioc'), dict) else {}
    if set(ent) != {'victim', 'attacker', 'attack_vector_or_cause', 'affected_system', 'impact'}:
        errors.append('entities_fields_mismatch')
    if set(ioc) != {'ips', 'domains', 'urls', 'hashes', 'file_paths', 'vulnerabilities'}:
        errors.append('ioc_fields_mismatch')
    for k in ('event_time', 'title', 'source_url', 'summary', 'data_breach_scope', 'lesson'):
        if not str(obj.get(k, '')).strip():
            errors.append('empty_' + k)
    for k in ('attack_vector_or_cause', 'affected_system', 'impact'):
        if not str(ent.get(k, '')).strip():
            errors.append('empty_entities_' + k)
    for who in ('victim', 'attacker'):
        e = ent.get(who) if isinstance(ent.get(who), dict) else {}
        if set(e) != {'value', 'certainty'}:
            errors.append(who + '_fields_mismatch')
        val = str(e.get('value', ''))
        certainty = str(e.get('certainty', ''))
        if not val:
            errors.append(who + '_empty_value')
        if certainty not in CERT:
            errors.append(who + '_certainty')
        if (val.casefold() == 'unknown') != (certainty == 'unknown'):
            errors.append(who + '_unknown_pair')
    content = str(article.get('content', '')).casefold()
    clean_ioc = {}
    for k in ('ips', 'domains', 'urls', 'hashes', 'file_paths', 'vulnerabilities'):
        vals = ioc.get(k, []) if isinstance(ioc.get(k, []), list) else []
        vals = _unique(vals)
        clean_ioc[k] = vals
        for val in vals:
            if str(val).casefold() not in content:
                errors.append('ioc_not_grounded:' + k + '=' + str(val))
    obj = dict(obj)
    obj['ioc'] = clean_ioc
    obj['_validation_error'] = ';'.join(errors)
    try:
        triage = json.loads(triage_json or '{}')
    except Exception:
        triage = {}
    result = {
        'kind': 'error' if errors else 'incident',
        'article': article,
        'triage': triage,
        'facts': obj,
        'ioc': clean_ioc,
        '_error': ';'.join(errors),
    }
    return result


def validate_incident(raw: str, article_text: str, triage_json: str) -> dict:
    """执行事件评分、事实约束和 IOC 校验；诊断码兼容既有消费方。"""
    try:
        result = parse_incident_fields(raw, article_text, triage_json)
        if not isinstance(result, dict):
            raise ValueError('legacy_result_not_object')
        for key in ('article', 'facts', 'triage', 'candidate'):
            if key in result and (not isinstance(result[key], dict)):
                raise ValueError('legacy_' + key + '_not_object')
    except Exception as exc:
        result = {
            'article': {},
            'facts': {},
            'triage': {},
            'candidate': {},
            'errors': ['legacy_validation:' + str(exc)],
            '_error': 'legacy_validation:' + str(exc),
        }
    article, facts, triage = (result['article'], result['facts'], result['triage'])
    errors = [x for x in str(result.get('_error') or '').split(';') if x]
    errors.extend(score_errors(triage))
    if triage.get('_validation_error'):
        errors.append('invalid_triage:' + triage['_validation_error'])
    if triage.get('decision') != 'KEEP' or triage.get('route') != 'security_event':
        errors.append('incident_triage_route_mismatch')
    source = str(article.get('content') or '')
    for key in (
        'source_article_id',
        'event_time',
        'title',
        'source_url',
        'summary',
        'data_breach_scope',
        'lesson',
    ):
        if not text_value(facts.get(key)):
            errors.append('invalid_text:' + key)
    ent = facts.get('entities') or {}
    for key in ('attack_vector_or_cause', 'affected_system', 'impact'):
        if not isinstance(ent, dict) or not text_value(ent.get(key)):
            errors.append('invalid_text:entities.' + key)
    errors.extend(factual_errors(facts, source))
    if is_label_title(facts.get('title')):
        errors.append('label_only_title')
    try:
        raw_ioc = parse_contract(raw, 'incident_result').get('ioc', {})
        clean, excluded, more = example_ioc_filter(raw_ioc, source)
        errors.extend(more)
    except Exception as exc:
        clean, excluded = ({key: [] for key in IOC_KEYS}, [])
        errors.append('ioc_parse:' + str(exc))
    excluded = unique_objects(excluded + ioc_exclusions_in_source(source))
    facts['ioc'] = clean
    facts['_validation_error'] = ';'.join(dict.fromkeys(errors))
    result.update(
        {
            'contract_version': CONTRACT_VERSION,
            'kind': 'error' if errors else 'incident',
            'ioc': clean,
            'excluded_iocs': excluded,
            'errors': list(dict.fromkeys(errors)),
            '_error': facts['_validation_error'],
            'evidence_text': source[:2000],
            'quality_warnings': ['example_iocs_excluded'] if excluded else [],
        }
    )
    if str(article.get('content_truncated')).lower() == 'true':
        result['quality_warnings'].append('input_content_truncated')
    return result


def main(raw: str, article_text: str, triage_json: str, article_json: str = '') -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    try:
        payload = (model_failure_result() if raw == '__NODE_EXECUTION_FAILED__'
                   else validate_incident(raw, article_text, triage_json))
    except Exception as exc:
        payload = {
            'kind': 'error',
            'errors': ['child_code_exception:' + str(exc)],
            'contract_version': CONTRACT_VERSION,
        }
    try:
        if not payload.get('triage'):
            payload['triage'] = json.loads(triage_json)
    except Exception:
        payload['triage'] = {}
    payload['storage_contract_version'] = 'news-storage-v1'
    payload['error_stage'] = 'incident_extract'
    payload['article'] = json.loads(article_json)
    return {'result_json': json.dumps(payload, ensure_ascii=False)}
