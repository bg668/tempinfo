"""节点 00_4000 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import json
import re
from common import CONTRACT_VERSION, SCORE_KEYS, digest_parent_errors, unique_objects


def text_value(value):
    return isinstance(value, str) and bool(value.strip()) and (not re.search('<[^>]+>', value))


def score_errors(triage):
    errors = []
    scores = triage.get('scores')
    if not isinstance(scores, dict) or set(scores) != set(SCORE_KEYS):
        return ['scores_fields']
    for key in SCORE_KEYS:
        if type(scores[key]) is not int or not 0 <= scores[key] <= 5:
            errors.append('score_integer_0_5:' + key)
    if not text_value(triage.get('reason')):
        errors.append('missing_reason')
    if 'total_score' in triage and (not errors) and (triage['total_score'] != sum(scores.values()) * 4):
        errors.append('total_score_mismatch')
    return errors


def main(digest_results: list, normal_results: list, prepare_errors_json: str, manifest_json: str) -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    digest, incidents, policies, warnings = ([], [], [], [])
    errors = json.loads(prepare_errors_json)
    manifest = json.loads(manifest_json)
    expected = {
        route: [a['source_article_id'] for a in manifest['articles'] if a['route'] == route]
        for route in ('digest', 'normal')
    }
    stats = {
        'input_count': manifest['input_count'],
        'prepared_count': len(manifest['articles']),
        'prepare_rejected_count': manifest['input_count'] - len(manifest['articles']),
        'digest_parent_count': len(expected['digest']),
        'normal_article_count': len(expected['normal']),
        'digest_success_count': 0,
        'digest_partial_parent_count': 0,
        'digest_observed_item_count': 0,
        'digest_observed_keep_count': 0,
        'digest_observed_drop_count': 0,
        'digest_observed_uncertain_count': 0,
        'digest_failed_item_count': 0,
        'normal_observed_keep_count': 0,
        'normal_observed_drop_count': 0,
        'normal_observed_uncertain_count': 0,
        'digest_item_count': 0,
        'digest_keep_count': 0,
        'digest_drop_count': 0,
        'digest_uncertain_count': 0,
        'digest_coverage_verified_count': 0,
        'normal_incident_count': 0,
        'normal_policy_count': 0,
        'normal_drop_count': 0,
        'normal_uncertain_count': 0,
        'digest_error_count': 0,
        'normal_error_count': 0,
    }

    def fail(stage, index, message, sid=''):
        errors.append({'stage': stage, 'index': index, 'source_article_id': sid, 'error': message})

    for route, results in (('digest', digest_results), ('normal', normal_results)):
        received = set()
        for index, raw in enumerate(results or []):
            sid = ''
            try:
                if raw is None:
                    sid = expected[route][index] if index < len(expected[route]) else ''
                    received.add(sid)
                    raise ValueError('iteration_item_execution_failed')
                obj = json.loads(raw)
                if not isinstance(obj, dict):
                    raise ValueError('result_not_object')
                if obj.get('contract_version') != CONTRACT_VERSION:
                    raise ValueError('contract_version_mismatch:' + route)
                sid = str(
                    obj.get('parent_article_id')
                    if route == 'digest'
                    else (obj.get('article') or {}).get('source_article_id') or ''
                )
                if sid not in expected[route]:
                    raise ValueError('unexpected_source_article_id')
                if sid in received:
                    raise ValueError('duplicate_result')
                received.add(sid)
                child_errors = obj.get('errors')
                if not isinstance(child_errors, list):
                    raise ValueError('errors_not_list')
                if route == 'digest':
                    observed = obj.get('items') if isinstance(obj.get('items'), list) else []
                    stats['digest_observed_item_count'] += len(observed)
                    stats['digest_failed_item_count'] += sum(
                        bool(x.get('validation_errors')) for x in observed if isinstance(x, dict)
                    )
                    for decision in ('keep', 'drop', 'uncertain'):
                        stats['digest_observed_' + decision + '_count'] += sum(
                            isinstance(x, dict) and x.get('decision') == decision.upper() for x in observed
                        )
                else:
                    observed_decision = (obj.get('triage') or {}).get('decision', '').lower()
                    if observed_decision in ('keep', 'drop', 'uncertain'):
                        stats['normal_observed_' + observed_decision + '_count'] += 1
                if child_errors or obj.get('kind') == 'error':
                    stats[route + '_error_count'] += 1
                    for error in child_errors or [obj.get('_error') or 'child_error']:
                        if isinstance(error, dict):
                            errors.append({**error, 'index': index, 'source_article_id': sid})
                        else:
                            fail(route, index, str(error), sid)
                    if route != 'digest' or obj.get('kind') == 'error' or digest_parent_errors(obj):
                        continue
                if route == 'digest':
                    if (
                        obj.get('kind') != 'digest'
                        or not isinstance(obj.get('items'), list)
                        or (not obj['items'])
                    ):
                        raise ValueError('digest_items_missing')
                    children = [x for x in obj['items'] if isinstance(x, dict) and not x.get('validation_errors')]
                    candidates = obj.get('candidates')
                    if not isinstance(candidates, list):
                        raise ValueError('candidates_not_list')
                    if any(
                        (
                            not isinstance(x, dict) or x.get('decision') not in ('KEEP', 'DROP', 'UNCERTAIN')
                            for x in children
                        )
                    ):
                        raise ValueError('invalid_digest_item')
                    keep_ids = [x['candidate_id'] for x in children if x['decision'] == 'KEEP']
                    if sorted(keep_ids) != sorted((x['candidate_id'] for x in candidates)):
                        raise ValueError('digest_keep_candidate_mismatch')
                    digest.extend(candidates)
                    stats['digest_partial_parent_count' if child_errors else 'digest_success_count'] += 1
                    stats['digest_item_count'] += len(children)
                    for decision in ('keep', 'drop', 'uncertain'):
                        stats['digest_' + decision + '_count'] += sum(
                            (x['decision'] == decision.upper() for x in children)
                        )
                    for child in children:
                        if child['decision'] == 'UNCERTAIN':
                            warnings.append(
                                {
                                    'stage': 'digest',
                                    'source_article_id': sid,
                                    'candidate_id': child['candidate_id'],
                                    'warning': 'uncertain_requires_review_in_audit',
                                }
                            )
                    if (obj.get('stats') or {}).get('coverage_verified') is True:
                        stats['digest_coverage_verified_count'] += 1
                    else:
                        warnings.append(
                            {
                                'stage': 'digest',
                                'source_article_id': sid,
                                'warning': 'digest_coverage_unverified',
                            }
                        )
                else:
                    triage = obj.get('triage') or {}
                    if score_errors(triage):
                        raise ValueError('triage_metadata_invalid')
                    kind = obj.get('kind')
                    if (
                        kind == 'incident'
                        and triage.get('decision') == 'KEEP'
                        and (triage.get('route') == 'security_event')
                        and isinstance(obj.get('facts'), dict)
                    ):
                        incidents.append(obj)
                        stats['normal_incident_count'] += 1
                    elif (
                        kind == 'policy'
                        and triage.get('decision') == 'KEEP'
                        and (triage.get('route') == 'compliance_policy')
                        and isinstance(obj.get('review_item'), dict)
                    ):
                        policies.append(obj['review_item'])
                        stats['normal_policy_count'] += 1
                    elif kind == 'nonkeep' and (triage.get('decision'), triage.get('route')) in (
                        ('DROP', 'non_target'),
                        ('UNCERTAIN', 'uncertain'),
                    ):
                        stats['normal_' + triage['decision'].lower() + '_count'] += 1
                        if triage['decision'] == 'UNCERTAIN':
                            warnings.append(
                                {
                                    'stage': 'normal',
                                    'source_article_id': sid,
                                    'warning': 'uncertain_requires_review_in_audit',
                                }
                            )
                    else:
                        raise ValueError('unknown_or_inconsistent_result_kind:' + str(kind))
            except Exception as exc:
                stats[route + '_error_count'] += 1
                fail(route, index, str(exc), sid)
        for sid in expected[route]:
            if sid not in received:
                stats[route + '_error_count'] += 1
                fail(route, -1, 'missing_child_result', sid)
    stats['digest_failed_parent_count'] = (
        stats['digest_parent_count'] - stats['digest_success_count'] - stats['digest_partial_parent_count']
    )
    stats['normal_processed_count'] = sum(
        (
            stats[key]
            for key in (
                'normal_incident_count',
                'normal_policy_count',
                'normal_drop_count',
                'normal_uncertain_count',
            )
        )
    )
    stats['normal_failed_article_count'] = stats['normal_article_count'] - stats['normal_processed_count']
    return {
        'digest_candidates_json': json.dumps(digest, ensure_ascii=False),
        'incidents_json': json.dumps(incidents, ensure_ascii=False),
        'policy_candidates_json': json.dumps(policies, ensure_ascii=False),
        'errors_json': json.dumps(unique_objects(errors), ensure_ascii=False),
        'stage_stats_json': json.dumps(stats, ensure_ascii=False),
        'warnings_json': json.dumps(warnings, ensure_ascii=False),
    }
