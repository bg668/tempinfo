"""Build self-contained model instructions from the validator's enum definitions."""

from pathlib import Path

import yaml

from common import ALLOWED_CATEGORIES, ALLOWED_NATURES

MARKER = '\n## 分类契约（程序同步）\n'


def sync_digest_prompt():
    path = Path(__file__).resolve().parent / 'templates/01_快讯汇总处理.yml'
    document = yaml.safe_load(path.read_text(encoding='utf-8'))
    node = next(n['data'] for n in document['workflow']['graph']['nodes'] if n['id'] == '200')
    system = next(p for p in node['prompt_template'] if p['role'] == 'system')
    text = system['text'].split(MARKER)[0]
    text = text.replace('Article Triage允许值', '下方分类契约允许值')
    text += MARKER
    text += '\ncategory 只允许：' + '、'.join(sorted(ALLOWED_CATEGORIES)) + '。\n'
    text += 'content_nature 只允许：' + '、'.join(sorted(ALLOWED_NATURES)) + '。\n'
    text += '\n- security_event 的 category 只能是 security_incident、threat_activity、vulnerability、data_breach、ransomware。\n'
    text += '- compliance_policy 必须使用 category=compliance_policy、content_nature=policy。\n'
    text += '- DDoS 事件使用 security_incident；在野漏洞利用使用 vulnerability；符合目标范围的网络犯罪活动可使用 threat_activity。不要输出 ddos、vulnerability_exploitation、cybercrime 等额外枚举。\n'
    text += '- 内容性质和证据可靠程度分开表达。针对真实世界的攻击指控可使用 real_world_event，未获证实的状态放在 summary、reason 和 evidence_quality；不要输出 unverified_claim。\n'
    text += '- 此枚举说明不改变 KEEP/DROP/UNCERTAIN 的业务判断。只允许上述值，不得自行创造分类。\n'
    system['text'] = text
    path.write_text(yaml.safe_dump(document, allow_unicode=True, sort_keys=False, width=120), encoding='utf-8')
