"""Compose business modules into one deployable Dify graph with no workflow tools."""

import copy
import re
from pathlib import Path

import yaml

SOURCE = Path(__file__).resolve().parent
MODULES = SOURCE.parent / 'build/modules'
OUTPUT = SOURCE.parent / '00_安全资讯处理_单工作流.yml'
NODE_MAPS = {
    '01': {'150': '2050', '200': '2110', '300': '2120'},
    '02': {'150': '3050', '200': '3110', '300': '3120', '400': '3130',
           '500': '3140', '510': '3150', '600': '3160', '610': '3170',
           '700': '3180', '800': '3190'},
    '03': {'200': '4050', '300': '4070', '400': '4100', '410': '4120',
           '500': '4130', '600': '4150'},
    '04': {'200': '5050', '300': '5110', '400': '5120'},
}
PARENTS = {'01': '2000', '02': '3000', '03': None, '04': '5000'}
INPUTS = {
    '01': {'article_json': ['2000', 'item']},
    '02': {'article_json': ['3000', 'item']},
    '03': {'incidents_json': ['4000', 'incidents_json'], 'grouping_mode': ['1000', 'grouping_mode']},
    '04': {'group_json': ['5000', 'item']},
}
TEMPLATE_REF = re.compile(r'\{\{#([^#]+)#\}\}')


def remap_selector(selector, prefix):
    if selector[0] == '100':
        return INPUTS[prefix][selector[1]] + selector[2:]
    return [NODE_MAPS[prefix][selector[0]], *selector[1:]]


def remap_data(value, prefix):
    """Only rewrite variable selectors and template references, never business strings."""
    if isinstance(value, dict):
        return {key: remap_data(child, prefix) for key, child in value.items()}
    if isinstance(value, list):
        if len(value) >= 2 and isinstance(value[0], str) and value[0] in {'100', *NODE_MAPS[prefix]}:
            return remap_selector(value, prefix)
        return [remap_data(child, prefix) for child in value]
    if isinstance(value, str):
        def replace(match):
            parts = match.group(1).split('.')
            return '{{#' + '.'.join(remap_selector(parts, prefix)) + '#}}'
        return TEMPLATE_REF.sub(replace, value)
    return value


def edge(source, target, nodes, handle='source'):
    parent = nodes[source].get('parentId')
    internal = bool(parent and parent == nodes[target].get('parentId'))
    return {
        'id': f'{source}-{handle}-{target}-target', 'source': source, 'target': target,
        'sourceHandle': handle, 'targetHandle': 'target', 'type': 'custom',
        'zIndex': 1002 if internal else 0,
        'data': {'isInIteration': internal, 'isInLoop': False,
                 'iteration_id': parent if internal else None, 'loop_id': None,
                 'sourceType': nodes[source]['data']['type'], 'targetType': nodes[target]['data']['type']},
    }


def place(node, x, y):
    node['position'] = {'x': x, 'y': y}
    node['positionAbsolute'] = {'x': x, 'y': y}


def layout(nodes):
    """Size each iteration from the actual child bounds and its branch lanes."""
    for node in nodes.values():
        kind = node['data']['type']
        node['selected'] = node['data']['selected'] = False
        if kind not in ('iteration', 'iteration-start'):
            node['width'] = 254
            node['height'] = 190 if kind == 'if-else' else 130 if kind == 'llm' else 108
    inside = {
        '2000': {'2000start': (28, 94), '2050': (120, 64), '2110': (420, 64), '2120': (720, 64)},
        '3000': {'3000start': (28, 304), '3050': (120, 274), '3110': (420, 274),
                 '3120': (720, 274), '3130': (1020, 234), '3140': (1320, 64),
                 '3150': (1620, 64), '3160': (1320, 274), '3170': (1620, 274),
                 '3180': (1620, 484), '3190': (1920, 274)},
        '5000': {'5000start': (28, 94), '5050': (120, 64), '5110': (420, 64), '5120': (720, 64)},
    }
    for parent_id, positions in inside.items():
        for child_id, (x, y) in positions.items():
            place(nodes[child_id], x, y)
        parent = nodes[parent_id]
        parent['width'] = parent['data']['width'] = max(x + nodes[k]['width'] for k, (x, _) in positions.items()) + 40
        parent['height'] = parent['data']['height'] = max(y + nodes[k]['height'] for k, (_, y) in positions.items()) + 40
    collect_x = 700 + nodes['3000']['width'] + 100
    outside = {'1000': (40, 610), '1100': (340, 610), '2000': (700, 100),
               '3000': (700, 430), '4000': (collect_x, 610)}
    for node_id, offset, y in [('4050', 300, 610), ('4070', 600, 570),
                               ('4100', 900, 390), ('4120', 1200, 390),
                               ('4130', 1200, 800), ('4150', 1500, 610),
                               ('4200', 1800, 610), ('5000', 2100, 550)]:
        outside[node_id] = (collect_x + offset, y)
    export_x = outside['5000'][0] + nodes['5000']['width'] + 100
    for index, node_id in enumerate(('6000', '6050', '6060', '6100', '6200', '6500', '7000')):
        outside[node_id] = (export_x + index * 300, 610)
    for node_id, (x, y) in outside.items():
        place(nodes[node_id], x, y)
    for node in nodes.values():
        if node.get('parentId'):
            origin = nodes[node['parentId']]['position']
            node['positionAbsolute'] = {axis: origin[axis] + node['position'][axis] for axis in ('x', 'y')}


def build_single():
    documents = {p.name[:2]: yaml.safe_load(p.read_text(encoding='utf-8')) for p in MODULES.glob('*.yml')}
    document = copy.deepcopy(documents['00'])
    graph = document['workflow']['graph']
    removed = {'2110', '2120', '3110', '3120', '4100', '4120', '5110', '5120'}
    graph['nodes'] = [n for n in graph['nodes'] if n['id'] not in removed]
    connections = [(e['source'], e['target'], e['sourceHandle']) for e in graph['edges']
                   if e['source'] not in removed and e['target'] not in removed]
    for prefix, mapping in NODE_MAPS.items():
        for original in documents[prefix]['workflow']['graph']['nodes']:
            if original['id'] not in mapping:
                continue
            node = copy.deepcopy(original)
            node['id'] = mapping[original['id']]
            node['data'] = remap_data(node['data'], prefix)
            parent = PARENTS[prefix]
            if parent:
                node.update(parentId=parent, zIndex=1002)
                node['data'].update(isInIteration=True, iteration_id=parent, isInLoop=False)
            if node['data']['type'] == 'llm':
                node['data'].update(error_strategy='default-value', default_value=[
                    {'key': 'text', 'type': 'string', 'value': '__NODE_EXECUTION_FAILED__'}])
            graph['nodes'].append(node)
        for original in documents[prefix]['workflow']['graph']['edges']:
            if original['source'] in mapping and original['target'] in mapping:
                connections.append((mapping[original['source']], mapping[original['target']], original['sourceHandle']))
    nodes = {n['id']: n for n in graph['nodes']}
    nodes['3000']['data']['output_selector'] = ['3190', 'output']
    for variable in nodes['4200']['data']['variables']:
        if variable['variable'] == 'result_json':
            variable['value_selector'] = ['4150', 'output']
    for source, target in [('2000start', '2050'), ('3000start', '3050'),
                           ('4000', '4050'), ('4150', '4200'), ('5000start', '5050')]:
        connections.append((source, target, 'source'))
    for node_id in ('2000', '3000', '5000'):
        nodes[node_id]['data'].update(is_parallel=False, parallel_nums=1, flatten_output=False,
                                     error_handle_mode='continue-on-error')
    nodes['4000']['data']['title'] = '汇总文章结果与分阶段统计'
    nodes['2000start']['data']['title'] = '快讯遍历入口'
    nodes['3000start']['data']['title'] = '普通资讯遍历入口'
    nodes['5000start']['data']['title'] = '候选遍历入口'
    graph['edges'] = [edge(source, target, nodes, handle) for source, target, handle in connections]
    layout(nodes)
    graph['viewport'] = {'x': 30, 'y': 30, 'zoom': 0.5}
    document['app'].update(name='安全资讯处理（单工作流）',
                           description='单次发布：文章分流、筛选、抽取、事件归并、候选生成与JSON/CSV导出。')
    dependencies = []
    for doc in documents.values():
        for dependency in doc.get('dependencies', []):
            if dependency not in dependencies:
                dependencies.append(dependency)
    document['dependencies'] = dependencies
    OUTPUT.write_text(yaml.safe_dump(document, allow_unicode=True, sort_keys=False, width=120), encoding='utf-8')
    return OUTPUT
