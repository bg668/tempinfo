"""Embed the shared normalization contract, then build all standalone Dify nodes."""

import ast
import runpy
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "dify" / "source"


def replace_functions(text: str, replacements: dict[str, str]) -> str:
    lines = text.splitlines(keepends=True)
    targets = [
        n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name in replacements
    ]
    for node in reversed(targets):
        lines[node.lineno - 1 : node.end_lineno] = [replacements[node.name] + "\n"]
    return "".join(lines)


def main():
    contract = (ROOT / "src/news_local/article_contract.py").read_text(encoding="utf-8")
    functions = {
        n.name: ast.get_source_segment(contract, n)
        for n in ast.parse(contract).body
        if isinstance(n, ast.FunctionDef)
    }
    common = SOURCE / "common.py"
    common.write_text(
        replace_functions(
            common.read_text(encoding="utf-8"),
            {key: functions[key] for key in ("canonical_json", "parse_digest_keywords")},
        ),
        encoding="utf-8",
    )
    prepare = SOURCE / "nodes/00_1100.py"
    text = replace_functions(
        prepare.read_text(encoding="utf-8"),
        {k: functions[k] for k in ("text_value", "normalize_article")},
    )
    old = "def main(articles_json: str, digest_keywords: str = '', max_content_chars: int = 50000) -> dict:"
    new = "def main(articles_json: str, digest_keywords: str = '', max_content_chars: int = 50000, run_id: str = '') -> dict:"
    text = text.replace(old, new)
    marker = "    errors, digest, normal, articles, records = ([], [], [], [], [])"
    guard = "    if run_id and not re.fullmatch(r'run_[a-f0-9]{32}', run_id):\n        raise ValueError('invalid_run_id')\n"
    if guard not in text:
        text = text.replace(marker, guard + marker)
    text = text.replace(
        "'run_id': 'run_' + uuid.uuid4().hex", "'run_id': run_id or ('run_' + uuid.uuid4().hex)"
    )
    prepare.write_text(text, encoding="utf-8")
    path = SOURCE / "templates/00_主控工作流_最终_Dify1.17_CSV.yml"
    doc = yaml.safe_load(path.read_text(encoding="utf-8"))
    nodes = {node["id"]: node for node in doc["workflow"]["graph"]["nodes"]}
    for node in doc["workflow"]["graph"]["nodes"]:
        data = node["data"]
        if node.get("parentId"):
            parent = nodes[node["parentId"]]
            absolute = node["positionAbsolute"]
            origin = parent["positionAbsolute"]
            node["position"] = {axis: absolute[axis] - origin[axis] for axis in ("x", "y")}
            for dimension, axis in (("width", "x"), ("height", "y")):
                parent[dimension] = max(
                    parent[dimension], node["position"][axis] + node[dimension] + 32
                )
                parent["data"][dimension] = parent[dimension]
        if node["id"] == "1000":
            variables = data["variables"]
            for variable in variables:
                if variable["variable"] == "articles_json":
                    variable["max_length"] = 4000000
            if not any(v["variable"] == "run_id" for v in variables):
                variables.append(
                    {
                        "variable": "run_id",
                        "label": "本地批次ID（可空）",
                        "type": "text-input",
                        "required": False,
                        "default": "",
                        "max_length": 36,
                        "options": [],
                    }
                )
        if node["id"] == "1100" and not any(v["variable"] == "run_id" for v in data["variables"]):
            data["variables"].append(
                {"variable": "run_id", "value_selector": ["1000", "run_id"], "value_type": "string"}
            )
    path.write_text(
        yaml.safe_dump(doc, allow_unicode=True, sort_keys=False, width=120), encoding="utf-8"
    )
    build_path = SOURCE / "build.py"
    build_path.write_text(
        build_path.read_text(encoding="utf-8").replace("news-json-files-v5-", "news-local-v1-"),
        encoding="utf-8",
    )
    sys.path.insert(0, str(SOURCE))
    runpy.run_path(str(SOURCE / "prompt_contracts.py"))["sync_digest_prompt"]()
    version = runpy.run_path(str(build_path))["build"]()
    path = runpy.run_path(str(SOURCE / "single_workflow.py"))["build_single"]()
    print("Published build:", version)
    print("Deployable DSL:", path.name)


if __name__ == "__main__":
    main()
