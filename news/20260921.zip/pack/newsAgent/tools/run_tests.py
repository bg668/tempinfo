"""Portable test entry point for Windows and Linux; no shell environment syntax."""

import importlib.util
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(command: list[str], python_paths: list[Path]):
    environment = dict(os.environ, PYTHONPATH=os.pathsep.join(map(str, python_paths)))
    subprocess.run([sys.executable, *command], cwd=ROOT, env=environment, check=True)


def main():
    run(["-m", "unittest", "discover", "-s", "tests", "-v"], [ROOT / "src", ROOT / "tests"])
    if importlib.util.find_spec("yaml"):
        run(["-m", "unittest", "discover", "-s", "dify/tests", "-v"], [ROOT / "dify/tests"])
        run(["dify/tests/validate_dsl.py"], [])
        run(["dify/tests/validate_single.py"], [])
    else:
        print("PyYAML 未安装：跳过 DSL 回归；核心运行不需要此依赖。")


if __name__ == "__main__":
    main()
