"""Create a disposable demo using synthetic Dify responses, without network calls."""

import argparse
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tests")]


def main():
    from helpers import FakeDify, collector_db

    from news_local.progress import configure

    configure()
    from news_local.collector import Collector
    from news_local.config import Settings
    from news_local.repository import Repository
    from news_local.service import Runner
    from news_local.state import RunStore

    parser = argparse.ArgumentParser(description="创建独立演示数据，不读取或覆盖实际采集库")
    parser.add_argument("directory", type=Path)
    destination = parser.parse_args().directory.resolve()
    if destination.exists():
        raise SystemExit("目标目录必须不存在，避免覆盖已有数据")
    destination.mkdir(parents=True)
    source = destination / "collector.db"
    collector_db(source, 12)
    titles = {
        1: "某制造企业遭勒索软件攻击致部分业务中断",
        2: "监管机构发布数据安全管理要求",
        3: "某零售企业披露数据泄露，范围仍在调查",
        4: "安全平台修复身份认证高危漏洞",
        8: "某企业通报邮件账号遭到入侵",
        9: "研究团队披露软件供应链攻击活动",
    }
    with sqlite3.connect(source) as db:
        for sid, title in titles.items():
            db.execute("UPDATE article_contents SET title=? WHERE article_id=?", (title, sid))
    settings = Settings(source, source, destination / "state", api_key="synthetic-demo")
    runner = Runner(
        settings, Collector(source), Repository(source), FakeDify(), RunStore(settings.state_dir)
    )
    report = runner.run()
    if report["status"] != "SUCCESS":
        raise SystemExit(str(report))
    (destination / "config.toml").write_text(
        'source_db="collector.db"\nresult_db="collector.db"\nstate_dir="state"\n'
        'log_level="detailed"\n',
        encoding="utf-8",
    )
    print("演示数据（不是模型实测结果）已生成：", destination)
    print(
        "查看概况：python run.py --config", destination / "config.toml", "status", report["run_id"]
    )


if __name__ == "__main__":
    main()
