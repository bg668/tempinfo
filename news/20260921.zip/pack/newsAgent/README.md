# 本地资讯处理 v1.8.1：分层进度日志、共享 Schema 兼容与单 Worker 断点续跑

只导入并发布 `dify/00_安全资讯处理_单工作流.yml`。Web 前端与 HTTP 响应层不在本包内；本包负责 Collector → Dify → SQLite 的长期后台处理，以及审核/反馈的数据层。

## v1.8.1 更新：资讯处理作为共享主阶段

快讯拆分与研判、普通资讯筛选与抽取是平级分支，现在共享 `S 2/6 资讯处理` 主阶段编号。内部仍分别维护 `digest/normal` 的生命周期、Item 进度和统计，不修改 Dify 工作流。其余主阶段顺延为 S 3/6 至 S 6/6。

## v1.8.0 更新：从 Batch 到 Item 的可读进度

`run-forever` 的默认日志改为进度视图：持久递增的 `B012` 表示 Batch；六个主阶段固定显示为 `S 1/6` … `S 6/6`；三个 Dify iteration 分别显示 `快讯x/N`、`文章x/N`、`事件组x/N`。长时间模型调用的 heartbeat 会继承当前 Item 和子步骤，例如 `[B012][S 2/6 资讯处理-普通资讯筛选与抽取][文章4/5][价值筛选]`。父 iteration 的 0-based index 是唯一 Item 进度来源，子节点自身重复出现的 index 不再用于表示文章序号。

默认 `log_level = "key"`，节点流水账只在 `--log-level detailed` 中显示。每个 `run_xxx` 同时写入 `progress.jsonl` 结构化进度事件，供后续 Web 状态页直接消费。Batch 序号从历史 run journal 续号；中断恢复沿用原 Batch 编号。Dify Workflow 与业务契约没有修改。完整格式见 [docs/LOGGING.md](docs/LOGGING.md)。

## v1.7.1 更新：允许 Web 扩展共享结果表

`processing_items` 与 `candidates` 的初始化校验改为“本程序必需字段必须存在且类型兼容”，不再要求整张表字段集合完全一致。Web 可在共享表追加可省略字段，例如 `candidates.review_version INTEGER` 或带 DEFAULT 的扩展字段；本程序的显式列 INSERT/UPDATE 不读写这些扩展字段，也不会因为它们存在而停止 `run-forever`。如果扩展字段为 `NOT NULL` 且没有 DEFAULT，仍会拒绝启动，因为这种字段会真实阻断本程序 INSERT。旧审核状态 CHECK 自动迁移时会保留这些扩展列，以及 `candidates` 上已有的自建索引和触发器。

## v1.7.0 更新：run-forever 不再使用 session

推荐长期运行唯一入口：

```bash
uv run --env-file .env run.py --config config.toml run-forever --interval 30
```

`run-forever` 现在是单个长期 Worker，不再为每轮创建 `session_xxx`、冻结整轮 scope 或要求 `resume-all`。每个 Dify 批次仍保留独立 `run_xxx`，用于保存输入快照、远程执行 ID、下载结果和入库状态。进程因 Ctrl+C、机器重启或异常退出后，再执行同一条 `run-forever` 命令即可：程序先自动恢复未结束 run，恢复完成后重新扫描 Collector，跳过数据库里已经形成业务终态的 `(source_article_id, input_hash)`，继续处理剩余和新增数据。

断点规则以数据库业务结果为准：已事务提交的 SUCCESS、业务 FAILED、以及本地确定性输入错误都算“已处理”，不会每 30 秒重复失败；原文内容或元数据修复后指纹变化，会重新进入队列。数据库/下载/远程状态等基础设施故障没有业务终态，因此仍会恢复或重试。已拿到 `workflow_run_id` 时只查询原执行；若 POST 是否成功无法确认且没有执行 ID，后台模式复用同一 `run_id` 和输入快照重提，避免生成两份业务结果。

后台会连续清空现有 backlog，只有没有工作或处于等待/恢复状态时才按 `--interval` 休眠。旧 `run-all/resume-all/status-all/abandon-all` 仍作为兼容命令保留，但不再是 `run-forever` 的组成部分。

候选人工状态保持 `pending / starred / ignored`，`Repository.review()` 固定审核身份 `root`，同状态重试无副作用。独立 `feedback` 表仍严格只有 `feedback_id / target_type / target_id / content / created_at` 五字段。

## v1.5.1 更新：批次与业务阶段日志

日志现在按 6 个主阶段显示：批次准备与文章分流、资讯处理（包含平级的快讯拆分与研判/普通资讯筛选与抽取）、处理结果汇总与事件归并、安全事件候选生成、两表整理与文件导出、本地校验与入库。每批有独立编号，详细档显示节点和子步骤，关键信息档保留阶段状态、异常与最终汇总。

更新本地代码即可；保留现有配置、.env、数据库及 state_dir，无需重新导入 Dify。继续执行下方命令即可使用默认进度档；追加 `--log-level detailed` 查看节点细节。阶段执行结束不代表业务校验通过，最终有效数量在 SQLite 提交后显示。并列分支、重复事件与恢复场景已覆盖，缺失的历史阶段日志不补造。完整规则见 [docs/LOGGING.md](docs/LOGGING.md)。

## v1.5.0 更新：一次启动处理全部待处理文章

v1.5.0 的 session 型 `run-all` 现在仅保留兼容。长期后台处理请使用上面的 `run-forever`；已经跑通的 Dify 工作流无需重新导入或发布。

```bash
uv run --env-file .env run.py --config config.toml run-all
uv run --env-file .env run.py --config config.toml resume-all session_xxx
uv run --env-file .env run.py --config config.toml status-all session_xxx
```

`run-all` 固定本轮查询范围，每批最多 25 篇，入库后继续下一批。每篇本轮只尝试一次，单篇失败写库后继续，失败文章留待下一轮。整轮系统故障会暂停并给出 session_id，使用 `resume-all` 恢复；既有 `run` 仍只处理一批。默认进度日志；需要节点细节时加 `--log-level detailed`。完整说明与统计口径见 [docs/CONTINUOUS.md](docs/CONTINUOUS.md)。

`session.py/session_state.py/session_reporting.py` 仅保留给旧 `run-all` 兼容路径；`continuous.py` 的长期 Worker 不再依赖它们。

## 首次部署单工作流

1. 在 Dify 新建工作流并导入上述 YAML。确认六个 LLM 节点（2110、3110、3140、3160、4100、5110）使用你已配置的模型；文件沿用先前模型配置，名称不匹配时请重新选择。保留已安装的 File Tools。
2. 使用 `dify/examples/articles_25_replay.json` 的文件内容填写 `articles_json`，先测试，再发布这一个工作流。模型处理前后仍使用缩进树纯文本，JSON 只用于程序交换。
3. 本地程序沿用原 SQLite、state_dir 和 config.toml；如果新建了 Dify 应用，将 `.env` 中的 `DIFY_API_KEY` 换成这个单工作流应用的 Key。已有原文、处理记录和人工反馈无需删除。
4. 保持 `batch_size = 25`，`digest_keywords = "日报,周报,快讯,安全简讯"`。示例配置已改为 25，不要求修改 Docker。执行新批次重新处理失败原文。

```bash
uv run --env-file .env run.py --config config.toml run
uv run --env-file .env run.py --config config.toml run --log-level key
```

默认 `key` 进度日志；`detailed` 追加节点细节。日志写 stderr，最终概况 JSON 写 stdout。运行只需 Python 3.11+ 标准库。数据库访问、文件下载与最终入库仍由本地 Python 完成，网页由你现有系统展示。路径以配置文件所在目录为基准，移动配置文件时应检查数据库和 state_dir 指向。

## 本轮行为

- 三个遍历块分别处理快讯、普通资讯和事件分组。事件归并位于同一画布；默认单篇分组，选择 event_match 时，对两条以上事件事实调用归并模型。
- 标识符保持文本，评分保持整数；已有 think 过滤继续生效。LLM 调用失败直接记录错误，已完成的筛选结论和原文关联继续保留。
- 快讯提示词完整列出分类枚举，构建时从代码校验器同步。父 ID、子项覆盖、片段来源错误阻断整篇；独立子项的分类、标题或事实错误只隔离该项。有效兄弟子项继续生成候选，失败子项和父记录继续入库。
- 新增 observed 统计说明模型输出的初步决定；有效汇总数和最终候选数分别保留，避免把校验失败解释成“模型没有选中”。
- 汇总候选用 JSON 字符串传递，避免快讯展开后的候选数受到 Code 数组元素上限影响；未截断文章、候选或错误。输入遍历数组仍与批次大小有关，字符串等容量仍受部署配置限制。
- 两表字段、人工反馈、北京时间 +08:00、JSON/CSV 文件以及结束节点既有输出保持兼容。仅有部分快讯子项成功时，Python 概况显示 PARTIAL；只要该结果已经完整事务提交，这个输入版本即视为已处理，不自动 poison-loop 重试。

## 验证

测试入口：`python tools/run_tests.py`。DSL 测试依赖通过 `uv sync --extra build-dsl` 安装。测试使用真实 Code、选择器、互斥分支和遍历输出；模型与文件保存插件使用测试替身，不等同于用户 Dify 实机测试。验证报告见 `VALIDATION_REPORT.json` 和 `docs/VALIDATION.md`。

目录：`src/news_local/` 是本地运行程序；`dify/` 顶层唯一 YAML 是部署文件；`dify/source/` 按职责维护代码与模板；`dify/build/modules/` 是内部构建与测试产物，不需要导入；`dify/tests/` 是回归；`docs/NODE_IO.md` 给出全部节点编号与输入输出来源。旧多工作流绑定脚本仅保留供内部兼容测试和后续拆分使用。

构建：`python tools/build_dsl.py`。构建器先编译各业务模块，再映射节点 ID、变量引用和分支，生成一份完整 DSL。Code 节点仅内嵌实际使用的函数，每个节点只有一个 main，无历史版本套娃。

其他命令：`plan` 只读预览；`check --remote` 核对应用参数；`resume run_id` 是人工保守恢复入口，默认不会重提未知 POST；`ingest run_id` 重复导入会保护人工状态与反馈；`status run_id` 查看本地概况。首次创建结果库使用 `init`。详细恢复规则见 `docs/OPERATIONS.md`。
