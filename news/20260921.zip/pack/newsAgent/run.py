"""Run directly without pip: python run.py --config config.toml run"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from news_local.cli import main

if __name__ == "__main__":
    main()
