# WeChat Collector MVP

目标：把 DoonSec RSS 当作“文章发现源”，支持“全量采集”或“仅采集配置中的目标公众号”；拿到微信文章 URL 后直接抓正文，标准化落到 SQLite + 文件系统。Collector 不负责资讯价值判断、评分、摘要或报告生成。

## 设计边界

- `sources/doonsec.py`：只负责 `RSS -> FeedItem`。
- `fetchers/weixin.py`：只负责 `微信 URL -> ArticleContent`。
- `services/discovery.py`：只负责发现、落库、目标公众号匹配。
- `services/article.py`：只负责待抓文章执行、失败记录、正文保存。
- `repositories/sqlite.py`：只负责结构化状态/正文持久化。
- `storage/filesystem.py`：只负责文章文件产物持久化和按获取日期组织目录。
- `jobs/poll.py`：只编排“一次轮询”。
- `jobs/watch.py`：只负责周期调度和瞬时失败后的继续运行；复用 `PollJob`，不重复采集逻辑。
- `cli.py`：只做依赖组装和命令入口，无 DI/IoC 框架。

依赖方向保持为：`services -> models/ports/errors`，适配器实现端口；业务服务不直接依赖 requests、BeautifulSoup、sqlite3。

## 目录

```text
src/collector/
├─ models.py
├─ errors.py
├─ ports.py
├─ config.py
├─ targets.py
├─ services/
│  ├─ discovery.py
│  └─ article.py
├─ sources/
│  └─ doonsec.py
├─ fetchers/
│  └─ weixin.py
├─ repositories/
│  └─ sqlite.py
├─ storage/
│  └─ filesystem.py
├─ jobs/
│  ├─ poll.py
│  └─ watch.py
└─ cli.py
```

## Windows + uv

```powershell
cd wechat_collector
uv sync
uv run pytest
```

复制并修改公众号配置：

```powershell
Copy-Item .\config\targets.example.yaml .\config\targets.yaml
```

初始化：

```powershell
uv run collector init --config .\config\targets.yaml
```

执行一次采集：

```powershell
uv run collector poll --config .\config\targets.yaml
```

首次测试建议限制正文抓取数量：

```powershell
uv run collector poll --config .\config\targets.yaml --fetch-limit 5
```

`poll` 执行完即退出。若希望 Collector 自己常驻并周期探测 RSS，使用：

```powershell
uv run .\src\main.py watch --config .\config\targets.yaml
```

`watch.interval_seconds` 控制探测间隔，默认 3600 秒（1 小时）。`watch` 启动后立即执行第一轮，不会先等待一个周期；之后每隔配置时间复用同一个 `PollJob`。URL 唯一键决定 RSS 是否真正新增文章。Ctrl+C 可安全停止。Windows Task Scheduler 调用单次 `poll` 仍然保留，两种运行方式互不影响。

运行日志统一采用本轮工作量口径：`received`=RSS 返回总数，`duplicate`=已存在 URL 数，`new`=本轮首次发现数，`selected`=本轮新增且命中采集策略数，`fetched`=本轮正文抓取成功数，`failed`=本轮抓取失败数，`retry`=安排下轮自动重试数，`terminal_failed`=本轮进入终态失败数。

示例：

```text
[2026-08-17T09:45:00+00:00] cycle=20 RSS=UPDATED received=197 duplicate=194 new=3 selected=3 fetched=2 failed=1 retry=1 terminal_failed=0 newest=2026-08-17T08:30:00 oldest=2026-08-10T... next=3600s
```

`selected` 只统计“本轮新发现且进入采集范围”的文章；如果存在上一轮的 `RETRY_PENDING`，可能出现 `selected=0` 但 `fetched>0`。


### 采集范围

`collect_all` 明确控制采集范围：

- `collect_all: true`：忽略 `targets` 白名单，DoonSec RSS 中的所有文章都进入正文采集。
- `collect_all: false`：只抓取 `targets` 中 `enabled: true` 且名称/别名匹配的公众号。
- `collect_all: false` 且 `targets: []`：不抓取任何正文，但 RSS 发现记录仍会先落库并标记为 `NOT_TARGET`。

因此不要使用“空 targets 代表全量”这类隐式语义。

## 数据流

```text
DoonSec RSS
  -> FeedItem
  -> feed_items（所有发现先落库）
  -> TargetMatcher
       -> 非目标：NOT_TARGET
       -> 目标：PENDING
  -> WeixinArticleFetcher
  -> 获取正文 + 正文 HTML + 图片 URL
  -> data/articles/YYYYMMDD/<stable_id>/
       raw.html
       article.html
       article.txt
       image_urls.txt
  -> article_contents 保存正文、图片 URL 和产物路径
  -> feed_items.fetch_status = FETCHED
```

正文失败不会删除发现记录。失败状态按类型收敛：

- 可重试失败：第一次失败进入 `RETRY_PENDING`，后续 `poll/watch` 自动再尝试 1 次；再次失败进入终态 `FETCH_FAILED`。
- 不可重试失败：第一次失败直接进入终态 `FETCH_FAILED`。
- `FETCH_FAILED` 不再参与后续自动抓取，因此不会在每轮 watch 中重复失败。
- `fetch_attempts` 记录实际调用正文抓取器的次数。

## 正文失败与重试策略

自动重试不是按“所有失败统一重试”，而是由正文抓取器返回统一失败类型和 `retryable` 属性，`ArticleService` 只执行策略，不依赖微信实现细节。

| 失败类型 | 示例 | 自动策略 |
|---|---|---|
| `TIMEOUT` / `NETWORK` | 超时、连接失败 | 自动重试 1 次 |
| `RATE_LIMITED` | HTTP 429 | 自动重试 1 次 |
| `HTTP_RETRYABLE` | 403/408/425/5xx | 自动重试 1 次 |
| `ABNORMAL_PAGE` | 微信环境异常、安全验证、访问频繁 | 自动重试 1 次 |
| `NOT_FOUND` | HTTP 404/410 | 直接终态失败 |
| `HTTP_PERMANENT` | 其他永久 4xx | 直接终态失败 |
| `UNSUPPORTED_URL` | 非微信文章 URL | 直接终态失败 |
| `PARSE_ERROR` | 没有文章 DOM、正文为空 | 直接终态失败 |
| `UNKNOWN` | 未分类程序异常 | 默认直接终态失败 |

状态链：

```text
PENDING
  ├─ 成功 ───────────────→ FETCHED
  ├─ 可重试失败 ─────────→ RETRY_PENDING
  │                           ├─ 成功 → FETCHED
  │                           └─ 再失败 → FETCH_FAILED
  └─ 不可重试失败 ───────→ FETCH_FAILED
```

`FETCH_FAILED` 是终态，不会被后续 `poll/watch` 自动选中。代码或策略修复后，可显式重新入队：

```powershell
uv run .\src\main.py retry --article-id <stable_id>
```

显式重试会把该目标文章重置为 `PENDING`、`fetch_attempts=0` 并清空上次错误；不会自动批量复活历史失败任务。

## 文章文件目录

新抓取文章按“正文实际获取日期 / 稳定 article_id”组织：

```text
data/articles/
└─ 20260814/
   └─ 7f4c...<32 hex>/
      ├─ raw.html          # 微信返回的完整页面
      ├─ article.html      # 提取并清理后的正文 HTML
      ├─ article.txt       # 正文纯文本
      └─ image_urls.txt    # 正文图片 URL，每行一个
```

日期使用 `storage.date_timezone` 转换 `fetched_at` 后生成，默认 `Asia/Singapore`。旧版本 SQLite 数据库会在 `init/poll/watch` 启动时自动补充 `stable_id` 和新增的文章产物字段；旧文件不会移动，新抓取文件使用新目录规则。

## SQLite 数据

### feed_items
发现事实和抓取状态。`url UNIQUE` 是第一层去重键；`stable_id` 由 URL 的 SHA-256 确定性派生，不依赖 SQLite 自增编号，数据库重建后仍保持稳定。

### article_contents
正文、图片 URL、`raw.html/article.html/article.txt/image_urls.txt` 路径和正文抓取时间。

### poll_runs
每轮 RSS 的条目数、新增数、目标数、抓取结果、RSS 最老/最新文章时间。用于判断 RSS 是否异常，以及轮询周期是否可能超过 RSS 窗口。

## 配置示例

```yaml
# true: 全量采集；false: 只采集 targets 中匹配的公众号
collect_all: false

targets:
  - name: 安全内参
    aliases: []
    enabled: true
  - name: 奇安信病毒响应中心
    aliases:
      - QAX病毒响应中心
    enabled: true

doonsec:
  rss_url: https://wechat.doonsec.com/rss.xml
  timeout_seconds: 15
weixin:
  timeout_seconds: 15
  # 初次失败后的自动重试次数；默认只重试 1 次
  max_retries: 1
storage:
  db_path: data/collector.db
  article_dir: data/articles
  date_timezone: Asia/Singapore
watch:
  # 启动后立即拉取一次，之后每 1 小时轮询
  interval_seconds: 3600
```

## MVP 已实现 / 未实现

已实现：DoonSec RSS、目标公众号过滤、URL 去重、稳定 article_id、按获取日期分目录、微信正文解析、原始 HTML/正文 HTML/正文文本/图片 URL 留存、SQLite、旧库自动迁移、按失败类型决定重试、可重试失败最多自动重试 1 次、终态失败隔离、显式人工重试、poll 运行审计、周期 watch 模式、CLI、离线单元测试。

未实现：正文图片二进制下载、公众号 `biz` 稳定 ID、并发抓取、代理/Cookie/浏览器降级、正文质量清洗、Agent 评分与摘要。当前会保存正文中的图片 URL，但不下载图片文件。
