from __future__ import annotations

from collections.abc import Sequence

from .config import AccountTarget


def _normalize(value: str) -> str:
    return " ".join(value.split()).strip().casefold()


class TargetMatcher:
    def __init__(self, targets: list[AccountTarget], collect_all: bool = False):
        self._collect_all = collect_all
        self._targets = [target for target in targets if target.enabled]
        self._names: set[str] = set()
        for target in self._targets:
            self._names.add(_normalize(target.name))
            self._names.update(_normalize(alias) for alias in target.aliases)

    def match(self, account: str) -> bool:
        if self._collect_all:
            return True
        return _normalize(account) in self._names

    @property
    def collect_all(self) -> bool:
        return self._collect_all

    def configured_accounts(self) -> Sequence[str]:
        return tuple(target.name for target in self._targets)
