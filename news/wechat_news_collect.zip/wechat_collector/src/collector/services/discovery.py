from __future__ import annotations

from dataclasses import dataclass

from ..models import FeedItem
from ..ports import ArticleRepository, FeedSource, TargetMatcherPort


@dataclass(slots=True)
class DiscoveryResult:
    items: list[FeedItem]
    new_item_count: int
    duplicate_count: int
    selected_count: int
    target_count: int


class DiscoveryService:
    def __init__(
        self,
        source: FeedSource,
        repository: ArticleRepository,
        targets: TargetMatcherPort,
    ):
        self._source = source
        self._repository = repository
        self._targets = targets

    def run(self) -> DiscoveryResult:
        items = self._source.fetch()
        new_count = 0
        duplicate_count = 0
        selected_count = 0
        target_count = 0

        for item in items:
            is_new = self._repository.save_discovered(item)
            if is_new:
                new_count += 1
            else:
                duplicate_count += 1

            matched = self._targets.match(item.account)
            self._repository.mark_target(item.url, matched)
            if matched:
                target_count += 1
                if is_new:
                    selected_count += 1

        return DiscoveryResult(
            items=items,
            new_item_count=new_count,
            duplicate_count=duplicate_count,
            selected_count=selected_count,
            target_count=target_count,
        )
