from __future__ import annotations

from dataclasses import dataclass

from ..errors import ArticleFetchError, FetchFailureType
from ..ports import ArticleFetcher, ArticleRepository, RawStorage


@dataclass(slots=True)
class ArticleFetchResult:
    fetched_count: int = 0
    failed_count: int = 0
    retry_scheduled_count: int = 0
    terminal_failed_count: int = 0


class ArticleService:
    def __init__(
        self,
        fetcher: ArticleFetcher,
        repository: ArticleRepository,
        storage: RawStorage,
        max_retries: int = 1,
    ):
        if max_retries < 0:
            raise ValueError("max_retries must be >= 0")
        self._fetcher = fetcher
        self._repository = repository
        self._storage = storage
        self._max_retries = max_retries

    def fetch_pending(self, limit: int | None = None) -> ArticleFetchResult:
        result = ArticleFetchResult()

        for pending in self._repository.list_pending(limit=limit):
            # fetch_attempts counts actual fetch calls. Increment immediately before
            # invoking the adapter so every network/parse attempt is auditable.
            self._repository.mark_fetch_attempt(pending.id)

            try:
                content = self._fetcher.fetch(pending.url)
                content = content.model_copy(
                    update={
                        "title": content.title or pending.title,
                        "account": content.account or pending.account,
                        "published_at": content.published_at or pending.published_at,
                    }
                )

                artifacts = self._storage.save_article(
                    pending.stable_id,
                    content.fetched_at,
                    raw_html=content.raw_html,
                    article_html=content.article_html,
                    text=content.text,
                    image_urls=content.image_urls,
                )
                self._repository.save_content(pending.id, content, artifacts)
                result.fetched_count += 1

            except ArticleFetchError as exc:
                # pending.fetch_attempts is the number of attempts completed before
                # this call. With max_retries=1, only the first retryable failure is
                # scheduled once; a second failure becomes terminal.
                schedule_retry = exc.retryable and pending.fetch_attempts < self._max_retries
                self._repository.mark_fetch_failed(
                    pending.id,
                    failure_type=exc.failure_type.value,
                    error=str(exc),
                    retryable=exc.retryable,
                    schedule_retry=schedule_retry,
                )
                result.failed_count += 1
                if schedule_retry:
                    result.retry_scheduled_count += 1
                else:
                    result.terminal_failed_count += 1

            except Exception as exc:
                # Unknown failures are terminal by default. This keeps a programming
                # bug or unsupported response from polluting every future watch cycle.
                self._repository.mark_fetch_failed(
                    pending.id,
                    failure_type=FetchFailureType.UNKNOWN.value,
                    error=f"{type(exc).__name__}: {exc}",
                    retryable=False,
                    schedule_retry=False,
                )
                result.failed_count += 1
                result.terminal_failed_count += 1

        return result
