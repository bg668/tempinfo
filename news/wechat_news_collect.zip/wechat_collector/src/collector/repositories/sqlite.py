from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from ..identity import stable_article_id
from ..models import ArticleContent, FeedItem, PendingArticle, StoredArticleArtifacts


SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS feed_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    stable_id TEXT,
    source TEXT NOT NULL,
    source_id TEXT,
    account TEXT NOT NULL,
    title TEXT NOT NULL,
    url TEXT NOT NULL UNIQUE,
    published_at TEXT,
    discovered_at TEXT NOT NULL,
    is_target INTEGER,
    fetch_status TEXT NOT NULL DEFAULT 'DISCOVERED',
    fetch_attempts INTEGER NOT NULL DEFAULT 0,
    last_error_type TEXT,
    last_error TEXT,
    last_failure_retryable INTEGER
);

CREATE TABLE IF NOT EXISTS article_contents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article_id INTEGER NOT NULL UNIQUE,
    url TEXT NOT NULL UNIQUE,
    title TEXT,
    account TEXT,
    published_at TEXT,
    content TEXT NOT NULL,
    raw_html_path TEXT NOT NULL,
    article_html_path TEXT,
    text_path TEXT,
    image_urls_path TEXT,
    image_urls_json TEXT NOT NULL DEFAULT '[]',
    fetched_at TEXT NOT NULL,
    FOREIGN KEY(article_id) REFERENCES feed_items(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS poll_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    success INTEGER,
    item_count INTEGER NOT NULL DEFAULT 0,
    duplicate_count INTEGER NOT NULL DEFAULT 0,
    new_item_count INTEGER NOT NULL DEFAULT 0,
    selected_count INTEGER NOT NULL DEFAULT 0,
    target_count INTEGER NOT NULL DEFAULT 0,
    fetched_count INTEGER NOT NULL DEFAULT 0,
    fetch_failed_count INTEGER NOT NULL DEFAULT 0,
    retry_scheduled_count INTEGER NOT NULL DEFAULT 0,
    terminal_failed_count INTEGER NOT NULL DEFAULT 0,
    newest_published_at TEXT,
    oldest_published_at TEXT,
    error TEXT
);
"""

INDEXES = """
CREATE UNIQUE INDEX IF NOT EXISTS idx_feed_items_stable_id_unique ON feed_items(stable_id);
CREATE INDEX IF NOT EXISTS idx_feed_items_status ON feed_items(fetch_status);
CREATE INDEX IF NOT EXISTS idx_feed_items_account ON feed_items(account);
CREATE INDEX IF NOT EXISTS idx_feed_items_published ON feed_items(published_at);
"""


class SQLiteArticleRepository:
    def __init__(self, db_path: str | Path):
        self._path = Path(db_path)

    @contextmanager
    def _connection(self):
        self._path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self._path, timeout=20)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def initialize(self) -> None:
        with self._connection() as conn:
            conn.executescript(SCHEMA)
            self._migrate(conn)
            conn.executescript(INDEXES)

    @staticmethod
    def _columns(conn: sqlite3.Connection, table: str) -> set[str]:
        return {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}

    def _migrate(self, conn: sqlite3.Connection) -> None:
        """Upgrade databases created by earlier MVP versions in place."""
        feed_columns = self._columns(conn, "feed_items")
        if "stable_id" not in feed_columns:
            conn.execute("ALTER TABLE feed_items ADD COLUMN stable_id TEXT")

        for row in conn.execute("SELECT id, url, stable_id FROM feed_items"):
            if not row["stable_id"]:
                conn.execute(
                    "UPDATE feed_items SET stable_id=? WHERE id=?",
                    (stable_article_id(row["url"]), row["id"]),
                )

        feed_columns = self._columns(conn, "feed_items")
        feed_additions = {
            "last_error_type": "TEXT",
            "last_failure_retryable": "INTEGER",
        }
        for name, sql_type in feed_additions.items():
            if name not in feed_columns:
                conn.execute(f"ALTER TABLE feed_items ADD COLUMN {name} {sql_type}")

        content_columns = self._columns(conn, "article_contents")
        additions = {
            "article_html_path": "TEXT",
            "text_path": "TEXT",
            "image_urls_path": "TEXT",
            "image_urls_json": "TEXT NOT NULL DEFAULT '[]'",
        }
        for name, sql_type in additions.items():
            if name not in content_columns:
                conn.execute(f"ALTER TABLE article_contents ADD COLUMN {name} {sql_type}")

        poll_columns = self._columns(conn, "poll_runs")
        poll_additions = {
            "duplicate_count": "INTEGER NOT NULL DEFAULT 0",
            "selected_count": "INTEGER NOT NULL DEFAULT 0",
            "retry_scheduled_count": "INTEGER NOT NULL DEFAULT 0",
            "terminal_failed_count": "INTEGER NOT NULL DEFAULT 0",
        }
        for name, sql_type in poll_additions.items():
            if name not in poll_columns:
                conn.execute(f"ALTER TABLE poll_runs ADD COLUMN {name} {sql_type}")

    def save_discovered(self, item: FeedItem) -> bool:
        stable_id = stable_article_id(item.url)
        with self._connection() as conn:
            cursor = conn.execute(
                """
                INSERT OR IGNORE INTO feed_items(
                    stable_id, source, source_id, account, title, url, published_at, discovered_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    stable_id,
                    item.source,
                    item.source_id,
                    item.account,
                    item.title,
                    item.url,
                    _dt(item.published_at),
                    _dt(item.discovered_at),
                ),
            )
            inserted = cursor.rowcount == 1
            if not inserted:
                conn.execute(
                    """
                    UPDATE feed_items
                    SET stable_id = COALESCE(stable_id, ?),
                        source_id = COALESCE(?, source_id),
                        account = ?,
                        title = ?,
                        published_at = COALESCE(?, published_at)
                    WHERE url = ?
                    """,
                    (stable_id, item.source_id, item.account, item.title, _dt(item.published_at), item.url),
                )
            return inserted

    def mark_target(self, url: str, matched: bool) -> None:
        with self._connection() as conn:
            if matched:
                conn.execute(
                    """
                    UPDATE feed_items
                    SET is_target = 1,
                        fetch_status = CASE
                            WHEN fetch_status IN ('DISCOVERED','NOT_TARGET') THEN 'PENDING'
                            ELSE fetch_status
                        END
                    WHERE url = ?
                    """,
                    (url,),
                )
            else:
                conn.execute(
                    """
                    UPDATE feed_items
                    SET is_target = 0,
                        fetch_status = CASE
                            WHEN fetch_status IN ('DISCOVERED','PENDING','RETRY_PENDING') THEN 'NOT_TARGET'
                            ELSE fetch_status
                        END
                    WHERE url = ?
                    """,
                    (url,),
                )

    def list_pending(self, limit: int | None = None) -> list[PendingArticle]:
        sql = """
            SELECT id, stable_id, url, account, title, published_at, fetch_attempts
            FROM feed_items
            WHERE is_target = 1 AND fetch_status IN ('PENDING','RETRY_PENDING')
            ORDER BY COALESCE(published_at, discovered_at) ASC
        """
        params: tuple[object, ...] = ()
        if limit is not None:
            sql += " LIMIT ?"
            params = (limit,)

        with self._connection() as conn:
            rows = conn.execute(sql, params).fetchall()

        return [
            PendingArticle(
                id=row["id"],
                stable_id=row["stable_id"] or stable_article_id(row["url"]),
                url=row["url"],
                account=row["account"],
                title=row["title"],
                published_at=_parse_dt(row["published_at"]),
                fetch_attempts=row["fetch_attempts"],
            )
            for row in rows
        ]

    def mark_fetch_attempt(self, article_id: int) -> None:
        with self._connection() as conn:
            conn.execute(
                "UPDATE feed_items SET fetch_attempts=fetch_attempts+1 WHERE id=?",
                (article_id,),
            )

    def save_content(
        self,
        article_id: int,
        content: ArticleContent,
        artifacts: StoredArticleArtifacts,
    ) -> None:
        with self._connection() as conn:
            conn.execute(
                """
                INSERT INTO article_contents(
                    article_id, url, title, account, published_at, content,
                    raw_html_path, article_html_path, text_path,
                    image_urls_path, image_urls_json, fetched_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(article_id) DO UPDATE SET
                    title=excluded.title,
                    account=excluded.account,
                    published_at=excluded.published_at,
                    content=excluded.content,
                    raw_html_path=excluded.raw_html_path,
                    article_html_path=excluded.article_html_path,
                    text_path=excluded.text_path,
                    image_urls_path=excluded.image_urls_path,
                    image_urls_json=excluded.image_urls_json,
                    fetched_at=excluded.fetched_at
                """,
                (
                    article_id,
                    content.url,
                    content.title,
                    content.account,
                    _dt(content.published_at),
                    content.text,
                    artifacts.raw_html_path,
                    artifacts.article_html_path,
                    artifacts.text_path,
                    artifacts.image_urls_path,
                    json.dumps(content.image_urls, ensure_ascii=False),
                    _dt(content.fetched_at),
                ),
            )
            conn.execute(
                """
                UPDATE feed_items
                SET fetch_status = 'FETCHED', last_error_type = NULL, last_error = NULL, last_failure_retryable = NULL
                WHERE id = ?
                """,
                (article_id,),
            )

    def mark_fetch_failed(
        self,
        article_id: int,
        *,
        failure_type: str,
        error: str,
        retryable: bool,
        schedule_retry: bool,
    ) -> None:
        status = "RETRY_PENDING" if schedule_retry else "FETCH_FAILED"
        with self._connection() as conn:
            conn.execute(
                """
                UPDATE feed_items
                SET fetch_status=?,
                    last_error_type=?,
                    last_error=?,
                    last_failure_retryable=?
                WHERE id=?
                """,
                (
                    status,
                    failure_type,
                    error[:2000],
                    1 if retryable else 0,
                    article_id,
                ),
            )

    def retry_failed(self, stable_id: str) -> bool:
        """Explicitly requeue one terminal failure after a code/policy fix."""
        with self._connection() as conn:
            cursor = conn.execute(
                """
                UPDATE feed_items
                SET fetch_status='PENDING',
                    fetch_attempts=0,
                    last_error_type=NULL,
                    last_error=NULL,
                    last_failure_retryable=NULL
                WHERE stable_id=? AND is_target=1 AND fetch_status='FETCH_FAILED'
                """,
                (stable_id,),
            )
            return cursor.rowcount == 1

    def start_poll_run(self, source: str) -> int:
        with self._connection() as conn:
            cursor = conn.execute(
                "INSERT INTO poll_runs(source, started_at) VALUES (?, ?)",
                (source, _dt(datetime.now(timezone.utc))),
            )
            return int(cursor.lastrowid)

    def finish_poll_run(
        self,
        run_id: int,
        *,
        success: bool,
        item_count: int,
        duplicate_count: int,
        new_item_count: int,
        selected_count: int,
        target_count: int,
        fetched_count: int,
        fetch_failed_count: int,
        retry_scheduled_count: int,
        terminal_failed_count: int,
        newest_published_at: datetime | None,
        oldest_published_at: datetime | None,
        error: str | None = None,
    ) -> None:
        with self._connection() as conn:
            conn.execute(
                """
                UPDATE poll_runs SET
                    finished_at=?, success=?, item_count=?, duplicate_count=?, new_item_count=?, selected_count=?, target_count=?,
                    fetched_count=?, fetch_failed_count=?, retry_scheduled_count=?, terminal_failed_count=?,
                    newest_published_at=?, oldest_published_at=?, error=?
                WHERE id=?
                """,
                (
                    _dt(datetime.now(timezone.utc)),
                    1 if success else 0,
                    item_count,
                    duplicate_count,
                    new_item_count,
                    selected_count,
                    target_count,
                    fetched_count,
                    fetch_failed_count,
                    retry_scheduled_count,
                    terminal_failed_count,
                    _dt(newest_published_at),
                    _dt(oldest_published_at),
                    error,
                    run_id,
                ),
            )


def _dt(value: datetime | None) -> str | None:
    if value is None:
        return None
    return value.isoformat()


def _parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    return datetime.fromisoformat(value)
