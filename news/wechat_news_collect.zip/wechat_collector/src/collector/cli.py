from __future__ import annotations

import argparse
from pathlib import Path

from .config import load_config
from .fetchers.weixin import WeixinArticleFetcher
from .jobs.poll import PollJob
from .jobs.watch import WatchJob
from .repositories.sqlite import SQLiteArticleRepository
from .services.article import ArticleService
from .services.discovery import DiscoveryService
from .sources.doonsec import DoonSecSource
from .storage.filesystem import FileSystemStorage
from .targets import TargetMatcher


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="DoonSec -> WeChat article collector")
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="initialize SQLite schema")
    init.add_argument("--config", default="config/targets.yaml")

    poll = sub.add_parser("poll", help="run one discovery + article fetch cycle")
    poll.add_argument("--config", default="config/targets.yaml")
    poll.add_argument("--fetch-limit", type=int, default=None)

    watch = sub.add_parser("watch", help="continuously poll RSS using watch.interval_seconds")
    watch.add_argument("--config", default="config/targets.yaml")
    watch.add_argument("--fetch-limit", type=int, default=None)

    retry = sub.add_parser("retry", help="explicitly requeue one terminal FETCH_FAILED article")
    retry.add_argument("--config", default="config/targets.yaml")
    retry.add_argument("--article-id", required=True, help="stable article id")

    return parser


def _build(config_path: str):
    cfg = load_config(config_path)
    repo = SQLiteArticleRepository(cfg.storage.db_path)
    repo.initialize()

    matcher = TargetMatcher(cfg.targets, collect_all=cfg.collect_all)
    source = DoonSecSource(cfg.doonsec.rss_url, cfg.doonsec.timeout_seconds)
    fetcher = WeixinArticleFetcher(cfg.weixin.timeout_seconds)
    storage = FileSystemStorage(cfg.storage.article_dir, cfg.storage.date_timezone)

    discovery = DiscoveryService(source, repo, matcher)
    articles = ArticleService(fetcher, repo, storage, max_retries=cfg.weixin.max_retries)
    poll_job = PollJob(source.name, discovery, articles, repo)
    watch_job = WatchJob(poll_job, cfg.watch.interval_seconds)
    return cfg, repo, matcher, poll_job, watch_job


def _format_datetime(value) -> str:
    return value.isoformat() if value is not None else "-"


def _format_stats(stats) -> str:
    return (
        f"received={stats.item_count} "
        f"duplicate={stats.duplicate_count} "
        f"new={stats.new_item_count} "
        f"selected={stats.selected_count} "
        f"fetched={stats.fetched_count} "
        f"failed={stats.fetch_failed_count} "
        f"retry={stats.retry_scheduled_count} "
        f"terminal_failed={stats.terminal_failed_count} "
        f"newest={_format_datetime(stats.newest_published_at)} "
        f"oldest={_format_datetime(stats.oldest_published_at)}"
    )


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    cfg, repo, matcher, poll_job, watch_job = _build(args.config)

    if args.command == "init":
        print(f"initialized: {Path(cfg.storage.db_path).resolve()}")
        print(f"collection mode: {'ALL' if matcher.collect_all else 'TARGETS_ONLY'}")
        print(f"weixin retry policy: max_retries={cfg.weixin.max_retries}")
        if not matcher.collect_all:
            print("targets:")
            for name in matcher.configured_accounts():
                print(f"  - {name}")
        return 0

    if args.command == "poll":
        stats = poll_job.run(fetch_limit=args.fetch_limit)
        print(f"RSS=OK {_format_stats(stats)}", flush=True)
        return 0

    if args.command == "watch":
        print(
            f"watching RSS every {watch_job.interval_seconds:g}s; "
            f"first poll runs immediately; Ctrl+C to stop",
            flush=True,
        )
        try:
            for event in watch_job.cycles(fetch_limit=args.fetch_limit):
                timestamp = event.checked_at.isoformat()
                if event.error is not None:
                    print(
                        f"[{timestamp}] cycle={event.cycle} status=ERROR "
                        f"error={event.error!r} next={event.interval_seconds:g}s",
                        flush=True,
                    )
                    continue

                assert event.stats is not None
                stats = event.stats
                state = "UPDATED" if event.rss_updated else "UNCHANGED"
                print(
                    f"[{timestamp}] cycle={event.cycle} RSS={state} "
                    f"{_format_stats(stats)} next={event.interval_seconds:g}s",
                    flush=True,
                )
        except KeyboardInterrupt:
            print("watch stopped", flush=True)
        return 0

    if args.command == "retry":
        if repo.retry_failed(args.article_id):
            print(f"requeued: {args.article_id}")
            return 0
        print(f"not requeued: {args.article_id} (not found, not target, or not FETCH_FAILED)")
        return 1

    return 2


if __name__ == "__main__":
    raise SystemExit(main())
