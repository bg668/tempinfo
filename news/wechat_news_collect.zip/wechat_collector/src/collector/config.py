from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import BaseModel, Field


class AccountTarget(BaseModel):
    name: str
    aliases: list[str] = Field(default_factory=list)
    enabled: bool = True


class DoonSecConfig(BaseModel):
    rss_url: str = "https://wechat.doonsec.com/rss.xml"
    timeout_seconds: float = 15.0


class WeixinConfig(BaseModel):
    timeout_seconds: float = 15.0
    # Number of automatic retries after the first failed fetch.
    # 1 = at most two total fetch calls for retryable failures.
    max_retries: int = Field(default=1, ge=0)


class StorageConfig(BaseModel):
    db_path: str = "data/collector.db"
    article_dir: str = "data/articles"
    date_timezone: str = "Asia/Singapore"


class WatchConfig(BaseModel):
    interval_seconds: float = Field(default=3600.0, gt=0)


class AppConfig(BaseModel):
    collect_all: bool = False
    targets: list[AccountTarget] = Field(default_factory=list)
    doonsec: DoonSecConfig = Field(default_factory=DoonSecConfig)
    weixin: WeixinConfig = Field(default_factory=WeixinConfig)
    storage: StorageConfig = Field(default_factory=StorageConfig)
    watch: WatchConfig = Field(default_factory=WatchConfig)


def load_config(path: str | Path) -> AppConfig:
    path = Path(path)
    with path.open("r", encoding="utf-8-sig") as f:
        raw = yaml.safe_load(f) or {}
    return AppConfig.model_validate(raw)
