from __future__ import annotations

import re
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

from ..errors import ArticleFetchError, FetchFailureType
from ..models import ArticleContent


class WeixinArticleFetcher:
    def __init__(self, timeout_seconds: float = 15.0, session: requests.Session | None = None):
        self._timeout = timeout_seconds
        self._session = session or requests.Session()
        self._headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/151.0.0.0 Safari/537.36"
            ),
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        }

    def fetch(self, url: str) -> ArticleContent:
        if not _is_weixin_url(url):
            raise ArticleFetchError(
                FetchFailureType.UNSUPPORTED_URL,
                f"unsupported WeChat article URL: {url}",
                retryable=False,
            )

        try:
            response = self._session.get(
                url,
                timeout=self._timeout,
                allow_redirects=True,
                headers=self._headers,
            )
        except requests.Timeout as exc:
            raise ArticleFetchError(
                FetchFailureType.TIMEOUT,
                f"WeChat article request timed out: {exc}",
                retryable=True,
            ) from exc
        except requests.ConnectionError as exc:
            raise ArticleFetchError(
                FetchFailureType.NETWORK,
                f"WeChat article connection failed: {exc}",
                retryable=True,
            ) from exc
        except requests.RequestException as exc:
            raise ArticleFetchError(
                FetchFailureType.NETWORK,
                f"WeChat article request failed: {exc}",
                retryable=True,
            ) from exc

        _raise_for_status(response.status_code)

        if not response.encoding or response.encoding.lower() == "iso-8859-1":
            response.encoding = response.apparent_encoding or "utf-8"

        return self.parse(url, response.text)

    @staticmethod
    def parse(url: str, html: str) -> ArticleContent:
        soup = BeautifulSoup(html, "lxml")
        abnormal_hint = _detect_abnormal_page(soup)
        if abnormal_hint:
            raise ArticleFetchError(
                FetchFailureType.ABNORMAL_PAGE,
                f"WeChat returned abnormal page: {abnormal_hint}",
                retryable=True,
            )

        if not _has_article_markers(soup):
            raise ArticleFetchError(
                FetchFailureType.PARSE_ERROR,
                "WeChat returned a page without article DOM markers",
                retryable=False,
            )

        title = _first_text(soup, ["#activity-name", "h1.rich_media_title", ".rich_media_title"])
        account = _first_text(soup, ["#js_name", ".rich_media_meta_nickname", "#profileBt .profile_nickname"])
        body = soup.select_one("#js_content") or soup.select_one(".rich_media_content")

        if body is None:
            raise ArticleFetchError(
                FetchFailureType.PARSE_ERROR,
                "article body not found",
                retryable=False,
            )

        clean = BeautifulSoup(str(body), "lxml")
        content = clean.select_one("#js_content") or clean.select_one(".rich_media_content") or clean

        for node in content.select("script, style, noscript, svg"):
            node.decompose()

        image_urls: list[str] = []
        for img in content.find_all("img"):
            src = (img.get("data-src") or img.get("src") or img.get("data-original") or "").strip()
            if src and src not in image_urls:
                image_urls.append(src)

        text = _normalize_text(content.get_text("\n", strip=True))
        if not text:
            raise ArticleFetchError(
                FetchFailureType.PARSE_ERROR,
                "article body is empty",
                retryable=False,
            )

        return ArticleContent(
            url=url,
            title=title or None,
            account=account or None,
            text=text,
            raw_html=html,
            article_html=str(content),
            image_urls=image_urls,
        )


def _raise_for_status(status_code: int) -> None:
    if status_code < 400:
        return

    if status_code in {404, 410}:
        raise ArticleFetchError(
            FetchFailureType.NOT_FOUND,
            f"WeChat article returned HTTP {status_code}",
            retryable=False,
        )

    if status_code == 429:
        raise ArticleFetchError(
            FetchFailureType.RATE_LIMITED,
            "WeChat article returned HTTP 429",
            retryable=True,
        )

    if status_code in {403, 408, 425}:
        raise ArticleFetchError(
            FetchFailureType.HTTP_RETRYABLE,
            f"WeChat article returned HTTP {status_code}",
            retryable=True,
        )

    if 500 <= status_code <= 599:
        raise ArticleFetchError(
            FetchFailureType.HTTP_RETRYABLE,
            f"WeChat article returned HTTP {status_code}",
            retryable=True,
        )

    raise ArticleFetchError(
        FetchFailureType.HTTP_PERMANENT,
        f"WeChat article returned HTTP {status_code}",
        retryable=False,
    )


def _is_weixin_url(url: str) -> bool:
    parsed = urlparse(url)
    return parsed.scheme in {"http", "https"} and parsed.hostname == "mp.weixin.qq.com"


def _normalize_text(value: str) -> str:
    value = value.replace("\xa0", " ")
    value = re.sub(r"[ \t]+", " ", value)
    value = re.sub(r"\n[ \t]+", "\n", value)
    value = re.sub(r"\n{3,}", "\n\n", value)
    return value.strip()


def _first_text(soup: BeautifulSoup, selectors: list[str]) -> str:
    for selector in selectors:
        node = soup.select_one(selector)
        if node:
            text = _normalize_text(node.get_text(" ", strip=True))
            if text:
                return text
    return ""


def _detect_abnormal_page(soup: BeautifulSoup) -> str | None:
    visible = _normalize_text(soup.get_text(" ", strip=True))[:8000]
    for hint in (
        "环境异常",
        "访问过于频繁",
        "安全验证",
        "请输入验证码",
        "当前环境异常",
        "网络环境存在风险",
    ):
        if hint in visible:
            return hint
    return None


def _has_article_markers(soup: BeautifulSoup) -> bool:
    return bool(
        soup.select_one("#js_content")
        or soup.select_one(".rich_media_content")
        or soup.select_one("#activity-name")
        or soup.select_one("h1.rich_media_title")
    )
