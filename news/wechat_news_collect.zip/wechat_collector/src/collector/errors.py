from __future__ import annotations

from enum import StrEnum


class FetchFailureType(StrEnum):
    UNSUPPORTED_URL = "UNSUPPORTED_URL"
    TIMEOUT = "TIMEOUT"
    NETWORK = "NETWORK"
    RATE_LIMITED = "RATE_LIMITED"
    HTTP_RETRYABLE = "HTTP_RETRYABLE"
    HTTP_PERMANENT = "HTTP_PERMANENT"
    NOT_FOUND = "NOT_FOUND"
    ABNORMAL_PAGE = "ABNORMAL_PAGE"
    PARSE_ERROR = "PARSE_ERROR"
    UNKNOWN = "UNKNOWN"


class ArticleFetchError(RuntimeError):
    """Fetcher-neutral failure contract consumed by ArticleService."""

    def __init__(
        self,
        failure_type: FetchFailureType,
        message: str,
        *,
        retryable: bool,
    ):
        super().__init__(message)
        self.failure_type = failure_type
        self.retryable = retryable
