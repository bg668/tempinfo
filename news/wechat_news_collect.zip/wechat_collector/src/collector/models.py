from __future__ import annotations

from datetime import datetime, timezone
from enum import StrEnum

from pydantic import BaseModel, Field


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class FetchStatus(StrEnum):
    DISCOVERED = "DISCOVERED"
    NOT_TARGET = "NOT_TARGET"
    PENDING = "PENDING"
    RETRY_PENDING = "RETRY_PENDING"
    FETCHED = "FETCHED"
    FETCH_FAILED = "FETCH_FAILED"


class FeedItem(BaseModel):
    source: str
    source_id: str | None = None
    account: str
    title: str
    url: str
    published_at: datetime | None = None
    discovered_at: datetime = Field(default_factory=utc_now)


class ArticleContent(BaseModel):
    url: str
    title: str | None = None
    account: str | None = None
    published_at: datetime | None = None
    text: str
    raw_html: str
    article_html: str
    image_urls: list[str] = Field(default_factory=list)
    fetched_at: datetime = Field(default_factory=utc_now)


class StoredArticleArtifacts(BaseModel):
    directory: str
    raw_html_path: str
    article_html_path: str
    text_path: str
    image_urls_path: str


class PendingArticle(BaseModel):
    id: int
    stable_id: str
    url: str
    account: str
    title: str
    published_at: datetime | None = None
    fetch_attempts: int = 0


class PollStats(BaseModel):
    source: str
    # Number of items returned by the source in this cycle.
    item_count: int = 0
    # Existing URLs ignored by deterministic URL de-duplication.
    duplicate_count: int = 0
    # URLs first discovered in this cycle.
    new_item_count: int = 0
    # Newly discovered items selected for article fetching in this cycle.
    selected_count: int = 0
    # Total items in the current feed matching the target policy. Kept for audit
    # compatibility; operational logs intentionally do not display it.
    target_count: int = 0
    fetched_count: int = 0
    fetch_failed_count: int = 0
    retry_scheduled_count: int = 0
    terminal_failed_count: int = 0
    newest_published_at: datetime | None = None
    oldest_published_at: datetime | None = None
