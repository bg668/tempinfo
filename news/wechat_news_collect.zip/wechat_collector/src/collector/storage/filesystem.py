from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Sequence
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from ..models import StoredArticleArtifacts


class FileSystemStorage:
    def __init__(self, root: str | Path, date_timezone: str = "Asia/Singapore"):
        self._root = Path(root)
        try:
            self._timezone = ZoneInfo(date_timezone)
        except ZoneInfoNotFoundError as exc:
            raise ValueError(f"unknown storage timezone: {date_timezone}") from exc

    def _article_dir(self, stable_id: str, fetched_at: datetime) -> Path:
        if fetched_at.tzinfo is None:
            raise ValueError("fetched_at must be timezone-aware")
        date_dir = fetched_at.astimezone(self._timezone).strftime("%Y%m%d")
        article_dir = self._root / date_dir / stable_id
        article_dir.mkdir(parents=True, exist_ok=True)
        return article_dir

    def save_article(
        self,
        stable_id: str,
        fetched_at: datetime,
        *,
        raw_html: str,
        article_html: str,
        text: str,
        image_urls: Sequence[str],
    ) -> StoredArticleArtifacts:
        article_dir = self._article_dir(stable_id, fetched_at)

        raw_html_path = article_dir / "raw.html"
        article_html_path = article_dir / "article.html"
        text_path = article_dir / "article.txt"
        image_urls_path = article_dir / "image_urls.txt"

        raw_html_path.write_text(raw_html, encoding="utf-8", errors="replace")
        article_html_path.write_text(article_html, encoding="utf-8", errors="replace")
        text_path.write_text(text, encoding="utf-8", errors="replace")
        image_urls_path.write_text("\n".join(image_urls), encoding="utf-8")

        return StoredArticleArtifacts(
            directory=str(article_dir.resolve()),
            raw_html_path=str(raw_html_path.resolve()),
            article_html_path=str(article_html_path.resolve()),
            text_path=str(text_path.resolve()),
            image_urls_path=str(image_urls_path.resolve()),
        )
