from __future__ import annotations

from datetime import datetime
from typing import Protocol, Sequence

from .models import ArticleContent, FeedItem, PendingArticle, StoredArticleArtifacts


class FeedSource(Protocol):
    name: str

    def fetch(self) -> list[FeedItem]: ...


class ArticleFetcher(Protocol):
    def fetch(self, url: str) -> ArticleContent: ...


class ArticleRepository(Protocol):
    def initialize(self) -> None: ...

    def save_discovered(self, item: FeedItem) -> bool: ...

    def mark_target(self, url: str, matched: bool) -> None: ...

    def list_pending(self, limit: int | None = None) -> list[PendingArticle]: ...

    def mark_fetch_attempt(self, article_id: int) -> None: ...

    def save_content(
        self,
        article_id: int,
        content: ArticleContent,
        artifacts: StoredArticleArtifacts,
    ) -> None: ...

    def mark_fetch_failed(
        self,
        article_id: int,
        *,
        failure_type: str,
        error: str,
        retryable: bool,
        schedule_retry: bool,
    ) -> None: ...

    def retry_failed(self, stable_id: str) -> bool: ...

    def start_poll_run(self, source: str) -> int: ...

    def finish_poll_run(
        self,
        run_id: int,
        *,
        success: bool,
        item_count: int,
        duplicate_count: int,
        new_item_count: int,
        selected_count: int,
        target_count: int,
        fetched_count: int,
        fetch_failed_count: int,
        retry_scheduled_count: int,
        terminal_failed_count: int,
        newest_published_at: datetime | None,
        oldest_published_at: datetime | None,
        error: str | None = None,
    ) -> None: ...


class RawStorage(Protocol):
    def save_article(
        self,
        stable_id: str,
        fetched_at: datetime,
        *,
        raw_html: str,
        article_html: str,
        text: str,
        image_urls: Sequence[str],
    ) -> StoredArticleArtifacts: ...


class TargetMatcherPort(Protocol):
    def match(self, account: str) -> bool: ...

    def configured_accounts(self) -> Sequence[str]: ...
