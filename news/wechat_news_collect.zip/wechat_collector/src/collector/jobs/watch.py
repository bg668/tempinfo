from __future__ import annotations

import time
from datetime import datetime
from collections.abc import Callable, Iterator

from pydantic import BaseModel, Field

from ..models import PollStats, utc_now
from .poll import PollJob


class WatchCycle(BaseModel):
    cycle: int
    checked_at: datetime = Field(default_factory=utc_now)
    interval_seconds: float
    rss_updated: bool = False
    stats: PollStats | None = None
    error: str | None = None


class WatchJob:
    """Periodically executes an existing PollJob without changing one-shot poll semantics."""

    def __init__(
        self,
        poll_job: PollJob,
        interval_seconds: float,
        sleep: Callable[[float], None] = time.sleep,
    ):
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be > 0")
        self._poll_job = poll_job
        self._interval_seconds = float(interval_seconds)
        self._sleep = sleep

    @property
    def interval_seconds(self) -> float:
        return self._interval_seconds

    def cycles(
        self,
        fetch_limit: int | None = None,
        max_cycles: int | None = None,
    ) -> Iterator[WatchCycle]:
        cycle = 0

        while True:
            cycle += 1
            try:
                stats = self._poll_job.run(fetch_limit=fetch_limit)
                event = WatchCycle(
                    cycle=cycle,
                    interval_seconds=self._interval_seconds,
                    rss_updated=stats.new_item_count > 0,
                    stats=stats,
                )
            except Exception as exc:
                # PollJob has already persisted the failed poll_run. A transient
                # source/network failure must not terminate long-running watch mode.
                event = WatchCycle(
                    cycle=cycle,
                    interval_seconds=self._interval_seconds,
                    error=str(exc),
                )

            yield event

            if max_cycles is not None and cycle >= max_cycles:
                return

            self._sleep(self._interval_seconds)
