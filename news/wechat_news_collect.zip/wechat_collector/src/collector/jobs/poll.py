from __future__ import annotations

from ..models import PollStats
from ..ports import ArticleRepository
from ..services.article import ArticleService
from ..services.discovery import DiscoveryService


class PollJob:
    def __init__(
        self,
        source_name: str,
        discovery: DiscoveryService,
        articles: ArticleService,
        repository: ArticleRepository,
    ):
        self._source_name = source_name
        self._discovery = discovery
        self._articles = articles
        self._repository = repository

    def run(self, fetch_limit: int | None = None) -> PollStats:
        run_id = self._repository.start_poll_run(self._source_name)
        stats = PollStats(source=self._source_name)

        try:
            discovered = self._discovery.run()
            stats.item_count = len(discovered.items)
            stats.duplicate_count = discovered.duplicate_count
            stats.new_item_count = discovered.new_item_count
            stats.selected_count = discovered.selected_count
            stats.target_count = discovered.target_count

            dates = [item.published_at for item in discovered.items if item.published_at is not None]
            if dates:
                stats.newest_published_at = max(dates)
                stats.oldest_published_at = min(dates)

            fetched = self._articles.fetch_pending(limit=fetch_limit)
            stats.fetched_count = fetched.fetched_count
            stats.fetch_failed_count = fetched.failed_count
            stats.retry_scheduled_count = fetched.retry_scheduled_count
            stats.terminal_failed_count = fetched.terminal_failed_count

            self._repository.finish_poll_run(
                run_id,
                success=True,
                item_count=stats.item_count,
                duplicate_count=stats.duplicate_count,
                new_item_count=stats.new_item_count,
                selected_count=stats.selected_count,
                target_count=stats.target_count,
                fetched_count=stats.fetched_count,
                fetch_failed_count=stats.fetch_failed_count,
                retry_scheduled_count=stats.retry_scheduled_count,
                terminal_failed_count=stats.terminal_failed_count,
                newest_published_at=stats.newest_published_at,
                oldest_published_at=stats.oldest_published_at,
            )
            return stats

        except Exception as exc:
            self._repository.finish_poll_run(
                run_id,
                success=False,
                item_count=stats.item_count,
                duplicate_count=stats.duplicate_count,
                new_item_count=stats.new_item_count,
                selected_count=stats.selected_count,
                target_count=stats.target_count,
                fetched_count=stats.fetched_count,
                fetch_failed_count=stats.fetch_failed_count,
                retry_scheduled_count=stats.retry_scheduled_count,
                terminal_failed_count=stats.terminal_failed_count,
                newest_published_at=stats.newest_published_at,
                oldest_published_at=stats.oldest_published_at,
                error=str(exc),
            )
            raise
