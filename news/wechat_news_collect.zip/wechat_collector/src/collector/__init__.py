"""wechat_collector package."""

__version__ = "0.1.0"
