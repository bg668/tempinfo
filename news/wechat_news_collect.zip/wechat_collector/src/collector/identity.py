from __future__ import annotations

import hashlib


def stable_article_id(url: str) -> str:
    """Return a deterministic 128-bit article id derived from the canonical URL string."""
    normalized = url.strip()
    if not normalized:
        raise ValueError("article URL must not be empty")
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:32]
