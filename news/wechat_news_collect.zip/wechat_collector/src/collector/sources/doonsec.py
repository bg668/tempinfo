from __future__ import annotations

from datetime import datetime
from email.utils import parsedate_to_datetime

import requests
from bs4 import BeautifulSoup

from ..models import FeedItem


class DoonSecSourceError(RuntimeError):
    pass


class DoonSecSource:
    name = "doonsec"

    def __init__(self, rss_url: str, timeout_seconds: float = 15.0, session: requests.Session | None = None):
        self._rss_url = rss_url
        self._timeout = timeout_seconds
        self._session = session or requests.Session()

    def fetch(self) -> list[FeedItem]:
        try:
            response = self._session.get(
                self._rss_url,
                timeout=self._timeout,
                headers={"User-Agent": "wechat-collector/0.1"},
            )
            response.raise_for_status()
        except requests.RequestException as exc:
            raise DoonSecSourceError(f"DoonSec RSS request failed: {exc}") from exc

        return self.parse(response.text)

    @staticmethod
    def parse(xml_text: str) -> list[FeedItem]:
        soup = BeautifulSoup(xml_text, "xml")
        items: list[FeedItem] = []

        for node in soup.find_all("item"):
            title = _text(node, "title")
            url = _text(node, "link")
            account = _text(node, "author") or _text(node, "dc:creator") or _text(node, "creator")
            source_id = _text(node, "guid") or None
            published_at = _parse_pub_date(_text(node, "pubDate"))

            if not title or not url or not account:
                continue

            items.append(
                FeedItem(
                    source="doonsec",
                    source_id=source_id,
                    account=account,
                    title=title,
                    url=url,
                    published_at=published_at,
                )
            )

        return items


def _text(node, tag: str) -> str:
    found = node.find(tag)
    if not found:
        return ""
    return " ".join(found.get_text(" ", strip=True).split())


def _parse_pub_date(value: str) -> datetime | None:
    if not value:
        return None

    # Current DoonSec rss.xml uses ISO 8601 (for example
    # 2026-08-17T08:30:00), while older feeds may use RFC 2822.
    # Support both without assuming a timezone when the source omits one.
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        pass

    try:
        return parsedate_to_datetime(value)
    except (TypeError, ValueError, OverflowError):
        return None
