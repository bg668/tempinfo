from __future__ import annotations

import sys

from collector.cli import main as collector_main


if __name__ == "__main__":
    sys.exit(collector_main())
