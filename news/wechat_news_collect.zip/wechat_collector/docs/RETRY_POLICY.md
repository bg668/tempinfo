# 正文抓取失败与重试策略

## 状态机

```text
PENDING
  ├─ 成功 → FETCHED
  ├─ 可重试失败 → RETRY_PENDING
  │                 ├─ 成功 → FETCHED
  │                 └─ 再失败 → FETCH_FAILED
  └─ 不可重试失败 → FETCH_FAILED
```

`FETCH_FAILED` 为终态，`poll/watch` 不会再次选择。默认 `weixin.max_retries: 1`，含义是首次失败后最多自动再尝试一次。

## 失败类型

| 类型 | 自动重试 |
|---|---|
| TIMEOUT / NETWORK | 1 次 |
| RATE_LIMITED (429) | 1 次 |
| HTTP_RETRYABLE (403/408/425/5xx) | 1 次 |
| ABNORMAL_PAGE（微信风控/验证页） | 1 次 |
| NOT_FOUND (404/410) | 否 |
| HTTP_PERMANENT | 否 |
| UNSUPPORTED_URL | 否 |
| PARSE_ERROR | 否 |
| UNKNOWN | 否 |

## 人工重新入队

代码或解析规则修复后，通过稳定 article_id 显式恢复：

```powershell
uv run .\src\main.py retry --article-id <stable_id>
```

该操作只允许目标文章且当前状态为 `FETCH_FAILED`；成功后重置为 `PENDING`、`fetch_attempts=0` 并清空上次错误。
