# MVP 设计实现核对

| 设计要求 | 实现位置 | 验证 |
|---|---|---|
| 核心流程只依赖统一契约 | `models.py`, `ports.py` | 服务层只引用模型/端口 |
| DoonSec 只负责 RSS → FeedItem | `sources/doonsec.py` | `tests/test_doonsec.py` |
| 微信抓取只负责 URL → ArticleContent | `fetchers/weixin.py` | `tests/test_weixin.py` |
| 目标公众号独立于来源 | `targets.py`, `config/targets.yaml` | `tests/test_targets.py` |
| 全量/白名单采集由显式配置控制 | `collect_all`, `TargetMatcher` | `tests/test_targets.py`, `tests/test_services.py` |
| 所有发现先落库，避免抓取失败丢文章 | `services/discovery.py`, `repositories/sqlite.py` | `tests/test_repository.py` |
| URL 唯一去重 | `feed_items.url UNIQUE` | `tests/test_repository.py` |
| article_id 跨数据库稳定 | `identity.py`, `feed_items.stable_id` | `tests/test_storage.py`, `tests/test_repository.py` |
| 文件按获取日期/stable_id 组织 | `storage/filesystem.py` | `tests/test_storage.py` |
| raw/article HTML、正文文本、图片 URL 全部留存 | `fetchers/weixin.py`, `storage/filesystem.py` | `tests/test_weixin.py`, `tests/test_services.py` |
| 旧 v3 SQLite 自动迁移 | `repositories/sqlite.py::_migrate` | `tests/test_repository.py` |
| 非目标与目标/重试/终态失败状态明确 | `NOT_TARGET` / `PENDING` / `RETRY_PENDING` / `FETCH_FAILED` | `repositories/sqlite.py` |
| 正文成功后独立存储 | `article_contents` | `tests/test_repository.py` |
| 文件产物不塞数据库，只保存路径 | `storage/filesystem.py` | `tests/test_storage.py`, `tests/test_services.py` |
| 抓取失败按类型重试且有限次 | `errors.py`, `RETRY_PENDING/FETCH_FAILED`, `max_retries=1` | `tests/test_retry_policy.py`, `tests/test_weixin_failures.py` |
| 终态失败不会污染后续 watch 队列 | `list_pending()` 只取 `PENDING/RETRY_PENDING` | `tests/test_retry_policy.py` |
| 失败可显式人工重新入队 | `retry_failed()`, `main.py retry --article-id` | `tests/test_retry_policy.py` |
| 每轮采集可审计 | `poll_runs` | `jobs/poll.py` |
| 业务层不直接碰 requests/BS/sqlite3 | `services/*` | 代码依赖检查 |
| 构造函数注入，不引入 DI 框架 | `cli.py` | 入口统一装配 |
| 单次轮询与周期调度职责分离 | `jobs/poll.py`, `jobs/watch.py` | `tests/test_watch_job.py` |
| watch 启动立即拉取、默认 1 小时间隔 | `jobs/watch.py`, `config.py` | `tests/test_watch_job.py`, `tests/test_config_watch.py` |
| 运行统计按 received/duplicate/new/selected/fetched/failed 输出 | `models.py`, `services/discovery.py`, `cli.py` | `tests/test_services.py`, `tests/test_cli_output.py` |
| Windows + uv 可运行 | `pyproject.toml`, `README.md` | 提供 `uv run collector ...` |
| Agent 筛选/评分与采集解耦 | Collector 无 Agent 模块 | 明确 MVP 非目标 |

## 当前刻意不做

- `watch` 提供轻量常驻轮询；生产环境仍可选择 Windows Task Scheduler/cron 调用单次 `poll`，两者互不依赖。
- 不做复杂 IoC/Clean Architecture 层级：当前变化边界仅来源、抓取器、仓库、文件存储。
- 不下载正文图片二进制：当前保存 `image_urls.txt` 和数据库中的图片 URL，确认需要离线图片后再增加图片下载器。
- 不做 Cookie/Selenium 降级：只有实测普通 HTTP 出现稳定失败后再增加第二抓取器。
- 不把 Agent 评分、摘要、报告生成放进 Collector。


## 周期 RSS 探测

- `PollJob` 仍保持单次执行语义。
- `WatchJob` 启动后立即执行一次 `PollJob`，随后按 `watch.interval_seconds` 周期复用；默认间隔 3600 秒。
- RSS 是否更新使用 `feed_items.url UNIQUE` + `new_item_count` 判断，不依赖易变化的 RSS `lastBuildDate`。
- 单轮请求/解析失败由 `PollJob` 写入 `poll_runs`，`WatchJob` 记录错误后继续下一周期。
- `Ctrl+C` 在 CLI 层安全退出，不吞掉 `KeyboardInterrupt`。
