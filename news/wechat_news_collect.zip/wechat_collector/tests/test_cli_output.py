from datetime import datetime

from collector.cli import _format_stats
from collector.models import PollStats


def test_format_stats_uses_operational_cycle_counts():
    stats = PollStats(
        source="doonsec",
        item_count=197,
        duplicate_count=194,
        new_item_count=3,
        selected_count=2,
        fetched_count=2,
        fetch_failed_count=1,
        retry_scheduled_count=1,
        terminal_failed_count=0,
        newest_published_at=datetime.fromisoformat("2026-08-17T08:30:00"),
    )

    text = _format_stats(stats)

    assert "received=197" in text
    assert "duplicate=194" in text
    assert "new=3" in text
    assert "selected=2" in text
    assert "fetched=2" in text
    assert "failed=1" in text
    assert "retry=1" in text
    assert "terminal_failed=0" in text
    assert "newest=2026-08-17T08:30:00" in text
    assert "target=" not in text
