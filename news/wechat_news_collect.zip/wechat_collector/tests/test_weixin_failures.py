import pytest

from collector.errors import ArticleFetchError, FetchFailureType
from collector.fetchers.weixin import WeixinArticleFetcher


def test_abnormal_weixin_page_is_retryable_once_by_policy():
    html = "<html><body>当前环境异常，请稍后再试</body></html>"
    with pytest.raises(ArticleFetchError) as caught:
        WeixinArticleFetcher.parse("https://mp.weixin.qq.com/s/a", html)
    assert caught.value.failure_type == FetchFailureType.ABNORMAL_PAGE
    assert caught.value.retryable is True


def test_page_without_article_dom_is_non_retryable_parse_failure():
    html = "<html><body>ordinary page</body></html>"
    with pytest.raises(ArticleFetchError) as caught:
        WeixinArticleFetcher.parse("https://mp.weixin.qq.com/s/a", html)
    assert caught.value.failure_type == FetchFailureType.PARSE_ERROR
    assert caught.value.retryable is False
