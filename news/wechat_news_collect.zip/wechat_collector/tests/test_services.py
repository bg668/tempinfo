from datetime import datetime, timezone
from pathlib import Path

from collector.config import AccountTarget
from collector.fetchers.weixin import WeixinArticleFetcher
from collector.identity import stable_article_id
from collector.repositories.sqlite import SQLiteArticleRepository
from collector.services.article import ArticleService
from collector.services.discovery import DiscoveryService
from collector.sources.doonsec import DoonSecSource
from collector.storage.filesystem import FileSystemStorage
from collector.targets import TargetMatcher


FETCHED_AT = datetime(2026, 8, 14, 7, 30, tzinfo=timezone.utc)


class FixtureSource:
    name = "fixture"

    def fetch(self):
        xml = Path("tests/fixtures/doonsec_rss.xml").read_text(encoding="utf-8")
        return DoonSecSource.parse(xml)


class FixtureFetcher:
    def fetch(self, url):
        html = Path("tests/fixtures/weixin_article.html").read_text(encoding="utf-8")
        return WeixinArticleFetcher.parse(url, html).model_copy(update={"fetched_at": FETCHED_AT})


def test_services_end_to_end(tmp_path):
    repo = SQLiteArticleRepository(tmp_path / "collector.db")
    repo.initialize()
    matcher = TargetMatcher([AccountTarget(name="安全内参")])

    discovery = DiscoveryService(FixtureSource(), repo, matcher)
    d = discovery.run()
    assert d.new_item_count == 2
    assert d.duplicate_count == 0
    assert d.selected_count == 1
    assert d.target_count == 1

    articles = ArticleService(FixtureFetcher(), repo, FileSystemStorage(tmp_path / "articles"))
    f = articles.fetch_pending()
    assert f.fetched_count == 1
    assert f.failed_count == 0

    article_url = "https://mp.weixin.qq.com/s/test-a"
    article_dir = tmp_path / "articles" / "20260814" / stable_article_id(article_url)
    assert (article_dir / "raw.html").exists()
    assert (article_dir / "article.html").exists()
    assert (article_dir / "article.txt").exists()
    assert (article_dir / "image_urls.txt").read_text(encoding="utf-8") == "https://example.com/a.jpg"


def test_services_collect_all_fetches_every_feed_item(tmp_path):
    repo = SQLiteArticleRepository(tmp_path / "collector.db")
    repo.initialize()
    matcher = TargetMatcher([], collect_all=True)

    discovery = DiscoveryService(FixtureSource(), repo, matcher)
    d = discovery.run()
    assert d.new_item_count == 2
    assert d.duplicate_count == 0
    assert d.selected_count == 2
    assert d.target_count == 2

    articles = ArticleService(FixtureFetcher(), repo, FileSystemStorage(tmp_path / "articles"))
    f = articles.fetch_pending()
    assert f.fetched_count == 2
    assert f.failed_count == 0


def test_discovery_second_run_reports_duplicates_not_new(tmp_path):
    repo = SQLiteArticleRepository(tmp_path / "collector.db")
    repo.initialize()
    matcher = TargetMatcher([], collect_all=True)
    discovery = DiscoveryService(FixtureSource(), repo, matcher)

    first = discovery.run()
    second = discovery.run()

    assert first.new_item_count == 2
    assert first.duplicate_count == 0
    assert first.selected_count == 2
    assert second.new_item_count == 0
    assert second.duplicate_count == 2
    assert second.selected_count == 0
