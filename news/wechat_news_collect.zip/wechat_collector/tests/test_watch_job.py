from collector.jobs.watch import WatchJob
from collector.models import PollStats


class FakePollJob:
    def __init__(self):
        self.calls = 0

    def run(self, fetch_limit=None):
        self.calls += 1
        if self.calls == 2:
            raise RuntimeError("temporary rss failure")
        return PollStats(
            source="fixture",
            item_count=2,
            duplicate_count=1 if self.calls == 1 else 2,
            new_item_count=1 if self.calls == 1 else 0,
            selected_count=1 if self.calls == 1 else 0,
            fetched_count=1 if self.calls == 1 else 0,
        )


def test_watch_job_reuses_poll_and_survives_transient_error():
    sleeps = []
    poll = FakePollJob()
    watch = WatchJob(poll, interval_seconds=12, sleep=sleeps.append)

    events = list(watch.cycles(fetch_limit=5, max_cycles=3))

    assert len(events) == 3
    assert events[0].rss_updated is True
    assert events[0].stats is not None
    assert events[1].error == "temporary rss failure"
    assert events[2].rss_updated is False
    assert sleeps == [12.0, 12.0]


def test_watch_runs_first_poll_before_sleeping():
    sleeps = []
    poll = FakePollJob()
    watch = WatchJob(poll, interval_seconds=3600, sleep=sleeps.append)

    events = list(watch.cycles(max_cycles=1))

    assert len(events) == 1
    assert poll.calls == 1
    assert sleeps == []
