import pytest
from pydantic import ValidationError

from collector.config import AppConfig


def test_watch_interval_defaults_to_one_hour():
    cfg = AppConfig()
    assert cfg.watch.interval_seconds == 3600.0


def test_watch_interval_must_be_positive():
    with pytest.raises(ValidationError):
        AppConfig.model_validate({"watch": {"interval_seconds": 0}})


def test_weixin_max_retries_defaults_to_one():
    cfg = AppConfig()
    assert cfg.weixin.max_retries == 1


def test_weixin_max_retries_cannot_be_negative():
    with pytest.raises(ValidationError):
        AppConfig.model_validate({"weixin": {"max_retries": -1}})
