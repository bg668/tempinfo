from datetime import datetime, timezone

from collector.identity import stable_article_id
from collector.storage.filesystem import FileSystemStorage


def test_stable_article_id_is_deterministic_and_url_based():
    url = "https://mp.weixin.qq.com/s/example"
    first = stable_article_id(url)
    second = stable_article_id(url)
    assert first == second
    assert len(first) == 32
    assert first != stable_article_id(url + "-other")


def test_storage_uses_fetch_date_and_stable_id(tmp_path):
    storage = FileSystemStorage(tmp_path / "articles", "Asia/Singapore")
    fetched_at = datetime(2026, 8, 14, 16, 30, tzinfo=timezone.utc)
    stable_id = stable_article_id("https://mp.weixin.qq.com/s/example")

    artifacts = storage.save_article(
        stable_id,
        fetched_at,
        raw_html="<html>raw</html>",
        article_html='<div id="js_content">body</div>',
        text="body",
        image_urls=["https://img.example/a.jpg", "https://img.example/b.jpg"],
    )

    # 16:30 UTC == 00:30 next day in Asia/Singapore.
    expected = tmp_path / "articles" / "20260815" / stable_id
    assert expected.exists()
    assert expected.as_posix() in artifacts.directory.replace("\\", "/")
    assert (expected / "raw.html").read_text(encoding="utf-8") == "<html>raw</html>"
    assert "js_content" in (expected / "article.html").read_text(encoding="utf-8")
    assert (expected / "article.txt").read_text(encoding="utf-8") == "body"
    assert (expected / "image_urls.txt").read_text(encoding="utf-8").splitlines() == [
        "https://img.example/a.jpg",
        "https://img.example/b.jpg",
    ]
