from pathlib import Path

from collector.fetchers.weixin import WeixinArticleFetcher


def test_parse_weixin_fixture():
    html = Path("tests/fixtures/weixin_article.html").read_text(encoding="utf-8")
    article = WeixinArticleFetcher.parse("https://mp.weixin.qq.com/s/test-a", html)
    assert article.title == "测试微信文章"
    assert article.account == "安全内参"
    assert "第一段正文" in article.text
    assert article.image_urls == ["https://example.com/a.jpg"]
    assert 'id="js_content"' in article.article_html
    assert "第一段正文" in article.article_html
