from collector.config import AccountTarget
from collector.targets import TargetMatcher


def test_target_match_name_and_alias():
    matcher = TargetMatcher([
        AccountTarget(name="奇安信病毒响应中心", aliases=["QAX病毒响应中心"])
    ])
    assert matcher.match("奇安信病毒响应中心")
    assert matcher.match("QAX病毒响应中心")
    assert not matcher.match("其他公众号")


def test_collect_all_matches_any_account():
    matcher = TargetMatcher([], collect_all=True)
    assert matcher.match("安全内参")
    assert matcher.match("任意公众号")
    assert matcher.match("")


def test_empty_targets_without_collect_all_matches_nothing():
    matcher = TargetMatcher([], collect_all=False)
    assert not matcher.match("安全内参")
