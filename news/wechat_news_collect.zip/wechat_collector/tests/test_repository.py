import json
import sqlite3
from datetime import datetime, timezone

from collector.identity import stable_article_id
from collector.models import ArticleContent, FeedItem, StoredArticleArtifacts
from collector.repositories.sqlite import SQLiteArticleRepository


def test_repository_discovery_and_content(tmp_path):
    repo = SQLiteArticleRepository(tmp_path / "collector.db")
    repo.initialize()

    item = FeedItem(
        source="doonsec",
        account="安全内参",
        title="测试",
        url="https://mp.weixin.qq.com/s/test",
        published_at=datetime.now(timezone.utc),
    )
    assert repo.save_discovered(item) is True
    assert repo.save_discovered(item) is False

    repo.mark_target(item.url, True)
    pending = repo.list_pending()
    assert len(pending) == 1
    assert pending[0].stable_id == stable_article_id(item.url)

    content = ArticleContent(
        url=item.url,
        title=item.title,
        account=item.account,
        text="正文",
        raw_html="<html>正文</html>",
        article_html="<div>正文</div>",
        image_urls=["https://example.com/a.jpg"],
    )
    artifacts = StoredArticleArtifacts(
        directory="dir",
        raw_html_path="raw.html",
        article_html_path="article.html",
        text_path="article.txt",
        image_urls_path="image_urls.txt",
    )
    repo.save_content(pending[0].id, content, artifacts)
    assert repo.list_pending() == []

    conn = sqlite3.connect(tmp_path / "collector.db")
    row = conn.execute(
        "SELECT article_html_path,text_path,image_urls_path,image_urls_json FROM article_contents"
    ).fetchone()
    conn.close()
    assert row[:3] == ("article.html", "article.txt", "image_urls.txt")
    assert json.loads(row[3]) == ["https://example.com/a.jpg"]


def test_removed_target_is_not_fetched(tmp_path):
    repo = SQLiteArticleRepository(tmp_path / "collector.db")
    repo.initialize()
    item = FeedItem(
        source="doonsec",
        account="安全内参",
        title="测试",
        url="https://mp.weixin.qq.com/s/removed",
    )
    repo.save_discovered(item)
    repo.mark_target(item.url, True)
    assert len(repo.list_pending()) == 1
    repo.mark_target(item.url, False)
    assert repo.list_pending() == []


def test_initialize_migrates_v3_database_and_backfills_stable_id(tmp_path):
    db = tmp_path / "collector.db"
    conn = sqlite3.connect(db)
    conn.executescript(
        """
        CREATE TABLE feed_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT NOT NULL,
            source_id TEXT,
            account TEXT NOT NULL,
            title TEXT NOT NULL,
            url TEXT NOT NULL UNIQUE,
            published_at TEXT,
            discovered_at TEXT NOT NULL,
            is_target INTEGER,
            fetch_status TEXT NOT NULL DEFAULT 'DISCOVERED',
            fetch_attempts INTEGER NOT NULL DEFAULT 0,
            last_error TEXT
        );
        CREATE TABLE article_contents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            article_id INTEGER NOT NULL UNIQUE,
            url TEXT NOT NULL UNIQUE,
            title TEXT,
            account TEXT,
            published_at TEXT,
            content TEXT NOT NULL,
            raw_html_path TEXT NOT NULL,
            fetched_at TEXT NOT NULL
        );
        CREATE TABLE poll_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT NOT NULL,
            started_at TEXT NOT NULL,
            finished_at TEXT,
            success INTEGER,
            item_count INTEGER NOT NULL DEFAULT 0,
            new_item_count INTEGER NOT NULL DEFAULT 0,
            target_count INTEGER NOT NULL DEFAULT 0,
            fetched_count INTEGER NOT NULL DEFAULT 0,
            fetch_failed_count INTEGER NOT NULL DEFAULT 0,
            newest_published_at TEXT,
            oldest_published_at TEXT,
            error TEXT
        );
        """
    )
    url = "https://mp.weixin.qq.com/s/legacy"
    conn.execute(
        "INSERT INTO feed_items(source,account,title,url,discovered_at) VALUES(?,?,?,?,?)",
        ("doonsec", "安全内参", "旧文章", url, datetime.now(timezone.utc).isoformat()),
    )
    conn.commit()
    conn.close()

    repo = SQLiteArticleRepository(db)
    repo.initialize()

    conn = sqlite3.connect(db)
    feed_cols = {row[1] for row in conn.execute("PRAGMA table_info(feed_items)")}
    content_cols = {row[1] for row in conn.execute("PRAGMA table_info(article_contents)")}
    poll_cols = {row[1] for row in conn.execute("PRAGMA table_info(poll_runs)")}
    stable_id = conn.execute("SELECT stable_id FROM feed_items WHERE url=?", (url,)).fetchone()[0]
    conn.close()

    assert "stable_id" in feed_cols
    assert {"article_html_path", "text_path", "image_urls_path", "image_urls_json"} <= content_cols
    assert {"duplicate_count", "selected_count"} <= poll_cols
    assert stable_id == stable_article_id(url)
