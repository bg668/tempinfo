import sqlite3
from pathlib import Path

from collector.config import AccountTarget
from collector.fetchers.weixin import WeixinArticleFetcher
from collector.jobs.poll import PollJob
from collector.repositories.sqlite import SQLiteArticleRepository
from collector.services.article import ArticleService
from collector.services.discovery import DiscoveryService
from collector.sources.doonsec import DoonSecSource
from collector.storage.filesystem import FileSystemStorage
from collector.targets import TargetMatcher


class FixtureSource:
    name = "fixture"

    def fetch(self):
        xml = Path("tests/fixtures/doonsec_rss.xml").read_text(encoding="utf-8")
        return DoonSecSource.parse(xml)


class FixtureFetcher:
    def fetch(self, url):
        html = Path("tests/fixtures/weixin_article.html").read_text(encoding="utf-8")
        return WeixinArticleFetcher.parse(url, html)


def test_poll_job_writes_run_audit(tmp_path):
    db = tmp_path / "collector.db"
    repo = SQLiteArticleRepository(db)
    repo.initialize()

    matcher = TargetMatcher([AccountTarget(name="安全内参")])
    discovery = DiscoveryService(FixtureSource(), repo, matcher)
    articles = ArticleService(FixtureFetcher(), repo, FileSystemStorage(tmp_path / "articles"))
    job = PollJob("fixture", discovery, articles, repo)

    stats = job.run()
    assert stats.item_count == 2
    assert stats.duplicate_count == 0
    assert stats.new_item_count == 2
    assert stats.selected_count == 1
    assert stats.target_count == 1
    assert stats.fetched_count == 1

    conn = sqlite3.connect(db)
    row = conn.execute(
        "SELECT success,item_count,duplicate_count,new_item_count,selected_count,target_count,fetched_count FROM poll_runs"
    ).fetchone()
    conn.close()
    assert row == (1, 2, 0, 2, 1, 1, 1)
