import sqlite3

from collector.errors import ArticleFetchError, FetchFailureType
from collector.models import FeedItem
from collector.repositories.sqlite import SQLiteArticleRepository
from collector.services.article import ArticleService
from collector.storage.filesystem import FileSystemStorage


class AlwaysRetryableFetcher:
    def __init__(self):
        self.calls = 0

    def fetch(self, url):
        self.calls += 1
        raise ArticleFetchError(
            FetchFailureType.TIMEOUT,
            "timeout",
            retryable=True,
        )


class PermanentFetcher:
    def __init__(self):
        self.calls = 0

    def fetch(self, url):
        self.calls += 1
        raise ArticleFetchError(
            FetchFailureType.NOT_FOUND,
            "not found",
            retryable=False,
        )


def _make_target(repo, url="https://mp.weixin.qq.com/s/retry"):
    item = FeedItem(source="doonsec", account="安全内参", title="测试", url=url)
    repo.save_discovered(item)
    repo.mark_target(url, True)
    return item


def _row(db, url):
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    row = conn.execute(
        "SELECT fetch_status,fetch_attempts,last_error_type,last_failure_retryable,stable_id "
        "FROM feed_items WHERE url=?",
        (url,),
    ).fetchone()
    conn.close()
    return row


def test_retryable_failure_is_retried_exactly_once(tmp_path):
    db = tmp_path / "collector.db"
    repo = SQLiteArticleRepository(db)
    repo.initialize()
    item = _make_target(repo)
    fetcher = AlwaysRetryableFetcher()
    service = ArticleService(fetcher, repo, FileSystemStorage(tmp_path / "articles"), max_retries=1)

    first = service.fetch_pending()
    assert first.failed_count == 1
    assert first.retry_scheduled_count == 1
    assert first.terminal_failed_count == 0
    row = _row(db, item.url)
    assert row["fetch_status"] == "RETRY_PENDING"
    assert row["fetch_attempts"] == 1
    assert row["last_error_type"] == "TIMEOUT"
    assert row["last_failure_retryable"] == 1

    second = service.fetch_pending()
    assert second.failed_count == 1
    assert second.retry_scheduled_count == 0
    assert second.terminal_failed_count == 1
    row = _row(db, item.url)
    assert row["fetch_status"] == "FETCH_FAILED"
    assert row["fetch_attempts"] == 2

    third = service.fetch_pending()
    assert third.failed_count == 0
    assert fetcher.calls == 2


def test_permanent_failure_is_terminal_immediately(tmp_path):
    db = tmp_path / "collector.db"
    repo = SQLiteArticleRepository(db)
    repo.initialize()
    item = _make_target(repo, "https://mp.weixin.qq.com/s/permanent")
    fetcher = PermanentFetcher()
    service = ArticleService(fetcher, repo, FileSystemStorage(tmp_path / "articles"), max_retries=1)

    first = service.fetch_pending()
    assert first.failed_count == 1
    assert first.retry_scheduled_count == 0
    assert first.terminal_failed_count == 1
    row = _row(db, item.url)
    assert row["fetch_status"] == "FETCH_FAILED"
    assert row["fetch_attempts"] == 1
    assert row["last_error_type"] == "NOT_FOUND"
    assert row["last_failure_retryable"] == 0

    service.fetch_pending()
    assert fetcher.calls == 1


def test_explicit_retry_requeues_terminal_failure(tmp_path):
    db = tmp_path / "collector.db"
    repo = SQLiteArticleRepository(db)
    repo.initialize()
    item = _make_target(repo, "https://mp.weixin.qq.com/s/manual-retry")
    fetcher = PermanentFetcher()
    service = ArticleService(fetcher, repo, FileSystemStorage(tmp_path / "articles"), max_retries=1)
    service.fetch_pending()

    row = _row(db, item.url)
    assert row["fetch_status"] == "FETCH_FAILED"
    assert repo.retry_failed(row["stable_id"]) is True

    row = _row(db, item.url)
    assert row["fetch_status"] == "PENDING"
    assert row["fetch_attempts"] == 0
    assert row["last_error_type"] is None
    assert len(repo.list_pending()) == 1
