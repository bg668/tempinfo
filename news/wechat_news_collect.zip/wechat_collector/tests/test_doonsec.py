from pathlib import Path

from collector.sources.doonsec import DoonSecSource


def test_parse_doonsec_fixture():
    xml = Path("tests/fixtures/doonsec_rss.xml").read_text(encoding="utf-8")
    items = DoonSecSource.parse(xml)
    assert len(items) == 2
    assert items[0].account == "安全内参"
    assert items[0].url == "https://mp.weixin.qq.com/s/test-a"
    assert items[0].source_id == "guid-a"
    assert items[0].published_at is not None


def test_parse_iso8601_pubdate_used_by_current_doonsec():
    xml = """<rss><channel><item><title>x</title><link>https://mp.weixin.qq.com/s/x</link><author>a</author><pubDate>2026-08-17T08:30:00</pubDate></item></channel></rss>"""
    items = DoonSecSource.parse(xml)
    assert len(items) == 1
    assert items[0].published_at is not None
    assert items[0].published_at.isoformat() == "2026-08-17T08:30:00"
