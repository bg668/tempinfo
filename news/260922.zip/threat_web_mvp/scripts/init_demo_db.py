from __future__ import annotations

import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

source_path = Path(sys.argv[1] if len(sys.argv) > 1 else "demo_source.db")
analysis_path = Path(sys.argv[2] if len(sys.argv) > 2 else "demo_analysis.db")
for path in (source_path, analysis_path):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        path.unlink()

now = datetime.now(timezone(timedelta(hours=8))).replace(microsecond=0)

source = sqlite3.connect(source_path)
source.executescript('''
CREATE TABLE feed_items(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    stable_id TEXT,
    source TEXT NOT NULL,
    source_id TEXT,
    account TEXT NOT NULL,
    title TEXT NOT NULL,
    url TEXT NOT NULL UNIQUE,
    published_at TEXT,
    discovered_at TEXT NOT NULL,
    is_target INTEGER,
    fetch_status TEXT NOT NULL DEFAULT 'DISCOVERED',
    fetch_attempts INTEGER NOT NULL DEFAULT 0,
    last_error_type TEXT,
    last_error TEXT,
    last_failure_retryable INTEGER
);
CREATE TABLE article_contents(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article_id INTEGER NOT NULL UNIQUE,
    url TEXT NOT NULL UNIQUE,
    title TEXT,
    account TEXT,
    published_at TEXT,
    content TEXT NOT NULL,
    raw_html_path TEXT NOT NULL,
    article_html_path TEXT,
    text_path TEXT,
    image_urls_path TEXT,
    image_urls_json TEXT NOT NULL DEFAULT '[]',
    fetched_at TEXT NOT NULL,
    FOREIGN KEY(article_id) REFERENCES feed_items(id) ON DELETE CASCADE
);
''')

analysis = sqlite3.connect(analysis_path)
analysis.executescript('''
CREATE TABLE candidates(
    candidate_record_id TEXT PRIMARY KEY,
    candidate_id TEXT,
    run_id TEXT,
    candidate_type TEXT,
    primary_item_id TEXT,
    title TEXT NOT NULL,
    summary TEXT,
    reason TEXT,
    total_score INTEGER,
    facts_json TEXT,
    ioc_json TEXT,
    created_at TEXT
);
CREATE TABLE processing_items(
    item_id TEXT PRIMARY KEY,
    run_id TEXT,
    source_article_id TEXT,
    candidate_record_id TEXT,
    item_kind TEXT,
    item_key TEXT,
    source_heading TEXT,
    source_text TEXT,
    process_status TEXT,
    decision TEXT,
    title TEXT,
    summary TEXT,
    reason TEXT,
    created_at TEXT
);
''')

for i in range(1, 7):
    url = f'https://example.invalid/article/{i}'
    published = (now - timedelta(minutes=i*13)).isoformat()
    # feed_items intentionally contains unusable display metadata to verify Web prefers article_contents.
    cur = source.execute(
        '''INSERT INTO feed_items(stable_id,source,source_id,account,title,url,published_at,discovered_at,is_target,fetch_status)
           VALUES(?,?,?,?,?,?,?,?,?,?)''',
        (f'stable-a{i:03d}', 'demo-feed', f'src-{i}', f'乱码来源{i}', f'乱码标题{i}', url, published, published, 1, 'FETCHED')
    )
    article_id = cur.lastrowid
    body = f'这是第 {i} 条原始资讯正文。用于本地双库 Web MVP 验证。正文来自 article_contents。'
    source.execute(
        '''INSERT INTO article_contents(article_id,url,title,account,published_at,content,raw_html_path,article_html_path,text_path,image_urls_path,image_urls_json,fetched_at)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
        (article_id, url, f'示例原始资讯 {i}', f'研究组{i}', published, body, f'raw/{i}.html', None, None, None, '[]', now.isoformat())
    )

    cid = f'c{i:03d}'
    candidate_type = 'compliance_policy' if i in (3, 6) else 'security_event'
    analysis.execute(
        'INSERT INTO candidates VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
        (cid, f'C-{i:03d}', 'demo-run', candidate_type, f'p{i:03d}', f'示例候选 {i}', f'候选摘要 {i}', '用于验证 Web MVP 的推荐理由', 96-i, '{"进入方式":"示例","影响":"待核实"}', None, published)
    )
    decision = 'KEEP' if i <= 4 else ('DROP' if i == 5 else 'UNCERTAIN')
    analysis.execute(
        'INSERT INTO processing_items VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        (f'p{i:03d}', 'demo-run', str(article_id), cid, 'article', 'article', None, None, 'SUCCESS', decision, f'处理结果 {i}', f'处理摘要 {i}', '示例判断理由', published)
    )

source.commit(); source.close()
analysis.commit(); analysis.close()
print(f"source={source_path.resolve()}")
print(f"analysis={analysis_path.resolve()}")
