# Threat Briefing Web MVP

基于 V3 视觉原型的 FastAPI + Jinja2 Web MVP。资讯处理程序独立运行；Web 只查询已经提交的数据，并在 Analysis DB 中维护人工标记和反馈。

## 数据库边界

本版本**只支持双数据库模式**，没有单库兼容配置：

- **Source DB（只读）**：`feed_items`、`article_contents`
- **Analysis DB（读写）**：`processing_items`、`candidates`、`feedback`

Web 不使用 SQLite `ATTACH DATABASE`。跨库关联在 Repository/ViewModel 层完成：

`processing_items.source_article_id -> feed_items.<SOURCE_ARTICLE_KEY> -> feed_items.id -> article_contents.article_id`

`SOURCE_ARTICLE_KEY` 必须明确设置为 `id` 或 `stable_id`，不会自动猜测。页面展示的文章标题、账号、发布时间、URL 和正文优先读取 `article_contents`；`feed_items` 主要提供来源标识、发现时间和跨库关联键。

## 安装

```powershell
uv sync
```

或者：

```powershell
uv pip install -r requirements.txt
```

Windows 使用 `zoneinfo` 时需要 `tzdata`，已经包含在依赖中。

## 启动

假设当前目录就是 `threatWeb`，其中直接包含 `app/`：

```powershell
$env:THREAT_SOURCE_DB_PATH="D:\path\to\source.db"
$env:THREAT_ANALYSIS_DB_PATH="D:\path\to\analysis.db"
$env:SOURCE_ARTICLE_KEY="id"
uv run uvicorn app.main:app --host 127.0.0.1 --port 8000
```

三个环境变量缺少任何一个都会直接启动失败，不存在 `THREAT_DB_PATH` 回退行为。

浏览器访问：`http://127.0.0.1:8000`

## Web 写入范围

Web 只写 Analysis DB：

- `candidates.review_status`
- `candidates.reviewer_id`
- `candidates.reviewed_at`
- `candidates.updated_at`
- `candidates.review_version`
- `feedback`

Source DB 通过 SQLite `mode=ro` + `query_only` 打开，Web 不对其执行迁移或写入。

## Demo 双库

```powershell
uv run python scripts/init_demo_db.py demo_source.db demo_analysis.db
$env:THREAT_SOURCE_DB_PATH="$PWD\demo_source.db"
$env:THREAT_ANALYSIS_DB_PATH="$PWD\demo_analysis.db"
$env:SOURCE_ARTICLE_KEY="id"
uv run uvicorn app.main:app --host 127.0.0.1 --port 8000
```

## 测试

```powershell
uv run pytest -q
```

测试覆盖跨库候选/原文查询、Source DB 只读、三态写入与版本冲突、收藏查询、候选/处理记录反馈、反馈幂等与输入校验。


## 首页数据口径

- `累计采集`：Source DB 中 `feed_items` 总数。
- `累计候选`：Analysis DB 中 `candidates` 总数。
- `今日新增数据`：今日新增原文数 + 今日生成候选数。
- `收藏`：全部历史 `review_status='starred'` 的候选数。
- `今日概览`：仅统计今日生成候选的三态与候选类型。
- `来源原文`：优先展示焦点候选 `primary_item_id` 对应的 `processing_items.source_article_id`，再读取 `article_contents` 的可读元数据和正文摘录。
- `更多候选`：安全事件/合规政策按钮仅在首页当前区域筛选，不跳转候选页。
- `今日新增分布`、`今日处理结果`：只统计当前业务日，不用历史日期冒充今日数据。

## 枚举与时间口径

- 候选类型的内部值固定为 `security_event / compliance_policy`；页面只把它们显示为“安全事件 / 合规政策”。URL、SQL、DOM `data-*` 和前端筛选都不再使用中文文案作为业务值。
- `SOURCE_ARTICLE_KEY` 会在启动迁移阶段用真实 `processing_items.source_article_id` 做关联校验；如果配置字段完全无法匹配 Source DB，会直接报错，不再静默显示 0 篇来源。
- “今日”统计不再使用 `substr(timestamp,1,10)`。Web 先按 `BUSINESS_TIMEZONE` 计算当天起止边界，再用带时区时间范围统计；`+00:00`、`+08:00` 等同一时刻会正确归入同一个业务日。


## 原始资讯读取契约

Web 的可阅读原始资讯只来自 `article_contents`：`title`、`account`、`published_at`、`url`、`content` 和首页原文统计都不回退读取 `feed_items`。`feed_items` 仅用于必要的 ID / `stable_id` 关联。若 `article_contents` 缺失，对应原文不会展示。
