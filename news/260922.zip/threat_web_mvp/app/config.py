from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    source_db_path: Path
    analysis_db_path: Path
    source_article_key: str
    business_timezone: str = "Asia/Shanghai"
    page_size_default: int = 20
    page_size_max: int = 100


def _required_path(name: str) -> Path:
    raw = (os.getenv(name) or "").strip()
    if not raw:
        raise RuntimeError(f"必须设置环境变量 {name}")
    return Path(raw).expanduser().resolve()


def get_settings() -> Settings:
    source_key = (os.getenv("SOURCE_ARTICLE_KEY") or "").strip()
    if source_key not in {"id", "stable_id"}:
        raise RuntimeError("必须设置 SOURCE_ARTICLE_KEY=id 或 stable_id")
    return Settings(
        source_db_path=_required_path("THREAT_SOURCE_DB_PATH"),
        analysis_db_path=_required_path("THREAT_ANALYSIS_DB_PATH"),
        source_article_key=source_key,
    )
