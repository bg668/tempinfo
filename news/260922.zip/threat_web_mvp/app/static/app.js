(() => {
  'use strict';
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const toast = $('#toast'), announcer = $('#announcer');
  let toastTimer = null;
  const announce = (msg) => {
    if (!announcer) return;
    announcer.textContent='';
    requestAnimationFrame(()=>{announcer.textContent=msg;});
  };
  const notify = (msg) => {
    announce(msg);
    if (!toast) return;
    toast.textContent=msg; toast.hidden=false;
    clearTimeout(toastTimer); toastTimer=setTimeout(()=>toast.hidden=true,2800);
  };
  const statusName = v => ({pending:'未审核',starred:'收藏',ignored:'忽略'})[v] || v;
  const statusClasses = new Set(['pending','starred','ignored','keep','drop','uncertain','failed']);
  const statusClass = v => statusClasses.has(String(v||'').toLowerCase()) ? String(v).toLowerCase() : 'unknown';
  const statusHtml = v => `<span class="state ${statusClass(v)}"><i aria-hidden="true"></i>${esc(statusName(v))}</span>`;

  async function saveReview(select){
    const id=select.dataset.reviewId, previous=select.dataset.reviewCurrent, desired=select.value, version=Number(select.dataset.reviewVersion || '0');
    if (desired===previous) return;
    select.disabled=true; select.classList.add('is-saving');
    try {
      const r=await fetch(`/api/v1/candidates/${encodeURIComponent(id)}/review-status`,{method:'PUT',headers:{'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'},body:JSON.stringify({review_status:desired,expected_review_version:version})});
      const data=await r.json().catch(()=>({detail:'服务端返回无效响应'}));
      if(!r.ok){
        if(r.status===409 && data.current){
          const current=data.current.review_status;
          $$(`[data-review-id="${CSS.escape(id)}"]`).forEach(el=>{el.value=current;el.dataset.reviewCurrent=current;el.dataset.reviewVersion=String(data.current.review_version ?? version);});
          $$(`[data-review-state-for="${CSS.escape(id)}"]`).forEach(el=>el.innerHTML=statusHtml(current));
          $$(`[data-review-version-label-for="${CSS.escape(id)}"]`).forEach(el=>el.textContent=String(data.current.review_version ?? version));
          notify(`状态已在其他页面改为“${statusName(current)}”，未覆盖。`);
        } else {
          select.value=previous; notify(data.detail || '保存失败');
        }
        return;
      }
      $$(`[data-review-id="${CSS.escape(id)}"]`).forEach(el=>{el.value=data.review_status;el.dataset.reviewCurrent=data.review_status;el.dataset.reviewVersion=String(data.review_version);});
      $$(`[data-review-state-for="${CSS.escape(id)}"]`).forEach(el=>el.innerHTML=statusHtml(data.review_status));
      $$(`[data-review-version-label-for="${CSS.escape(id)}"]`).forEach(el=>el.textContent=String(data.review_version));
      notify(`已标记为“${statusName(data.review_status)}”`);
      if(location.pathname==='/favorites' && data.review_status!=='starred'){
        const row=select.closest('[data-candidate-id]');
        if(row) row.remove();
        const totalText=$('.result-line>span');
        if(totalText){const m=totalText.textContent.match(/(\d+)/);if(m) totalText.textContent=totalText.textContent.replace(m[1],String(Math.max(0,Number(m[1])-1)));}
        if(!$('#candidate-list')?.querySelector('[data-candidate-id]')) location.reload();
      }
    } catch(e){ select.value=previous; notify('保存失败：网络或服务暂不可用'); }
    finally { select.disabled=false; select.classList.remove('is-saving'); }
  }
  document.addEventListener('change',e=>{ if(e.target.matches('.review-select')) saveReview(e.target); });

  const feedbackDialog=$('#feedback-dialog'), feedbackForm=$('#feedback-form'), textarea=$('#feedback-content'), counter=$('#feedback-counter'), feedbackError=$('#feedback-error'), feedbackSubmit=$('#feedback-submit'), targetTitle=$('#feedback-target-title');
  let feedbackTarget=null, feedbackId=null, dirty=false;
  const newFeedbackId = () => globalThis.crypto?.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}-${Math.random().toString(16).slice(2)}`;
  function openFeedback(btn){
    feedbackTarget={type:btn.dataset.targetType,id:btn.dataset.targetId,title:btn.dataset.targetTitle||btn.dataset.targetId}; feedbackId=newFeedbackId(); textarea.value=''; dirty=false; feedbackError.textContent=''; counter.textContent='0 / 5000'; targetTitle.textContent=feedbackTarget.title; feedbackDialog.showModal(); textarea.focus();
  }
  function closeFeedback(){ if(dirty && textarea.value.trim() && !confirm('反馈尚未提交，确定关闭吗？')) return; feedbackDialog.close(); feedbackTarget=null; feedbackId=null; dirty=false; }
  textarea?.addEventListener('input',()=>{ dirty=!!textarea.value; counter.textContent=`${textarea.value.length} / 5000`; feedbackError.textContent=''; });
  feedbackForm?.addEventListener('submit',async e=>{
    e.preventDefault(); if(!feedbackTarget) return;
    const content=textarea.value.trim(); if(!content){feedbackError.textContent='反馈内容不能为空';return;} if(content.length>5000){feedbackError.textContent='反馈不能超过 5000 字';return;}
    feedbackSubmit.disabled=true; textarea.disabled=true; feedbackError.textContent='';
    try{
      const r=await fetch('/api/v1/feedback',{method:'POST',headers:{'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'},body:JSON.stringify({feedback_id:feedbackId,target_type:feedbackTarget.type,target_id:feedbackTarget.id,content})});
      const data=await r.json().catch(()=>({detail:'服务端返回无效响应'}));
      if(!r.ok){feedbackError.textContent=data.detail || '提交失败';return;}
      dirty=false; feedbackDialog.close(); notify('反馈已保存');
      if(location.pathname==='/feedback' || location.pathname.startsWith('/candidates/')) location.reload();
    }catch(e){feedbackError.textContent='提交失败，文字已保留，可直接重试';}
    finally{feedbackSubmit.disabled=false; textarea.disabled=false;}
  });
  window.addEventListener('beforeunload',e=>{ if(dirty && textarea?.value.trim()){e.preventDefault();e.returnValue='';} });

  const drawer=$('#drawer'), drawerTitle=$('#drawer-title'), drawerSubtitle=$('#drawer-subtitle'), drawerContent=$('#drawer-content');
  function openDrawer(title, subtitle, html){drawerTitle.textContent=title;drawerSubtitle.textContent=subtitle;drawerContent.innerHTML=html;if(!drawer.open)drawer.showModal();drawer.scrollTop=0;}
  async function traceDrawer(id){
    openDrawer('AI 处理记录','正在读取具体处理项…','<div class="note-surface">加载中…</div>');
    try{
      const r=await fetch(`/api/v1/processing-items/${encodeURIComponent(id)}`); const p=await r.json();
      if(!r.ok) throw new Error(p.detail || '处理记录读取失败');
      const decision=p.decision || '未判断';
      const detailRows=[['item_id',p.item_id],['run_id',p.run_id],['source_article_id',p.source_article_id],['candidate_record_id',p.candidate_record_id||'未关联'],['created_at',p.created_at_display||'未提供']];
      openDrawer('AI 处理记录','从结果追溯具体处理对象，不修改历史结果。',`
        <section class="drawer-summary"><div class="meta"><span class="state ${statusClass(decision)}"><i></i>${esc(decision)}</span><span>处理状态：${esc(p.process_status||'未提供')}</span></div><h3>${esc(p.title||p.source_heading||p.item_id)}</h3><p>${esc(p.reason||p.summary||'未提供判断理由')}</p></section>
        <ol class="trace-list"><li class="trace-step"><span class="step-no">00</span><div><h3>输入关联 <span>记录可查</span></h3><p>原文 ID：${esc(p.source_article_id||'未提供')}</p></div></li><li class="trace-step"><span class="step-no">01</span><div><h3>AI 判断 <span>${esc(decision)}</span></h3><p>${esc(p.summary||p.reason||'没有摘要或判断说明。')}</p>${p.source_text?`<blockquote class="source-quote">${esc(p.source_text)}</blockquote>`:''}</div></li><li class="trace-step"><span class="step-no">04</span><div><h3>候选关联 <span>${p.candidate_record_id?'已建立':'未生成候选'}</span></h3><p>${p.candidate_record_id?`关联候选 ${esc(p.candidate_record_id)}`:'该记录未关联候选。'}</p></div></li></ol>
        <details class="drawer-meta"><summary>技术字段与版本</summary><dl class="technical-list">${detailRows.map(([k,v])=>`<dt>${esc(k)}</dt><dd><code>${esc(v)}</code></dd>`).join('')}</dl></details>`);
    }catch(err){openDrawer('AI 处理记录','读取失败',`<div class="note-surface"><strong>无法读取处理记录</strong>${esc(err.message)}</div>`);}
  }

  async function copy(text){try{await navigator.clipboard.writeText(text);notify('已复制');}catch{notify('复制不可用，请手动选择文本');}}

  const searchDialog=$('#search-dialog'), globalQuery=$('#global-query');
  function openSearch(){searchDialog?.showModal(); if(globalQuery){globalQuery.value='';globalQuery.focus();}}
  function doGlobalSearch(kind){const q=(globalQuery?.value||'').trim(); if(!q){globalQuery?.focus();return;} location.href=`/${kind}?q=${encodeURIComponent(q)}`;}

  const homeTypeNames={all:'全部',security_event:'安全事件',compliance_policy:'合规政策'};
  function applyHomeType(selected,{syncUrl=true}={}){
    if(!Object.hasOwn(homeTypeNames,selected)) selected='all';
    $$('[data-home-type]').forEach(x=>{
      const active=x.dataset.homeType===selected;
      x.classList.toggle('active',active);
      if(active) x.setAttribute('aria-current','true'); else x.removeAttribute('aria-current');
    });
    let visible=0;
    $$('[data-home-candidate-type]').forEach(x=>{
      const show=selected==='all'||x.dataset.homeCandidateType===selected;
      x.hidden=!show; if(show) visible+=1;
    });
    const empty=$('#home-filter-empty'); if(empty) empty.hidden=visible!==0;
    const status=$('#home-filter-status');
    if(status) status.textContent=`${homeTypeNames[selected]}：当前显示 ${visible} 项候选`;
    if(syncUrl && location.pathname==='/'){
      const url=new URL(location.href);
      if(selected==='all') url.searchParams.delete('type'); else url.searchParams.set('type',selected);
      url.hash='more-candidates';
      history.replaceState({homeType:selected},'',`${url.pathname}${url.search}${url.hash}`);
    }
  }

  document.addEventListener('click',e=>{
    const btn=e.target.closest('button,a'); if(!btn) return;
    if(btn.dataset.homeType){
      if(e.metaKey||e.ctrlKey||e.shiftKey||e.altKey) return;
      e.preventDefault();
      applyHomeType(btn.dataset.homeType);
      return;
    }
    if(btn.dataset.feedbackOpen!==undefined){e.preventDefault();openFeedback(btn);return;}
    if(btn.hasAttribute('data-feedback-close')){e.preventDefault();closeFeedback();return;}
    if(btn.dataset.trace){e.preventDefault();traceDrawer(btn.dataset.trace);return;}
    if(btn.dataset.copy){e.preventDefault();copy(btn.dataset.copy);return;}
    if(btn.dataset.action==='close-drawer'){drawer.close();return;}
    if(btn.dataset.action==='search'){openSearch();return;}
    if(btn.dataset.action==='close-search'){searchDialog.close();return;}
    if(btn.dataset.globalSearch){doGlobalSearch(btn.dataset.globalSearch);return;}
  });
  $('#global-search-form')?.addEventListener('submit',e=>{e.preventDefault();doGlobalSearch('candidates');});
  document.addEventListener('keydown',e=>{
    if(e.key.toLowerCase()==='k'&&(e.ctrlKey||e.metaKey)){e.preventDefault();openSearch();}
  });

  function initReportSectionNav(){
    const nav=$('[data-report-nav]');
    if(!nav) return;
    const links=$$('a[href^="#"]',nav);
    const targets=links.map(a=>document.querySelector(a.getAttribute('href'))).filter(Boolean);
    if(!links.length||!targets.length) return;
    const setCurrent=id=>links.forEach(a=>{
      const on=a.getAttribute('href')===`#${id}`;
      a.classList.toggle('active',on);
      if(on) a.setAttribute('aria-current','location'); else a.removeAttribute('aria-current');
    });
    const stickyOffset=()=>{
      const root=getComputedStyle(document.documentElement);
      return (parseFloat(root.getPropertyValue('--app-header-h'))||76)+(parseFloat(root.getPropertyValue('--report-tabs-h'))||53)+18;
    };
    let queued=false;
    const update=()=>{
      queued=false;
      const offset=stickyOffset();
      let current=targets[0], best=Infinity;
      for(const target of targets){
        const distance=Math.abs(target.getBoundingClientRect().top-offset);
        if(distance<best){best=distance;current=target;}
      }
      if(window.innerHeight+window.scrollY>=document.documentElement.scrollHeight-8) current=targets[targets.length-1];
      setCurrent(current.id);
    };
    const schedule=()=>{if(!queued){queued=true;requestAnimationFrame(update);}};
    window.addEventListener('scroll',schedule,{passive:true});
    window.addEventListener('resize',schedule);
    update();
  }
  initReportSectionNav();

  window.addEventListener('popstate',()=>{
    if(location.pathname!=='/') return;
    const selected=new URL(location.href).searchParams.get('type')||'all';
    applyHomeType(selected,{syncUrl:false});
  });
  $$('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}}));
})();
