from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field, field_validator

ReviewStatus = Literal["pending", "starred", "ignored"]
TargetType = Literal["candidate", "processing_item"]


class ReviewStatusUpdate(BaseModel):
    review_status: ReviewStatus
    expected_review_version: int = Field(ge=0)


class ReviewStatusResult(BaseModel):
    candidate_record_id: str
    review_status: ReviewStatus
    review_version: int
    reviewer_id: str | None
    reviewed_at: str | None
    updated_at: str | None


class FeedbackCreate(BaseModel):
    feedback_id: str = Field(min_length=1, max_length=128)
    target_type: TargetType
    target_id: str = Field(min_length=1, max_length=512)
    content: str = Field(max_length=5000)

    @field_validator("feedback_id", "target_id")
    @classmethod
    def strip_identifier(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("不能为空")
        return value

    @field_validator("content")
    @classmethod
    def validate_content(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("反馈内容不能为空")
        return value


class FeedbackResult(BaseModel):
    feedback_id: str
    target_type: TargetType
    target_id: str
    content: str
    created_at: str
