# News Agent v0.3.1 — 可恢复长任务补丁

## 目标

把 `event_match` 从“输出重试耗尽 → 整个 mvp-run 异常退出”改为：

```text
任务级原子提交
+ SUCCESS 复用
+ FAILED 精确重试
+ 输入变化 STALE 重算
+ exact-cover 确定性保守修复
+ 单任务失败隔离
```

## 接入原则

不要修改现有 `event_candidates / event_match_runs / policy_candidates` 的业务字段语义。新增 `llm_task_checkpoints` 仅保存运行态和诊断。

### 1. 初始化

在 News Agent SQLite repository/schema 初始化后增加：

```python
from news_agent.resilience import CheckpointStore
checkpoints = CheckpointStore(news_db_path)
```

它会幂等创建 `llm_task_checkpoints`。

### 2. Article Analysis

每篇文章作为一个 task：

```text
stage = article_analysis
subject = [source_article_id]
input_hash = hash(真正送给模型的文章内容 + 影响语义的配置/skill/model task id)
```

只有 `SUCCESS + input_hash 相同` 才复用。FAILED 下次 resume 重新调用；hash 改变自动失效。

### 3. Event Match

必须以 candidate merge group 为原子 task，不能把失败响应里“看起来已经分好的文章”逐篇提交。

```python
run_resumable_tasks(
    stage="event_match",
    tasks=merge_groups,
    store=checkpoints,
    input_payload=build_event_match_input_payload,
    execute=execute_one_event_match_group,
)
```

`execute_one_event_match_group()` 内保留 PydanticAI 自身 `output_retries`。如果最终仍抛出 `exceeded maximum output retries`，异常只跨出当前 task，由 runner 写 `FAILED`，随后继续其他 merge group。

### 4. exact-cover

模型输出能够解析出 groups 后，立即：

```python
reconciled = reconcile_exact_cover(expected_article_ids, model_groups)
```

规则：
- unknown ID：删除；
- missing ID：单独成组；
- duplicate ID：从所有冲突组撤出，再单独成组；
- 唯一且合法的原归属保持不变；
- 修复后再次验证 exact-cover，必须通过。

这是集合完整性修复，不替模型发明“同一事件”语义。

建议把下面诊断写入 checkpoint：

```python
{
    "degraded": reconciled.degraded,
    "missing": list(reconciled.issue_before.missing),
    "duplicate": list(reconciled.issue_before.duplicate),
    "unknown": list(reconciled.issue_before.unknown),
}
```

### 5. raw retry 输出

现有 PydanticAI `TextOutput(_parse_output)` 回调每次收到 `text` 时，将原文写入 `OutputAttemptCollector`。最终成功用 `as_task_success(...)` 返回；最终失败转换为 `TaskExecutionError`：

```python
collector = OutputAttemptCollector()

# _parse_output 中：
collector.record(text, validation_error_if_any)

# run_sync 最终失败：
raise as_task_failure(exc, collector=collector) from exc
```

如果当前 runtime 可能并发，collector 必须放在“本次 task deps/上下文”中，不要使用模块全局 list。

### 6. mvp-run 状态

单个任务失败不再 `raise SystemExit` / 让顶层异常退出。最终状态：

```text
无失败任务                         -> SUCCESS
存在失败任务，但有可用成功结果      -> PARTIAL
没有任何可用结果且关键阶段全部失败   -> FAILED
```

第二次运行同一批输入时：SUCCESS 直接复用，FAILED 重新执行，STALE 重新执行。

## 重要边界

- PydanticAI 的 2~3 次 output retry 仍保留，它解决“同一次模型任务内纠正输出”。
- checkpoint resume 是另一层，它解决“长任务跨进程/跨运行恢复”。
- 不要为了 exact-cover 增加无限模型重试。
- Event Match task 必须整组原子提交。
- `input_hash` 必须覆盖真正影响模型结果的输入；至少包括文章 ID、文章事实/正文摘要、candidate-group 上下文，以及相关 skill/model-task 版本。

## Candidate-group 计划变化

`run_resumable_tasks()` 每次执行前会比较当前 stage 的 active task IDs：上一轮存在、但本轮确定性计划中已经消失的历史任务自动标记为 `STALE(task_not_in_current_plan)`。因此 `[A,B] -> [A,B,C]` 时，旧 `[A,B]` 不会继续显示为有效 SUCCESS。
