"""Patch test package marker. When overlaying an existing News Agent, keep the target __init__.py."""
