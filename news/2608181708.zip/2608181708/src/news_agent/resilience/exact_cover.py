from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Iterable, Sequence


@dataclass(frozen=True)
class ExactCoverIssue:
    missing: tuple[str, ...] = ()
    duplicate: tuple[str, ...] = ()
    unknown: tuple[str, ...] = ()

    @property
    def ok(self) -> bool:
        return not (self.missing or self.duplicate or self.unknown)


@dataclass(frozen=True)
class ReconcileResult:
    groups: tuple[tuple[str, ...], ...]
    issue_before: ExactCoverIssue
    issue_after: ExactCoverIssue
    degraded: bool


def _normalize_expected(expected_article_ids: Iterable[str]) -> tuple[str, ...]:
    ids = tuple(str(x) for x in expected_article_ids)
    if len(ids) != len(set(ids)):
        raise ValueError("expected_article_ids 本身包含重复 article_id")
    return ids


def validate_exact_cover(
    expected_article_ids: Iterable[str],
    groups: Sequence[Sequence[str]],
) -> ExactCoverIssue:
    expected = _normalize_expected(expected_article_ids)
    expected_set = set(expected)
    flattened = [str(article_id) for group in groups for article_id in group]
    counts = Counter(flattened)

    missing = tuple(article_id for article_id in expected if counts[article_id] == 0)
    duplicate = tuple(article_id for article_id in expected if counts[article_id] > 1)
    unknown = tuple(sorted(article_id for article_id in counts if article_id not in expected_set))
    return ExactCoverIssue(missing=missing, duplicate=duplicate, unknown=unknown)


def reconcile_exact_cover(
    expected_article_ids: Iterable[str],
    groups: Sequence[Sequence[str]],
) -> ReconcileResult:
    """Conservatively repair set-integrity defects in an LLM grouping.

    Semantic decisions are never invented. Unknown IDs are discarded. Any expected ID
    that is missing or appears more than once is removed from all model groups and emitted
    as a singleton. Unique, valid memberships are preserved.

    This guarantees exact cover while following the project's "宁可拆开，不可错合" rule.
    """
    expected = _normalize_expected(expected_article_ids)
    expected_set = set(expected)
    issue_before = validate_exact_cover(expected, groups)
    if issue_before.ok:
        normalized = tuple(tuple(str(x) for x in group) for group in groups if group)
        return ReconcileResult(normalized, issue_before, issue_before, False)

    duplicate_set = set(issue_before.duplicate)
    repaired: list[tuple[str, ...]] = []
    assigned: set[str] = set()

    for group in groups:
        kept: list[str] = []
        for raw in group:
            article_id = str(raw)
            if article_id not in expected_set:
                continue
            if article_id in duplicate_set:
                continue
            if article_id in assigned:
                # Defensive: validation should already classify this as duplicate.
                continue
            assigned.add(article_id)
            kept.append(article_id)
        if kept:
            repaired.append(tuple(kept))

    # Missing + duplicated IDs carry unresolved semantic membership. Make them singletons.
    for article_id in expected:
        if article_id not in assigned:
            repaired.append((article_id,))
            assigned.add(article_id)

    result_groups = tuple(repaired)
    issue_after = validate_exact_cover(expected, result_groups)
    if not issue_after.ok:
        raise AssertionError(f"exact-cover reconciliation failed: {issue_after}")

    return ReconcileResult(
        groups=result_groups,
        issue_before=issue_before,
        issue_after=issue_after,
        degraded=True,
    )
