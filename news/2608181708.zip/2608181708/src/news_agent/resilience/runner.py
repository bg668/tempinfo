from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping, Protocol, Sequence

from .checkpoint import CheckpointStore, stable_input_hash, stable_task_id


class TaskLike(Protocol):
    article_ids: Sequence[str]


@dataclass(frozen=True)
class TaskExecutionResult:
    result: Any
    attempts: int = 1
    raw_outputs: tuple[str, ...] = ()
    diagnostics: Mapping[str, Any] | None = None


@dataclass(frozen=True)
class ResumableRunResult:
    results: tuple[Any, ...]
    reused_task_ids: tuple[str, ...]
    succeeded_task_ids: tuple[str, ...]
    failed_task_ids: tuple[str, ...]

    @property
    def status(self) -> str:
        if self.failed_task_ids and (self.results or self.reused_task_ids or self.succeeded_task_ids):
            return "PARTIAL"
        if self.failed_task_ids:
            return "FAILED"
        return "SUCCESS"


def run_resumable_tasks(
    *,
    stage: str,
    tasks: Iterable[TaskLike],
    store: CheckpointStore,
    input_payload: Callable[[TaskLike], Any],
    execute: Callable[[TaskLike], TaskExecutionResult],
    serialize_result: Callable[[Any], Any] = lambda x: x,
    deserialize_result: Callable[[Any], Any] = lambda x: x,
) -> ResumableRunResult:
    """Execute independent tasks with atomic checkpoints and precise resume.

    - SUCCESS + same input hash: reuse without calling execute.
    - FAILED: execute again on the next run.
    - changed input: historical checkpoint becomes STALE and executes again.
    - one task failure never aborts remaining independent tasks.
    """
    task_list = list(tasks)
    active_task_ids = [stable_task_id(stage, task.article_ids) for task in task_list]
    store.mark_inactive_stage_tasks_stale(stage, active_task_ids)

    results: list[Any] = []
    reused: list[str] = []
    succeeded: list[str] = []
    failed: list[str] = []

    for task in task_list:
        article_ids = tuple(str(x) for x in task.article_ids)
        task_id = stable_task_id(stage, article_ids)
        payload = input_payload(task)
        input_hash = stable_input_hash(payload)

        old = store.prepare(
            task_id=task_id,
            stage=stage,
            input_hash=input_hash,
            input_article_ids=article_ids,
        )
        if old is not None:
            results.append(deserialize_result(old.result))
            reused.append(task_id)
            continue

        try:
            execution = execute(task)
        except Exception as exc:  # task boundary: isolate model/provider/validation failures
            previous = store.get(task_id)
            attempts = (previous.attempts if previous and previous.input_hash == input_hash else 0) + 1
            raw_outputs = getattr(exc, "raw_outputs", ()) or ()
            diagnostics = getattr(exc, "diagnostics", {}) or {}
            store.save_failed(
                task_id=task_id,
                stage=stage,
                input_hash=input_hash,
                input_article_ids=article_ids,
                attempts=attempts,
                error=exc,
                raw_outputs=raw_outputs,
                diagnostics=diagnostics,
            )
            failed.append(task_id)
            continue

        previous = store.get(task_id)
        previous_attempts = previous.attempts if previous and previous.input_hash == input_hash else 0
        total_attempts = previous_attempts + max(1, execution.attempts)
        store.save_success(
            task_id=task_id,
            stage=stage,
            input_hash=input_hash,
            input_article_ids=article_ids,
            result=serialize_result(execution.result),
            attempts=total_attempts,
            raw_outputs=execution.raw_outputs,
            diagnostics=execution.diagnostics or {},
        )
        results.append(execution.result)
        succeeded.append(task_id)

    return ResumableRunResult(
        results=tuple(results),
        reused_task_ids=tuple(reused),
        succeeded_task_ids=tuple(succeeded),
        failed_task_ids=tuple(failed),
    )
