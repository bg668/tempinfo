from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Generic, Mapping, Sequence, TypeVar

from .errors import TaskExecutionError
from .exact_cover import ReconcileResult, reconcile_exact_cover
from .runner import TaskExecutionResult

T = TypeVar("T")


@dataclass
class OutputAttemptCollector:
    """Per-task collector. Put one instance in deps/context when execution may be concurrent."""

    raw_outputs: list[str] = field(default_factory=list)
    validation_errors: list[str] = field(default_factory=list)

    def record(self, text: str, error: BaseException | str | None = None) -> None:
        self.raw_outputs.append(text)
        if error is not None:
            self.validation_errors.append(
                error if isinstance(error, str) else f"{type(error).__name__}: {error}"
            )


@dataclass(frozen=True)
class EventMatchValidatedResult(Generic[T]):
    domain_result: T
    reconcile: ReconcileResult


def validate_and_reconcile_groups(
    *,
    expected_article_ids: Sequence[str],
    model_groups: Sequence[Sequence[str]],
    build_domain_result: Callable[[tuple[tuple[str, ...], ...]], T],
) -> EventMatchValidatedResult[T]:
    """Run deterministic exact-cover repair after the model's output is structurally parseable."""
    reconciled = reconcile_exact_cover(expected_article_ids, model_groups)
    return EventMatchValidatedResult(
        domain_result=build_domain_result(reconciled.groups),
        reconcile=reconciled,
    )


def as_task_success(
    *,
    result: Any,
    collector: OutputAttemptCollector,
    reconcile: ReconcileResult | None = None,
) -> TaskExecutionResult:
    diagnostics: dict[str, Any] = {
        "model_output_attempts": len(collector.raw_outputs),
        "validation_errors": list(collector.validation_errors),
    }
    if reconcile is not None:
        diagnostics.update(
            {
                "degraded": reconcile.degraded,
                "missing": list(reconcile.issue_before.missing),
                "duplicate": list(reconcile.issue_before.duplicate),
                "unknown": list(reconcile.issue_before.unknown),
            }
        )
    return TaskExecutionResult(
        result=result,
        attempts=1,
        raw_outputs=tuple(collector.raw_outputs),
        diagnostics=diagnostics,
    )


def as_task_failure(
    error: BaseException,
    *,
    collector: OutputAttemptCollector,
    extra_diagnostics: Mapping[str, Any] | None = None,
) -> TaskExecutionError:
    diagnostics: dict[str, Any] = {
        "model_output_attempts": len(collector.raw_outputs),
        "validation_errors": list(collector.validation_errors),
        "cause_type": type(error).__name__,
    }
    if extra_diagnostics:
        diagnostics.update(dict(extra_diagnostics))
    return TaskExecutionError(
        message=f"{type(error).__name__}: {error}",
        raw_outputs=tuple(collector.raw_outputs),
        diagnostics=diagnostics,
        model_output_attempts=len(collector.raw_outputs),
    )
