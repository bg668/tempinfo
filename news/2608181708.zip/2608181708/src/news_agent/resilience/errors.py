from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass
class TaskExecutionError(Exception):
    """A task-scoped failure that preserves model-attempt diagnostics."""

    message: str
    raw_outputs: tuple[str, ...] = ()
    diagnostics: Mapping[str, Any] | None = None
    model_output_attempts: int = 0

    def __post_init__(self) -> None:
        super().__init__(self.message)
        if self.diagnostics is None:
            self.diagnostics = {}

    def __str__(self) -> str:
        return self.message
