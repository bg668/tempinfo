from __future__ import annotations

import hashlib
import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path
from typing import Any, Iterable, Mapping


class TaskStatus(StrEnum):
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    STALE = "STALE"


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def stable_input_hash(payload: Any) -> str:
    return hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()


def stable_task_id(stage: str, subject_ids: Iterable[str]) -> str:
    ordered = sorted(str(x) for x in subject_ids)
    digest = hashlib.sha256((stage + "\n" + "\n".join(ordered)).encode("utf-8")).hexdigest()[:20]
    return f"{stage}:{digest}"


@dataclass(frozen=True)
class TaskCheckpoint:
    task_id: str
    stage: str
    input_hash: str
    status: TaskStatus
    input_article_ids: tuple[str, ...]
    attempts: int
    result: Any | None
    last_error: str | None
    raw_outputs: tuple[str, ...]
    diagnostics: Mapping[str, Any]
    created_at: str
    updated_at: str


class CheckpointStore:
    """SQLite-backed task checkpoint store, deliberately isolated from business tables."""

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.ensure_schema()

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def ensure_schema(self) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS llm_task_checkpoints (
                    task_id TEXT PRIMARY KEY,
                    stage TEXT NOT NULL,
                    input_hash TEXT NOT NULL,
                    status TEXT NOT NULL CHECK(status IN ('SUCCESS','FAILED','STALE')),
                    input_article_ids_json TEXT NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    result_json TEXT,
                    last_error TEXT,
                    raw_outputs_json TEXT NOT NULL DEFAULT '[]',
                    diagnostics_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_llm_task_checkpoints_stage_status "
                "ON llm_task_checkpoints(stage, status)"
            )

    @staticmethod
    def _row_to_checkpoint(row: sqlite3.Row) -> TaskCheckpoint:
        return TaskCheckpoint(
            task_id=row["task_id"],
            stage=row["stage"],
            input_hash=row["input_hash"],
            status=TaskStatus(row["status"]),
            input_article_ids=tuple(json.loads(row["input_article_ids_json"])),
            attempts=int(row["attempts"]),
            result=json.loads(row["result_json"]) if row["result_json"] is not None else None,
            last_error=row["last_error"],
            raw_outputs=tuple(json.loads(row["raw_outputs_json"])),
            diagnostics=json.loads(row["diagnostics_json"]),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def get(self, task_id: str) -> TaskCheckpoint | None:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM llm_task_checkpoints WHERE task_id = ?", (task_id,)
            ).fetchone()
        return self._row_to_checkpoint(row) if row else None

    def reusable(self, task_id: str, input_hash: str) -> TaskCheckpoint | None:
        checkpoint = self.get(task_id)
        if checkpoint and checkpoint.status is TaskStatus.SUCCESS and checkpoint.input_hash == input_hash:
            return checkpoint
        return None

    def prepare(self, *, task_id: str, stage: str, input_hash: str, input_article_ids: Iterable[str]) -> TaskCheckpoint | None:
        """Return reusable SUCCESS or mark changed historical data STALE."""
        old = self.get(task_id)
        if old is None:
            return None
        if old.status is TaskStatus.SUCCESS and old.input_hash == input_hash:
            return old
        if old.input_hash != input_hash and old.status is not TaskStatus.STALE:
            self.mark_stale(task_id, reason="input_hash_changed")
        return None

    def mark_stale(self, task_id: str, *, reason: str) -> None:
        old = self.get(task_id)
        if old is None:
            return
        diagnostics = dict(old.diagnostics)
        diagnostics["stale_reason"] = reason
        diagnostics["stale_at"] = _utcnow()
        with self.connect() as conn:
            conn.execute(
                "UPDATE llm_task_checkpoints SET status='STALE', diagnostics_json=?, updated_at=? WHERE task_id=?",
                (_canonical_json(diagnostics), _utcnow(), task_id),
            )

    def save_success(
        self,
        *,
        task_id: str,
        stage: str,
        input_hash: str,
        input_article_ids: Iterable[str],
        result: Any,
        attempts: int,
        raw_outputs: Iterable[str] = (),
        diagnostics: Mapping[str, Any] | None = None,
    ) -> None:
        self._upsert(
            task_id=task_id,
            stage=stage,
            input_hash=input_hash,
            status=TaskStatus.SUCCESS,
            input_article_ids=input_article_ids,
            attempts=attempts,
            result=result,
            last_error=None,
            raw_outputs=raw_outputs,
            diagnostics=diagnostics or {},
        )

    def save_failed(
        self,
        *,
        task_id: str,
        stage: str,
        input_hash: str,
        input_article_ids: Iterable[str],
        attempts: int,
        error: BaseException | str,
        raw_outputs: Iterable[str] = (),
        diagnostics: Mapping[str, Any] | None = None,
    ) -> None:
        message = error if isinstance(error, str) else f"{type(error).__name__}: {error}"
        self._upsert(
            task_id=task_id,
            stage=stage,
            input_hash=input_hash,
            status=TaskStatus.FAILED,
            input_article_ids=input_article_ids,
            attempts=attempts,
            result=None,
            last_error=message,
            raw_outputs=raw_outputs,
            diagnostics=diagnostics or {},
        )

    def _upsert(
        self,
        *,
        task_id: str,
        stage: str,
        input_hash: str,
        status: TaskStatus,
        input_article_ids: Iterable[str],
        attempts: int,
        result: Any | None,
        last_error: str | None,
        raw_outputs: Iterable[str],
        diagnostics: Mapping[str, Any],
    ) -> None:
        now = _utcnow()
        old = self.get(task_id)
        created_at = old.created_at if old else now
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO llm_task_checkpoints(
                    task_id, stage, input_hash, status, input_article_ids_json,
                    attempts, result_json, last_error, raw_outputs_json,
                    diagnostics_json, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(task_id) DO UPDATE SET
                    stage=excluded.stage,
                    input_hash=excluded.input_hash,
                    status=excluded.status,
                    input_article_ids_json=excluded.input_article_ids_json,
                    attempts=excluded.attempts,
                    result_json=excluded.result_json,
                    last_error=excluded.last_error,
                    raw_outputs_json=excluded.raw_outputs_json,
                    diagnostics_json=excluded.diagnostics_json,
                    updated_at=excluded.updated_at
                """,
                (
                    task_id,
                    stage,
                    input_hash,
                    status.value,
                    _canonical_json(tuple(str(x) for x in input_article_ids)),
                    int(attempts),
                    None if result is None else _canonical_json(result),
                    last_error,
                    _canonical_json(tuple(raw_outputs)),
                    _canonical_json(dict(diagnostics)),
                    created_at,
                    now,
                ),
            )

    def mark_inactive_stage_tasks_stale(self, stage: str, active_task_ids: Iterable[str]) -> tuple[str, ...]:
        """Mark historical tasks that disappeared from the current deterministic plan as STALE.

        This matters when a new article changes candidate-group membership: the new group has a
        different task_id, so the previous SUCCESS must remain auditable but must no longer look active.
        """
        active = {str(x) for x in active_task_ids}
        changed: list[str] = []
        for checkpoint in self.list_stage(stage):
            if checkpoint.task_id in active or checkpoint.status is TaskStatus.STALE:
                continue
            self.mark_stale(checkpoint.task_id, reason="task_not_in_current_plan")
            changed.append(checkpoint.task_id)
        return tuple(changed)

    def list_stage(self, stage: str) -> list[TaskCheckpoint]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM llm_task_checkpoints WHERE stage=? ORDER BY task_id", (stage,)
            ).fetchall()
        return [self._row_to_checkpoint(row) for row in rows]
