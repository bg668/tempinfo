from __future__ import annotations

from dataclasses import dataclass
from typing import Any


ALLOWED_ISSUE_TYPES = {
    "source_data",
    "extraction",
    "strategy",
    "prompt",
    "workflow",
    "model",
    "user_misunderstanding",
    "no_issue",
    "other",
}

ALLOWED_PROPOSAL_TARGETS = {
    "source_data",
    "extraction",
    "strategy",
    "prompt",
    "workflow",
    "model_config",
    "none",
    "other",
}


@dataclass(frozen=True)
class FeedbackRecord:
    feedback_id: str
    target_type: str
    target_id: str
    content: str
    created_at: str


@dataclass(frozen=True)
class FeedbackContext:
    feedback_id: str
    target_type: str
    feedback_content: str
    source_material: str
    previous_judgement: str
    historical_runtime: str
    current_runtime: str = ""

    def to_dify_inputs(self) -> dict[str, str]:
        return {
            "target_type": self.target_type,
            "feedback_content": self.feedback_content,
            "source_material": self.source_material,
            "previous_judgement": self.previous_judgement,
            "historical_runtime": self.historical_runtime,
            "current_runtime": self.current_runtime,
        }


@dataclass(frozen=True)
class FeedbackAnalysis:
    issue: str
    issue_type: str
    affected_stage: str
    root_cause: str
    systemic_risk: bool
    confidence: float


@dataclass(frozen=True)
class ChangeProposal:
    need_change: bool
    target: str
    suggestion: str
    reason: str
    risk: str


@dataclass(frozen=True)
class WorkflowResult:
    feedback_analysis: FeedbackAnalysis
    change_proposal: ChangeProposal

    @classmethod
    def from_mapping(cls, raw: dict[str, Any]) -> "WorkflowResult":
        if not isinstance(raw, dict):
            raise ValueError("workflow result must be a JSON object")

        a = raw.get("feedback_analysis")
        p = raw.get("change_proposal")
        if not isinstance(a, dict) or not isinstance(p, dict):
            raise ValueError("workflow result must contain feedback_analysis and change_proposal objects")

        issue = _required_text(a, "issue")
        issue_type = _required_text(a, "issue_type")
        if issue_type not in ALLOWED_ISSUE_TYPES:
            raise ValueError(f"unsupported issue_type: {issue_type}")
        affected_stage = _required_text(a, "affected_stage")
        root_cause = _required_text(a, "root_cause")
        systemic_risk = a.get("systemic_risk")
        if not isinstance(systemic_risk, bool):
            raise ValueError("feedback_analysis.systemic_risk must be boolean")
        confidence = a.get("confidence")
        if isinstance(confidence, bool) or not isinstance(confidence, (int, float)):
            raise ValueError("feedback_analysis.confidence must be a number")
        confidence = float(confidence)
        if not 0.0 <= confidence <= 1.0:
            raise ValueError("feedback_analysis.confidence must be between 0 and 1")

        need_change = p.get("need_change")
        if not isinstance(need_change, bool):
            raise ValueError("change_proposal.need_change must be boolean")
        target = _required_text(p, "target")
        if target not in ALLOWED_PROPOSAL_TARGETS:
            raise ValueError(f"unsupported change_proposal.target: {target}")
        if not need_change and target != "none":
            raise ValueError("change_proposal.target must be 'none' when need_change=false")
        if need_change and target == "none":
            raise ValueError("change_proposal.target cannot be 'none' when need_change=true")

        return cls(
            feedback_analysis=FeedbackAnalysis(
                issue=issue,
                issue_type=issue_type,
                affected_stage=affected_stage,
                root_cause=root_cause,
                systemic_risk=systemic_risk,
                confidence=confidence,
            ),
            change_proposal=ChangeProposal(
                need_change=need_change,
                target=target,
                suggestion=_required_text(p, "suggestion"),
                reason=_required_text(p, "reason"),
                risk=_required_text(p, "risk"),
            ),
        )


def _required_text(obj: dict[str, Any], key: str) -> str:
    value = obj.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{key} must be a non-empty string")
    return value.strip()
