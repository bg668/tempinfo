from __future__ import annotations

import argparse
import logging

from .config import Settings
from .context_builder import FeedbackContextBuilder
from .dify_client import DifyFeedbackClient
from .processor import FeedbackProcessor
from .repository import FeedbackRepository


def build_processor(settings: Settings) -> FeedbackProcessor:
    repository = FeedbackRepository(
        analysis_db=settings.analysis_db,
        source_db=settings.source_db,
    )
    return FeedbackProcessor(
        repository=repository,
        context_builder=FeedbackContextBuilder(repository),
        dify_client=DifyFeedbackClient(
            base_url=settings.dify_base_url,
            api_key=settings.dify_api_key,
            timeout_seconds=settings.timeout_seconds,
            user=settings.dify_user,
        ),
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Process unhandled feedback through Dify Feedback Workflow")
    parser.add_argument("--limit", type=int, default=None, help="Maximum feedback rows to process in this run")
    parser.add_argument("--init-db", action="store_true", help="Only create the two MVP result tables and exit")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    settings = Settings.from_env()
    processor = build_processor(settings)

    if args.init_db:
        processor.repository.ensure_schema()
        print("feedback_analysis/change_proposal schema ready")
        return 0

    summary = processor.run_batch(limit=args.limit or settings.batch_limit)
    print(
        f"feedback batch: pending={summary.pending} succeeded={summary.succeeded} "
        f"failed={summary.failed} proposals={summary.proposals}"
    )
    return 0 if summary.failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
