CREATE TABLE IF NOT EXISTS feedback_analysis (
    analysis_id TEXT PRIMARY KEY,
    feedback_id TEXT NOT NULL UNIQUE,
    issue TEXT NOT NULL,
    issue_type TEXT NOT NULL,
    affected_stage TEXT NOT NULL,
    root_cause TEXT NOT NULL,
    systemic_risk INTEGER NOT NULL,
    confidence REAL NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS change_proposal (
    proposal_id TEXT PRIMARY KEY,
    feedback_id TEXT NOT NULL,
    analysis_id TEXT NOT NULL UNIQUE,
    need_change INTEGER NOT NULL,
    target TEXT NOT NULL,
    suggestion TEXT NOT NULL,
    reason TEXT NOT NULL,
    risk TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_feedback_analysis_feedback_id
    ON feedback_analysis(feedback_id);

CREATE INDEX IF NOT EXISTS idx_change_proposal_feedback_id
    ON change_proposal(feedback_id);
