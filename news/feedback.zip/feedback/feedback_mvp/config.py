from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _first_env(*names: str, default: str | None = None) -> str | None:
    for name in names:
        value = os.getenv(name)
        if value is not None and value.strip():
            return value.strip()
    return default


@dataclass(frozen=True)
class Settings:
    source_db: Path
    analysis_db: Path
    dify_base_url: str
    dify_api_key: str
    batch_limit: int = 100
    timeout_seconds: float = 120.0
    dify_user: str = "feedback-backend"

    @classmethod
    def from_env(cls) -> "Settings":
        source_db = _first_env("FEEDBACK_SOURCE_DB_PATH", "THREAT_SOURCE_DB_PATH")
        analysis_db = _first_env("FEEDBACK_ANALYSIS_DB_PATH", "THREAT_ANALYSIS_DB_PATH")
        dify_base_url = _first_env("DIFY_FEEDBACK_BASE_URL", "DIFY_BASE_URL")
        dify_api_key = _first_env("DIFY_FEEDBACK_API_KEY")

        missing = [
            name
            for name, value in (
                ("FEEDBACK_SOURCE_DB_PATH/THREAT_SOURCE_DB_PATH", source_db),
                ("FEEDBACK_ANALYSIS_DB_PATH/THREAT_ANALYSIS_DB_PATH", analysis_db),
                ("DIFY_FEEDBACK_BASE_URL/DIFY_BASE_URL", dify_base_url),
                ("DIFY_FEEDBACK_API_KEY", dify_api_key),
            )
            if not value
        ]
        if missing:
            raise ValueError("missing required configuration: " + ", ".join(missing))

        return cls(
            source_db=Path(source_db),
            analysis_db=Path(analysis_db),
            dify_base_url=dify_base_url.rstrip("/"),
            dify_api_key=dify_api_key,
            batch_limit=int(_first_env("FEEDBACK_BATCH_LIMIT", default="100") or "100"),
            timeout_seconds=float(_first_env("DIFY_FEEDBACK_TIMEOUT_SECONDS", default="120") or "120"),
            dify_user=_first_env("DIFY_FEEDBACK_USER", default="feedback-backend") or "feedback-backend",
        )
