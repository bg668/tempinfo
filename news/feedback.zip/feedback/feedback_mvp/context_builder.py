from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .models import FeedbackContext, FeedbackRecord
from .repository import FeedbackRepository


class FeedbackContextBuilder:
    def __init__(self, repository: FeedbackRepository, runtime_context_path: Path):
        self.repository = repository
        self.runtime_context_path = Path(runtime_context_path)

    def build(self, feedback: FeedbackRecord) -> FeedbackContext:
        runtime_text = self.runtime_context_path.read_text(encoding="utf-8").strip()
        if not runtime_text:
            raise ValueError(f"runtime context is empty: {self.runtime_context_path}")

        if feedback.target_type == "processing_item":
            target = self.repository.get_processing_item(feedback.target_id)
            if target is None:
                raise LookupError(f"processing_item not found: {feedback.target_id}")
            related_items = [target]
            previous_judgement = {
                "target_type": "processing_item",
                "processing_item": target,
            }
        elif feedback.target_type == "candidate":
            target = self.repository.get_candidate(feedback.target_id)
            if target is None:
                raise LookupError(f"candidate not found: {feedback.target_id}")
            related_items = self.repository.list_processing_items_for_candidate(feedback.target_id)
            previous_judgement = {
                "target_type": "candidate",
                "candidate": target,
                "processing_items": related_items,
            }
        else:
            raise ValueError(f"unsupported feedback target_type: {feedback.target_type}")

        article_ids = _unique_nonempty(
            str(row.get("source_article_id", "")) for row in related_items
        )
        if not article_ids:
            raise LookupError(f"no source_article_id found for feedback target: {feedback.target_id}")

        articles = self.repository.list_articles(article_ids)
        if not articles:
            raise LookupError(
                "article_contents not found for source_article_id(s): " + ", ".join(article_ids)
            )

        versions = _unique_nonempty(
            str(row.get("processing_version", "")) for row in related_items
        )
        historical_runtime = runtime_text
        if versions:
            historical_runtime = (
                "处理记录中的 processing_version: " + ", ".join(versions) + "\n\n" + runtime_text
            )

        return FeedbackContext(
            feedback_id=feedback.feedback_id,
            target_type=feedback.target_type,
            feedback_content=feedback.content,
            source_material=json.dumps(
                {"articles": [_json_safe(row) for row in articles]},
                ensure_ascii=False,
                separators=(",", ":"),
            ),
            previous_judgement=json.dumps(
                _json_safe(previous_judgement),
                ensure_ascii=False,
                separators=(",", ":"),
            ),
            historical_runtime=historical_runtime,
            current_runtime="",
        )


def _unique_nonempty(values) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        value = value.strip()
        if value and value not in seen:
            seen.add(value)
            result.append(value)
    return result


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value
