from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

from .models import FeedbackContext, WorkflowResult


@dataclass(frozen=True)
class DifyResponse:
    workflow_run_id: str | None
    result: WorkflowResult


class DifyFeedbackClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        timeout_seconds: float = 120.0,
        user: str = "feedback-backend",
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds
        self.user = user

    def analyze(self, context: FeedbackContext) -> DifyResponse:
        endpoint = self._workflow_endpoint()
        payload = {
            "inputs": context.to_dify_inputs(),
            "response_mode": "blocking",
            "user": self.user,
        }
        request = urllib.request.Request(
            endpoint,
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            method="POST",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                body = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Dify HTTP {exc.code}: {detail[:2000]}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Dify request failed: {exc.reason}") from exc

        try:
            raw = json.loads(body)
        except json.JSONDecodeError as exc:
            raise ValueError("Dify response is not valid JSON") from exc
        if not isinstance(raw, dict):
            raise ValueError("Dify response must be a JSON object")

        data = raw.get("data")
        if not isinstance(data, dict):
            raise ValueError("Dify response missing data object")
        status = data.get("status")
        if status != "succeeded":
            raise RuntimeError(f"Dify workflow failed: status={status!r}, error={data.get('error')!r}")
        outputs = data.get("outputs")
        if not isinstance(outputs, dict) or "result" not in outputs:
            raise ValueError("Dify response missing data.outputs.result")

        result_raw: Any = outputs["result"]
        if isinstance(result_raw, str):
            try:
                result_raw = json.loads(result_raw)
            except json.JSONDecodeError as exc:
                raise ValueError("Dify outputs.result string is not valid JSON") from exc

        workflow_run_id = raw.get("workflow_run_id") or data.get("id")
        return DifyResponse(
            workflow_run_id=str(workflow_run_id) if workflow_run_id else None,
            result=WorkflowResult.from_mapping(result_raw),
        )

    def _workflow_endpoint(self) -> str:
        if self.base_url.endswith("/v1"):
            return self.base_url + "/workflows/run"
        return self.base_url + "/v1/workflows/run"
