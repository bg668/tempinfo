from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from zoneinfo import ZoneInfo
from uuid import uuid4

from .context_builder import FeedbackContextBuilder
from .dify_client import DifyFeedbackClient
from .repository import FeedbackRepository

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class BatchSummary:
    pending: int
    succeeded: int
    failed: int
    proposals: int


class FeedbackProcessor:
    def __init__(
        self,
        *,
        repository: FeedbackRepository,
        context_builder: FeedbackContextBuilder,
        dify_client: DifyFeedbackClient,
    ):
        self.repository = repository
        self.context_builder = context_builder
        self.dify_client = dify_client

    def run_batch(self, *, limit: int = 100) -> BatchSummary:
        self.repository.ensure_schema()
        pending = self.repository.list_pending_feedback(limit=limit)
        succeeded = 0
        failed = 0
        proposals = 0

        for feedback in pending:
            try:
                context = self.context_builder.build(feedback)
                response = self.dify_client.analyze(context)
                result = response.result
                now = datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds")
                analysis_id = "analysis_" + uuid4().hex
                proposal_id = "proposal_" + uuid4().hex if result.change_proposal.need_change else None
                self.repository.save_result(
                    feedback_id=feedback.feedback_id,
                    analysis_id=analysis_id,
                    proposal_id=proposal_id,
                    analysis=result.feedback_analysis,
                    proposal=result.change_proposal,
                    created_at=now,
                )
                succeeded += 1
                if result.change_proposal.need_change:
                    proposals += 1
                logger.info(
                    "feedback_processed feedback_id=%s target_type=%s target_id=%s dify_run_id=%s need_change=%s",
                    feedback.feedback_id,
                    feedback.target_type,
                    feedback.target_id,
                    response.workflow_run_id,
                    result.change_proposal.need_change,
                )
            except Exception:
                failed += 1
                logger.exception(
                    "feedback_processing_failed feedback_id=%s target_type=%s target_id=%s",
                    feedback.feedback_id,
                    feedback.target_type,
                    feedback.target_id,
                )
                continue

        return BatchSummary(
            pending=len(pending),
            succeeded=succeeded,
            failed=failed,
            proposals=proposals,
        )
