from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from .models import ChangeProposal, FeedbackAnalysis, FeedbackRecord


class FeedbackRepository:
    def __init__(self, analysis_db: Path, source_db: Path):
        self.analysis_db = Path(analysis_db)
        self.source_db = Path(source_db)

    def ensure_schema(self) -> None:
        schema_path = Path(__file__).with_name("schema.sql")
        with self._analysis_connection() as conn:
            self._validate_feedback_table(conn)
            conn.executescript(schema_path.read_text(encoding="utf-8"))
            conn.commit()

    @staticmethod
    def _validate_feedback_table(conn: sqlite3.Connection) -> None:
        row = conn.execute(
            "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'feedback' LIMIT 1"
        ).fetchone()
        if row is None:
            raise RuntimeError("required backend table not found: feedback")

        columns = {
            str(item["name"]): str(item["type"] or "").upper()
            for item in conn.execute("PRAGMA table_info(feedback)").fetchall()
        }
        required = {
            "feedback_id": "TEXT",
            "target_type": "TEXT",
            "target_id": "TEXT",
            "content": "TEXT",
            "created_at": "TEXT",
        }
        missing = [name for name in required if name not in columns]
        if missing:
            raise RuntimeError(
                "feedback table is incompatible; missing column(s): " + ", ".join(missing)
            )
        wrong_types = [
            f"{name}={columns[name]}"
            for name, expected in required.items()
            if columns[name] != expected
        ]
        if wrong_types:
            raise RuntimeError(
                "feedback table is incompatible; expected TEXT column(s): " + ", ".join(wrong_types)
            )

    def list_pending_feedback(self, limit: int = 100) -> list[FeedbackRecord]:
        sql = """
            SELECT f.feedback_id, f.target_type, f.target_id, f.content, f.created_at
            FROM feedback AS f
            LEFT JOIN feedback_analysis AS a
                ON a.feedback_id = f.feedback_id
            WHERE a.feedback_id IS NULL
            ORDER BY f.created_at ASC, f.feedback_id ASC
            LIMIT ?
        """
        with self._analysis_connection(read_only=True) as conn:
            rows = conn.execute(sql, (int(limit),)).fetchall()
        return [
            FeedbackRecord(
                feedback_id=str(row["feedback_id"]),
                target_type=str(row["target_type"]),
                target_id=str(row["target_id"]),
                content=str(row["content"]),
                created_at=str(row["created_at"]),
            )
            for row in rows
        ]

    def get_processing_item(self, item_id: str) -> dict[str, Any] | None:
        with self._analysis_connection(read_only=True) as conn:
            row = conn.execute(
                "SELECT * FROM processing_items WHERE item_id = ? LIMIT 1",
                (item_id,),
            ).fetchone()
        return _row_to_dict(row)

    def get_candidate(self, candidate_record_id: str) -> dict[str, Any] | None:
        with self._analysis_connection(read_only=True) as conn:
            row = conn.execute(
                "SELECT * FROM candidates WHERE candidate_record_id = ? LIMIT 1",
                (candidate_record_id,),
            ).fetchone()
        return _row_to_dict(row)

    def list_processing_items_for_candidate(self, candidate_record_id: str) -> list[dict[str, Any]]:
        with self._analysis_connection(read_only=True) as conn:
            rows = conn.execute(
                "SELECT * FROM processing_items WHERE candidate_record_id = ? ORDER BY item_id",
                (candidate_record_id,),
            ).fetchall()
        return [_row_to_dict(row) for row in rows if row is not None]

    def list_articles(self, article_ids: list[str]) -> list[dict[str, Any]]:
        if not article_ids:
            return []
        normalized: list[int | str] = []
        for article_id in article_ids:
            text = str(article_id).strip()
            normalized.append(int(text) if text.isdigit() else text)
        placeholders = ",".join("?" for _ in normalized)
        sql = f"""
            SELECT article_id, url, title, account, published_at, content, fetched_at
            FROM article_contents
            WHERE article_id IN ({placeholders})
            ORDER BY article_id
        """
        with self._source_connection(read_only=True) as conn:
            rows = conn.execute(sql, normalized).fetchall()
        return [_row_to_dict(row) for row in rows if row is not None]

    def save_result(
        self,
        *,
        feedback_id: str,
        analysis_id: str,
        proposal_id: str | None,
        analysis: FeedbackAnalysis,
        proposal: ChangeProposal,
        created_at: str,
    ) -> None:
        with self._analysis_connection() as conn:
            conn.execute("BEGIN")
            conn.execute(
                """
                INSERT INTO feedback_analysis (
                    analysis_id, feedback_id, issue, issue_type, affected_stage,
                    root_cause, systemic_risk, confidence, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    analysis_id,
                    feedback_id,
                    analysis.issue,
                    analysis.issue_type,
                    analysis.affected_stage,
                    analysis.root_cause,
                    1 if analysis.systemic_risk else 0,
                    analysis.confidence,
                    created_at,
                ),
            )
            if proposal.need_change:
                if not proposal_id:
                    raise ValueError("proposal_id is required when need_change=true")
                conn.execute(
                    """
                    INSERT INTO change_proposal (
                        proposal_id, feedback_id, analysis_id, need_change,
                        target, suggestion, reason, risk, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        proposal_id,
                        feedback_id,
                        analysis_id,
                        1,
                        proposal.target,
                        proposal.suggestion,
                        proposal.reason,
                        proposal.risk,
                        created_at,
                    ),
                )
            conn.commit()

    @contextmanager
    def _analysis_connection(self, *, read_only: bool = False) -> Iterator[sqlite3.Connection]:
        with _connect(self.analysis_db, read_only=read_only) as conn:
            yield conn

    @contextmanager
    def _source_connection(self, *, read_only: bool = False) -> Iterator[sqlite3.Connection]:
        with _connect(self.source_db, read_only=read_only) as conn:
            yield conn


@contextmanager
def _connect(path: Path, *, read_only: bool) -> Iterator[sqlite3.Connection]:
    if read_only:
        uri = f"file:{path.resolve().as_posix()}?mode=ro"
        conn = sqlite3.connect(uri, uri=True, timeout=30)
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(path, timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def _row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    return {key: row[key] for key in row.keys()}
