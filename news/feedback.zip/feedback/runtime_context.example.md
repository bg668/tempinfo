# 当前资讯处理策略 / Prompt 上下文

把当前用于生成 processing_items / candidates 的筛选策略、关键 Prompt 或规则摘要放在这里。
MVP 不做版本比较；后台会把处理记录中的 processing_version 与本文一起传给 Feedback Workflow。
