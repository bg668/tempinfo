from feedback_mvp.cli import main

raise SystemExit(main())
