from __future__ import annotations

import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from feedback_mvp.context_builder import FeedbackContextBuilder
from feedback_mvp.models import FeedbackRecord, WorkflowResult
from feedback_mvp.processor import FeedbackProcessor
from feedback_mvp.repository import FeedbackRepository
from feedback_mvp.dify_client import DifyResponse


class FakeDifyClient:
    def analyze(self, context):
        raw = {
            "feedback_analysis": {
                "issue": "摘要遗漏关键事实",
                "issue_type": "prompt",
                "affected_stage": "candidate_generation",
                "root_cause": "摘要约束未要求保留该事实",
                "systemic_risk": True,
                "confidence": 0.9,
            },
            "change_proposal": {
                "need_change": True,
                "target": "prompt",
                "suggestion": "在摘要要求中增加关键事实保留约束",
                "reason": "同类内容可能重复遗漏",
                "risk": "摘要长度可能略增加",
            },
        }
        return DifyResponse("run_test", WorkflowResult.from_mapping(raw))


class FeedbackMvpTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.source_db = root / "collector.db"
        self.analysis_db = root / "newsagent.db"
        self._seed_source()
        self._seed_analysis()

    def tearDown(self):
        self.tmp.cleanup()

    def _seed_source(self):
        with sqlite3.connect(self.source_db) as conn:
            conn.executescript(
                """
                CREATE TABLE article_contents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    article_id INTEGER NOT NULL UNIQUE,
                    url TEXT NOT NULL UNIQUE,
                    title TEXT,
                    account TEXT,
                    published_at TEXT,
                    content TEXT NOT NULL,
                    fetched_at TEXT NOT NULL
                );
                INSERT INTO article_contents(article_id,url,title,account,published_at,content,fetched_at)
                VALUES(1001,'https://example.test/1','测试标题','测试来源','2026-09-18 08:00:00','原始正文关键事实','2026-09-18T08:01:00+08:00');
                """
            )

    def _seed_analysis(self):
        with sqlite3.connect(self.analysis_db) as conn:
            conn.executescript(
                """
                CREATE TABLE feedback (
                    feedback_id TEXT PRIMARY KEY NOT NULL,
                    target_type TEXT NOT NULL CHECK (target_type IN ('candidate','processing_item')),
                    target_id TEXT NOT NULL CHECK (length(trim(target_id)) > 0),
                    content TEXT NOT NULL CHECK (length(trim(content)) BETWEEN 1 AND 5000),
                    created_at TEXT NOT NULL
                );
                CREATE TABLE processing_items (
                    item_id TEXT PRIMARY KEY,
                    source_article_id TEXT NOT NULL,
                    candidate_record_id TEXT,
                    title TEXT,
                    summary TEXT,
                    reason TEXT,
                    processing_version TEXT
                );
                CREATE TABLE candidates (
                    candidate_record_id TEXT PRIMARY KEY,
                    primary_item_id TEXT,
                    title TEXT,
                    summary TEXT,
                    reason TEXT
                );
                INSERT INTO processing_items VALUES('item_1','1001','cand_1','旧标题','旧摘要','旧理由','news-local-v1-test');
                INSERT INTO candidates VALUES('cand_1','item_1','候选标题','候选摘要','候选理由');
                INSERT INTO feedback VALUES('fb_1','candidate','cand_1','这里遗漏了关键事实','2026-09-18T09:00:00+08:00');
                """
            )

    def test_candidate_context(self):
        repo = FeedbackRepository(self.analysis_db, self.source_db)
        repo.ensure_schema()
        feedback = repo.list_pending_feedback()[0]
        ctx = FeedbackContextBuilder(repo).build(feedback)
        source = json.loads(ctx.source_material)
        judgement = json.loads(ctx.previous_judgement)
        self.assertEqual(source["articles"][0]["title"], "测试标题")
        self.assertEqual(judgement["candidate"]["candidate_record_id"], "cand_1")
        self.assertEqual(
            set(ctx.to_dify_inputs()),
            {"target_type", "feedback_content", "source_material", "previous_judgement"},
        )


    def test_processing_item_context(self):
        with sqlite3.connect(self.analysis_db) as conn:
            conn.execute(
                "INSERT INTO feedback VALUES(?,?,?,?,?)",
                ("fb_2", "processing_item", "item_1", "处理记录判断有问题", "2026-09-18T09:01:00+08:00"),
            )
        repo = FeedbackRepository(self.analysis_db, self.source_db)
        repo.ensure_schema()
        feedback = [x for x in repo.list_pending_feedback() if x.feedback_id == "fb_2"][0]
        ctx = FeedbackContextBuilder(repo).build(feedback)
        judgement = json.loads(ctx.previous_judgement)
        self.assertEqual(judgement["processing_item"]["item_id"], "item_1")
        self.assertEqual(ctx.target_type, "processing_item")

    def test_end_to_end_write(self):
        repo = FeedbackRepository(self.analysis_db, self.source_db)
        processor = FeedbackProcessor(
            repository=repo,
            context_builder=FeedbackContextBuilder(repo),
            dify_client=FakeDifyClient(),
        )
        summary = processor.run_batch()
        self.assertEqual(summary.succeeded, 1)
        self.assertEqual(summary.proposals, 1)
        self.assertEqual(len(repo.list_pending_feedback()), 0)
        with sqlite3.connect(self.analysis_db) as conn:
            analysis_count = conn.execute("SELECT COUNT(*) FROM feedback_analysis").fetchone()[0]
            proposal_count = conn.execute("SELECT COUNT(*) FROM change_proposal").fetchone()[0]
        self.assertEqual(analysis_count, 1)
        self.assertEqual(proposal_count, 1)

    def test_no_proposal_when_need_change_false(self):
        raw = {
            "feedback_analysis": {
                "issue": "未发现问题",
                "issue_type": "no_issue",
                "affected_stage": "unknown",
                "root_cause": "现有判断与输入一致",
                "systemic_risk": False,
                "confidence": 0.8,
            },
            "change_proposal": {
                "need_change": False,
                "target": "none",
                "suggestion": "无需修改",
                "reason": "反馈未指出实际缺陷",
                "risk": "无",
            },
        }
        result = WorkflowResult.from_mapping(raw)
        self.assertFalse(result.change_proposal.need_change)

    def test_feedback_schema_matches_backend_contract(self):
        repo = FeedbackRepository(self.analysis_db, self.source_db)
        repo.ensure_schema()
        with sqlite3.connect(self.analysis_db) as conn:
            ddl = conn.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='feedback'"
            ).fetchone()[0]
        self.assertIn("target_type IN ('candidate','processing_item')", ddl)
        self.assertIn("length(trim(content)) BETWEEN 1 AND 5000", ddl)

    def test_feedback_schema_validation_rejects_missing_column(self):
        broken_db = Path(self.tmp.name) / "broken.db"
        with sqlite3.connect(broken_db) as conn:
            conn.execute(
                "CREATE TABLE feedback (feedback_id TEXT PRIMARY KEY, target_type TEXT, target_id TEXT, content TEXT)"
            )
        repo = FeedbackRepository(broken_db, self.source_db)
        with self.assertRaisesRegex(RuntimeError, r"missing column\(s\): created_at"):
            repo.ensure_schema()


if __name__ == "__main__":
    unittest.main()
