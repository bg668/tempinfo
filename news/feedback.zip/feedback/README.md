# Feedback Agent 后台 MVP

当前链路：

`feedback 未处理记录 → 组装原始文章/原研判 → 调 Dify Feedback Workflow → 写 feedback_analysis；need_change=true 时再写 change_proposal`

## 数据库

现有 `feedback` 表不修改。Backend/Analysis DB 读取 `feedback / processing_items / candidates` 并写入 `feedback_analysis / change_proposal`；Source DB 只读 `article_contents`。

## Dify 输入

Python 只向 Feedback Workflow 传 4 个字段：

- `target_type`
- `feedback_content`
- `source_material`
- `previous_judgement`

业务关注范围、反馈判断规则和修改原则全部由 Dify Workflow 的 LLM Prompt 定义。Python 不再读取或维护策略/Prompt 文件。

因此旧配置 `FEEDBACK_RUNTIME_CONTEXT_PATH` 已删除，不再需要 `runtime_context.example.md`。

## 必需配置

```env
THREAT_SOURCE_DB_PATH=data/collector.db
THREAT_ANALYSIS_DB_PATH=data/newsagent.db
DIFY_FEEDBACK_BASE_URL=http://127.0.0.1
DIFY_FEEDBACK_API_KEY=app-REPLACE_ME
```

可选：

```env
FEEDBACK_BATCH_LIMIT=100
DIFY_FEEDBACK_TIMEOUT_SECONDS=120
DIFY_FEEDBACK_USER=feedback-backend
```

## 运行

初始化两张结果表：

```bash
uv run --env-file .env python run_feedback.py --init-db
```

处理所有尚无 `feedback_analysis` 的 feedback：

```bash
uv run --env-file .env python run_feedback.py
```

限制单次处理数量：

```bash
uv run --env-file .env python run_feedback.py --limit 20
```

单条处理失败时不会写 `feedback_analysis`，下次运行会自然再次处理。
