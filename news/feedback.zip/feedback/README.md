# Feedback Agent 后台 MVP

只实现一条链路：

`feedback 未处理记录 → 组装原始文章/原研判/当前策略上下文 → 调 Dify Feedback Workflow → 写 feedback_analysis；need_change=true 时再写 change_proposal`

## 1. 数据库

现有 `feedback` 表不修改。当前代码已按 Backend 的真实表契约对接：

```sql
CREATE TABLE feedback (
    feedback_id TEXT PRIMARY KEY NOT NULL,
    target_type TEXT NOT NULL CHECK (target_type IN ('candidate','processing_item')),
    target_id TEXT NOT NULL CHECK (length(trim(target_id)) > 0),
    content TEXT NOT NULL CHECK (length(trim(content)) BETWEEN 1 AND 5000),
    created_at TEXT NOT NULL
);
```

启动时会校验这 5 个字段是否存在且为 TEXT；不修改 `feedback` 表。随后在同一个 Backend/Analysis DB 中创建两张结果表：

- `feedback_analysis`：每条反馈的根因分析，一条 feedback 最多一条。
- `change_proposal`：仅当 Dify 返回 `need_change=true` 时创建。

Source DB 只读 `article_contents`。Backend/Analysis DB 读取 `feedback / processing_items / candidates` 并写两张结果表。

因此 `THREAT_ANALYSIS_DB_PATH` 应指向当前 Backend 实际使用、包含上述三张业务表的 SQLite 数据库。

## 2. 上下文关联

- `target_type=processing_item`：`feedback.target_id → processing_items.item_id → source_article_id → article_contents.article_id`
- `target_type=candidate`：`feedback.target_id → candidates.candidate_record_id`，同时通过 `processing_items.candidate_record_id` 找到关联处理记录和 `source_article_id`。
- 原始标题、账号、发布时间和正文都读取 `article_contents`，不会使用 `feed_items` 中可能乱码的 title/account。

## 3. 配置

复制 `.env.example` 中的变量到你的运行环境。程序本身不读取 `.env`，如果项目原来通过 `uv run --env-file .env ...` 启动，可以继续沿用。

必须配置：

- `THREAT_SOURCE_DB_PATH`
- `THREAT_ANALYSIS_DB_PATH`
- `DIFY_FEEDBACK_BASE_URL`
- `DIFY_FEEDBACK_API_KEY`
- `FEEDBACK_RUNTIME_CONTEXT_PATH`

`FEEDBACK_RUNTIME_CONTEXT_PATH` 指向一份文本/Markdown/YAML 文件，内容放当前资讯处理的筛选策略和关键 Prompt。MVP 不做历史/当前版本比较；处理记录里的 `processing_version` 会自动附在这份内容前面。

## 4. 初始化

```bash
uv run --env-file .env python run_feedback.py --init-db
```

只创建 `feedback_analysis` 和 `change_proposal`。

## 5. 处理新增反馈

```bash
uv run --env-file .env python run_feedback.py
```

或限制本轮最多处理 20 条：

```bash
uv run --env-file .env python run_feedback.py --limit 20
```

后台定时器只需要每天固定时间执行这条命令即可。

## 6. 未处理判定

程序只查询不存在 `feedback_analysis` 的 feedback。某条调用失败时不会落 `feedback_analysis`，下一次执行自然会再次处理，不额外引入任务状态表或 retry_count。

## 7. Dify 输入/输出

请求使用 blocking 模式调用发布后的 Workflow `/v1/workflows/run`。

传入字段和已经生成的 `feedback_agent_workflow_v0.7.yml` 一致：

- `target_type`
- `feedback_content`
- `source_material`
- `previous_judgement`
- `historical_runtime`
- `current_runtime`（MVP 固定为空）

要求 End 节点返回 `outputs.result` JSON object，其中包含：

- `feedback_analysis`
- `change_proposal`

后台会再次校验枚举、必填字符串、boolean 和 confidence 0~1。结构不合法则本条失败且不写数据库。

## 8. MVP 明确不做

不做版本比较、任务状态机、重试计数、聚类、Eval、人工审批状态、自动修改 Prompt/Workflow。先跑通完整链路。
