# 安全资讯工作流 v5：代码架构清理

v4.1 修复了 `<think>` 过滤，仍保留历史代码包装。本版完成主控及四个子流程全部 19 个 Code 节点的冗余清理。

## 本次修改

- 每个 Code 节点只有一个 `main`，删除 `_legacy_main`、`_v2_main`、`_v3_result_main` 包装及无用函数、重复定义和导入。
- 子流程内部函数直接传递 Python 对象，结果仅在入口返回时编码为 `result_json`。主控也移除了被覆盖的旧 Markdown 和中间结果序列化。
- 快讯处理分为父级覆盖校验、单项校验和结果出口。保留原子隔离：一项有误时整篇快讯不发布候选，但保留处理记录。
- 公共解析、IOC 和业务校验函数在 `source/common.py` 集中维护；各节点业务代码在 `source/nodes/`，配置在 `source/templates/`。构建脚本按依赖嵌入必要函数，导入 Dify 后不依赖外部 Python 文件。
- 保留六个 LLM 解析入口的 `<think>` 清洗。只移除开头完整推理块；未闭合块、空答案继续报错；主控 JSON 和原文字面标签不作全局删除。

JSON → 树文本 → LLM → 树文本 → JSON 的接口、两表字段、CSV 34 列、结束节点七个输出、工具绑定、模型提示词、连线和容器布局均保持。`processing_version` 升级至 v5。

部分错误码仍含 `legacy_validation` 字样，以保持消费方诊断兼容；它们是稳定字符串，不是旧实现或多层入口。原始 IOC 结构校验与事实校验仍各自保留，避免删掉实际防错规则。

## 更新方法

1. 更新并发布包内 01～04 四个子工作流，再更新 00 主控。
2. 沿用原应用及原 Workflow Tool 且工具 ID 不变时，输入输出契约无需调整。
3. 如导入为新应用或重新创建工具，重新导出含四个工具的临时 DSL，用下列脚本绑定真实工具信息后再导入主控。

```powershell
python tools\bind_main_workflow.py `
  --template "00_主控工作流_最终_Dify1.17_CSV.yml" `
  --tool-dsl "临时工具工作流.yml" `
  --output "00_主控工作流_已绑定.yml"
```

工具调用名依次为 `news_digest_process`、`news_article_process`、`news_event_match`、`news_event_candidate`。01、02 的工具参数为 `article_json`，不接受早期 `article_text` 契约。模型和 File Tools 插件沿用实际环境配置；包内主控保留此前提供的真实工具 ID。

## 输入输出

主控仍接收 `articles_json`：采集文章数组或含 `articles` 数组的对象。支持 account/publisher/author、content/body_text/article_text 等既有别名。文章对象的 source_article_id/title/url/content 必填；来源元数据禁止换行，正文允许换行和缩进。

01、02 接收单个文章对象的 JSON 字符串 `article_json`；01 另外保留 verbose。03 接收 incidents_json、grouping_mode；04 接收 group_json。所有子流程继续返回原 result_json 业务契约，主控不把 JSON 直接发送给模型。01、02 单独测试可使用 examples/article_01.json 和 article_02.json 的全文。

主控按 max_content_chars 裁剪正文并传递 content_chars/content_truncated。01、02 入口还设置 100000 字符正文上限，超长输入会明确标记截断；快讯覆盖检查保留原规则。无效 JSON/缺少必填字段在子流程输入 Code 节点失败，模型不执行；主控工具错误路径会将其记录为 FAILED，不伪造 DROP/UNCERTAIN。采集源已入库正文不在本版重复存储。

最终文件：

| 文件 | 内容 |
|---|---|
| 处理结果_run_xxx.json | schema_version/run_id/processing_version/process_status/stats/errors/warnings，以及 processing_items、candidates 完整数组 |
| 候选审核_run_xxx.csv | 原有 34 列人工审核视图，仅有效候选；保留来源账号、关联 ID、评分和审核字段 |

JSON 中 `*_json` 表字段为实际 JSON 对象/数组或 null，供程序解析；不再套一层转义字符串。两表字段未删减。DROP、UNCERTAIN、失败及快讯父记录都在 processing_items 中；人工反馈初始化仍为 pending/null。created_at/updated_at 等入库时间为 null，由真正入库的程序填写；本版不写数据库、不处理 CSV 回传反馈。

结束节点仅输出：run_id、run_status、stats、export_status、error_summary、result_json_file、review_csv_file。两个文件输出均为 array[file]，不输出完整候选 JSON 或长篇 Markdown。文件下载入口是工作流交付物，不是已经完成数据库持久化的凭证；接收程序如需长期保存应下载归档。

统计区分输入文章、处理记录、叶子记录、候选数量。新增 keep_count/drop_count/uncertain_count 按有效叶子判断统计，快讯父记录不计入；KEEP 且后续抽取失败可能同时计入 processing_failed_count，这两种统计不是互斥分类。

run_status 表示处理及本次导出的整体情况。两文件正常返回后保留 SUCCESS/PARTIAL/FAILED 业务状态；空文件返回强制 FAILED。工具抛出运行错误时 Dify 运行直接失败，正常结束节点不会执行，不会把未完成导出报告为成功。JSON 内 process_status 仅表示处理阶段结果，不代表后续 CSV 已成功生成。

## 字段与版本

表字段与产生阶段见 docs/FIELD_ORIGINS.md。input_hash 自 v4 起按规范化单篇 JSON 的 UTF-8 字节 SHA-256 计算，JSON 使用排序键和固定分隔符；input_meta_json.hash_basis=canonical_article_json_v1。同一规范化输入跨批次哈希一致，但不能与旧版树文本哈希直接比较。processing_version 已升级，用于区分版本。

完整 JSON 可关联既有采集库，并完整保留两表关系及人工字段；CSV 只作审核投影，不应当作无损入库数据源。

## 验证与源码维护

本版 57 项离线测试通过；431 次调用覆盖全部 19 个 Code 节点，与 v4.1 的业务输出一致。另检查了节点参数、变量上游、容器范围、依赖和工具绑定。样例仍为 5 条资讯处理记录、3 条候选和 3 行 CSV。未在实际 Dify 环境执行导入、发布和文件下载测试。

```powershell
python -m pip install PyYAML
python source\build.py
python -m unittest discover -s tests -p "test*.py" -v
python tests\validate_dsl.py
```

`build.py` 直接覆盖解压目录根部的五份 DSL；无需历史版本代码。只修改源码和模板，然后重新构建，不在 YAML 内追加补丁包装。报告见 `VALIDATION_REPORT.json`、`COMPARISON_REPORT.json`。

若需自行复核与 v4.1 的差分结果：

```powershell
python tests\compare_release.py --baseline "此前v4.1解压目录" --report comparison.json
```

`tests/fixtures/` 只保存接口及图配置的历史测试基线，不参与构建；`examples/fixture_*` 为固定模型响应生成的示例，文件对象使用离线占位元数据，不是真实下载地址。
