import ast
import builtins
import copy
import json
from pathlib import Path
import symtable
import unittest
import yaml
import test_regression as fixture


class ArchitectureTests(unittest.TestCase):
    def test_all_nodes_have_one_entry_and_resolved_globals(self):
        for path in fixture.RELEASE.glob('*.yml'):
            doc = yaml.safe_load(path.read_text())
            for node in doc['workflow']['graph']['nodes']:
                if node['data']['type'] != 'code':
                    continue
                code = node['data']['code']
                parsed = ast.parse(code)
                functions = [n.name for n in parsed.body if isinstance(n, ast.FunctionDef)]
                self.assertEqual(functions.count('main'), 1)
                self.assertEqual(len(functions), len(set(functions)))
                module = symtable.symtable(code, path.name, 'exec')
                known = set(module.get_identifiers()) | set(dir(builtins))
                pending = list(module.get_children())
                while pending:
                    scope = pending.pop()
                    pending.extend(scope.get_children())
                    missing = [s.get_name() for s in scope.get_symbols()
                               if s.is_global() and s.is_referenced() and s.get_name() not in known]
                    self.assertEqual(missing, [], (path.name, node['id'], scope.get_name()))

    def test_child_results_serialize_only_at_entry_boundary(self):
        for prefix, node in [('01', '300'), ('02', '510'), ('02', '610'), ('02', '700'), ('04', '400')]:
            doc = yaml.safe_load(next(fixture.RELEASE.glob(prefix + '*.yml')).read_text())
            code = next(n['data']['code'] for n in doc['workflow']['graph']['nodes'] if n['id'] == node)
            owners = []
            for fn in ast.parse(code).body:
                if not isinstance(fn, ast.FunctionDef):
                    continue
                for item in ast.walk(fn):
                    if isinstance(item, ast.Dict) and any(isinstance(k, ast.Constant) and k.value == 'result_json' for k in item.keys):
                        owners.append(fn.name)
            self.assertEqual(owners, ['main'])

    def members(self):
        fixture.WorkflowTests.setUpClass()
        f = fixture.WorkflowTests()
        first = fixture.decode(f.incident())
        second = copy.deepcopy(first)
        for field in ('article', 'facts', 'triage'):
            second[field]['source_article_id'] = 'A-SEC-002'
        return [first, second]

    def test_group_input_rendering_and_route(self):
        rows = self.members()
        value = fixture.invoke('03', '200', incidents_json=json.dumps(rows), grouping_mode='event_match')
        self.assertEqual(value['route'], 'event_match')
        self.assertEqual(value['incident_count'], 2)
        self.assertTrue(value['incidents_text'].startswith('event_match_input:\n'))
        self.assertIn('    A-SEC-001:', value['incidents_text'])
        self.assertNotIn('_validation_error', value['incidents_text'])
        single = fixture.invoke('03', '200', incidents_json=json.dumps(rows[:1]), grouping_mode='event_match')
        self.assertEqual(single['route'], 'singleton')

    def test_group_validator_repairs_duplicate_and_missing_members(self):
        rows = self.members()
        draft = {'groups': {'group_001': {'canonical_title': '制造企业勒索事件',
                  'member_article_ids': ['A-SEC-001', 'A-SEC-001'], 'match_reason': '同一事件'}}}
        output = fixture.decode(fixture.invoke('03', '410', incidents_json=json.dumps(rows),
            raw='<think>内部推理</think>' + fixture.raw('event_match_result', draft)))
        self.assertTrue(output['degraded'])
        ids = [sid for g in output['groups'] for sid in g['member_article_ids']]
        self.assertEqual(ids, ['A-SEC-001', 'A-SEC-002'])
        self.assertIn('unknown_or_duplicate:A-SEC-001', output['errors'])

    def test_candidate_renderer_and_unclosed_group_reasoning(self):
        rows = self.members()
        repaired = fixture.decode(fixture.invoke('03', '410', incidents_json=json.dumps(rows), raw='<think>unfinished'))
        self.assertIn('model_reasoning_unclosed', str(repaired['errors']))
        self.assertEqual(len(repaired['groups']), 2)
        text = fixture.invoke('04', '200', group_json=json.dumps(repaired['groups'][0]))['candidate_input_text']
        self.assertTrue(text.startswith('event_candidate_input:\n'))
        self.assertIn('  source_count: 1', text)
        self.assertNotIn('_validation_error', text)


if __name__ == '__main__':
    unittest.main()
