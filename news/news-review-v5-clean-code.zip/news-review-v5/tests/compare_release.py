"""Replay regression calls against an older release and compare semantic outputs.

Usage: python tests/compare_release.py --baseline /path/to/v4.1 --report comparison.json
Only processing_version and the random run UUID are controlled. Business fields,
errors, ordering, output CSV text and JSON tables must remain equivalent.
"""
import argparse
import copy
import io
import json
from pathlib import Path
import unittest
from unittest.mock import patch
import uuid
import yaml
import test_regression as fixture


def normalize(value):
    if isinstance(value, dict):
        return {key: '__VERSION__' if key == 'processing_version' else normalize(child)
                for key, child in value.items()}
    if isinstance(value, (list, tuple)):
        return [normalize(child) for child in value]
    if isinstance(value, str) and value.startswith(('{', '[')):
        try:
            return normalize(json.loads(value))
        except ValueError:
            pass
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    prior, current = {}, {}
    for prefix in ('00', '01', '02', '03', '04'):
        doc = yaml.safe_load(next(args.baseline.glob(prefix + '*.yml')).read_text())
        for node in doc['workflow']['graph']['nodes']:
            if node['data']['type'] == 'code':
                ns = {}
                exec(compile(node['data']['code'], 'baseline:' + node['id'], 'exec'), ns)
                prior[(prefix, node['id'])] = ns['main']
    original = fixture.runtime
    comparisons = {}
    mismatches = []

    def runtime(prefix, node):
        key = (prefix, node)
        if key not in current:
            current[key] = original(prefix, node)
        ns = dict(current[key])
        target = ns['main']

        def compare(*call_args, **kwargs):
            seed = uuid.uuid4()
            results = []
            for func in (prior[key], target):
                with patch('uuid.uuid4', return_value=seed):
                    try:
                        results.append(('ok', func(*copy.deepcopy(call_args), **copy.deepcopy(kwargs))))
                    except Exception as exc:
                        results.append(('error', type(exc).__name__, str(exc)))
            comparisons[prefix + '/' + node] = comparisons.get(prefix + '/' + node, 0) + 1
            if normalize(results[0][1:]) != normalize(results[1][1:]) or results[0][0] != results[1][0]:
                mismatches.append({'node': prefix + '/' + node,
                                   'baseline': normalize(list(results[0])), 'current': normalize(list(results[1]))})
                raise AssertionError('release_output_mismatch:' + prefix + '/' + node)
            if results[1][0] == 'error':
                # Repeat only to propagate the actual exception type to existing tests.
                return target(*call_args, **kwargs)
            return results[1][1]
        ns['main'] = compare
        return ns

    fixture.runtime = runtime
    stream = io.StringIO()
    suite = unittest.TestLoader().discover(str(Path(__file__).parent), pattern='test*.py')
    result = unittest.TextTestRunner(stream=stream, verbosity=1).run(suite)
    report = {'tests_run': result.testsRun, 'passed': result.wasSuccessful() and not mismatches,
              'comparison_count': sum(comparisons.values()), 'compared_nodes': comparisons,
              'mismatches': mismatches, 'test_output': stream.getvalue(),
              'normalization': ['processing_version', 'controlled_random_run_uuid']}
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(stream.getvalue())
    print('Compared calls:', report['comparison_count'])
    raise SystemExit(0 if report['passed'] else 1)


if __name__ == '__main__':
    main()
