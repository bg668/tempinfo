"""节点 00_6100 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import json
import re
import csv
import io

FIELDS = [
    '批次ID',
    '候选记录ID',
    '来源处理记录ID',
    '评分来源处理记录ID',
    '来源账号/媒体',
    '审核状态',
    '是否采用',
    '审核意见',
    '候选ID',
    '来源文章ID',
    '发布时间',
    '类型',
    '标题',
    '概述',
    '原文标题',
    '来源链接',
    '总分',
    '相关性',
    '影响程度',
    '时效性',
    '证据质量',
    '受众价值',
    '筛选理由',
    'IP',
    '域名',
    'IOC_URL',
    'Hash',
    '文件路径',
    '漏洞编号',
    '原文小标题',
    '原文预览',
    '评分来源文章ID',
    '质量提示',
    '示例IOC（已排除）',
]
TYPE_LABELS = {'security_event': '安全事件', 'compliance_policy': '合规政策'}


def safe_cell(value):
    if isinstance(value, list):
        value = '; '.join((str(x) for x in value))
    if value is None:
        value = ''
    value = str(value).replace('\x00', '')
    value = re.sub('[\\r\\n\\t\\x01-\\x1f\\x7f]+', ' ', value)
    probe = value.lstrip(' \xa0\u200b\u200c\u200d\u2060\ufeff')
    if probe.startswith(('=', '+', '-', '@', '＝', '＋', '－', '＠')):
        value = "'" + value
    return value


def main(review_items_json: str) -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    items = json.loads(review_items_json)
    if not isinstance(items, list):
        raise ValueError('review_items_must_be_array')
    buffer = io.StringIO(newline='')
    writer = csv.DictWriter(buffer, fieldnames=FIELDS, lineterminator='\r\n', quoting=csv.QUOTE_MINIMAL)
    writer.writeheader()
    for item in items:
        if not isinstance(item, dict) or item.get('decision') != 'KEEP' or (not item.get('candidate_id')):
            raise ValueError('invalid_review_item_for_csv')
        scores, ioc = (item['scores'], item.get('ioc') or {})
        row = {
            '批次ID': item.get('run_id', ''),
            '候选记录ID': item.get('candidate_record_id', ''),
            '来源处理记录ID': item.get('source_item_ids', []),
            '评分来源处理记录ID': item.get('score_source_item_id', ''),
            '来源账号/媒体': item.get('source_accounts', []),
            '审核状态': '待审核',
            '是否采用': '',
            '审核意见': '',
            '候选ID': item['candidate_id'],
            '来源文章ID': item['source_article_ids'],
            '发布时间': item.get('published_at', ''),
            '类型': TYPE_LABELS.get(item['type'], item['type']),
            '标题': item['title'],
            '概述': item['summary'],
            '原文标题': item['original_title'],
            '来源链接': item['source_urls'],
            '总分': item['total_score'],
            '相关性': scores['relevance'],
            '影响程度': scores['impact'],
            '时效性': scores['freshness'],
            '证据质量': scores['evidence_quality'],
            '受众价值': scores['audience_value'],
            '筛选理由': item['reason'],
            'IP': ioc.get('ips', []),
            '域名': ioc.get('domains', []),
            'IOC_URL': ioc.get('urls', []),
            'Hash': ioc.get('hashes', []),
            '文件路径': ioc.get('file_paths', []),
            '漏洞编号': ioc.get('vulnerabilities', []),
            '原文小标题': item.get('source_heading', ''),
            '原文预览': item.get('source_preview', item.get('evidence_text', '')),
            '评分来源文章ID': item.get('score_source_article_id', ''),
            '质量提示': item.get('quality_warnings', []),
            '示例IOC（已排除）': [x['value'] for x in item.get('excluded_iocs', [])],
        }
        writer.writerow({key: safe_cell(row.get(key, '')) for key in FIELDS})
    return {'csv_text': '\ufeff' + buffer.getvalue(), 'row_count': len(items)}
