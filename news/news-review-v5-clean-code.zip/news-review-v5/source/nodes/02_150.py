"""节点 02_150 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import json
from common import canonical_json


def text_value(value):
    if value is None:
        return ''
    if not isinstance(value, (str, int, float)) or isinstance(value, bool):
        raise ValueError('invalid_scalar_type')
    return str(value).strip()


def normalize_article(row, max_chars=100000):
    if not isinstance(row, dict):
        raise ValueError('article_not_object')
    aliases = {
        'source_article_id': ('source_article_id', 'stable_article_id', 'article_id', 'id'),
        'account': ('account', 'publisher', 'author'),
        'title': ('title',),
        'url': ('url', 'source_url', 'link'),
        'published_at': ('published_at', 'publish_time', 'pub_date'),
        'content': ('content', 'body_text', 'article_text'),
    }
    out = {
        key: text_value(next((row.get(k) for k in keys if row.get(k)), None)) for key, keys in aliases.items()
    }
    if not all((out[k] for k in ('source_article_id', 'title', 'url', 'content'))):
        raise ValueError('missing_required_field')
    if any(('\n' in v or '\r' in v for k, v in out.items() if k != 'content')):
        raise ValueError('multiline_metadata')
    original_chars = row.get('content_chars', len(out['content']))
    truncated = row.get('content_truncated', False)
    if type(original_chars) is not int or original_chars < len(out['content']):
        raise ValueError('invalid_content_chars')
    if type(truncated) is not bool or (original_chars > len(out['content']) and (not truncated)):
        raise ValueError('invalid_content_truncated')
    out['content_chars'] = original_chars
    out['content_truncated'] = truncated or len(out['content']) > max_chars
    out['content'] = out['content'][:max_chars]
    out['source_version'] = row.get('source_version')
    return out


def main(article_json: str) -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    article = normalize_article(json.loads(article_json))
    lines = ['article:']
    for key in ('source_article_id', 'account', 'title', 'url', 'published_at'):
        value = article[key] or ('unknown' if key == 'published_at' else '')
        lines.append('  ' + key + ': ' + value)
    lines.extend(
        [
            '  content_chars: ' + str(article['content_chars']),
            '  content_truncated: ' + str(article['content_truncated']).lower(),
            '  content:',
        ]
    )
    lines.extend(('    ' + line for line in article['content'].splitlines()))
    return {'article_text': '\n'.join(lines), 'article_json': canonical_json(article)}
