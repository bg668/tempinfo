"""节点 00_4200 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import json
from common import stable_event_id


def main(result_json: str, incidents_json: str) -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    errors, groups = ([], [])
    incidents = json.loads(incidents_json)
    expected = {r['article']['source_article_id']: r for r in incidents}
    try:
        obj = json.loads(result_json)
        if (
            not isinstance(obj, dict)
            or not isinstance(obj.get('groups'), list)
            or (not isinstance(obj.get('errors'), list))
        ):
            raise ValueError('invalid_event_match_envelope')
        errors.extend((str(e) for e in obj['errors']))
        if obj.get('degraded') and (not obj['errors']):
            errors.append('event_match_degraded')
        seen, event_ids = (set(), set())
        for group in obj['groups']:
            if (
                not isinstance(group, dict)
                or not isinstance(group.get('member_article_ids'), list)
                or (not group['member_article_ids'])
            ):
                raise ValueError('invalid_group')
            ids = group['member_article_ids']
            if (
                len(ids) != len(set(ids))
                or any((sid not in expected for sid in ids))
                or seen.intersection(ids)
            ):
                raise ValueError('event_group_exact_cover_violation')
            if group.get('event_id') != stable_event_id(ids) or group['event_id'] in event_ids:
                raise ValueError('event_group_id_mismatch')
            member_ids = [(r.get('article') or {}).get('source_article_id') for r in group.get('members', [])]
            if len(member_ids) != len(ids) or set(member_ids) != set(ids):
                raise ValueError('group_member_records_mismatch')
            group = {**group, 'members': [expected[sid] for sid in ids]}
            seen.update(ids)
            event_ids.add(group['event_id'])
            groups.append(group)
        if seen != set(expected):
            raise ValueError('event_group_missing_incidents')
    except Exception as exc:
        errors.append('event_match:' + str(exc))
        groups = []
    return {
        'group_jsons': [json.dumps(g, ensure_ascii=False) for g in groups],
        'event_match_errors_json': json.dumps(list(dict.fromkeys(errors)), ensure_ascii=False),
    }
