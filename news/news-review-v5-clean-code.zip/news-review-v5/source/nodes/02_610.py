"""节点 02_610 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import hashlib
import json
import re
from common import (
    CONTRACT_VERSION,
    SCORE_KEYS,
    _unique,
    enrich_review,
    factual_errors,
    ioc_report,
    is_label_title,
    norm_text,
    parse_article_input,
    parse_contract,
)

STATUS = {'officially_issued', 'draft_for_comment', 'other', 'unknown'}


def stable_policy_id(article_id):
    return 'policy_' + hashlib.sha256(str(article_id).encode('utf-8')).hexdigest()[:16]


def _empty_report():
    return ioc_report(
        {'ips': [], 'domains': [], 'urls': [], 'hashes': [], 'file_paths': [], 'vulnerabilities': []}
    )


def text_value(value):
    return isinstance(value, str) and bool(value.strip()) and (not re.search('<[^>]+>', value))


def score_errors(triage):
    errors = []
    scores = triage.get('scores')
    if not isinstance(scores, dict) or set(scores) != set(SCORE_KEYS):
        return ['scores_fields']
    for key in SCORE_KEYS:
        if type(scores[key]) is not int or not 0 <= scores[key] <= 5:
            errors.append('score_integer_0_5:' + key)
    if not text_value(triage.get('reason')):
        errors.append('missing_reason')
    if 'total_score' in triage and (not errors) and (triage['total_score'] != sum(scores.values()) * 4):
        errors.append('total_score_mismatch')
    return errors


def parse_policy_fields(raw: str, article_text: str, triage_json: str) -> dict:
    """解析政策树文本并校验基础字段；返回对象，不进行结果序列化。"""
    errors = []
    try:
        article = parse_article_input(article_text)
    except Exception as e:
        article = {}
        errors.append('article_tree:' + str(e))
    try:
        obj = parse_contract(raw, 'policy_result')
    except Exception as e:
        obj = {}
        errors.append('policy_tree:' + str(e))
    required = {
        'source_article_id',
        'policy_time',
        'title',
        'source_url',
        'issuer',
        'policy_name',
        'policy_status',
        'effective_time',
        'affected_entities',
        'requirements',
        'key_changes',
        'impact',
        'summary',
    }
    if set(obj) != required:
        errors.append('fields_mismatch')
    if str(obj.get('source_article_id', '')) != str(article.get('source_article_id', '')):
        errors.append('source_article_id_mismatch')
    if str(obj.get('source_url', '')) != str(article.get('url', '')):
        errors.append('source_url_mismatch')
    if str(obj.get('policy_status', '')) not in STATUS:
        errors.append('invalid_policy_status')
    for k in (
        'source_article_id',
        'policy_time',
        'title',
        'source_url',
        'issuer',
        'policy_name',
        'policy_status',
        'effective_time',
        'impact',
        'summary',
    ):
        if not str(obj.get(k, '')).strip():
            errors.append('empty_' + k)
    for k in ('affected_entities', 'requirements', 'key_changes'):
        if not isinstance(obj.get(k), list):
            errors.append(k + '_not_list')
            obj[k] = []
        else:
            obj[k] = _unique(obj[k])
    obj['_validation_error'] = ';'.join(errors)
    try:
        triage = json.loads(triage_json or '{}')
    except Exception:
        triage = {}
    candidate = {
        'policy_id': stable_policy_id(article.get('source_article_id', '')),
        'source_article_id': article.get('source_article_id', ''),
        'policy_time': str(obj.get('policy_time', 'unknown')),
        'title': str(obj.get('title') or article.get('title', '')),
        'source_url': article.get('url', ''),
        'issuer': str(obj.get('issuer', 'unknown')),
        'policy_name': str(obj.get('policy_name', 'unknown')),
        'policy_status': str(obj.get('policy_status', 'unknown')),
        'effective_time': str(obj.get('effective_time', 'unknown')),
        'affected_entities': obj.get('affected_entities', []),
        'requirements': obj.get('requirements', []),
        'key_changes': obj.get('key_changes', []),
        'impact': str(obj.get('impact', 'unknown')),
        'summary': str(obj.get('summary', '')),
    }
    review = {
        'published_at': article.get('published_at') or candidate['policy_time'] or 'unknown',
        'title': candidate['title'],
        'original_title': article.get('title') or candidate['title'],
        'summary': candidate['summary'],
        'source_url': article.get('url', ''),
        'type': 'compliance_policy',
        'ioc': _empty_report(),
    }
    result = {
        'kind': 'error' if errors else 'policy',
        'article': article,
        'triage': triage,
        'facts': obj,
        '_error': ';'.join(errors),
    }
    if not errors:
        result['candidate'] = candidate
        result['review_item'] = review
    return result


def validate_policy(raw: str, article_text: str, triage_json: str) -> dict:
    """执行政策评分、正式名称和事实约束校验，构建审核项。"""
    try:
        result = parse_policy_fields(raw, article_text, triage_json)
        if not isinstance(result, dict):
            raise ValueError('legacy_result_not_object')
        for key in ('article', 'facts', 'triage', 'candidate'):
            if key in result and (not isinstance(result[key], dict)):
                raise ValueError('legacy_' + key + '_not_object')
    except Exception as exc:
        result = {
            'article': {},
            'facts': {},
            'triage': {},
            'candidate': {},
            'errors': ['legacy_validation:' + str(exc)],
            '_error': 'legacy_validation:' + str(exc),
        }
    article, facts, triage = (result['article'], result['facts'], result['triage'])
    errors = [x for x in str(result.get('_error') or '').split(';') if x]
    errors.extend(score_errors(triage))
    if triage.get('_validation_error'):
        errors.append('invalid_triage:' + triage['_validation_error'])
    if triage.get('decision') != 'KEEP' or triage.get('route') != 'compliance_policy':
        errors.append('policy_triage_route_mismatch')
    source = str(article.get('content') or '')
    for key in (
        'source_article_id',
        'policy_time',
        'title',
        'source_url',
        'issuer',
        'policy_name',
        'policy_status',
        'effective_time',
        'impact',
        'summary',
    ):
        if not text_value(facts.get(key)):
            errors.append('invalid_text:' + key)
    errors.extend(factual_errors(facts, source))
    if is_label_title(facts.get('title')):
        errors.append('label_only_title')
    policy_name = str(facts.get('policy_name') or '')
    if policy_name != 'unknown' and norm_text(policy_name.strip('《》')) not in norm_text(source):
        errors.append('policy_name_not_grounded')
    if errors:
        result.pop('review_item', None)
        result.pop('candidate', None)
    else:
        review = enrich_review(result['review_item'], result['candidate']['policy_id'], article, triage)
        review['policy_id'] = result['candidate']['policy_id']
        review['policy_facts'] = {key: value for key, value in facts.items() if not key.startswith('_')}
    result.update(
        {
            'contract_version': CONTRACT_VERSION,
            'kind': 'error' if errors else 'policy',
            'errors': list(dict.fromkeys(errors)),
            '_error': ';'.join(dict.fromkeys(errors)),
        }
    )
    return result


def main(raw: str, article_text: str, triage_json: str, article_json: str = '') -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    try:
        payload = validate_policy(raw, article_text, triage_json)
    except Exception as exc:
        payload = {
            'kind': 'error',
            'errors': ['child_code_exception:' + str(exc)],
            'contract_version': CONTRACT_VERSION,
        }
    try:
        if not payload.get('triage'):
            payload['triage'] = json.loads(triage_json)
    except Exception:
        payload['triage'] = {}
    if raw == '__NODE_EXECUTION_FAILED__':
        payload.setdefault('errors', []).append('llm_execution_failed')
    payload['storage_contract_version'] = 'news-storage-v1'
    payload['error_stage'] = 'policy_extract'
    payload['article'] = json.loads(article_json)
    return {'result_json': json.dumps(payload, ensure_ascii=False)}
