"""节点 00_6050 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import json
import re


def main(
    processing_items_json: str,
    candidates_json: str,
    run_id: str,
    processing_version: str,
    run_status: str,
    stats_json: str,
    errors_json: str,
    warnings_json: str,
) -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    rows, candidates = (json.loads(processing_items_json), json.loads(candidates_json))
    if not isinstance(rows, list) or not isinstance(candidates, list):
        raise ValueError('invalid_result_tables')
    if not re.fullmatch('run_[a-f0-9]{32}', run_id):
        raise ValueError('invalid_run_id')
    if any((row.get('run_id') != run_id for row in rows + candidates)):
        raise ValueError('result_run_id_mismatch')
    stats = json.loads(stats_json)
    stats.update(
        {
            'processing_item_count': len(rows),
            'candidate_count': len(candidates),
            'keep_count': sum((r['decision'] == 'KEEP' for r in rows if r['item_kind'] != 'digest_parent')),
            'drop_count': sum((r['decision'] == 'DROP' for r in rows if r['item_kind'] != 'digest_parent')),
            'uncertain_count': sum(
                (r['decision'] == 'UNCERTAIN' for r in rows if r['item_kind'] != 'digest_parent')
            ),
        }
    )
    bundle = {
        'schema_version': 'news-result-bundle-v1',
        'run_id': run_id,
        'processing_version': processing_version,
        'process_status': run_status,
        'stats': stats,
        'errors': json.loads(errors_json),
        'warnings': json.loads(warnings_json),
        'processing_items': rows,
        'candidates': candidates,
    }
    return {
        'bundle_json': json.dumps(bundle, ensure_ascii=False, separators=(',', ':'), allow_nan=False),
        'json_filename': '处理结果_' + run_id + '.json',
        'csv_filename': '候选审核_' + run_id + '.csv',
        'stats_json': json.dumps(stats, ensure_ascii=False),
    }
