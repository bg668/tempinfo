"""节点 03_500 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import json
from common import stable_event_id


def main(incidents_json: str) -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    try:
        rows = json.loads(incidents_json or '[]')
    except Exception:
        rows = []
    groups = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        f = r.get('facts') or {}
        sid = str(f.get('source_article_id') or (r.get('article') or {}).get('source_article_id') or '')
        if sid:
            groups.append(
                {
                    'event_id': stable_event_id([sid]),
                    'canonical_title': str(f.get('title') or ''),
                    'match_reason': 'MVP singleton mode: this article is processed as an independent candidate.',
                    'member_article_ids': [sid],
                    'members': [r],
                }
            )
    return {
        'result_json': json.dumps({'groups': groups, 'degraded': False, 'errors': []}, ensure_ascii=False)
    }
