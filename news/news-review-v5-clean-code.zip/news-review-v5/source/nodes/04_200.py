"""节点 04_200 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import json
from common import render_lines


def main(group_json: str) -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    try:
        group = json.loads(group_json or '{}')
    except Exception:
        group = {}
    facts = {}
    for r in group.get('members') or []:
        f = r.get('facts') if isinstance(r, dict) else None
        if isinstance(f, dict):
            f = {k: v for k, v in f.items() if not k.startswith('_')}
            sid = str(f.get('source_article_id') or '')
            if sid:
                facts[sid] = f
    payload = {
        'event_candidate_input': {
            'event_id': group.get('event_id', ''),
            'canonical_title': group.get('canonical_title', ''),
            'match_reason': group.get('match_reason', ''),
            'source_count': len(facts),
            'incident_facts': facts,
        }
    }
    return {'candidate_input_text': '\n'.join(render_lines(payload))}
