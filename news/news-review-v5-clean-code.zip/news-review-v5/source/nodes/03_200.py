"""节点 03_200 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import json
from common import render_lines


def main(incidents_json: str, grouping_mode: str = 'singleton') -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    try:
        incidents = json.loads(incidents_json or '[]')
    except Exception:
        incidents = []
    incident_facts = {}
    for row in incidents:
        f = row.get('facts') if isinstance(row, dict) else None
        if isinstance(f, dict):
            f = {k: v for k, v in f.items() if not k.startswith('_')}
            sid = str(f.get('source_article_id') or (row.get('article') or {}).get('source_article_id') or '')
            if sid:
                incident_facts[sid] = f
    payload = {
        'event_match_input': {
            'triage_signature': 'dify-workflow',
            'incident_signature': 'dify-workflow',
            'incident_count': len(incident_facts),
            'incidents': incident_facts,
        }
    }
    text = '\n'.join(render_lines(payload))
    route = 'event_match' if str(grouping_mode) == 'event_match' and len(incident_facts) > 1 else 'singleton'
    return {'incidents_text': text, 'route': route, 'incident_count': len(incident_facts)}
