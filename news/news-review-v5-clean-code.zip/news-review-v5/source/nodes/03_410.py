"""节点 03_410 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import json
from common import parse_contract, stable_event_id


def main(raw: str, incidents_json: str) -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    errors = []
    degraded = False
    try:
        rows = json.loads(incidents_json or '[]')
    except Exception:
        rows = []
    by_id = {
        str(
            (r.get('facts') or {}).get('source_article_id')
            or (r.get('article') or {}).get('source_article_id')
            or ''
        ): r
        for r in rows
        if isinstance(r, dict)
    }
    by_id = {k: v for k, v in by_id.items() if k}
    all_ids = list(by_id)
    try:
        out = parse_contract(raw, 'event_match_result')
    except Exception as e:
        out = {}
        errors.append('event_match_tree:' + str(e))
        degraded = True
    raw_groups = out.get('groups') if isinstance(out.get('groups'), dict) else {}
    if not raw_groups:
        degraded = True
        errors.append('groups_missing')
    groups = []
    used = set()
    for key, gr in raw_groups.items():
        if not isinstance(gr, dict):
            errors.append('group_not_mapping:' + str(key))
            degraded = True
            continue
        if set(gr) != {'canonical_title', 'member_article_ids', 'match_reason'}:
            errors.append('group_fields_mismatch:' + str(key))
            degraded = True
        if not str(gr.get('canonical_title', '')).strip():
            errors.append('group_empty_title:' + str(key))
            degraded = True
        if not str(gr.get('match_reason', '')).strip():
            errors.append('group_empty_reason:' + str(key))
            degraded = True
        ids = gr.get('member_article_ids') if isinstance(gr.get('member_article_ids'), list) else []
        if not ids:
            errors.append('group_empty_members:' + str(key))
            degraded = True
        valid = []
        for sid in ids:
            sid = str(sid)
            if sid in by_id and sid not in used:
                valid.append(sid)
                used.add(sid)
            else:
                errors.append('unknown_or_duplicate:' + sid)
                degraded = True
        if valid:
            groups.append(
                {
                    'event_id': stable_event_id(valid),
                    'canonical_title': str(
                        gr.get('canonical_title') or (by_id[valid[0]].get('facts') or {}).get('title') or ''
                    ),
                    'match_reason': str(gr.get('match_reason') or 'model grouping'),
                    'member_article_ids': valid,
                    'members': [by_id[x] for x in valid],
                }
            )
    for sid in all_ids:
        if sid not in used:
            degraded = True
            f = by_id[sid].get('facts') or {}
            groups.append(
                {
                    'event_id': stable_event_id([sid]),
                    'canonical_title': str(f.get('title') or ''),
                    'match_reason': 'exact-cover repair: singleton fallback',
                    'member_article_ids': [sid],
                    'members': [by_id[sid]],
                }
            )
    return {
        'result_json': json.dumps(
            {'groups': groups, 'degraded': degraded, 'errors': errors}, ensure_ascii=False
        )
    }
