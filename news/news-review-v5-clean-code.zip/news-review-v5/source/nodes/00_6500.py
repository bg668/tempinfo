"""节点 00_6500 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import json


def main(run_status: str, stats_json: str, errors_json: str, json_files: list, csv_files: list) -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    stats = json.loads(stats_json)
    errors = json.loads(errors_json)
    json_ok, csv_ok = (bool(json_files), bool(csv_files))
    export_status = {
        'result_json': 'SUCCESS' if json_ok else 'FAILED',
        'review_csv': 'SUCCESS' if csv_ok else 'FAILED',
    }
    codes = []
    for value in errors:
        code = (
            value.get('code') or value.get('error') or 'processing_error'
            if isinstance(value, dict)
            else 'processing_error'
        )
        code = str(code).split(':', 1)[0][:80]
        if code not in codes:
            codes.append(code)
    if not json_ok:
        codes.append('result_json_export_empty')
    if not csv_ok:
        codes.append('review_csv_export_empty')
    return {
        'run_status': run_status if json_ok and csv_ok else 'FAILED',
        'stats': stats,
        'export_status': export_status,
        'error_summary': '；'.join(codes[:5]) + ('；更多详情见结果文件' if len(codes) > 5 else ''),
    }
