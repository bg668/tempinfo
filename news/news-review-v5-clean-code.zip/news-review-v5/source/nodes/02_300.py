"""节点 02_300 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import json
import re
from common import SCORE_KEYS, parse_article_input, parse_contract, validate_triage_payload


def text_value(value):
    return isinstance(value, str) and bool(value.strip()) and (not re.search('<[^>]+>', value))


def score_errors(triage):
    errors = []
    scores = triage.get('scores')
    if not isinstance(scores, dict) or set(scores) != set(SCORE_KEYS):
        return ['scores_fields']
    for key in SCORE_KEYS:
        if type(scores[key]) is not int or not 0 <= scores[key] <= 5:
            errors.append('score_integer_0_5:' + key)
    if not text_value(triage.get('reason')):
        errors.append('missing_reason')
    if 'total_score' in triage and (not errors) and (triage['total_score'] != sum(scores.values()) * 4):
        errors.append('total_score_mismatch')
    return errors


def strict_triage(obj):
    if not isinstance(obj, dict):
        return ({}, ['triage_not_mapping'])
    errors = score_errors(obj)
    clean, more = validate_triage_payload(obj)
    errors.extend(more)
    if errors:
        clean['scores'] = obj.get('scores') if isinstance(obj.get('scores'), dict) else {}
        clean.pop('total_score', None)
    else:
        clean['total_score'] = sum(clean['scores'].values()) * 4
    return (clean, list(dict.fromkeys(errors)))


def main(raw: str, article_text: str) -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    errors = []
    article, obj = ({}, {})
    try:
        article = parse_article_input(article_text)
        obj = parse_contract(raw, 'triage_result')
    except Exception as exc:
        errors.append('parse:' + str(exc))
    obj, more = strict_triage(obj)
    errors.extend(more)
    if not article.get('source_article_id') or obj.get('source_article_id') != article['source_article_id']:
        errors.append('source_article_id_mismatch')
    obj['_validation_error'] = ';'.join(dict.fromkeys(errors))
    return {
        'decision': 'UNCERTAIN' if errors else obj['decision'],
        'route': 'uncertain' if errors else obj['route'],
        'triage_json': json.dumps(obj, ensure_ascii=False),
        'validation_error': obj['_validation_error'],
    }
