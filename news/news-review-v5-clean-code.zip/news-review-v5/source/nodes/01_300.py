"""节点 01_300 的业务代码。公共函数在 common.py 维护，DSL 由 build.py 生成。"""

import hashlib
import json
import re
from common import (
    CONTRACT_VERSION,
    SCORE_KEYS,
    enrich_review,
    example_ioc_filter,
    factual_errors,
    ioc_report,
    is_label_title,
    literal_iocs,
    norm_text,
    parse_article_input,
    parse_contract,
    validate_triage_payload,
)


def text_value(value):
    return isinstance(value, str) and bool(value.strip()) and (not re.search('<[^>]+>', value))


def score_errors(triage):
    errors = []
    scores = triage.get('scores')
    if not isinstance(scores, dict) or set(scores) != set(SCORE_KEYS):
        return ['scores_fields']
    for key in SCORE_KEYS:
        if type(scores[key]) is not int or not 0 <= scores[key] <= 5:
            errors.append('score_integer_0_5:' + key)
    if not text_value(triage.get('reason')):
        errors.append('missing_reason')
    if 'total_score' in triage and (not errors) and (triage['total_score'] != sum(scores.values()) * 4):
        errors.append('total_score_mismatch')
    return errors


def strict_triage(obj):
    if not isinstance(obj, dict):
        return ({}, ['triage_not_mapping'])
    errors = score_errors(obj)
    clean, more = validate_triage_payload(obj)
    errors.extend(more)
    if errors:
        clean['scores'] = obj.get('scores') if isinstance(obj.get('scores'), dict) else {}
        clean.pop('total_score', None)
    else:
        clean['total_score'] = sum(clean['scores'].values()) * 4
    return (clean, list(dict.fromkeys(errors)))


def digest_sections(content):
    """Recognize explicit bracket/numbered/Markdown headings, not arbitrary prose."""
    pattern = (
        '(?m)^\\s*(【[^\\n】]{1,100}】|#{1,4} +[^\\n]+|(?:\\d{1,3}[.、]|[一二三四五六七八九十]+、) +?[^\\n]+)'
    )
    matches = list(re.finditer(pattern, content))
    if not matches:
        return []
    sections = []
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(content)
        heading = match.group(1).strip()
        body = content[match.end() : end].strip()
        sections.append({'heading': heading, 'body': body, 'whole': content[match.start() : end].strip()})
    return sections


def validate_digest_item(
    item, key, ordinal, article, parent_id, source, sections, warnings, seen_spans, previous_pos, local
):
    """校验单个快讯：评分、原文分段覆盖、事实约束及 IOC；保留源顺序。"""
    triage, triage_errors = strict_triage(
        {
            **{k: item[k] for k in ('decision', 'route', 'category', 'content_nature', 'scores', 'reason')},
            'source_article_id': parent_id,
        }
    )
    local.extend(triage_errors)
    for field in ('source_heading', 'title', 'source_text', 'summary'):
        if not text_value(item[field]):
            local.append('invalid_text:' + field)
    if is_label_title(item['title']):
        local.append('label_only_title')
    evidence = str(item['source_text'])
    normalized_evidence = norm_text(evidence)
    pos = norm_text(source).find(normalized_evidence) if normalized_evidence else -1
    if pos < 0:
        local.append('source_text_not_grounded')
    if normalized_evidence in seen_spans:
        local.append('duplicate_source_text')
    seen_spans.add(normalized_evidence)
    if pos >= 0 and pos < previous_pos:
        local.append('item_order_mismatch')
    previous_pos = max(previous_pos, pos)
    if sections and ordinal <= len(sections):
        section = sections[ordinal - 1]
        if norm_text(item['source_heading']) != norm_text(section['heading']):
            local.append('source_heading_mismatch')
        if normalized_evidence not in {norm_text(section['body']), norm_text(section['whole'])}:
            local.append('source_text_must_cover_own_section')
    elif item['source_heading'] != 'unknown' and norm_text(item['source_heading']) not in norm_text(source):
        local.append('source_heading_not_grounded')
    local.extend(factual_errors(item, evidence))
    ioc, excluded, ioc_errors = example_ioc_filter(literal_iocs(evidence), evidence)
    local.extend(ioc_errors)
    cid = (
        'digest_'
        + hashlib.sha256(
            (parent_id + '\n' + str(ordinal) + '\n' + normalized_evidence).encode('utf-8')
        ).hexdigest()[:24]
    )
    review = enrich_review(
        {
            'published_at': article.get('published_at') or 'unknown',
            'title': item['title'],
            'original_title': article.get('title') or '',
            'summary': item['summary'],
            'source_url': article.get('url') or '',
            'type': item['route'],
            'ioc': ioc_report(ioc),
        },
        cid,
        article,
        triage,
        evidence,
    )
    review.update(
        {
            'child_id': cid,
            'parent_article_id': parent_id,
            'item_key': key,
            'item_order': ordinal,
            'source_heading': item['source_heading'],
            'source_text': evidence,
            'excluded_iocs': excluded,
        }
    )
    if excluded:
        review['quality_warnings'].append('example_iocs_excluded')
    review['quality_warnings'].extend(warnings)
    return (review, local, previous_pos)


def validate_digest(raw: str, article_text: str, verbose: str = 'false') -> dict:
    """校验父快讯及全部子项；任一错误均隔离整篇候选，保留审核记录。"""
    errors, warnings, all_items, candidates = ([], [], [], [])
    article = {}
    out = {}
    try:
        article = parse_article_input(article_text)
        out = parse_contract(raw, 'digest_result')
    except Exception as exc:
        errors.append('parse:' + str(exc))
    parent_id = str(article.get('source_article_id') or '')
    if not parent_id or out.get('parent_article_id') != parent_id:
        errors.append('parent_article_id_mismatch')
    if set(out) != {'parent_article_id', 'items'}:
        errors.append('digest_fields_mismatch')
    source = str(article.get('content') or '')
    sections = digest_sections(source)
    items = out.get('items')
    if not isinstance(items, dict) or not items:
        errors.append('items_missing')
        items = {}
    if sections and len(items) != len(sections):
        errors.append('digest_item_coverage:expected=%d,returned=%d' % (len(sections), len(items)))
    if not sections:
        warnings.append('digest_coverage_unverified:no_recognized_headings')
    if str(article.get('content_truncated')).lower() == 'true':
        errors.append('digest_content_truncated:full_coverage_unavailable')
    seen_spans = set()
    previous_pos = -1
    for ordinal, (key, item) in enumerate(items.items(), 1):
        local = []
        if key != 'item_%03d' % ordinal:
            local.append('non_contiguous_item_key')
        required = {
            'source_heading',
            'title',
            'source_text',
            'summary',
            'decision',
            'route',
            'category',
            'content_nature',
            'scores',
            'reason',
        }
        if not isinstance(item, dict) or set(item) != required:
            errors.append(str(key) + ':fields_mismatch')
            continue
        review, local, previous_pos = validate_digest_item(
            item,
            key,
            ordinal,
            article,
            parent_id,
            source,
            sections,
            warnings,
            seen_spans,
            previous_pos,
            local,
        )
        audit = dict(review)
        audit['validation_errors'] = local
        all_items.append(audit)
        errors.extend((str(key) + ':' + x for x in local))
        if not local and item['decision'] == 'KEEP':
            candidates.append(review)
    if errors:
        candidates = []
    counts = {
        decision.lower() + '_count': sum((x.get('decision') == decision for x in all_items))
        for decision in ('KEEP', 'DROP', 'UNCERTAIN')
    }
    stats = {
        'parent_count': 1,
        'item_count': len(all_items),
        'expected_item_count': len(sections) if sections else -1,
        **counts,
        'candidate_count': len(candidates),
        'coverage_verified': bool(sections) and (not errors),
    }
    payload = {
        'contract_version': CONTRACT_VERSION,
        'kind': 'digest',
        'parent_article_id': parent_id,
        'candidates': candidates,
        'items': all_items,
        'stats': stats,
        'errors': list(dict.fromkeys(errors)),
        'warnings': warnings,
    }
    return (payload, article)


def main(raw: str, article_text: str, verbose: str = 'false', article_json: str = '') -> dict:
    """Dify 节点唯一入口：组织处理步骤，并按节点契约返回结果。"""
    try:
        payload, article = validate_digest(raw, article_text, verbose)
    except Exception as exc:
        payload = {
            'kind': 'error',
            'errors': ['child_code_exception:' + str(exc)],
            'contract_version': CONTRACT_VERSION,
        }
        try:
            article = parse_article_input(article_text)
        except Exception:
            article = {}
    payload['parent_article_id'] = article.get('source_article_id', '')
    payload.setdefault('items', [])
    payload.setdefault('candidates', [])
    for child in payload['items']:
        child['route'] = child.get('type')
    if raw == '__NODE_EXECUTION_FAILED__':
        payload.setdefault('errors', []).append('llm_execution_failed')
    payload['storage_contract_version'] = 'news-storage-v1'
    payload['error_stage'] = 'digest'
    payload['article'] = json.loads(article_json)
    return {
        'result_json': json.dumps(payload, ensure_ascii=False),
        'candidate_count': len(payload['candidates']),
        'error': ';'.join((str(e) for e in payload.get('errors', []))),
    }
