"""从干净源文件构建独立可运行的 Dify Code 节点，不依赖历史 DSL 代码。"""
import ast
import copy
import hashlib
from pathlib import Path
import yaml

SOURCE = Path(__file__).resolve().parent
OUTPUT = SOURCE.parent


def bindings(node):
    if isinstance(node, ast.FunctionDef):
        return [node.name]
    if isinstance(node, (ast.Import, ast.ImportFrom)):
        return [a.asname or a.name.split('.')[0] for a in node.names]
    if isinstance(node, ast.Assign):
        return [n.id for target in node.targets for n in ast.walk(target) if isinstance(n, ast.Name)]
    return []


def render_node(path):
    """静态解析 common 导入，按依赖闭包嵌入所需定义；保留源文件排版。"""
    texts = [(SOURCE / 'common.py').read_text(), path.read_text()]
    definitions, ordered = {}, []
    for text in texts:
        for node in ast.parse(text).body:
            if isinstance(node, ast.ImportFrom) and node.module == 'common':
                continue
            names = bindings(node)
            if not names:
                continue
            ordered.append((node, text))
            for name in names:
                definitions[name] = node
    pending, reachable = ['main'], set()
    while pending:
        name = pending.pop()
        if name in reachable or name not in definitions:
            continue
        reachable.add(name)
        pending.extend(n.id for n in ast.walk(definitions[name])
                       if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load))
    imports, constants, functions = [], [], []
    for node, text in ordered:
        keep = [name for name in bindings(node) if name in reachable and definitions[name] is node]
        if not keep:
            continue
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            selected = copy.deepcopy(node)
            selected.names = [a for a in selected.names if (a.asname or a.name.split('.')[0]) in keep]
            imports.append(ast.unparse(selected))
        elif isinstance(node, ast.Assign):
            constants.append(ast.get_source_segment(text, node))
        else:
            functions.append(ast.get_source_segment(text, node))
    code = '# 由 source/build.py 生成；修改对应源文件后重新构建。\n\n'
    code += '\n'.join(imports) + '\n\n' + '\n'.join(constants) + '\n\n'
    code += '\n\n\n'.join(functions) + '\n'
    namespace = {}
    exec(compile(code, path.stem, 'exec'), namespace)
    parsed = ast.parse(code)
    names = [n.name for n in parsed.body if isinstance(n, ast.FunctionDef)]
    assert len(names) == len(set(names)) and names.count('main') == 1
    return code


def build():
    material = [(p.relative_to(SOURCE).as_posix(), p.read_bytes())
                for p in sorted(SOURCE.rglob('*')) if p.is_file() and p.suffix in ('.py', '.yml')]
    digest = hashlib.sha256(b''.join(name.encode() + b'\0' + data for name, data in material)).hexdigest()[:12]
    version = 'news-json-files-v5-' + digest
    for path in sorted((SOURCE / 'templates').glob('*.yml')):
        doc = yaml.safe_load(path.read_text())
        for node in doc['workflow']['graph']['nodes']:
            if node['data']['type'] != 'code':
                continue
            code = render_node(SOURCE / 'nodes' / (path.name[:2] + '_' + node['id'] + '.py'))
            code = code.replace('__PROCESSING_VERSION__', version)
            node['data']['code'] = code
        (OUTPUT / path.name).write_text(yaml.safe_dump(doc, allow_unicode=True, sort_keys=False, width=120))
    print(version)
    return version


if __name__ == '__main__':
    build()
