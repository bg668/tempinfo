# 源码结构

- `common.py`：共用树文本、推理前缀、评分、IOC 和来源工具函数。
- `nodes/工作流编号_节点编号.py`：单节点职责；每个文件只有一个 main。
- `templates/`：保留图、节点接口、提示词和工具配置；Code 内容由构建填充。
- `build.py`：解析依赖、内嵌必要函数、检查单入口、计算 processing_version 并生成五份 DSL。

节点内部使用对象交接。Dify 边界所需 JSON 字符串只在对应出口编码。不同 DSL 节点中出现的共用函数副本是构建产物，维护时只改源文件。

源码采用 Python 标准库，构建另需 PyYAML。格式整理使用 Black，但构建和运行不依赖 Black。
