# 两表字段与产生阶段

完整结果文件可直接解析为JSON对象，包含两个表数组。时间与人工字段的占位及入库规则见 README。

## processing_items

| 字段 | 类型 | 说明 | 产生阶段 |
|---|---|---|---|
| `item_id` | TEXT | 处理记录主键 | 00 汇总生成 |
| `run_id` | TEXT | 本次批次 | 00 入口生成 |
| `source_article_id` | TEXT | 采集库原文关联ID | 采集端传入，00 保留 |
| `candidate_record_id` | TEXT | 本批次候选记录ID | 00 汇总生成并关联 |
| `item_kind` | TEXT | 普通/快讯父记录/快讯子项 | 00 分流与汇总 |
| `item_key` | TEXT | 批次内原文的条目键 | 01 子项键；00 补普通及父记录键 |
| `title` | TEXT | AI标题 | 01 / 02 / 04 |
| `summary` | TEXT | AI摘要 | 01 / 02 / 04 |
| `source_heading` | TEXT | 快讯原始小标题 | 01 |
| `source_text` | TEXT | 快讯子项原文 | 01 |
| `process_status` | TEXT | 整条应执行路径的SUCCESS/FAILED | 00 最终汇总 |
| `decision` | TEXT | 有效筛选结论 | 01 / 02 |
| `route` | TEXT | 业务路由 | 01 / 02 |
| `category` | TEXT | 细分类别 | 01 / 02 |
| `content_nature` | TEXT | 内容性质 | 01 / 02 |
| `relevance` | INTEGER | 相关性0–5 | 01 / 02；候选由04选择来源 |
| `impact` | INTEGER | 影响程度0–5 | 01 / 02；候选由04选择来源 |
| `freshness` | INTEGER | 时效性0–5 | 01 / 02；候选由04选择来源 |
| `evidence_quality` | INTEGER | 证据质量0–5 | 01 / 02；候选由04选择来源 |
| `audience_value` | INTEGER | 受众价值0–5 | 01 / 02；候选由04选择来源 |
| `total_score` | INTEGER | 五项评分之和×4 | 01 / 02；候选由04选择来源 |
| `reason` | TEXT | 判断理由 | 01 / 02；04 继承评分来源 |
| `facts_json` | JSON | 完整事实对象 | 资讯为02抽取；候选为02政策或04事件；快讯为空 |
| `ioc_json` | JSON | 六类IOC数组对象；null表示无有效提取结果 | 01 扫描、02事件抽取、00聚合；普通政策为空 |
| `excluded_iocs_json` | JSON | 排除IOC与依据 | 01 / 02 校验；00附来源并聚合 |
| `quality_warnings_json` | JSON | 质量提示 | 00 / 01 / 02 / 04，00归属到来源 |
| `errors_json` | JSON | 阶段、代码、说明 | 各阶段产生，00归属到记录 |
| `input_hash` | TEXT | 规范化单篇JSON的UTF-8字节SHA-256 | 00入口 |
| `input_meta_json` | JSON | 规范化正文长度、实际长度、截断和可选原文版本 | 00入口 |
| `processing_version` | TEXT | 交付配置版本 | 构建时写入00入口 |
| `created_at` | DATETIME | 实际入库时间 | 入库程序（传输占位null） |

## candidates

| 字段 | 类型 | 说明 | 产生阶段 |
|---|---|---|---|
| `candidate_record_id` | TEXT | 本批次候选记录ID | 00 汇总生成并关联 |
| `candidate_id` | TEXT | 工作流候选标识 | 01 / 02 / 03 生成 |
| `run_id` | TEXT | 本次批次 | 00 入口生成 |
| `candidate_type` | TEXT | 安全事件/合规政策 | 01 / 02 / 04 |
| `primary_item_id` | TEXT | 主要来源记录 | 00映射现有默认来源 |
| `title` | TEXT | AI标题 | 01 / 02 / 04 |
| `summary` | TEXT | AI摘要 | 01 / 02 / 04 |
| `facts_json` | JSON | 完整事实对象 | 资讯为02抽取；候选为02政策或04事件；快讯为空 |
| `relevance` | INTEGER | 相关性0–5 | 01 / 02；候选由04选择来源 |
| `impact` | INTEGER | 影响程度0–5 | 01 / 02；候选由04选择来源 |
| `freshness` | INTEGER | 时效性0–5 | 01 / 02；候选由04选择来源 |
| `evidence_quality` | INTEGER | 证据质量0–5 | 01 / 02；候选由04选择来源 |
| `audience_value` | INTEGER | 受众价值0–5 | 01 / 02；候选由04选择来源 |
| `total_score` | INTEGER | 五项评分之和×4 | 01 / 02；候选由04选择来源 |
| `reason` | TEXT | 判断理由 | 01 / 02；04 继承评分来源 |
| `score_strategy` | TEXT | 评分来源选择策略 | 01 / 02 / 04 |
| `score_source_item_id` | TEXT | 评分来源记录 | 00映射评分来源 |
| `match_reason` | TEXT | 多来源归并理由 | 03；00仅对多来源候选保留 |
| `ioc_json` | JSON | 六类IOC数组对象；null表示无有效提取结果 | 01 扫描、02事件抽取、00聚合；普通政策为空 |
| `excluded_iocs_json` | JSON | 排除IOC与依据 | 01 / 02 校验；00附来源并聚合 |
| `quality_warnings_json` | JSON | 质量提示 | 00 / 01 / 02 / 04，00归属到来源 |
| `review_status` | TEXT | pending/accepted/rejected/deferred | 00初始化pending；审核端更新 |
| `review_reason_code` | TEXT | 人工原因代码 | 人工审核端（初始null） |
| `review_comment` | TEXT | 人工意见 | 人工审核端（初始null） |
| `reviewed_title` | TEXT | 人工标题覆盖值 | 人工审核端（初始null） |
| `reviewed_summary` | TEXT | 人工摘要覆盖值 | 人工审核端（初始null） |
| `review_corrections_json` | JSON | 其他人工修正 | 人工审核端（初始null） |
| `reviewer_id` | TEXT | 审核人ID | 人工审核端（初始null） |
| `reviewed_at` | DATETIME | 审核提交时间 | 人工审核端（初始null） |
| `created_at` | DATETIME | 实际入库时间 | 入库程序（传输占位null） |
| `updated_at` | DATETIME | 最近修改时间 | 入库程序/审核端（传输占位null） |
