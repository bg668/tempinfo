#!/usr/bin/env python3
import argparse,json
from pathlib import Path
import yaml
EXPECTED={'news_digest_process':'DIGEST','news_article_process':'ARTICLE','news_event_match':'MATCH','news_event_candidate':'CANDIDATE'}
COPY=('provider_id','provider_type','provider_name','tool_name','tool_label','version','tool_node_version','tool_description','is_team_authorization','paramSchemas','params','plugin_id','provider_icon','provider_icon_dark','plugin_unique_identifier')
def from_dsl(path):
    d=yaml.safe_load(Path(path).read_text(encoding='utf-8')); out={}
    for n in d.get('workflow',{}).get('graph',{}).get('nodes',[]):
        x=n.get('data') or {}
        if x.get('type')=='tool' and x.get('provider_type')=='workflow' and x.get('tool_name') in EXPECTED: out[x['tool_name']]={k:x.get(k) for k in COPY if k in x}
    return out
def from_json(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--template',required=True); g=ap.add_mutually_exclusive_group(required=True); g.add_argument('--tool-dsl'); g.add_argument('--bindings-json'); ap.add_argument('--output',required=True); a=ap.parse_args()
    bind=from_dsl(a.tool_dsl) if a.tool_dsl else from_json(a.bindings_json); missing=[x for x in EXPECTED if x not in bind]
    if missing: raise SystemExit('缺少 Workflow Tool: '+','.join(missing))
    d=yaml.safe_load(Path(a.template).read_text(encoding='utf-8')); count=0
    for n in d['workflow']['graph']['nodes']:
        x=n.get('data') or {}; name=x.get('tool_name')
        if x.get('type')!='tool' or name not in EXPECTED: continue
        cfg=bind[name]
        if not cfg.get('provider_id'): raise SystemExit(name+' 缺少 provider_id')
        params=x.get('tool_parameters') or {}; title=x.get('title'); desc=x.get('desc')
        schemas=cfg.get('paramSchemas')
        if not isinstance(schemas,list): raise SystemExit(name+' 缺少真实参数定义；请发布新子流程并导出包含四个工具的临时DSL')
        names={p.get('name') for p in schemas}
        if set(params)-names: raise SystemExit(name+' 工具接口过期，缺少 '+','.join(sorted(set(params)-names))+'；请更新工具定义后重新导出')
        for k in COPY:
            if cfg.get(k) is not None: x[k]=cfg[k]
        x['provider_type']='workflow'; x['tool_name']=name; x['tool_parameters']=params; x['title']=title; x['desc']=desc; count+=1
    if count!=4: raise SystemExit(f'仅绑定 {count}/4 个工具')
    text=yaml.safe_dump(d,allow_unicode=True,sort_keys=False,width=120)
    if '__DIGEST_PROVIDER_ID__' in text or '__ARTICLE_PROVIDER_ID__' in text or '__MATCH_PROVIDER_ID__' in text or '__CANDIDATE_PROVIDER_ID__' in text: raise SystemExit('仍有未替换 provider placeholder')
    Path(a.output).write_text(text,encoding='utf-8'); print('已生成',a.output)
if __name__=='__main__': main()
