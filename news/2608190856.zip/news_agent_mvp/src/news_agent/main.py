from __future__ import annotations

import argparse
import json
from pathlib import Path

from .benchmark import BenchmarkCase, evaluate, load_labels
from .collector_adapter import CollectorAdapter
from .config import load_config
from .extraction_pipeline import ExtractionPipeline
from .pipeline import TriagePipeline, build_identity
from .schema_export import export_all_schemas, export_schema
from .skill import load_skill
from .store import NewsAgentStore
from .tree_text import render_article


def _default_triage_skill() -> Path:
    return Path("skills/article-triage/SKILL.md")


def _default_incident_skill() -> Path:
    return Path("skills/incident-extract/SKILL.md")


def _default_policy_skill() -> Path:
    return Path("skills/policy-extract/SKILL.md")


def _default_event_match_skill() -> Path:
    return Path("skills/event-match/SKILL.md")


def _default_candidate_skill() -> Path:
    return Path("skills/candidate-compose/SKILL.md")


def _add_extract_args(parser: argparse.ArgumentParser, *, include_limit: bool = True) -> None:
    parser.add_argument("--collector-db", required=True)
    parser.add_argument("--news-db", default="data/newsagent.db")
    parser.add_argument("--config", default="config/model.yaml")
    parser.add_argument("--triage-skill", default=str(_default_triage_skill()))
    if include_limit:
        parser.add_argument("--limit", type=int)
    parser.add_argument("--id", action="append", dest="ids")
    parser.add_argument(
        "--triage-signature",
        help="Use KEEP rows from one Stage 1 signature; default is the current config + article-triage SKILL signature",
    )
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--verbose", action="store_true")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="news-agent")
    sub = parser.add_subparsers(dest="command", required=True)

    inspect = sub.add_parser("inspect-input", help="Render Collector rows as the exact tree text sent to the LLM")
    inspect.add_argument("--collector-db", required=True)
    inspect.add_argument("--config", default="config/model.yaml")
    inspect.add_argument("--limit", type=int, default=1)
    inspect.add_argument("--id", action="append", dest="ids")

    triage = sub.add_parser("triage", help="Run Stage 1 Article Triage")
    triage.add_argument("--collector-db", required=True)
    triage.add_argument("--news-db", default="data/newsagent.db")
    triage.add_argument("--config", default="config/model.yaml")
    triage.add_argument("--skill", default=str(_default_triage_skill()))
    triage.add_argument("--limit", type=int)
    triage.add_argument("--id", action="append", dest="ids")
    triage.add_argument("--force", action="store_true")
    triage.add_argument("--verbose", action="store_true", help="Print category, nature, scores, reason and output retry errors")

    bench = sub.add_parser("benchmark", help="Run/evaluate the starter benchmark set")
    bench.add_argument("--collector-db", required=True)
    bench.add_argument("--news-db", default="data/newsagent.db")
    bench.add_argument("--config", default="config/model.yaml")
    bench.add_argument("--skill", default=str(_default_triage_skill()))
    bench.add_argument("--labels", default="tests/benchmark/labels.jsonl")
    bench.add_argument("--run", action="store_true", help="Run missing benchmark articles before evaluation")
    bench.add_argument("--force", action="store_true", help="Rerun benchmark rows even if the same analysis signature succeeded")
    bench.add_argument("--verbose", action="store_true", help="Print all benchmark cases; mismatches are always printed")

    debug = sub.add_parser("debug-result", help="Inspect one persisted triage trace without calling a model")
    debug.add_argument("--news-db", default="data/newsagent.db")
    debug.add_argument("--id", required=True)
    debug.add_argument("--signature", help="Inspect a specific analysis signature; default is latest result for the article")
    debug.add_argument("--full", action="store_true", help="Also print full skill snapshot, rendered LLM input and final raw output")

    extract = sub.add_parser("extract", help="Route current-signature KEEP rows to incident-extract or policy-extract")
    _add_extract_args(extract)
    extract.add_argument("--incident-skill", default=str(_default_incident_skill()))
    extract.add_argument("--policy-skill", default=str(_default_policy_skill()))

    incident = sub.add_parser("incident-extract", help="Extract facts from KEEP/security_event articles")
    _add_extract_args(incident)
    incident.add_argument("--skill", default=str(_default_incident_skill()))

    policy = sub.add_parser("policy-extract", help="Extract facts from KEEP/compliance_policy articles")
    _add_extract_args(policy)
    policy.add_argument("--skill", default=str(_default_policy_skill()))

    debug_extract = sub.add_parser("debug-extraction", help="Inspect one saved incident/policy extraction without calling a model")
    debug_extract.add_argument("--news-db", default="data/newsagent.db")
    debug_extract.add_argument("--stage", choices=["incident", "policy"], required=True)
    debug_extract.add_argument("--id", required=True)
    debug_extract.add_argument("--signature")
    debug_extract.add_argument("--full", action="store_true")

    event_match = sub.add_parser("event-match", help="Conservatively group current incident facts into Events")
    event_match.add_argument("--news-db", default="data/newsagent.db")
    event_match.add_argument("--config", default="config/model.yaml")
    event_match.add_argument("--triage-skill", default=str(_default_triage_skill()))
    event_match.add_argument("--incident-skill", default=str(_default_incident_skill()))
    event_match.add_argument("--skill", default=str(_default_event_match_skill()))
    event_match.add_argument("--triage-signature")
    event_match.add_argument("--id", action="append", dest="ids")
    event_match.add_argument("--force", action="store_true")
    event_match.add_argument("--verbose", action="store_true")

    compose = sub.add_parser("compose", help="Compose Event/Policy candidates and export JSON/Markdown")
    compose.add_argument("--news-db", default="data/newsagent.db")
    compose.add_argument("--config", default="config/model.yaml")
    compose.add_argument("--triage-skill", default=str(_default_triage_skill()))
    compose.add_argument("--incident-skill", default=str(_default_incident_skill()))
    compose.add_argument("--policy-skill", default=str(_default_policy_skill()))
    compose.add_argument("--event-match-skill", default=str(_default_event_match_skill()))
    compose.add_argument("--candidate-skill", default=str(_default_candidate_skill()))
    compose.add_argument("--triage-signature")
    compose.add_argument("--output-dir", default="output/mvp")
    compose.add_argument("--id", action="append", dest="ids")
    compose.add_argument("--force", action="store_true")
    compose.add_argument("--verbose", action="store_true")

    mvp = sub.add_parser("mvp-run", help="Run the complete MVP from Collector articles to human-review candidates")
    mvp.add_argument("--collector-db", required=True)
    mvp.add_argument("--news-db", default="data/newsagent.db")
    mvp.add_argument("--config", default="config/model.yaml")
    mvp.add_argument("--triage-skill", default=str(_default_triage_skill()))
    mvp.add_argument("--incident-skill", default=str(_default_incident_skill()))
    mvp.add_argument("--policy-skill", default=str(_default_policy_skill()))
    mvp.add_argument("--event-match-skill", default=str(_default_event_match_skill()))
    mvp.add_argument("--candidate-skill", default=str(_default_candidate_skill()))
    mvp.add_argument("--output-dir", default="output/mvp")
    mvp.add_argument("--limit", type=int)
    mvp.add_argument("--id", action="append", dest="ids")
    mvp.add_argument("--force", action="store_true")
    mvp.add_argument("--verbose", action="store_true")

    debug_match = sub.add_parser("debug-event-match", help="Inspect the latest saved event-match trace")
    debug_match.add_argument("--news-db", default="data/newsagent.db")
    debug_match.add_argument("--full", action="store_true")

    debug_candidate = sub.add_parser("debug-candidate", help="Inspect one saved Event candidate trace")
    debug_candidate.add_argument("--news-db", default="data/newsagent.db")
    debug_candidate.add_argument("--event-id", required=True)
    debug_candidate.add_argument("--full", action="store_true")

    schema = sub.add_parser("export-schema", help="Regenerate skill schema.json from Pydantic contracts")
    schema.add_argument(
        "--stage",
        choices=["article-triage", "incident-extract", "policy-extract", "event-match", "candidate-compose", "all"],
        default="article-triage",
    )
    schema.add_argument("--output", help="Custom output path; only valid for one stage")
    return parser


def _load_attempts(row) -> list[dict]:
    try:
        return json.loads(row["output_attempts_json"] or "[]")
    except (TypeError, json.JSONDecodeError):
        return []


def _print_row_details(row, *, indent: str = "  ", full: bool = False) -> None:
    print(f"{indent}status: {row['status']}")
    print(f"{indent}signature: {row['analysis_signature']}")
    print(f"{indent}model: {row['model_name']}")
    print(f"{indent}analyzed_at: {row['analyzed_at']}")
    if row["status"] == "SUCCESS":
        print(f"{indent}decision: {row['decision']}")
        print(f"{indent}route: {row['route']}")
        print(f"{indent}category: {row['category']}")
        print(f"{indent}nature: {row['content_nature']}")
        print(
            f"{indent}scores: relevance={row['relevance']} impact={row['impact']} "
            f"freshness={row['freshness']} evidence_quality={row['evidence_quality']} "
            f"audience_value={row['audience_value']} total={row['total_score']}"
        )
        print(f"{indent}reason: {row['reason']}")
    else:
        print(f"{indent}error: {row['error_type']}: {row['error_message']}")

    attempts = _load_attempts(row)
    print(f"{indent}output_attempts: {len(attempts)}")
    for item in attempts:
        suffix = ""
        if item.get("status") == "INVALID":
            suffix = f" {item.get('error_type')}: {item.get('error_message')}"
        print(f"{indent}  attempt[{item.get('attempt')}]: {item.get('status')}{suffix}")

    if full:
        print(f"{indent}--- skill_snapshot ---")
        print(row["skill_snapshot"] or "")
        print(f"{indent}--- rendered_input ---")
        print(row["rendered_input"] or "")
        print(f"{indent}--- raw_output ---")
        print(row["raw_output"] or "")
        if attempts:
            print(f"{indent}--- output_attempt_raw_text ---")
            for item in attempts:
                print(f"attempt[{item.get('attempt')}] status={item.get('status')}")
                print(item.get("raw_text") or "")
                print("---")


def _print_fact_details(row, *, stage: str, full: bool = False) -> None:
    print(f"status: {row['status']}")
    print(f"upstream_triage_signature: {row['upstream_triage_signature']}")
    print(f"signature: {row['analysis_signature']}")
    print(f"model: {row['model_name']}")
    print(f"analyzed_at: {row['analyzed_at']}")
    if row["status"] == "SUCCESS":
        try:
            data = json.loads(row["result_json"] or "{}")
        except json.JSONDecodeError:
            data = {}
        print(json.dumps(data, ensure_ascii=False, indent=2))
        if stage == "incident":
            print(
                "ioc_counts: "
                f"ip={row['ip_count']} domain={row['domain_count']} url={row['url_count']} "
                f"hash={row['hash_count']} file_path={row['file_path_count']}"
            )
    else:
        print(f"error: {row['error_type']}: {row['error_message']}")
    attempts = _load_attempts(row)
    print(f"output_attempts: {len(attempts)}")
    for item in attempts:
        suffix = ""
        if item.get("status") == "INVALID":
            suffix = f" {item.get('error_type')}: {item.get('error_message')}"
        print(f"  attempt[{item.get('attempt')}]: {item.get('status')}{suffix}")
    if full:
        print("--- skill_snapshot ---")
        print(row["skill_snapshot"] or "")
        print("--- rendered_input ---")
        print(row["rendered_input"] or "")
        print("--- raw_output ---")
        print(row["raw_output"] or "")


def _print_benchmark_case(case: BenchmarkCase, *, title: str = "", verbose: bool = False) -> None:
    if case.status != "SUCCESS":
        print(f"[UNAVAILABLE] {case.source_article_id} status={case.status} {title or case.note}")
        if case.row is not None:
            _print_row_details(case.row, indent="  ", full=False)
        return
    marker = "MATCH" if case.matched else "MISMATCH"
    if marker == "MATCH" and not verbose:
        return
    print(f"[{marker}] {case.source_article_id} {title or case.note}")
    print(f"  expected: {case.expected_decision} / {case.expected_route}")
    print(f"  actual:   {case.actual_decision} / {case.actual_route}")
    if case.note:
        print(f"  label_note: {case.note}")
    if case.row is not None:
        _print_row_details(case.row, indent="  ", full=False)


def _run_one_extraction(args, *, stage: str, skill_path: str, only_ids=None, limit=None):
    from .stages.incident import PydanticAIIncidentRuntime
    from .stages.policy import PydanticAIPolicyRuntime

    config = load_config(args.config)
    collector = CollectorAdapter(args.collector_db)
    store = NewsAgentStore(args.news_db)
    skill_text = load_skill(skill_path)
    if stage == "incident":
        runtime = PydanticAIIncidentRuntime(config=config, skill_text=skill_text)
    else:
        runtime = PydanticAIPolicyRuntime(config=config, skill_text=skill_text)
    pipeline = ExtractionPipeline(
        stage=stage,
        config=config,
        collector=collector,
        store=store,
        runtime=runtime,
        skill_text=skill_text,
    )
    triage_signature = args.triage_signature
    if triage_signature is None:
        triage_signature = build_identity(config, load_skill(args.triage_skill)).analysis_signature
    return pipeline.run(
        limit=limit,
        only_ids=only_ids if only_ids is not None else args.ids,
        triage_signature=triage_signature,
        force=args.force,
        verbose=args.verbose,
    ), pipeline.identity.analysis_signature


def main() -> None:
    args = build_parser().parse_args()

    if args.command == "mvp-run":
        from .mvp import run_mvp
        run_mvp(args)
        return

    if args.command == "event-match":
        from .mvp import run_event_match
        run_event_match(args)
        return

    if args.command == "compose":
        from .mvp import run_compose
        run_compose(args)
        return

    if args.command == "debug-event-match":
        from .resilience import CheckpointStore

        store = NewsAgentStore(args.news_db)
        row = store.get_latest_event_match_run()
        if row is None:
            raise SystemExit("no event-match result found")
        print(f"status: {row['status']}")
        print(f"triage_signature: {row['upstream_triage_signature']}")
        print(f"incident_signature: {row['upstream_incident_signature']}")
        print(f"signature: {row['analysis_signature']}")
        print(f"input_sha256: {row['input_sha256']}")
        print(f"group_count: {row['group_count']}")
        if row['status'] == 'SUCCESS':
            print(json.dumps(json.loads(row['result_json']), ensure_ascii=False, indent=2))
        else:
            print(f"error: {row['error_type']}: {row['error_message']}")
        checkpoint_store = CheckpointStore(args.news_db)
        checkpoint = next(
            (
                item
                for item in checkpoint_store.list_stage("event_match")
                if item.input_hash == row["input_sha256"]
            ),
            None,
        )
        task_history = checkpoint_store.list_attempts(checkpoint.task_id) if checkpoint else []
        if checkpoint is not None:
            print(f"task_id: {checkpoint.task_id}")
            print(f"task_status: {checkpoint.status.value}")
            print(f"task_attempts: {checkpoint.attempts}")
            print(f"task_articles: {', '.join(checkpoint.input_article_ids)}")
            if checkpoint.last_error:
                print(f"task_error: {checkpoint.last_error}")
            if checkpoint.diagnostics:
                print(
                    "task_diagnostics: "
                    + json.dumps(checkpoint.diagnostics, ensure_ascii=False, sort_keys=True)
                )
            if task_history:
                print(
                    "task_history: "
                    + ", ".join(
                        f"{item.task_attempt}:{item.status}" for item in task_history
                    )
                )
        if args.full:
            print("--- skill_snapshot ---"); print(row['skill_snapshot'] or '')
            print("--- rendered_input ---"); print(row['rendered_input'] or '')
            print("--- raw_output ---"); print(row['raw_output'] or '')
            attempts = _load_attempts(row)
            if attempts:
                print("--- output_attempts ---")
                print(json.dumps(attempts, ensure_ascii=False, indent=2))
            if checkpoint is not None and checkpoint.raw_outputs:
                print("--- checkpoint_raw_outputs ---")
                for index, output in enumerate(checkpoint.raw_outputs, start=1):
                    print(f"attempt[{index}]")
                    print(output)
                    print("---")
            if task_history:
                print("--- task_attempt_history ---")
                for item in task_history:
                    print(
                        f"task_attempt[{item.task_attempt}] status={item.status} "
                        f"input_hash={item.input_hash}"
                    )
                    if item.error_message:
                        print(f"error: {item.error_message}")
                    if item.diagnostics:
                        print(json.dumps(item.diagnostics, ensure_ascii=False, indent=2))
                    for output_index, output in enumerate(item.raw_outputs, start=1):
                        print(f"model_output[{output_index}]")
                        print(output)
                    print("---")
        return

    if args.command == "debug-candidate":
        store = NewsAgentStore(args.news_db)
        row = store.get_latest_event_candidate(args.event_id)
        if row is None:
            raise SystemExit(f"no event candidate found for {args.event_id}")
        print(f"status: {row['status']}")
        print(f"signature: {row['analysis_signature']}")
        if row['status'] == 'SUCCESS':
            print(json.dumps(json.loads(row['result_json']), ensure_ascii=False, indent=2))
        else:
            print(f"error: {row['error_type']}: {row['error_message']}")
        if args.full:
            print("--- skill_snapshot ---"); print(row['skill_snapshot'] or '')
            print("--- rendered_input ---"); print(row['rendered_input'] or '')
            print("--- raw_output ---"); print(row['raw_output'] or '')
        return

    if args.command == "export-schema":
        if args.stage == "all":
            if args.output:
                raise SystemExit("--output cannot be used with --stage all")
            for path in export_all_schemas():
                print(path)
        else:
            print(export_schema(args.stage, args.output))
        return

    if args.command == "debug-result":
        store = NewsAgentStore(args.news_db)
        row = store.get_result(args.id, args.signature) if args.signature else store.get_latest_result(args.id)
        if row is None:
            raise SystemExit(f"no triage result found for {args.id}")
        print(f"source_article_id: {args.id}")
        _print_row_details(row, indent="", full=args.full)
        return

    if args.command == "debug-extraction":
        store = NewsAgentStore(args.news_db)
        row = store.get_fact(args.stage, args.id, args.signature) if args.signature else store.get_latest_fact(args.stage, args.id)
        if row is None:
            raise SystemExit(f"no {args.stage} extraction found for {args.id}")
        print(f"source_article_id: {args.id}")
        _print_fact_details(row, stage=args.stage, full=args.full)
        return

    if args.command in {"incident-extract", "policy-extract"}:
        stage = "incident" if args.command == "incident-extract" else "policy"
        stats, signature = _run_one_extraction(
            args,
            stage=stage,
            skill_path=args.skill,
            limit=args.limit,
        )
        print(
            f"stage={stage} eligible={stats.eligible} processed={stats.processed} "
            f"succeeded={stats.succeeded} failed={stats.failed} "
            f"skipped_existing={stats.skipped_existing} missing_article={stats.missing_article} "
            f"signature={signature}"
        )
        return

    if args.command == "extract":
        store = NewsAgentStore(args.news_db)
        config = load_config(args.config)
        triage_signature = args.triage_signature or build_identity(
            config, load_skill(args.triage_skill)
        ).analysis_signature
        args.triage_signature = triage_signature
        selected = store.iter_kept_triage(
            triage_signature=triage_signature,
            only_ids=args.ids,
            limit=args.limit,
        )
        incident_ids = [r["source_article_id"] for r in selected if r["route"] == "security_event"]
        policy_ids = [r["source_article_id"] for r in selected if r["route"] == "compliance_policy"]
        total_processed = total_succeeded = total_failed = total_skipped = total_missing = 0
        signatures: list[str] = []
        if incident_ids:
            stats, sig = _run_one_extraction(
                args,
                stage="incident",
                skill_path=args.incident_skill,
                only_ids=incident_ids,
                limit=None,
            )
            signatures.append(f"incident={sig}")
            total_processed += stats.processed; total_succeeded += stats.succeeded
            total_failed += stats.failed; total_skipped += stats.skipped_existing; total_missing += stats.missing_article
        if policy_ids:
            stats, sig = _run_one_extraction(
                args,
                stage="policy",
                skill_path=args.policy_skill,
                only_ids=policy_ids,
                limit=None,
            )
            signatures.append(f"policy={sig}")
            total_processed += stats.processed; total_succeeded += stats.succeeded
            total_failed += stats.failed; total_skipped += stats.skipped_existing; total_missing += stats.missing_article
        print(
            f"extract eligible={len(selected)} incident={len(incident_ids)} policy={len(policy_ids)} "
            f"processed={total_processed} succeeded={total_succeeded} failed={total_failed} "
            f"skipped_existing={total_skipped} missing_article={total_missing} "
            + " ".join(signatures)
        )
        return

    config = load_config(args.config)
    collector = CollectorAdapter(args.collector_db)

    if args.command == "inspect-input":
        for article in collector.iter_fetched(only_ids=args.ids, limit=args.limit):
            print(render_article(article, max_content_chars=config.runtime.max_content_chars))
            print("\n---\n")
        return

    skill_text = load_skill(args.skill)
    store = NewsAgentStore(args.news_db)
    identity = build_identity(config, skill_text)

    if args.command == "triage":
        from .stages.triage import PydanticAITriageRuntime

        runtime = PydanticAITriageRuntime(config=config, skill_text=skill_text)
        stats = TriagePipeline(
            config=config,
            collector=collector,
            store=store,
            runtime=runtime,
            skill_text=skill_text,
        ).run(limit=args.limit, only_ids=args.ids, force=args.force, verbose=args.verbose)
        print(
            f"processed={stats.processed} keep={stats.keep} drop={stats.drop} "
            f"uncertain={stats.uncertain} failed={stats.failed} "
            f"signature={identity.analysis_signature}"
        )
        return

    if args.command == "benchmark":
        labels = load_labels(args.labels)
        benchmark_ids = [x["source_article_id"] for x in labels]
        title_map = {
            article.source_article_id: article.title
            for article in collector.iter_fetched(only_ids=benchmark_ids)
        }
        if args.run:
            from .stages.triage import PydanticAITriageRuntime

            runtime = PydanticAITriageRuntime(config=config, skill_text=skill_text)
            TriagePipeline(
                config=config,
                collector=collector,
                store=store,
                runtime=runtime,
                skill_text=skill_text,
            ).run(only_ids=benchmark_ids, force=args.force, verbose=args.verbose)
        summary = evaluate(
            store,
            analysis_signature=identity.analysis_signature,
            labels_path=args.labels,
        )
        for case in summary.cases:
            _print_benchmark_case(
                case,
                title=title_map.get(case.source_article_id, ""),
                verbose=args.verbose,
            )
        print(
            f"benchmark total={summary.total} available={summary.available} "
            f"mismatch={len(summary.mismatches)} unavailable={len(summary.unavailable)} "
            f"decision_accuracy={summary.decision_accuracy:.1%} "
            f"route_accuracy={summary.route_accuracy:.1%} "
            f"signature={identity.analysis_signature}"
        )
        return


if __name__ == "__main__":
    main()
