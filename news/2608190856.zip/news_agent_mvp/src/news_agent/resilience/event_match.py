from __future__ import annotations

from typing import Any

from ..contracts import EventGroup, EventMatchResult, IncidentResult
from .exact_cover import validate_exact_cover


def _partition_diagnostics(expected_ids: list[str], result: EventMatchResult) -> dict[str, Any]:
    groups = [group.member_article_ids for group in result.groups.values()]
    issue = validate_exact_cover(expected_ids, groups)
    return {
        "degraded": not issue.ok,
        "missing": list(issue.missing),
        "duplicate": list(issue.duplicate),
        "unknown": list(issue.unknown),
    }


def reconcile_event_match_result(
    incidents: tuple[IncidentResult, ...] | list[IncidentResult],
    result: EventMatchResult,
) -> tuple[EventMatchResult, dict[str, Any]]:
    """Repair only set-integrity defects; never invent a positive merge decision."""
    expected_ids = [item.source_article_id for item in incidents]
    before = _partition_diagnostics(expected_ids, result)
    if not before["degraded"]:
        return result, before

    expected = set(expected_ids)
    duplicate = set(before["duplicate"])
    by_id = {item.source_article_id: item for item in incidents}
    repaired_groups: dict[str, EventGroup] = {}
    assigned: set[str] = set()

    for key, group in result.groups.items():
        members: list[str] = []
        for article_id in group.member_article_ids:
            if article_id not in expected or article_id in duplicate or article_id in assigned:
                continue
            assigned.add(article_id)
            members.append(article_id)
        if members:
            repaired_groups[key] = group.model_copy(update={"member_article_ids": members})

    recovery_index = 1
    for article_id in expected_ids:
        if article_id in assigned:
            continue
        incident = by_id[article_id]
        while True:
            key = f"recovered_{recovery_index}"
            recovery_index += 1
            if key not in repaired_groups:
                break
        repaired_groups[key] = EventGroup(
            canonical_title=incident.title,
            member_article_ids=[article_id],
            match_reason="模型分组未能唯一覆盖该文章，按保守策略拆分为独立事件。",
        )
        assigned.add(article_id)

    repaired = EventMatchResult(groups=repaired_groups)
    after = _partition_diagnostics(expected_ids, repaired)
    if after["degraded"]:
        raise AssertionError(f"event-match exact-cover reconciliation failed: {after}")

    diagnostics = {
        **before,
        "degraded": True,
        "reconciled": True,
        "group_count_before": len(result.groups),
        "group_count_after": len(repaired.groups),
    }
    return repaired, diagnostics


def singleton_event_match_result(
    incidents: tuple[IncidentResult, ...] | list[IncidentResult],
    *,
    reason: str = "event-match 任务失败，按保守降级策略单篇保留，等待下次恢复重试。",
) -> EventMatchResult:
    """Safe in-memory fallback; callers must not persist it as a successful match task."""
    return EventMatchResult(
        groups={
            f"fallback_{index}": EventGroup(
                canonical_title=incident.title,
                member_article_ids=[incident.source_article_id],
                match_reason=reason,
            )
            for index, incident in enumerate(incidents, start=1)
        }
    )
