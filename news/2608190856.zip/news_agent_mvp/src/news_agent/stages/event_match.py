from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pydantic_ai import Agent, ModelRetry, RunContext, TextOutput
from pydantic_ai.capabilities import Capability

from ..config import AppConfig
from ..contracts import EventMatchResult
from ..provider import build_model
from ..resilience.event_match import reconcile_event_match_result
from ..tree_text import TreeTextError, parse_event_match_output, render_event_match_input
from ._attempts import begin_attempt, fail_attempt, finish_trace, pass_attempt, start_trace
from .base import EventMatchExecution, EventMatchExecutionError, EventMatchInput


def _parse_output(ctx: RunContext[EventMatchInput], text: str) -> EventMatchResult:
    attempt = begin_attempt(text, ctx.retry)
    try:
        parsed = parse_event_match_output(text)
    except TreeTextError as exc:
        fail_attempt(attempt, type(exc).__name__, str(exc))
        raise ModelRetry(
            "输出无法通过 event-match 数据契约。请按 SKILL.md 重新输出完整树状结构；"
            "不要增加字段或解释。"
            f"错误：{exc}"
        ) from exc

    # Exact-cover is a deterministic set-integrity constraint. Once the output is structurally
    # parseable, repair missing/duplicate/unknown memberships conservatively instead of spending
    # another model retry on a problem the program can resolve safely.
    try:
        result, diagnostics = reconcile_event_match_result(ctx.deps.incidents, parsed)
    except Exception as exc:
        fail_attempt(attempt, type(exc).__name__, str(exc))
        raise ModelRetry(
            "输出无法通过 event-match 数据契约。请按 SKILL.md 重新分组；"
            "所有输入文章必须且只能出现一次，不确定是否同一事件时拆开。"
            f"错误：{exc}"
        ) from exc

    attempt["diagnostics"] = diagnostics
    if diagnostics.get("degraded"):
        attempt["reconciled"] = True
    pass_attempt(attempt)
    return result


@dataclass
class PydanticAIEventMatchRuntime:
    config: AppConfig
    skill_text: str

    def __post_init__(self) -> None:
        model, model_settings = build_model(self.config)
        capability = Capability(
            id="event-match",
            description="Conservatively group extracted incident facts that describe the same real-world event.",
            instructions=self.skill_text,
            defer_loading=False,
        )
        self._agent = Agent(
            model,
            deps_type=EventMatchInput,
            output_type=TextOutput(_parse_output),
            capabilities=[capability],
            model_settings=model_settings,
            retries={"output": self.config.runtime.output_retries},
        )

    def run(self, data: EventMatchInput) -> EventMatchExecution:
        prompt = render_event_match_input(
            triage_signature=data.triage_signature,
            incident_signature=data.incident_signature,
            incidents=list(data.incidents),
        )
        attempts, token = start_trace()
        try:
            result = self._agent.run_sync(prompt, deps=data)
            parsed: EventMatchResult = result.output
            raw_output = str(attempts[-1].get("raw_text") or "") if attempts else ""
            diagnostics: dict[str, Any] = {}
            if attempts:
                diagnostics = dict(attempts[-1].get("diagnostics") or {})
            diagnostics["model_output_attempts"] = len(attempts)
            diagnostics["validation_errors"] = [
                {
                    "attempt": item.get("attempt"),
                    "error_type": item.get("error_type"),
                    "error_message": item.get("error_message"),
                }
                for item in attempts
                if item.get("status") == "INVALID"
            ]
            return EventMatchExecution(
                result=parsed,
                rendered_input=prompt,
                raw_output=raw_output,
                output_attempts=tuple(dict(item) for item in attempts),
                diagnostics=diagnostics,
            )
        except Exception as exc:
            raw_output = str(attempts[-1].get("raw_text") or "") if attempts else ""
            diagnostics = {
                "model_output_attempts": len(attempts),
                "validation_errors": [
                    {
                        "attempt": item.get("attempt"),
                        "error_type": item.get("error_type"),
                        "error_message": item.get("error_message"),
                    }
                    for item in attempts
                    if item.get("status") == "INVALID"
                ],
            }
            raise EventMatchExecutionError(
                cause=exc,
                rendered_input=prompt,
                raw_output=raw_output,
                output_attempts=tuple(dict(item) for item in attempts),
                diagnostics=diagnostics,
            ) from exc
        finally:
            finish_trace(token)
