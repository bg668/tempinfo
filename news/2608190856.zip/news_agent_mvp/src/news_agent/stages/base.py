from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Protocol

from ..contracts import (
    CollectorArticle,
    EventCandidateDraft,
    EventMatchResult,
    IncidentResult,
    PolicyResult,
    TriageResult,
)


class StageExecutionError(RuntimeError):
    def __init__(
        self,
        *,
        cause: Exception,
        rendered_input: str,
        raw_output: str = "",
        output_attempts: tuple[dict[str, Any], ...] = (),
        diagnostics: Mapping[str, Any] | None = None,
    ) -> None:
        super().__init__(str(cause))
        self.cause = cause
        self.rendered_input = rendered_input
        self.raw_output = raw_output
        self.output_attempts = output_attempts
        self.diagnostics = dict(diagnostics or {})


@dataclass(frozen=True)
class TriageExecution:
    result: TriageResult
    rendered_input: str
    raw_output: str
    output_attempts: tuple[dict[str, Any], ...] = ()


class TriageExecutionError(StageExecutionError):
    pass


class TriageRuntime(Protocol):
    def run(self, article: CollectorArticle) -> TriageExecution: ...


@dataclass(frozen=True)
class IncidentExecution:
    result: IncidentResult
    rendered_input: str
    raw_output: str
    output_attempts: tuple[dict[str, Any], ...] = ()


class IncidentExecutionError(StageExecutionError):
    pass


class IncidentRuntime(Protocol):
    def run(self, article: CollectorArticle) -> IncidentExecution: ...


@dataclass(frozen=True)
class PolicyExecution:
    result: PolicyResult
    rendered_input: str
    raw_output: str
    output_attempts: tuple[dict[str, Any], ...] = ()


class PolicyExecutionError(StageExecutionError):
    pass


class PolicyRuntime(Protocol):
    def run(self, article: CollectorArticle) -> PolicyExecution: ...


@dataclass(frozen=True)
class EventMatchInput:
    triage_signature: str
    incident_signature: str
    incidents: tuple[IncidentResult, ...]


@dataclass(frozen=True)
class EventMatchExecution:
    result: "EventMatchResult"
    rendered_input: str
    raw_output: str
    output_attempts: tuple[dict[str, Any], ...] = ()
    diagnostics: Mapping[str, Any] | None = None


class EventMatchExecutionError(StageExecutionError):
    pass


class EventMatchRuntime(Protocol):
    def run(self, data: EventMatchInput) -> EventMatchExecution: ...


@dataclass(frozen=True)
class EventCandidateInput:
    event_id: str
    canonical_title: str
    match_reason: str
    incidents: tuple[IncidentResult, ...]


@dataclass(frozen=True)
class EventCandidateExecution:
    result: "EventCandidateDraft"
    rendered_input: str
    raw_output: str
    output_attempts: tuple[dict[str, Any], ...] = ()


class EventCandidateExecutionError(StageExecutionError):
    pass


class EventCandidateRuntime(Protocol):
    def run(self, data: EventCandidateInput) -> EventCandidateExecution: ...
