from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace

from .collector_adapter import CollectorAdapter
from .config import AppConfig, load_config
from .event_pipeline import (
    CandidatePipeline,
    EventMatchPipeline,
    build_event_candidate_identity,
    build_event_match_identity,
    deterministic_policy_id,
    export_candidates,
)
from .extraction_pipeline import ExtractionPipeline, build_extraction_identity
from .pipeline import TriagePipeline, build_identity
from .skill import load_skill
from .store import NewsAgentStore


@dataclass(frozen=True)
class PipelineSignatures:
    triage: str
    incident: str
    policy: str
    event_match: str
    event_candidate: str


def current_signatures(
    *,
    config: AppConfig,
    triage_skill: str,
    incident_skill: str,
    policy_skill: str,
    event_match_skill: str,
    candidate_skill: str,
) -> PipelineSignatures:
    return PipelineSignatures(
        triage=build_identity(config, triage_skill).analysis_signature,
        incident=build_extraction_identity(config, incident_skill, stage="incident").analysis_signature,
        policy=build_extraction_identity(config, policy_skill, stage="policy").analysis_signature,
        event_match=build_event_match_identity(config, event_match_skill).analysis_signature,
        event_candidate=build_event_candidate_identity(config, candidate_skill).analysis_signature,
    )


def _load_skills(args) -> dict[str, str]:
    return {
        "triage": load_skill(args.triage_skill),
        "incident": load_skill(args.incident_skill),
        "policy": load_skill(args.policy_skill),
        "event_match": load_skill(args.event_match_skill),
        "candidate": load_skill(args.candidate_skill),
    }


def run_mvp(args) -> tuple[Path, Path, PipelineSignatures]:
    from .stages.candidate import PydanticAIEventCandidateRuntime
    from .stages.event_match import PydanticAIEventMatchRuntime
    from .stages.incident import PydanticAIIncidentRuntime
    from .stages.policy import PydanticAIPolicyRuntime
    from .stages.triage import PydanticAITriageRuntime

    config = load_config(args.config)
    collector = CollectorAdapter(args.collector_db)
    store = NewsAgentStore(args.news_db)
    skills = _load_skills(args)
    signatures = current_signatures(
        config=config,
        triage_skill=skills["triage"],
        incident_skill=skills["incident"],
        policy_skill=skills["policy"],
        event_match_skill=skills["event_match"],
        candidate_skill=skills["candidate"],
    )

    articles = list(collector.iter_fetched(only_ids=args.ids, limit=args.limit))
    run_ids = [item.source_article_id for item in articles]
    if not run_ids:
        raise RuntimeError("Collector 中没有符合本次范围的 FETCHED 正文")

    triage_runtime = PydanticAITriageRuntime(config=config, skill_text=skills["triage"])
    triage_stats = TriagePipeline(
        config=config,
        collector=collector,
        store=store,
        runtime=triage_runtime,
        skill_text=skills["triage"],
    ).run(only_ids=run_ids, force=args.force, verbose=args.verbose)

    selected = store.iter_kept_triage(
        triage_signature=signatures.triage,
        only_ids=run_ids,
    )
    incident_ids = [row["source_article_id"] for row in selected if row["route"] == "security_event"]
    policy_ids = [row["source_article_id"] for row in selected if row["route"] == "compliance_policy"]

    incident_stats = None
    if incident_ids:
        incident_runtime = PydanticAIIncidentRuntime(config=config, skill_text=skills["incident"])
        incident_stats = ExtractionPipeline(
            stage="incident",
            config=config,
            collector=collector,
            store=store,
            runtime=incident_runtime,
            skill_text=skills["incident"],
        ).run(
            only_ids=incident_ids,
            triage_signature=signatures.triage,
            force=args.force,
            verbose=args.verbose,
        )

    policy_stats = None
    if policy_ids:
        policy_runtime = PydanticAIPolicyRuntime(config=config, skill_text=skills["policy"])
        policy_stats = ExtractionPipeline(
            stage="policy",
            config=config,
            collector=collector,
            store=store,
            runtime=policy_runtime,
            skill_text=skills["policy"],
        ).run(
            only_ids=policy_ids,
            triage_signature=signatures.triage,
            force=args.force,
            verbose=args.verbose,
        )

    groups = []
    match_stats = None
    if incident_ids:
        event_match_runtime = PydanticAIEventMatchRuntime(config=config, skill_text=skills["event_match"])
        event_match_pipeline = EventMatchPipeline(
            config=config,
            store=store,
            runtime=event_match_runtime,
            skill_text=skills["event_match"],
        )
        groups, match_stats = event_match_pipeline.run(
            triage_signature=signatures.triage,
            incident_signature=signatures.incident,
            only_ids=incident_ids,
            force=args.force,
            verbose=args.verbose,
        )

    event_candidate_runtime = PydanticAIEventCandidateRuntime(
        config=config,
        skill_text=skills["candidate"],
    )
    candidate_pipeline = CandidatePipeline(
        config=config,
        store=store,
        runtime=event_candidate_runtime,
        skill_text=skills["candidate"],
    )
    event_stats = candidate_pipeline.compose_events(
        groups=groups,
        triage_signature=signatures.triage,
        incident_signature=signatures.incident,
        event_match_signature=signatures.event_match,
        force=args.force,
        verbose=args.verbose,
    )
    policy_count = candidate_pipeline.compose_policies(
        triage_signature=signatures.triage,
        policy_signature=signatures.policy,
        only_ids=policy_ids,
    )

    event_ids = [group.event_id for group in groups]
    policy_candidate_ids = [deterministic_policy_id(source_id) for source_id in policy_ids]
    json_path, md_path = export_candidates(
        store=store,
        output_dir=args.output_dir,
        triage_signature=signatures.triage,
        incident_signature=signatures.incident,
        policy_signature=signatures.policy,
        event_match_signature=signatures.event_match,
        event_candidate_signature=signatures.event_candidate,
        event_ids=event_ids,
        policy_ids=policy_candidate_ids,
    )

    failed_tasks = (
        triage_stats.failed
        + (incident_stats.failed if incident_stats is not None else 0)
        + (policy_stats.failed if policy_stats is not None else 0)
        + (1 if match_stats is not None and match_stats.failed else 0)
        + event_stats.event_failed
    )
    degraded = bool(match_stats is not None and match_stats.degraded)
    usable_results = (
        event_stats.event_succeeded
        + event_stats.event_skipped_existing
        + policy_count
    )
    if failed_tasks or degraded:
        run_status = "PARTIAL" if usable_results or groups or policy_count else "FAILED"
    else:
        run_status = "SUCCESS"

    print(
        "mvp-run "
        f"status={run_status} articles={len(run_ids)} triage_processed={triage_stats.processed} "
        f"triage_reused={triage_stats.skipped_existing} "
        f"keep={triage_stats.keep} drop={triage_stats.drop} uncertain={triage_stats.uncertain} "
        f"triage_failed={triage_stats.failed} incident_selected={len(incident_ids)} "
        f"policy_selected={len(policy_ids)} event_groups={len(groups)} "
        f"event_candidates={event_stats.event_succeeded + event_stats.event_skipped_existing} "
        f"event_candidate_failed={event_stats.event_failed} policy_candidates={policy_count} "
        f"event_match_degraded={degraded}"
    )
    print(
        "signatures "
        f"triage={signatures.triage} incident={signatures.incident} policy={signatures.policy} "
        f"event_match={signatures.event_match} event_candidate={signatures.event_candidate}"
    )
    print(f"candidates_json={json_path}")
    print(f"candidates_md={md_path}")
    return json_path, md_path, signatures


def run_event_match(args):
    from .stages.event_match import PydanticAIEventMatchRuntime

    config = load_config(args.config)
    store = NewsAgentStore(args.news_db)
    triage_text = load_skill(args.triage_skill)
    incident_text = load_skill(args.incident_skill)
    event_text = load_skill(args.skill)
    triage_signature = args.triage_signature or build_identity(config, triage_text).analysis_signature
    incident_signature = build_extraction_identity(config, incident_text, stage="incident").analysis_signature
    runtime = PydanticAIEventMatchRuntime(config=config, skill_text=event_text)
    pipeline = EventMatchPipeline(config=config, store=store, runtime=runtime, skill_text=event_text)
    groups, stats = pipeline.run(
        triage_signature=triage_signature,
        incident_signature=incident_signature,
        only_ids=args.ids,
        force=args.force,
        verbose=args.verbose,
    )
    print(
        f"event-match incidents={stats.incident_count} groups={stats.group_count} "
        f"status={stats.status} reused={stats.reused} degraded={stats.degraded} "
        f"retried_failed_task={stats.retried_failed_task} task_id={stats.task_id} "
        f"signature={pipeline.identity.analysis_signature}"
    )
    return groups, pipeline.identity.analysis_signature, triage_signature, incident_signature


def run_compose(args):
    from .stages.candidate import PydanticAIEventCandidateRuntime
    from .stages.event_match import PydanticAIEventMatchRuntime

    config = load_config(args.config)
    store = NewsAgentStore(args.news_db)
    triage_text = load_skill(args.triage_skill)
    incident_text = load_skill(args.incident_skill)
    policy_text = load_skill(args.policy_skill)
    event_text = load_skill(args.event_match_skill)
    candidate_text = load_skill(args.candidate_skill)
    signatures = current_signatures(
        config=config,
        triage_skill=triage_text,
        incident_skill=incident_text,
        policy_skill=policy_text,
        event_match_skill=event_text,
        candidate_skill=candidate_text,
    )
    triage_signature = args.triage_signature or signatures.triage

    event_runtime = PydanticAIEventMatchRuntime(config=config, skill_text=event_text)
    event_pipeline = EventMatchPipeline(
        config=config, store=store, runtime=event_runtime, skill_text=event_text
    )
    groups, match_stats = event_pipeline.run(
        triage_signature=triage_signature,
        incident_signature=signatures.incident,
        only_ids=args.ids,
        force=args.force,
        verbose=args.verbose,
    )
    candidate_runtime = PydanticAIEventCandidateRuntime(config=config, skill_text=candidate_text)
    pipeline = CandidatePipeline(
        config=config, store=store, runtime=candidate_runtime, skill_text=candidate_text
    )
    stats = pipeline.compose_events(
        groups=groups,
        triage_signature=triage_signature,
        incident_signature=signatures.incident,
        event_match_signature=signatures.event_match,
        force=args.force,
        verbose=args.verbose,
    )
    policy_count = pipeline.compose_policies(
        triage_signature=triage_signature,
        policy_signature=signatures.policy,
        only_ids=args.ids,
    )
    json_path, md_path = export_candidates(
        store=store,
        output_dir=args.output_dir,
        triage_signature=triage_signature,
        incident_signature=signatures.incident,
        policy_signature=signatures.policy,
        event_match_signature=signatures.event_match,
        event_candidate_signature=signatures.event_candidate,
        event_ids=[g.event_id for g in groups] if args.ids else None,
        policy_ids=None,
    )
    print(
        f"compose status={'PARTIAL' if match_stats.degraded or stats.event_failed else 'SUCCESS'} "
        f"event_candidates={stats.event_succeeded + stats.event_skipped_existing} "
        f"event_failed={stats.event_failed} policy_candidates={policy_count}"
    )
    print(f"candidates_json={json_path}")
    print(f"candidates_md={md_path}")
    return json_path, md_path
