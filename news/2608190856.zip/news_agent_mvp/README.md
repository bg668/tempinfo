# News Agent MVP — End-to-End Candidate Flow

v0.3.1 在 v0.3.0 完整产品闭环基础上增加长任务可恢复能力：

```text
Collector SQLite
  -> Article Triage
  -> KEEP
      -> security_event -> incident-extract -> event-match -> candidate-compose
      -> compliance_policy -> policy-extract -> deterministic policy candidate
  -> newsagent.db
  -> output/mvp/candidates.json
  -> output/mvp/candidates.md
  -> 人工审核
```

## 设计边界

- Python 固定调度业务流程，模型不自主选择阶段。
- 每个 LLM 阶段的 `SKILL.md` 是提示词唯一事实源。
- Pydantic Model 是可执行数据契约；`schema.json` 由代码生成。
- LLM 输入/输出均为树状连续文本，JSON 只存在于程序内部和持久化层。
- Pydantic AI 使用 always-on `Capability + TextOutput + Pydantic validation + ModelRetry`。
- Collector 只读，News Agent 独立使用 `newsagent.db`。
- 不联网补证据；正文/上游 facts 没有的信息保持 `unknown / []`。
- 一次完整 MVP run 固定一个 Triage signature；下游不得静默回退到其他历史 Triage 版本。

## 阶段

### 1. Article Triage

`skills/article-triage/SKILL.md`

输出 KEEP / DROP / UNCERTAIN、route/category/content nature 和五项原始评分；总分由 Python 计算。

### 2. Incident Extract

`skills/incident-extract/SKILL.md`

`KEEP / security_event` 单篇文章转换为 `IncidentResult`：事件时间、主体、攻击路径/原因、受影响系统、影响、泄露范围、启示及 IOC。IOC 必须能在原文找到，数量由 Python 计算。

### 3. Policy Extract

`skills/policy-extract/SKILL.md`

`KEEP / compliance_policy` 转换为 `PolicyResult`：发布时间、发布机构、政策状态、生效时间、影响主体、主要要求、关键变化、合规影响和概述。

### 4. Event Match

`skills/event-match/SKILL.md`

只消费当前 Triage signature 下、当前 incident-extract signature 的结构化事实。保守判断哪些文章描述同一真实事件：

- 宁可重复，不错误合并；
- 每篇输入文章必须且只能属于一个 Event；
- 不重新筛选，不重新拆分一篇文章里的多个事件；
- Event ID 由 Python 根据成员文章 ID 确定性生成，不由 LLM 决定。

### 5. Candidate Compose

`skills/candidate-compose/SKILL.md`

对每个 Event 汇总多篇 `IncidentResult`，生成供人工审核的最终叙述字段。来源文章、来源 URL、Event ID、IOC 数量由 Python 确定性附加。

Policy Candidate 在 MVP 中不再额外调用 LLM：`PolicyResult` 已经包含人工审核所需字段，Python 直接映射成候选，减少重复工作和成本。

## 数据库

`newsagent.db` 自动创建；旧 DB 原地升级到 schema v5，不删除历史记录。

主要表：

```text
article_triage
article_incident_facts
article_policy_facts
event_match_runs
event_candidates
policy_candidates
llm_task_checkpoints
llm_task_attempts
```

LLM 阶段继续保存：模型/配置 signature、contract version、Skill hash + snapshot、实际 LLM 输入、最终 raw output、每次输出解析/重试、错误详情。


## v0.3.1 长任务恢复与 Event Match 降级

- Article Triage、Incident/Policy Extract、Event Candidate 都按原有任务粒度立即落库；再次运行会复用输入哈希未变化的 SUCCESS，FAILED 或输入变化的任务重新执行。
- Event Match 增加 `llm_task_checkpoints`：记录稳定 task_id、input_hash、SUCCESS/FAILED/STALE、任务执行次数、模型原始输出和诊断；`llm_task_attempts` 追加保存每次跨运行尝试，恢复成功后仍可追溯之前的失败输出。进程重启后，失败任务仍以相同输入重新执行。
- PydanticAI 自身的 output retry 仍用于同一次模型任务内修正结构；重试耗尽只把当前 Event Match task 标记 FAILED，不再让整个 MVP run 异常退出。
- Event Match 输出只要结构可解析，`missing / duplicate / unknown article_id` 由程序做 exact-cover 保守修复：未知 ID 删除，遗漏或冲突文章拆成 singleton，再次校验后继续。此类结果标记为 degraded/PARTIAL。
- 如果 Event Match 最终仍无法解析，当前运行按每篇文章 singleton 临时降级并继续 Candidate Compose；该 fallback 不写成 Event Match SUCCESS，因此下一次运行仍会重试原失败 task。
- Event Candidate 新增输入哈希校验；同一 event_id 的上游 Incident facts 变化时会重新生成，避免错误复用旧候选。

这次修复不引入新的聚类、日期分桶或语义候选组算法，Event Match 的业务语义仍与 v0.3.0 一致，只调整失败边界与恢复机制。

## 最推荐：一条命令跑完整 MVP

PowerShell：

```powershell
uv run --env-file .env news-agent mvp-run `
  --collector-db data/collector.db `
  --news-db data/newsagent.db `
  --output-dir output/mvp `
  --verbose
```

流程会：

1. 对本次 Collector 范围执行当前版本 Triage；
2. 固定本次 `triage_signature`；
3. 对当前 KEEP 分别执行 incident/policy extract；
4. 对 incident facts 执行 event-match；
5. 生成 Event Candidate，并直接生成 Policy Candidate；
6. 输出 `candidates.json` 与适合人工阅读的 `candidates.md`。

小范围验证可使用：

```powershell
--limit 20
```

或重复指定：

```powershell
--id <stable_article_id>
```

`--force` 会强制重跑已有成功结果。默认运行即具备 resume 语义：输入未变化的 SUCCESS 直接复用，FAILED 自动重试；输入变化后旧结果不再复用。

## 分阶段运行

### Triage

```powershell
uv run --env-file .env news-agent triage `
  --collector-db data/collector.db `
  --news-db data/newsagent.db
```

### Extract

```powershell
uv run --env-file .env news-agent extract `
  --collector-db data/collector.db `
  --news-db data/newsagent.db `
  --verbose
```

v0.3.0 起，未指定 `--triage-signature` 时，不再使用“每篇文章历史最新成功结果”，而是使用当前 `config + article-triage/SKILL.md` 对应的唯一 signature，避免一次任务混用多个 Triage 版本。

### Event Match

```powershell
uv run --env-file .env news-agent event-match `
  --news-db data/newsagent.db `
  --verbose
```

### Compose + Export

```powershell
uv run --env-file .env news-agent compose `
  --news-db data/newsagent.db `
  --output-dir output/mvp `
  --verbose
```

## 最终输出

`candidates.json` 包含 manifest、Event candidates、Policy candidates。manifest 明确记录：

```text
triage_signature
incident_signature
policy_signature
event_match_signature
event_candidate_signature
policy_compose_version
```

`candidates.md` 面向人工审核，安全事件至少展示：时间、标题、来源、概述、泄露范围、启示、受害主体、攻击主体、攻击路径/原因、受影响系统、影响和 IOC 数量；政策展示发布机构、状态、生效时间、影响主体、主要要求、变化、合规影响和概述。

## 调试

Triage：

```powershell
uv run news-agent debug-result --news-db data/newsagent.db --id <stable_id> --full
```

Incident / Policy：

```powershell
uv run news-agent debug-extraction --news-db data/newsagent.db --stage incident --id <stable_id> --full
```

Event Match：

```powershell
uv run news-agent debug-event-match --news-db data/newsagent.db --full
```

Event Candidate：

```powershell
uv run news-agent debug-candidate --news-db data/newsagent.db --event-id <event_id> --full
```

## 导出数据契约

```powershell
uv run news-agent export-schema --stage all
```

生成：

```text
skills/article-triage/schema.json
skills/incident-extract/schema.json
skills/policy-extract/schema.json
skills/event-match/schema.json
skills/candidate-compose/schema.json
```

## 当前明确不做

为了验证最小完整闭环，v0.3.0 暂不实现：

- 一篇文章拆分多个独立 Event；
- IOC defang/规范化去重；
- 向量数据库/知识图谱/复杂聚类；
- Web 搜索补证据或 IOC enrichment；
- 政策跨文章归并；
- UI / 自动发布 / 自动周报 / 趋势分析。

这些应根据真实 `candidates.md` 的人工审核结果再决定优先级。
