# v0.3.1 — Resumable Event Match

本版本仅修复长任务可靠性与结果复用，不改变 Event Match 的业务语义。

## 核心变化

- Event Match 增加稳定 task checkpoint：`SUCCESS / FAILED / STALE`、`input_hash`、任务尝试次数、诊断与 raw outputs。
- 增加 `llm_task_attempts`，跨运行保留失败/成功尝试历史；恢复成功后此前失败输出仍可审计。
- `exceeded maximum output retries` 不再向上终止整个 MVP：当前 Event Match 标记 FAILED，本轮使用 singleton 安全降级继续，下一次运行重试同一 task。
- structurally valid 的 Event Match 输出如出现 missing / duplicate / unknown article_id，由程序保守修复 exact-cover，不再浪费模型重试。
- Triage、Incident/Policy Extract、Event Candidate 的 SUCCESS 复用增加输入哈希校验；输入变化自动重算。
- Event Candidate 增加 `input_sha256`；schema 升级到 v5，旧 DB 原地迁移。
- `mvp-run` / `event-match` / `compose` 输出 `SUCCESS / PARTIAL / FAILED` 或 degraded 状态；`debug-event-match --full` 可查看 checkpoint 与跨运行 attempt 历史。

## 验证

- pytest：46 passed。
- `python -m compileall -q src tests`：通过。
- 当前离线沙箱未缓存 `pydantic-ai==2.17.0`，因此未执行真实 Provider/模型调用 smoke test。
