import sqlite3

from news_agent.collector_adapter import CollectorAdapter
from news_agent.config import AppConfig
from news_agent.contracts import IncidentResult, PolicyResult, TriageResult
from news_agent.extraction_pipeline import ExtractionPipeline
from news_agent.stages.base import IncidentExecution, PolicyExecution
from news_agent.store import NewsAgentStore, RunIdentity


def make_collector(path):
    conn = sqlite3.connect(path)
    conn.executescript(
        """
        CREATE TABLE feed_items(id INTEGER PRIMARY KEY, stable_id TEXT, url TEXT, fetch_status TEXT, published_at TEXT, discovered_at TEXT);
        CREATE TABLE article_contents(article_id INTEGER, title TEXT, account TEXT, published_at TEXT, content TEXT);
        INSERT INTO feed_items VALUES(1,'incident','https://x/i','FETCHED','2026-08-17','2026-08-17');
        INSERT INTO article_contents VALUES(1,'安全事件','账号','2026-08-17','受害者遭攻击，IOC为1.2.3.4。');
        INSERT INTO feed_items VALUES(2,'policy','https://x/p','FETCHED','2026-08-17','2026-08-17');
        INSERT INTO article_contents VALUES(2,'政策','账号','2026-08-17','监管机构发布规定。');
        """
    )
    conn.commit(); conn.close()


def triage_result(source_id, route):
    if route == "security_event":
        category, nature = "security_incident", "real_world_event"
    else:
        category, nature = "compliance_policy", "policy"
    return TriageResult.model_validate(
        {
            "source_article_id": source_id,
            "decision": "KEEP",
            "route": route,
            "category": category,
            "content_nature": nature,
            "scores": {"relevance":5,"impact":4,"freshness":4,"evidence_quality":4,"audience_value":4},
            "reason": "keep",
        }
    )


class FakeIncidentRuntime:
    def run(self, article):
        result = IncidentResult.model_validate(
            {
                "source_article_id": article.source_article_id,
                "event_time": "unknown",
                "title": "受害者遭攻击",
                "source_url": article.url,
                "summary": "受害者遭攻击。",
                "entities": {
                    "victim": {"value":"受害者","certainty":"confirmed"},
                    "attacker": {"value":"unknown","certainty":"unknown"},
                    "attack_vector_or_cause":"unknown",
                    "affected_system":"unknown",
                    "impact":"unknown",
                },
                "data_breach_scope":"unknown",
                "lesson":"unknown",
                "ioc":{"ips":["1.2.3.4"],"domains":[],"urls":[],"hashes":[],"file_paths":[]},
            }
        )
        return IncidentExecution(result, "rendered", "raw")


class FakePolicyRuntime:
    def run(self, article):
        result = PolicyResult.model_validate(
            {
                "source_article_id": article.source_article_id,
                "policy_time":"unknown",
                "title":"规定发布",
                "source_url":article.url,
                "issuer":"监管机构",
                "policy_name":"规定",
                "policy_status":"officially_issued",
                "effective_time":"unknown",
                "affected_entities":[],"requirements":[],"key_changes":[],
                "impact":"unknown","summary":"监管机构发布规定。",
            }
        )
        return PolicyExecution(result, "rendered", "raw")


def seed_triage(store, collector):
    ident = RunIdentity("triage-sig", "triage", "contract", "skill", "model", "skill")
    for source_id, route in [("incident","security_event"),("policy","compliance_policy")]:
        article = collector.get(source_id)
        store.save_success(
            identity=ident, article=article, input_sha256="x",
            result=triage_result(source_id, route), total_score=90.0,
            rendered_input="r", raw_output="o",
        )


def config():
    return AppConfig.model_validate(
        {"provider":{"base_url":"http://127.0.0.1:8000/v1"},"model":{"name":"test-model"}}
    )


def test_incident_and_policy_pipelines_route_from_triage(tmp_path):
    collector_db = tmp_path / "collector.db"
    make_collector(collector_db)
    collector = CollectorAdapter(collector_db)
    store = NewsAgentStore(tmp_path / "news.db")
    seed_triage(store, collector)

    incident = ExtractionPipeline(
        stage="incident", config=config(), collector=collector, store=store,
        runtime=FakeIncidentRuntime(), skill_text="incident skill",
    ).run()
    policy = ExtractionPipeline(
        stage="policy", config=config(), collector=collector, store=store,
        runtime=FakePolicyRuntime(), skill_text="policy skill",
    ).run()
    assert incident.eligible == incident.succeeded == 1
    assert policy.eligible == policy.succeeded == 1
    assert store.get_latest_fact("incident", "incident")["status"] == "SUCCESS"
    assert store.get_latest_fact("policy", "policy")["status"] == "SUCCESS"


def test_extraction_reprocesses_success_when_article_input_changes(tmp_path):
    collector_db = tmp_path / "collector.db"
    make_collector(collector_db)
    collector = CollectorAdapter(collector_db)
    store = NewsAgentStore(tmp_path / "news.db")
    seed_triage(store, collector)
    pipeline = ExtractionPipeline(
        stage="incident", config=config(), collector=collector, store=store,
        runtime=FakeIncidentRuntime(), skill_text="incident skill",
    )

    first = pipeline.run()
    second = pipeline.run()
    assert first.succeeded == 1
    assert second.skipped_existing == 1

    conn = sqlite3.connect(collector_db)
    conn.execute("UPDATE article_contents SET content='更新后的攻击正文。' WHERE article_id=1")
    conn.commit(); conn.close()

    changed = pipeline.run()
    assert changed.processed == 1
    assert changed.succeeded == 1
    assert changed.skipped_existing == 0
