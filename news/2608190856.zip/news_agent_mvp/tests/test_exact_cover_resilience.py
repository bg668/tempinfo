from news_agent.resilience.exact_cover import reconcile_exact_cover, validate_exact_cover


def test_valid_exact_cover_is_preserved():
    result = reconcile_exact_cover(["A", "B", "C"], [["A", "B"], ["C"]])
    assert result.groups == (("A", "B"), ("C",))
    assert not result.degraded
    assert result.issue_after.ok


def test_missing_becomes_singleton():
    result = reconcile_exact_cover(["A", "B", "C"], [["A", "B"]])
    assert result.groups == (("A", "B"), ("C",))
    assert result.issue_before.missing == ("C",)
    assert result.issue_after.ok


def test_duplicate_is_removed_from_ambiguous_groups_and_becomes_singleton():
    result = reconcile_exact_cover(["A", "B", "C", "D"], [["A", "B"], ["C", "D"], ["D"]])
    assert result.groups == (("A", "B"), ("C",), ("D",))
    assert result.issue_before.duplicate == ("D",)
    assert result.issue_after.ok


def test_unknown_is_dropped_without_affecting_valid_membership():
    result = reconcile_exact_cover(["A", "B"], [["A", "X"], ["B"]])
    assert result.groups == (("A",), ("B",))
    assert result.issue_before.unknown == ("X",)
    assert result.issue_after.ok


def test_mixed_defects_always_end_in_exact_cover():
    expected = ["A", "B", "C", "D", "E"]
    result = reconcile_exact_cover(expected, [["A", "B"], ["C", "D"], ["D", "X"]])
    assert validate_exact_cover(expected, result.groups).ok
    flat = [x for group in result.groups for x in group]
    assert sorted(flat) == sorted(expected)
