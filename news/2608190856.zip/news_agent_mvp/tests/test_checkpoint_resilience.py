from news_agent.resilience.checkpoint import CheckpointStore, TaskStatus, stable_input_hash


def test_success_is_reusable_only_when_hash_matches(tmp_path):
    store = CheckpointStore(tmp_path / "news.db")
    h1 = stable_input_hash({"articles": ["A"]})
    store.save_success(
        task_id="event_match:t1", stage="event_match", input_hash=h1,
        input_article_ids=["A"], result={"groups": [["A"]]}, attempts=1,
    )
    assert store.reusable("event_match:t1", h1) is not None
    assert store.reusable("event_match:t1", stable_input_hash({"articles": ["A", "B"]})) is None


def test_changed_input_marks_success_stale(tmp_path):
    store = CheckpointStore(tmp_path / "news.db")
    h1 = stable_input_hash({"articles": ["A"]})
    h2 = stable_input_hash({"articles": ["A", "B"]})
    store.save_success(
        task_id="event_match:t1", stage="event_match", input_hash=h1,
        input_article_ids=["A"], result={"groups": [["A"]]}, attempts=1,
    )
    assert store.prepare(task_id="event_match:t1", stage="event_match", input_hash=h2, input_article_ids=["A", "B"]) is None
    assert store.get("event_match:t1").status is TaskStatus.STALE


def test_failed_checkpoint_keeps_diagnostics(tmp_path):
    store = CheckpointStore(tmp_path / "news.db")
    store.save_failed(
        task_id="event_match:t2", stage="event_match", input_hash="h",
        input_article_ids=["A", "B"], attempts=3,
        error="exceeded maximum output retries",
        raw_outputs=["bad1", "bad2", "bad3"],
        diagnostics={"missing": ["B"]},
    )
    cp = store.get("event_match:t2")
    assert cp.status is TaskStatus.FAILED
    assert cp.attempts == 3
    assert cp.raw_outputs == ("bad1", "bad2", "bad3")
    assert cp.diagnostics["missing"] == ["B"]


def test_removed_task_from_current_plan_is_marked_stale(tmp_path):
    store = CheckpointStore(tmp_path / "news.db")
    store.save_success(
        task_id="event_match:old", stage="event_match", input_hash="h1",
        input_article_ids=["A", "B"], result={"groups": [["A", "B"]]}, attempts=1,
    )
    changed = store.mark_inactive_stage_tasks_stale("event_match", ["event_match:new"])
    assert changed == ("event_match:old",)
    cp = store.get("event_match:old")
    assert cp.status is TaskStatus.STALE
    assert cp.diagnostics["stale_reason"] == "task_not_in_current_plan"
