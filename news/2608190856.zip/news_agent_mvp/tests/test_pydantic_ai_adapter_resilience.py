from news_agent.resilience.errors import TaskExecutionError
from news_agent.resilience.pydantic_ai_adapter import (
    OutputAttemptCollector,
    as_task_failure,
    as_task_success,
    validate_and_reconcile_groups,
)


def test_attempt_collector_preserves_failed_outputs_and_validation_errors():
    collector = OutputAttemptCollector()
    collector.record("bad-1", "missing B")
    collector.record("bad-2", "duplicate A")
    err = as_task_failure(RuntimeError("exceeded maximum output retries"), collector=collector)
    assert isinstance(err, TaskExecutionError)
    assert err.raw_outputs == ("bad-1", "bad-2")
    assert err.diagnostics["model_output_attempts"] == 2
    assert len(err.diagnostics["validation_errors"]) == 2


def test_reconcile_diagnostics_are_preserved_on_success():
    collector = OutputAttemptCollector(["parseable-output"], [])
    validated = validate_and_reconcile_groups(
        expected_article_ids=["A", "B", "C"],
        model_groups=[["A", "B"]],
        build_domain_result=lambda groups: {"groups": [list(g) for g in groups]},
    )
    success = as_task_success(
        result=validated.domain_result,
        collector=collector,
        reconcile=validated.reconcile,
    )
    assert success.result == {"groups": [["A", "B"], ["C"]]}
    assert success.diagnostics["degraded"] is True
    assert success.diagnostics["missing"] == ["C"]
