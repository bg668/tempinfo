from dataclasses import dataclass

from news_agent.resilience.checkpoint import CheckpointStore, TaskStatus, stable_task_id
from news_agent.resilience.runner import TaskExecutionResult, run_resumable_tasks


@dataclass(frozen=True)
class Task:
    article_ids: tuple[str, ...]
    version: int = 1


def payload(task):
    return {"article_ids": task.article_ids, "version": task.version}


def test_failure_is_isolated_and_resume_retries_only_failed_task(tmp_path):
    store = CheckpointStore(tmp_path / "news.db")
    calls = []
    fail_once = {("C", "D")}

    def execute(task):
        calls.append(task.article_ids)
        if task.article_ids in fail_once:
            fail_once.remove(task.article_ids)
            raise RuntimeError("exceeded maximum output retries")
        return TaskExecutionResult({"groups": [list(task.article_ids)]})

    tasks = [Task(("A", "B")), Task(("C", "D")), Task(("E",))]
    first = run_resumable_tasks(stage="event_match", tasks=tasks, store=store, input_payload=payload, execute=execute)
    assert first.status == "PARTIAL"
    assert calls == [("A", "B"), ("C", "D"), ("E",)]

    calls.clear()
    second = run_resumable_tasks(stage="event_match", tasks=tasks, store=store, input_payload=payload, execute=execute)
    assert second.status == "SUCCESS"
    assert calls == [("C", "D")]  # successful tasks were reused
    assert len(second.reused_task_ids) == 2
    assert len(second.succeeded_task_ids) == 1


def test_changed_input_is_stale_and_recomputed(tmp_path):
    store = CheckpointStore(tmp_path / "news.db")
    calls = []

    def execute(task):
        calls.append(task.version)
        return TaskExecutionResult({"version": task.version})

    run_resumable_tasks(
        stage="article_analysis", tasks=[Task(("A",), 1)], store=store,
        input_payload=payload, execute=execute,
    )
    run_resumable_tasks(
        stage="article_analysis", tasks=[Task(("A",), 2)], store=store,
        input_payload=payload, execute=execute,
    )
    assert calls == [1, 2]
    task_id = stable_task_id("article_analysis", ["A"])
    cp = store.get(task_id)
    assert cp.status is TaskStatus.SUCCESS
    assert cp.result == {"version": 2}


def test_candidate_group_membership_change_marks_old_group_stale(tmp_path):
    store = CheckpointStore(tmp_path / "news.db")

    def execute(task):
        return TaskExecutionResult({"ids": list(task.article_ids)})

    first_task = Task(("A", "B"), 1)
    run_resumable_tasks(
        stage="event_match", tasks=[first_task], store=store,
        input_payload=payload, execute=execute,
    )
    old_id = stable_task_id("event_match", ["A", "B"])
    assert store.get(old_id).status is TaskStatus.SUCCESS

    run_resumable_tasks(
        stage="event_match", tasks=[Task(("A", "B", "C"), 1)], store=store,
        input_payload=payload, execute=execute,
    )
    assert store.get(old_id).status is TaskStatus.STALE
    assert store.get(old_id).diagnostics["stale_reason"] == "task_not_in_current_plan"
