import json
import sqlite3

from news_agent.contracts import CollectorArticle, IncidentResult, PolicyResult
from news_agent.store import NewsAgentStore, RunIdentity


def _article():
    return CollectorArticle(
        source_article_id="sid",
        title="source title",
        account="a",
        url="https://example.test/a",
        content="事件包含 1.2.3.4 和 bad.example。",
    )


def _identity(sig="extract-sig"):
    return RunIdentity(sig, "stage", "contract", "skillhash", "model", "skill body")


def test_store_incident_success_and_counts(tmp_path):
    store = NewsAgentStore(tmp_path / "news.db")
    result = IncidentResult.model_validate(
        {
            "source_article_id": "sid",
            "event_time": "2026-08-17",
            "title": "事件",
            "source_url": "https://example.test/a",
            "summary": "摘要",
            "entities": {
                "victim": {"value": "受害者", "certainty": "confirmed"},
                "attacker": {"value": "unknown", "certainty": "unknown"},
                "attack_vector_or_cause": "unknown",
                "affected_system": "系统",
                "impact": "影响",
            },
            "data_breach_scope": "unknown",
            "lesson": "启示",
            "ioc": {
                "ips": ["1.2.3.4"],
                "domains": ["bad.example"],
                "urls": [],
                "hashes": [],
                "file_paths": [],
            },
        }
    )
    store.save_incident_success(
        identity=_identity(),
        upstream_triage_signature="triage-sig",
        article=_article(),
        input_sha256="input",
        result=result,
        rendered_input="rendered",
        raw_output="raw",
    )
    row = store.get_latest_fact("incident", "sid")
    assert row["ip_count"] == 1 and row["domain_count"] == 1
    assert json.loads(row["result_json"])["title"] == "事件"
    assert store.extraction_success_exists(
        stage="incident",
        source_article_id="sid",
        upstream_triage_signature="triage-sig",
        analysis_signature="extract-sig",
    )


def test_store_policy_success(tmp_path):
    store = NewsAgentStore(tmp_path / "news.db")
    result = PolicyResult.model_validate(
        {
            "source_article_id": "sid",
            "policy_time": "2026-08-17",
            "title": "政策",
            "source_url": "https://example.test/a",
            "issuer": "监管机构",
            "policy_name": "规定",
            "policy_status": "officially_issued",
            "effective_time": "unknown",
            "affected_entities": ["相关单位"],
            "requirements": ["落实安全义务"],
            "key_changes": [],
            "impact": "提出合规要求",
            "summary": "政策摘要",
        }
    )
    store.save_policy_success(
        identity=_identity("policy-sig"),
        upstream_triage_signature="triage-sig",
        article=_article(),
        input_sha256="input",
        result=result,
        rendered_input="rendered",
        raw_output="raw",
    )
    row = store.get_latest_fact("policy", "sid")
    assert row["issuer"] == "监管机构"
    assert json.loads(row["requirements_json"]) == ["落实安全义务"]


def test_schema_v3_creates_fact_tables(tmp_path):
    db = tmp_path / "news.db"
    NewsAgentStore(db)
    conn = sqlite3.connect(db)
    tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    version = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0]
    conn.close()
    assert {
        "article_incident_facts",
        "article_policy_facts",
        "llm_task_checkpoints",
        "llm_task_attempts",
    } <= tables
    assert version == "5"


def test_store_extraction_failures_persist(tmp_path):
    store = NewsAgentStore(tmp_path / "news.db")
    article = _article()
    err = ValueError("bad output")
    store.save_incident_failure(
        identity=_identity("incident-fail"),
        upstream_triage_signature="triage-sig",
        article=article,
        input_sha256="input",
        rendered_input="rendered",
        raw_output="bad",
        output_attempts=({"attempt": 1, "status": "INVALID"},),
        error=err,
    )
    store.save_policy_failure(
        identity=_identity("policy-fail"),
        upstream_triage_signature="triage-sig",
        article=article,
        input_sha256="input",
        rendered_input="rendered",
        raw_output="bad",
        output_attempts=({"attempt": 1, "status": "INVALID"},),
        error=err,
    )
    incident = store.get_latest_fact("incident", "sid")
    policy = store.get_latest_fact("policy", "sid")
    assert incident["status"] == "FAILED" and incident["error_type"] == "ValueError"
    assert policy["status"] == "FAILED" and policy["error_type"] == "ValueError"
