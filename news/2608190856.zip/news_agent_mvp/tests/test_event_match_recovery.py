from news_agent.config import AppConfig
from news_agent.contracts import EventMatchResult, IncidentResult
from news_agent.event_pipeline import EventMatchPipeline
from news_agent.resilience import CheckpointStore, TaskStatus
from news_agent.stages.base import EventMatchExecution, EventMatchExecutionError
from news_agent.resilience import reconcile_event_match_result
from news_agent.store import NewsAgentStore, RunIdentity


def config():
    return AppConfig.model_validate(
        {"provider": {"base_url": "http://127.0.0.1:8000/v1"}, "model": {"name": "test"}}
    )


def incident(source_id: str, title: str) -> IncidentResult:
    return IncidentResult.model_validate(
        {
            "source_article_id": source_id,
            "event_time": "2026-08-17",
            "title": title,
            "source_url": f"https://x/{source_id}",
            "summary": title,
            "entities": {
                "victim": {"value": "Victim", "certainty": "reported"},
                "attacker": {"value": "unknown", "certainty": "unknown"},
                "attack_vector_or_cause": "vector",
                "affected_system": "system",
                "impact": "impact",
            },
            "data_breach_scope": "unknown",
            "lesson": "lesson",
            "ioc": {"ips": [], "domains": [], "urls": [], "hashes": [], "file_paths": []},
        }
    )


def seed_fact(store: NewsAgentStore, result: IncidentResult):
    from news_agent.contracts import CollectorArticle

    article = CollectorArticle(
        source_article_id=result.source_article_id,
        title=result.title,
        account="a",
        url=result.source_url,
        content="x",
    )
    store.save_incident_success(
        identity=RunIdentity("incident", "stage", "contract", "skill", "model", "skill"),
        upstream_triage_signature="triage",
        article=article,
        input_sha256="input",
        result=result,
        rendered_input="rendered",
        raw_output="raw",
    )


def test_exact_cover_defects_are_repaired_conservatively():
    incidents = [incident("a", "A"), incident("b", "B"), incident("c", "C"), incident("d", "D")]
    raw = EventMatchResult.model_validate(
        {
            "groups": {
                "g1": {
                    "canonical_title": "maybe one",
                    "member_article_ids": ["a", "b"],
                    "match_reason": "model says same",
                },
                "g2": {
                    "canonical_title": "maybe two",
                    "member_article_ids": ["b", "unknown-id"],
                    "match_reason": "conflicting assignment",
                },
            }
        }
    )

    repaired, diagnostics = reconcile_event_match_result(incidents, raw)
    memberships = [member for group in repaired.groups.values() for member in group.member_article_ids]

    assert sorted(memberships) == ["a", "b", "c", "d"]
    assert len(memberships) == len(set(memberships))
    assert diagnostics["degraded"] is True
    assert diagnostics["missing"] == ["c", "d"]
    assert diagnostics["duplicate"] == ["b"]
    assert diagnostics["unknown"] == ["unknown-id"]
    singleton_ids = {
        group.member_article_ids[0]
        for group in repaired.groups.values()
        if len(group.member_article_ids) == 1
    }
    assert {"b", "c", "d"} <= singleton_ids


class FailThenSucceedRuntime:
    def __init__(self):
        self.calls = 0

    def run(self, data):
        self.calls += 1
        if self.calls == 1:
            raise EventMatchExecutionError(
                cause=RuntimeError("exceeded maximum output retries"),
                rendered_input="same-task-input",
                raw_output="bad-output-3",
                output_attempts=(
                    {"attempt": 1, "status": "INVALID", "raw_text": "bad-output-1"},
                    {"attempt": 2, "status": "INVALID", "raw_text": "bad-output-2"},
                    {"attempt": 3, "status": "INVALID", "raw_text": "bad-output-3"},
                ),
                diagnostics={"model_output_attempts": 3},
            )
        ids = [item.source_article_id for item in data.incidents]
        result = EventMatchResult.model_validate(
            {
                "groups": {
                    "g1": {
                        "canonical_title": "同一事件",
                        "member_article_ids": ids,
                        "match_reason": "核心事实一致",
                    }
                }
            }
        )
        return EventMatchExecution(
            result=result,
            rendered_input="same-task-input",
            raw_output="good-output",
            output_attempts=({"attempt": 1, "status": "VALID", "raw_text": "good-output"},),
            diagnostics={"degraded": False, "model_output_attempts": 1},
        )


def test_failed_event_match_isolated_and_next_run_retries_same_task(tmp_path):
    store = NewsAgentStore(tmp_path / "news.db")
    seed_fact(store, incident("a", "A"))
    seed_fact(store, incident("b", "B"))
    runtime = FailThenSucceedRuntime()
    pipeline = EventMatchPipeline(
        config=config(), store=store, runtime=runtime, skill_text="match skill"
    )

    fallback_groups, first = pipeline.run(
        triage_signature="triage", incident_signature="incident"
    )
    assert first.status == "PARTIAL"
    assert first.failed is True
    assert first.fallback_singletons == 2
    assert len(fallback_groups) == 2
    assert runtime.calls == 1

    checkpoints = CheckpointStore(store.db_path)
    failed = checkpoints.get(first.task_id)
    assert failed is not None
    assert failed.status is TaskStatus.FAILED
    assert failed.attempts == 1
    assert failed.raw_outputs == ("bad-output-1", "bad-output-2", "bad-output-3")

    groups, second = pipeline.run(triage_signature="triage", incident_signature="incident")
    assert second.status == "SUCCESS"
    assert second.retried_failed_task is True
    assert second.task_id == first.task_id
    assert len(groups) == 1
    assert set(groups[0].member_article_ids) == {"a", "b"}
    assert runtime.calls == 2

    success = checkpoints.get(second.task_id)
    assert success is not None
    assert success.status is TaskStatus.SUCCESS
    assert success.attempts == 2
    history = checkpoints.list_attempts(second.task_id)
    assert [item.status for item in history] == ["FAILED", "SUCCESS"]
    assert history[0].raw_outputs == ("bad-output-1", "bad-output-2", "bad-output-3")
    assert history[0].error_message is not None

    _, third = pipeline.run(triage_signature="triage", incident_signature="incident")
    assert third.reused is True
    assert runtime.calls == 2


class CountingRuntime:
    def __init__(self):
        self.calls = 0

    def run(self, data):
        self.calls += 1
        ids = [item.source_article_id for item in data.incidents]
        return EventMatchExecution(
            result=EventMatchResult.model_validate(
                {
                    "groups": {
                        "g1": {
                            "canonical_title": "group",
                            "member_article_ids": ids,
                            "match_reason": "same for test",
                        }
                    }
                }
            ),
            rendered_input="r",
            raw_output="o",
            diagnostics={"degraded": False},
        )


def test_event_match_input_change_reexecutes_same_logical_task(tmp_path):
    store = NewsAgentStore(tmp_path / "news.db")
    seed_fact(store, incident("a", "A"))
    runtime = CountingRuntime()
    pipeline = EventMatchPipeline(
        config=config(), store=store, runtime=runtime, skill_text="match skill"
    )

    _, first = pipeline.run(triage_signature="triage", incident_signature="incident")
    assert runtime.calls == 1

    seed_fact(store, incident("b", "B"))
    _, second = pipeline.run(triage_signature="triage", incident_signature="incident")
    assert runtime.calls == 2
    assert second.task_id == first.task_id
    assert second.reused is False


def test_event_candidate_recomputed_when_incident_input_changes(tmp_path):
    from news_agent.contracts import EventCandidateDraft
    from news_agent.event_pipeline import CandidatePipeline, MatchedEventGroup
    from news_agent.stages.base import EventCandidateExecution

    class CandidateRuntime:
        def __init__(self):
            self.calls = 0

        def run(self, data):
            self.calls += 1
            return EventCandidateExecution(
                EventCandidateDraft.model_validate(
                    {
                        "event_time": "2026-08-17",
                        "title": f"candidate-{self.calls}",
                        "summary": "summary",
                        "victim": "Victim",
                        "attacker": "unknown",
                        "attack_vector_or_cause": "vector",
                        "affected_system": "system",
                        "impact": "impact",
                        "data_breach_scope": "unknown",
                        "lesson": "lesson",
                    }
                ),
                "rendered",
                "raw",
            )

    store = NewsAgentStore(tmp_path / "news.db")
    seed_fact(store, incident("a", "A-v1"))
    group = MatchedEventGroup(
        event_id="event-a",
        canonical_title="A",
        match_reason="single",
        member_article_ids=("a",),
    )
    runtime = CandidateRuntime()
    pipeline = CandidatePipeline(
        config=config(), store=store, runtime=runtime, skill_text="candidate skill"
    )

    first = pipeline.compose_events(
        groups=[group],
        triage_signature="triage",
        incident_signature="incident",
        event_match_signature="match",
    )
    assert first.event_succeeded == 1
    assert runtime.calls == 1

    second = pipeline.compose_events(
        groups=[group],
        triage_signature="triage",
        incident_signature="incident",
        event_match_signature="match",
    )
    assert second.event_skipped_existing == 1
    assert runtime.calls == 1

    seed_fact(store, incident("a", "A-v2"))
    third = pipeline.compose_events(
        groups=[group],
        triage_signature="triage",
        incident_signature="incident",
        event_match_signature="match",
    )
    assert third.event_succeeded == 1
    assert runtime.calls == 2
